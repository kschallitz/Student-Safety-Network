"""Learn anonymous candidate values; select a permanent design on pre data only."""
import json,time
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np,pandas as pd,torch
from torch import nn
from mitigation_rl.learn import features,key,values
from .config import ROOT,DATA,OUT,ACTIONS,CHECKPOINTS,REWARD_SCALE,sha,reward

def scored(split):
    d=pd.read_csv(OUT/f'{split}_runs.csv')
    ids=set(pd.read_csv(DATA/'contexts.csv').query('split==@split').context_id)
    assert set(d.context_id)==ids
    assert not d.duplicated(['profile','context_id','action','seed']).any()
    assert d.groupby(['profile','context_id','action']).size().eq(30).all()
    assert d.groupby(['profile','context_id','seed']).traveler_sha256.nunique().eq(1).all()
    d['score']=[reward(c,n) if ok else np.nan for c,n,ok in zip(d.collision_pairs,d.near_pairs,d.complete)]
    return d

def batches(d):
    b=d.groupby(['profile','context_id','action']).agg(score=('score',lambda s:s.sum(min_count=30)),complete=('complete','all'),delay=('mean_motor_delay','mean'),collisions=('collision_pairs','sum'),near_misses=('near_pairs','sum'),repeats=('seed','size')).reset_index()
    base=b[b.action.eq('C01')][['profile','context_id','score','delay','complete']].rename(columns={'score':'base_score','delay':'base_delay','complete':'base_complete'})
    return b.merge(base,on=['profile','context_id'],validate='many_to_one')

def fixed_performance(action,b):
    z=b[b.action.eq(action)]
    valid=bool(len(z) and z.complete.all() and z.base_complete.all())
    return {'total_score':float(z.score.sum()) if valid else None,'eligible':valid and float((z.delay-z.base_delay).mean())<=30,
            'delay_increase_s':float((z.delay-z.base_delay).mean()),'collisions':int(z.collisions.sum()),'near_misses':int(z.near_misses.sum())}

def train(task):
    family,seed=task;name=f'{family}_{seed}';start=time.monotonic()
    c=pd.read_csv(DATA/'contexts.csv');c=c[c.split.eq('train')].reset_index(drop=True)
    tr=batches(scored('train'));va=batches(scored('validation'));assert tr.complete.all() and va.complete.all()
    matrix=tr.pivot(index='context_id',columns='action',values='score').loc[c.context_id,ACTIONS].to_numpy()
    rewards=matrix/REWARD_SCALE;k=len(ACTIONS)
    rng=np.random.default_rng(seed);torch.set_num_threads(1);torch.manual_seed(seed)
    mu=features(c).mean(0);sd=features(c).std(0);sd[sd<1e-6]=1;x=(features(c)-mu)/sd
    keys=[key(row) for row in c.to_dict('records')];table={q:np.zeros(k) for q in keys};counts={q:np.zeros(k) for q in keys}
    fallback=np.zeros(k);visits=np.zeros(k)
    net=nn.Linear(7,k) if family=='linear' else nn.Sequential(nn.Linear(7,32),nn.Tanh(),nn.Linear(32,32),nn.Tanh(),nn.Linear(32,k))
    opt=torch.optim.Adam(net.parameters(),lr=.001);records=[];models={}
    allowed=np.array([fixed_performance(a,tr)['eligible'] for a in ACTIONS]);assert allowed.any()
    for step in range(300000):
        i=int(rng.integers(len(c)));xx=x[i];epsilon=max(.1,1-step/30000)
        if family=='tabular':q=table[keys[i]]
        else:
            with torch.no_grad():q=net(torch.tensor(xx,dtype=torch.float32)).numpy()
        a=int(rng.integers(k)) if rng.random()<epsilon else int(np.argmax(np.where(allowed,q,-np.inf)))
        r=float(rewards[i,a]);visits[a]+=1;fallback[a]+=(r-fallback[a])/visits[a]
        if family=='tabular':
            counts[keys[i]][a]+=1;table[keys[i]][a]+=(r-q[a])/counts[keys[i]][a]
        else:
            if step in [30000,100000]:
                for group in opt.param_groups:group['lr']=.0001 if step==30000 else .00003
            pred=net(torch.tensor(xx,dtype=torch.float32))[a];loss=(pred-r)**2
            opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),10);opt.step()
        if (step+1)%10000==0:(OUT/f'{name}_progress.json').write_text(json.dumps({'updates':step+1,'seconds':time.monotonic()-start}))
        if step+1 not in CHECKPOINTS:continue
        model={'family':family,'seed':seed,'mean':mu.tolist(),'std':sd.tolist(),'actions':ACTIONS,'steps':step+1,'q_units':'points per 30-repeat batch'}
        if family=='tabular':model.update(table={q:(v*REWARD_SCALE).tolist() for q,v in table.items()},fallback=(fallback*REWARD_SCALE).tolist())
        elif family=='linear':model['weights']=np.vstack([net.weight.detach().numpy().T,net.bias.detach().numpy()]).astype(float).__mul__(REWARD_SCALE).tolist()
        else:
            model['layers']=[{'weight':layer.weight.detach().numpy().tolist(),'bias':layer.bias.detach().numpy().tolist(),'activation':'linear' if j==4 else 'tanh'} for j,layer in enumerate(net) if isinstance(layer,nn.Linear)]
            model['layers'][-1]['weight']=(np.array(model['layers'][-1]['weight'])*REWARD_SCALE).tolist();model['layers'][-1]['bias']=(np.array(model['layers'][-1]['bias'])*REWARD_SCALE).tolist()
        pred=values(model,c);averages=pred.mean(0);chosen=ACTIONS[int(np.argmax(np.where(allowed,averages,-np.inf)))]
        model.update(fixed_action=chosen,training_context_mean_q=averages.tolist())
        record={'agent':name,'family':family,'seed':seed,'updates':step+1,'action':chosen,'q_rmse_points':float(np.sqrt(np.mean((pred-matrix)**2))),
                'train_total_score':fixed_performance(chosen,tr)['total_score'],'training_regret_to_best_fixed':float(matrix.sum(0).max()-fixed_performance(chosen,tr)['total_score']),
                **{'validation_'+q:v for q,v in fixed_performance(chosen,va).items()},'action_update_counts':visits.astype(int).tolist()}
        models[str(step+1)]=model;records.append(record)
        (OUT/f'{name}_checkpoints.json').write_text(json.dumps({'models':models,'records':records},indent=2))
        print(f'{name}: {step+1:,} updates; anonymous choice {chosen}; validation {record["validation_total_score"]}',flush=True)
    return name,models,records

def main():
    allmodels={};records=[]
    with ProcessPoolExecutor(max_workers=3) as pool:
        for f in as_completed([pool.submit(train,(family,seed)) for family in ['tabular','linear','neural'] for seed in [41,73,109]]):
            name,m,r=f.result();allmodels[name]=m;records+=r
    pd.DataFrame(records).to_csv(OUT/'learning_checkpoints.csv',index=False)
    rank=lambda r:(not r['validation_eligible'],-r['validation_total_score'] if r['validation_total_score'] is not None else float('inf'),r['updates'],r['agent'])
    selected={name:min([r for r in records if r['agent']==name and r['updates']==300000],key=rank) for name in allmodels}
    ordered=sorted(selected.values(),key=rank);champion=ordered[0]['agent']
    models={name:allmodels[name][str(r['updates'])] for name,r in selected.items()}
    (OUT/'models.json').write_text(json.dumps(models,indent=2));pd.DataFrame(selected.values()).to_csv(OUT/'validation_agents.csv',index=False)
    freeze={'frozen_at_unix':time.time(),'champion':champion,'agents':{n:{'action':r['action'],'checkpoint':r['updates']} for n,r in selected.items()},
            'representatives':{f:next(r['agent'] for r in ordered if r['family']==f) for f in ['tabular','linear','neural']},
            'total_updates':2700000,'updates_per_agent':300000,'fresh_sumo_runs_during_learning':0,'training_actions':ACTIONS,
            'consultant_identity_supplied_to_learner':False,'test_outcomes_in_training':False,'fixed_design':True,
            'models_sha256':sha(OUT/'models.json'),'train_sha256':sha(OUT/'train_runs.csv'),'validation_sha256':sha(OUT/'validation_runs.csv'),
            'protocol_sha256':sha(ROOT/'mitigation_design/protocol.md'),'trainer_sha256':sha(__file__),'contexts_sha256':sha(DATA/'contexts.csv'),'observations_sha256':sha(DATA/'observations.csv'),'candidate_catalog_sha256':sha(DATA/'candidates.json')}
    (OUT/'policy_freeze.json').write_text(json.dumps(freeze,indent=2));print(json.dumps(freeze,indent=2))

if __name__=='__main__':main()
