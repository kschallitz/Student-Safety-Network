"""Anonymous, source-backed mitigation candidates and fixed-layout RL selection."""
