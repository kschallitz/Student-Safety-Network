/* Exact exported value inference; one permanent design over training contexts. */
(function(root){
 const actions=Array.from({length:8},(_,i)=>'C'+String(i+1).padStart(2,'0'));
 function features(c){const motor=c.passenger+c.heavy;return [Math.log1p(motor),Math.log1p(c.pedestrian),Math.log1p(c.bicycle),Math.sin(c.hour/24*2*Math.PI),Math.cos(c.hour/24*2*Math.PI),c.weekend,c.heavy/Math.max(motor,1)];}
 function key(c){const bin=(x,edges)=>edges.filter(v=>x>=v).length;return `${Math.floor(c.hour/3)}_${bin(c.pedestrian,[1,5,15,40])}_${bin(c.passenger+c.heavy,[150,250,400])}`;}
 function values(m,c){let x=features(c).map((v,i)=>(v-m.mean[i])/m.std[i]);if(m.family==='tabular')return m.table[key(c)]||m.fallback;
  if(m.family==='linear'){x.push(1);return actions.map((_,a)=>x.reduce((s,v,i)=>s+v*m.weights[i][a],0));}
  for(const l of m.layers)x=l.weight.map((w,j)=>{const z=w.reduce((s,v,i)=>s+v*x[i],l.bias[j]);return l.activation==='tanh'?Math.tanh(z):z;});return x;}
 function recommend(m,contexts,allowed){const mean=actions.map(()=>0);for(const c of contexts)values(m,c).forEach((v,i)=>mean[i]+=v/contexts.length);const q=mean.map((v,i)=>allowed.includes(actions[i])?v:-Infinity);return {action:actions[q.indexOf(Math.max(...q))],mean};}
 const api={actions,features,key,values,recommend};root.DesignPolicy=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
