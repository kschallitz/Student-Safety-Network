"""Editable plotting code: always rebuild figures from the current results."""
import json
import numpy as np,pandas as pd
from .config import OUT

def main():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    r=json.loads((OUT/'results.json').read_text());f=r['freeze'];d=pd.DataFrame(r['policies']).set_index('policy')
    names=list(dict.fromkeys(list(f['representatives'].values())+r['descriptive_best_test_agents']+['unchanged','consultant']));z=d.loc[names]
    labels=[(n.replace('_',' · ') if n in f['agents'] else n.title())+' → '+d.loc[n,'action'] for n in names]
    fig,ax=plt.subplots(figsize=(10,4.5),layout='constrained');y=np.arange(len(z))
    ax.axvline(0,color='#afc1c7',lw=1)
    ax.errorbar(z.mean_gain_vs_consultant,y,xerr=[z.mean_gain_vs_consultant-z.consultant_gain_low,z.consultant_gain_high-z.mean_gain_vs_consultant],fmt='o',color='#087b81',capsize=4)
    ax.set_yticks(y,labels);ax.invert_yaxis();ax.grid(axis='x',alpha=.15)
    ax.set_xlabel('Mean score gain over consultant design per 30-repeat batch\nPositive = better; 95% paired intervals across 32 observed traffic windows')
    ax.set_title('Fresh-seed testing after all designs were frozen',loc='left',fontsize=12)
    fig.savefig(OUT/'comparison.png',dpi=160);plt.close(fig)
    h=pd.read_csv(OUT/'learning_checkpoints.csv');fig,axes=plt.subplots(1,2,figsize=(10,4.2),layout='constrained')
    for family,color,style in [('tabular','#26798b','o-'),('linear','#b56c22','s--'),('neural','#7453a2','^:')]:
        g=h[h.family.eq(family)].groupby('updates').mean(numeric_only=True)
        axes[0].plot(g.index,g.q_rmse_points,style,label=family,color=color)
        axes[1].plot(g.index,g.training_regret_to_best_fixed,style,label=family,color=color)
    for ax in axes:ax.set_xscale('log');ax.set_xticks([6000,30000,100000,300000],['6k','30k','100k','300k']);ax.minorticks_off();ax.set_xlabel('Selected-action learning updates per agent');ax.grid(alpha=.15)
    axes[0].set_ylabel('Value prediction RMSE (30-repeat score points)');axes[1].set_ylabel('Training-score loss vs best available fixed design')
    axes[0].legend();fig.suptitle('Learning progress · mean of three learner seeds',x=.01,ha='left')
    fig.savefig(OUT/'learning.png',dpi=160);plt.close(fig)
    s=pd.DataFrame(r['sensitivity']);fig,ax=plt.subplots(figsize=(10,4.2),layout='constrained')
    ps=['nominal_subset','cautious','tighter_gaps','half_speed_response']
    for name,color,style in [('consultant','#785da5','s--'),('unchanged','#a36f30','^:'),(f['champion'],'#087b81','o-')]:
        z=s[s.policy.eq(name)].set_index('profile').loc[ps]
        ax.plot(range(4),z.total_score/8,style,label=name,color=color,markerfacecolor='white',markersize=7)
    ax.set_xticks(range(4),['Nominal subset','Cautious','Tighter gaps','Half speed response'])
    ax.set_ylabel('Mean score per 30-repeat batch (higher is better)');ax.legend();ax.grid(alpha=.15)
    ax.set_title('Same eight traffic windows · fixed agents and matched travelers',loc='left',fontsize=12)
    fig.savefig(OUT/'sensitivity.png',dpi=160);plt.close(fig)
if __name__=='__main__':main()
