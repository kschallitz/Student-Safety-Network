from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data/mitigation_design';OUT=ROOT/'outputs/mitigation_design'
ACTIONS=[f'C{i:02}' for i in range(1,9)]
VALIDATION=['20230302T080000','20230302T084500','20230302T144500','20230302T154500']
VALIDATION_SEEDS=list(range(1100000,1100030))
TEST_SEEDS=list(range(1200000,1200030))
CHECKPOINTS=[6000,30000,100000,300000]
REWARD_SCALE=1000.
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def reward(c,n):return -100*int(c)-5*int(n)
