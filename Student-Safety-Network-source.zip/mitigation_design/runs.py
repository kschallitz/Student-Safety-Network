import json,time,argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
import pandas as pd
from mitigation_rl.simulator import run as retained_run
from mitigation_batch.config import SEEDS as RETAINED_SEEDS,PROFILES,SENSITIVITY_CONTEXTS
from .config import ROOT,DATA,OUT,ACTIONS,VALIDATION_SEEDS,TEST_SEEDS

# Physics reuse only. The learner never imports this mapping or benchmark key.
REUSE={'C01':'A0','C02':'A1','C03':'A2','C04':'A3','C07':'H'}

def run(task):
    ctx,action,seed,profile=task
    if ctx.startswith('202305'):
        assert (OUT/'policy_freeze.json').exists(),'Freeze before test outcomes'
    if profile=='nominal' or (profile=='half_speed_response' and action not in ['C02','C04','C08']):
        if action in REUSE:r=retained_run((ctx,REUSE[action],seed,.1))
        else:
            from .engine import run as engine
            r=engine((ctx,action,seed,.1))
        r={**r,'action':action,'profile':profile,'traveler_sha256':r['demand_sha256']}
    else:
        from .sensitivity import run as engine
        r=engine((ctx,action,seed,.1,profile))
    return r

def execute(tasks,path,workers=6):
    start=time.monotonic();rows=[]
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for f in as_completed([pool.submit(run,t) for t in tasks]):
            rows.append(f.result())
            if len(rows)%100==0 or len(rows)==len(tasks):
                pd.DataFrame(rows).to_csv(path.with_suffix('.partial.csv'),index=False)
                print(f'{path.stem}: {len(rows)}/{len(tasks)}, invalid={sum(not r["complete"] for r in rows)}, seconds={time.monotonic()-start:.0f}',flush=True)
    d=pd.DataFrame(rows).sort_values(['profile','context_id','seed','action'])
    assert d.groupby(['profile','context_id','seed']).traveler_sha256.nunique().eq(1).all()
    assert d.groupby(['profile','context_id','action']).size().eq(30).all()
    d.to_csv(path,index=False)

def batch(split,actions=None,workers=6):
    c=pd.read_csv(DATA/'contexts.csv');c=c[c.split.eq(split)];tasks=[]
    for r in c.itertuples():
        seeds=RETAINED_SEEDS[r.original_split] if split=='train' else VALIDATION_SEEDS if split=='validation' else TEST_SEEDS
        tasks.extend((r.context_id,a,s,'nominal') for s in seeds for a in (actions or ACTIONS))
    execute(tasks,OUT/f'{split}_runs.csv',workers)

def sensitivity(actions,workers=6):
    tasks=[(ctx,a,s,p) for p in PROFILES for ctx in SENSITIVITY_CONTEXTS for s in TEST_SEEDS for a in actions]
    execute(tasks,OUT/'sensitivity_runs.csv',workers)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('split',choices=['train','validation']);p.add_argument('--workers',type=int,default=6);a=p.parse_args();batch(a.split,workers=a.workers)
