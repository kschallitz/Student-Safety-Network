"""Source-preserving road speed inputs, not a causal collision-effect model."""
# %% road_speed_inputs
import json
import numpy as np
import pandas as pd
import geopandas as gpd


def prepare_road_speeds(collection, source_manifest):
    roads = gpd.GeoDataFrame.from_features(collection['features'], crs='EPSG:4326')
    if roads.OBJECTID.isna().any() or roads.OBJECTID.duplicated().any():
        raise ValueError('Road segment IDs must be unique and present.')
    if len(roads) != source_manifest['records']:
        raise ValueError('Road source count does not reconcile.')
    if roads.geometry.isna().any() or roads.geometry.is_empty.any() or not roads.geometry.is_valid.all():
        raise ValueError('Invalid road geometry needs source review.')
    if not roads.geometry.geom_type.isin(['LineString', 'MultiLineString']).all():
        raise ValueError('Expected road line geometry.')
    roads['segment_id'] = 'livermore_gis_7_' + roads.OBJECTID.astype(str)
    # Keep the raw columns. Null/zero posted speed stays unknown; dispatch is not a substitute.
    for raw, name in [('PostedSpeedLimit', 'posted_speed_mph'),
                      ('DispatchSpeedLimit', 'dispatch_speed_mph')]:
        values = pd.to_numeric(roads[raw], errors='raise')
        if (values.dropna().lt(0) | values.dropna().gt(70)).any():
            raise ValueError(f'{raw} outside the source domain 0–70.')
        roads[name] = values.where(values.gt(0))
    roads['posted_speed_known'] = roads.posted_speed_mph.notna()
    roads['posted_dispatch_disagree'] = (
        roads.posted_speed_known & roads.dispatch_speed_mph.notna()
        & roads.posted_speed_mph.ne(roads.dispatch_speed_mph))
    roads['source_observed_utc'] = source_manifest['retrieved_utc']
    roads['source_url'] = source_manifest['source_url']
    # Record editing timestamps are deliberately not promoted to speed effective dates.
    roads['speed_effective_from'] = None
    roads['speed_effective_to'] = None
    roads['historical_speed_verified'] = False
    roads['length_m'] = roads.to_crs('EPSG:26910').length
    audit = {'segments': len(roads), 'posted_speed_populated': int(roads.posted_speed_known.sum()),
             'posted_speed_unknown': int((~roads.posted_speed_known).sum()),
             'posted_dispatch_disagreements': int(roads.posted_dispatch_disagree.sum()),
             'historical_speed_verified_segments': 0, 'speed_model_trained': False,
             'causal_effect_estimated': False}
    return roads, audit


def school_speed_context(roads, schools, radius_metres=1609.344):
    """Descriptive clipped road length; this is not historical or regional coverage."""
    projected = roads.loc[roads.Status.eq('Active')].to_crs('EPSG:26910')
    school_points = schools.to_crs(projected.crs)
    rows = []
    for _, school in school_points.iterrows():
        circle = school.geometry.buffer(radius_metres)
        candidates = projected.iloc[projected.sindex.query(circle, predicate='intersects')].copy()
        clipped_length = candidates.geometry.intersection(circle).length
        total = float(clipped_length.sum())
        known = candidates.posted_speed_known
        known_length = float(clipped_length[known].sum())
        weighted = float((clipped_length[known] * candidates.loc[known, 'posted_speed_mph']).sum())
        rows.append({'school_id': school.school_id, 'school_name': school.school_name,
            'radius_metres': radius_metres, 'inventory_road_km': total / 1000,
            'known_posted_road_km': known_length / 1000,
            'unknown_posted_road_km': (total - known_length) / 1000,
            'known_posted_length_share': known_length / total if total else np.nan,
            'length_weighted_posted_mph': weighted / known_length if known_length else np.nan,
            'known_ge35_road_km': float(clipped_length[candidates.posted_speed_mph.ge(35)].sum()) / 1000,
            'historical_speed_verified': False,
            'coverage_note': 'Livermore GIS inventory only; all road classes included. Cross-boundary coverage and effective dates unverified. Not student routes.'})
    return pd.DataFrame(rows)


def scenario_road_inputs(roads, segment_ids, proposed_speed_mph):
    """Prepare an explicit assumption for later models; do not invent risk outputs."""
    if not np.isfinite(proposed_speed_mph) or not 0 < proposed_speed_mph <= 70:
        raise ValueError('Proposed speed must be finite and between 0 and 70 mph.')
    ids = set(segment_ids)
    if not ids or not ids.issubset(set(roads.segment_id)):
        raise ValueError('Choose existing segment IDs, not an ambiguous road name.')
    chosen = roads.segment_id.isin(ids)
    if not roads.loc[chosen, 'posted_speed_known'].all():
        raise ValueError('Verify the current posted limit before defining its change.')
    if not roads.loc[chosen, 'Status'].eq('Active').all():
        raise ValueError('A scenario must use active road segments.')
    proposed = roads.copy()
    proposed['scenario_posted_speed_mph'] = roads.posted_speed_mph
    proposed.loc[chosen, 'scenario_posted_speed_mph'] = proposed_speed_mph
    proposed['scenario_changed'] = chosen & roads.posted_speed_mph.ne(proposed_speed_mph)
    # This separate column leaves observed fields and dispatch values untouched.
    return proposed


def export_road_speed_inputs(roads, audit, context, output_dir):
    output_dir.mkdir(parents=True, exist_ok=True)
    roads.to_file(output_dir / 'livermore_road_speed_inventory.geojson', driver='GeoJSON')
    roads.drop(columns='geometry').to_csv(output_dir / 'livermore_road_speed_inventory.csv', index=False)
    context.to_csv(output_dir / 'livermore_school_speed_context.csv', index=False)
    (output_dir / 'road_speed_readiness.json').write_text(json.dumps(audit, indent=2))
