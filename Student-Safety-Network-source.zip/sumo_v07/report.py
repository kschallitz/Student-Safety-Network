"""Publish the completed evidence test without broadening its claim."""
import html,json
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/sumo_v07'

def gates():
    s=json.loads((OUT/'speed_summary.json').read_text());l=json.loads((OUT/'summary.json').read_text())
    sensitivity=pd.read_csv(OUT/'detector_sensitivity.csv').mean_change_from_middle_mph.abs().max()
    rows=[
      ('Source speed extraction','Verified','1,056 hourly and 44 daily source populations reconcile.','None for the extracted populations.'),
      ('Intersection run reliability','Failed',f"{l['completed_primary_runs']}/{l['primary_runs']} refined runs complete; {len(l['incomplete_runs'])} stall. The entire affected session comparison is suppressed.",'Resolve the Hillcrest pedestrian/vehicle deadlocks and validate behavior/control assumptions before optimizing an intervention.'),
      ('Reported Saturday activity','Approximately reproduced','79 to 247 bicycle/pedestrian movements; 3.127 times as many.','Travel counts are observations, not a simulated mode-choice effect.'),
      ('Independent midblock speed','Passed at assumed detector' if s['post_screening_pass_n']==16 else 'Partial screening',f"{s['post_screening_pass_n']}/16 post targets meet 2 mph mean / 3 mph p85; mean MAE {s['post_mean_mae_mph']:.3f} mph versus constant {s['post_constant_mean_mae_mph']:.3f} mph.",f'Exact field detector location is absent; alternate positions change hourly means by up to {sensitivity:.2f} mph. Do not generalize to a treatment response.'),
      ('22% corridor crossing reduction','Not exactly replicated','The two-site traces shorten crossings, but the report lacks the six-site measurement worksheet; 22% refers to June-adjusted layout.','Per-crosswalk before/after lengths and dated installed plans for all six intersections.'),
      ('Turning and crossing-time benefit','Conditional simulation only','No numerical observed before/after target in this survey.','Before/after trajectories or turning speeds, crossing times and yielding observations at the modeled intersections.'),
      ('Numerical consistency','Flags retained' if l['numerical_flags'] else 'Checked for selected sessions',f"{len(l['numerical_flags'])}/{l['numerical_checks']} comparisons exceed prespecified time-step tolerances.",'Resolve relevant flags before relying on exact delay or crossing-time changes.' if l['numerical_flags'] else 'Checks cover arrival/dismissal sessions and two seeds, not every possible scenario.'),
      ('Collision-effect / intervention-agent reward','Not validated','The consultant report supplies no quantitative collision or conflict reduction target. Explorer outputs were not used as fitting targets.','Independent observed safety/conflict outcomes plus an externally tested relationship to the reward; audited controls and geometry for the candidate interventions.')]
    return pd.DataFrame(rows,columns=['test','status','result','remaining_requirement'])

def validation_section():
    s=json.loads((OUT/'speed_summary.json').read_text());l=json.loads((OUT/'summary.json').read_text());g=gates();d=pd.read_csv(OUT/'daily_validation.csv');post=d[d.split.str.startswith('post')]
    sensitivity=pd.read_csv(OUT/'detector_sensitivity.csv').mean_change_from_middle_mph.abs().max()
    comparison='lower' if s['post_mean_mae_mph']<s['post_constant_mean_mae_mph'] else 'higher'
    rows=''.join(f'<tr><td>{html.escape(r.test)}</td><td><strong>{html.escape(r.status)}</strong></td><td>{html.escape(r.result)}<small>{html.escape(r.remaining_requirement)}</small></td></tr>' for r in g.itertuples())
    details=''.join(f'<tr><td>{r.date}</td><td>{r.direction}</td><td>{r.observed_mean_mph:.2f}</td><td>{r.sim_mean_mph:.2f}</td><td>{r.mean_error_mph:+.2f}</td><td>{r.observed_p85_mph:.2f} / {r.sim_p85_mph:.2f}</td></tr>' for r in post.itertuples())
    return f'''<section id="validation"><h2>What reproduced the field measurements?</h2>
<div class="cards"><div class="card"><div>Post-installation mean-speed error</div><div class="value">{s['post_mean_mae_mph']:.2f} mph</div><div>Average absolute error across 16 day/direction targets.</div></div>
<div class="card"><div>Simple February reference error</div><div class="value">{s['post_constant_mean_mae_mph']:.2f} mph</div><div>SUMO's average-speed error is {comparison}. Both use pre-installation outcomes only.</div></div>
<div class="card"><div>Within 1 mph of measured mean</div><div class="value">{s['post_mean_within_1_mph_n']} / 16</div><div>{s['post_screening_pass_n']}/16 meet the broader 2 mph mean / 3 mph p85 screening limits.</div></div></div>
<p>Fit: February 1–3, 2023. Independent checks: February 4–7, May 24–25 and June 2–7. The same Jensen–Estates road model is used throughout; no post-installation speed or Explorer probability fitted its driver parameters.</p>
<p class="muted">1,872 hourly runs represent 720 distinct observed hour/direction records, not 1,872 independent days. This is a retrospective test; published post results were already known. Three-seed ranges quantify simulation randomness, not real-world confidence.</p>
<p class="muted">The field report names Jensen–Estates but omits the exact detector position. Alternative modeled positions changed individual school-hour means by up to {sensitivity:.2f} mph; that uncertainty is larger than the seed ranges.</p>
<img class="sourceimage" src="east-validation-speed_validation.png" alt="Measured speeds versus frozen February SUMO predictions, including a constant February baseline">
<p><a href="east-validation-speed_validation.png" target="_blank" rel="noopener">Open the speed chart at full size</a></p>
<p>The report found no substantial reduction in midblock speeds. Matching those speeds supports the operating-condition model; it does not show that SUMO has learned a collision-reduction effect.</p>
<details><summary>Exact May and June speed errors</summary><div class="table-scroll"><table><thead><tr><th>Date</th><th>Direction</th><th>Observed mean</th><th>SUMO mean</th><th>Error, mph</th><th>Observed / SUMO p85, mph</th></tr></thead><tbody>{details}</tbody></table></div><p class="muted">The 85th percentile is the speed at or below which 85% of vehicles travel. Daily simulated percentiles pool individual speeds; hourly percentiles are not averaged.</p></details>
<details><summary>Compare the full speed distributions</summary><img class="sourceimage" src="east-validation-speed_distributions.png" alt="Observed and simulated cumulative speed distributions, separately for May and June"><p class="muted">Reported speed bins are preserved. The source does not provide exact hourly post-installation means or percentiles. Curves are diagnostics, not a statistical equivalence test.</p></details>
<h3 style="margin-top:24px">Validation gate before the intervention agent</h3><div class="table-scroll"><table><thead><tr><th>Test</th><th>Status</th><th>Result and remaining requirement</th></tr></thead><tbody>{rows}</tbody></table></div>
<p><strong>The collision-reward gate remains unmet.</strong> The next agent's consultant-pilot benchmark and individual alternatives are specified, but no agent has been trained to claim a real collision reduction from these results.</p>
<p><strong>The intersection simulator also fails its completion gate:</strong> {l['completed_primary_runs']}/240 refined runs complete. The two stalled runs belong to one Hillcrest session; its comparison is unavailable rather than averaged over only the successful seeds.</p>
<div class="downloads"><a href="east-validation-daily_validation.csv" download>Daily validation CSV</a><a href="east-validation-error_scores.csv" download>Baseline comparison</a><a href="east-validation-Source_Audit.md">Source audit</a><a href="east-validation-intervention_candidates.csv" download>Future intervention candidates</a><a href="east-validation-report.md">Full findings</a></div>
</section>'''

def main():
    s=json.loads((OUT/'speed_summary.json').read_text());l=json.loads((OUT/'summary.json').read_text());g=gates();g.to_csv(OUT/'validation_gates.csv',index=False)
    scores=pd.read_csv(OUT/'error_scores.csv');changes=pd.read_csv(OUT/'observed_simulated_changes.csv');pairs=pd.read_csv(OUT/'paired_results.csv');placement=pd.read_csv(OUT/'detector_sensitivity.csv')
    tab=lambda d:d.to_markdown(index=False,floatfmt='.3f')
    text=f'''# East Avenue: independent validation · v0.14

The available before/after field comparison has been executed. It supports a
limited traffic-operating model, with the errors shown below. **It does not yet
validate the collision-probability reward needed to rank safety interventions.**

## What was changed

The earlier February fit used an idealized straight-road network and was later
transferred to mapped geometry, producing about 1.5 mph low bias in May. The May
refit reduced that bias but could not test the treatment independently. This
version fits February 1–3 only on the actual mapped network used for evaluation,
freezes it, and reserves February 4–7, May 24–25 and June 2–7 as outcome holdouts.
The fit and file hashes are saved in `outputs/sumo_v07/freeze.json`.

No post speed, predicted collision percentage, or favorable intervention outcome
selects its driver parameters. Published post results had already been read, so
this is a retrospective temporal test, not a blinded prospective validation.

## Independent speed results

{s['hourly_replays']:,} hourly simulations replay 720 distinct 2023 hour/direction
records over 15 source dates. There are 24 held-out day/direction targets, including
16 after installation. Every requested vehicle passed the detector.

- Post mean-speed average absolute error: **{s['post_mean_mae_mph']:.3f} mph**.
- Simple constant February mean-speed error: **{s['post_constant_mean_mae_mph']:.3f} mph**.
- Post 85th-percentile error: **{s['post_p85_mae_mph']:.3f} mph**; constant reference **{s['post_constant_p85_mae_mph']:.3f} mph**.
- {s['post_screening_pass_n']}/16 post targets meet the predeclared 2 mph mean / 3 mph p85 screening tolerances.
- {s['post_mean_within_1_mph_n']}/16 mean errors are at most 1 mph. Largest errors: mean {s['post_max_mean_error_mph']:.3f} mph, p85 {s['post_max_p85_error_mph']:.3f} mph.
- {s['holdout_screening_pass_n']}/24 targets pass across all held-out periods.

These are engineering screening limits, not a standard of collision accuracy or
statistical proof of equivalence. The midblock detector has an approximate position
within Jensen–Estates. Thirty-two alternate-position checks had a maximum mean
difference of {placement.mean_change_from_middle_mph.abs().max():.3f} mph. Do not compare this
field target with the separate junction approach sensors.

{tab(scores[scores.split!='fit'])}

The measured finding is **no substantial midblock speed reduction**. A model that
preserves speeds can agree with that result without establishing a treatment benefit.
May and June are kept separate; the report's 22% crossing reduction refers to June
adjustments. June contains a weekend; both full-period and weekday changes are saved.

{tab(changes[changes.day_selection=='weekdays'][['period','direction','observed_change_mph','sim_change_mph','change_error_mph']])}

## Physical pilot under frozen pre-installation behavior

{l['primary_runs']} layout runs form 120 matched pairs over 15 native two-hour count
sessions. Identical departures and speed draws are used in both layouts. All trips
are accounted for: **{l['completed_primary_runs']}/240 runs complete; two Hillcrest
runs stall**. The entire affected session's metric comparison is suppressed,
including otherwise successful seeds, to avoid selecting favorable outcomes.
The numerical check compares
0.05 and 0.025 second integration with a fixed 0.2 second driver action interval;
{len(l['numerical_flags'])}/{l['numerical_checks']} comparisons are flagged. Raw SUMO overlap
warnings remain diagnostics, not injury crashes or a collision reward.

The original 0.1-second batch had one incomplete Hillcrest evening run (113 trips
pending). A 0.05-second diagnostic completed the same demand. The ENTIRE 240-run
ensemble was then rerun at 0.05 seconds, rather than replacing only the failure.
Two different runs stalled in the refined ensemble. Therefore smaller time steps
do not establish reliable completion; the gate remains failed. The 0.025-second
checks above apply to this refined ensemble.

The original two-seed Estates dismissal check missed the left-turn tolerance
(0.3059 versus 0.3 mph). That one session was expanded to all eight seeds, with
unchanged model settings and tolerances. The original 16-run check is retained;
this selected follow-up is diagnostic, not an independent field test.

The following May dismissal demand is a scenario applied to the documented adjusted
pilot, not a claim of exact May as-built geometry. Seed intervals omit uncertainty
in geometry, signal controls, human behavior and field counts.

{tab(pairs[pairs.session_id.str.startswith('2023-05-18')&pairs.session_id.str.endswith('14:00')][['site','label','units','before','pilot','change','seed_interval_low','seed_interval_high']])}

## What the consultant survey actually lets us reproduce

The independent source audit reconciled all 1,056 original hourly speed populations
and 44 daily totals. Saturday combined bicycle/pedestrian activity was 79 before
and 247 after (3.127×), consistent with the report's approximate 3× headline.
The 18% afternoon activity, 19% Hillcrest activity and 5% volume headlines lack
fully specified aggregation formulas; alternate transparent recalculations are
saved rather than choosing a formula to force agreement.

The 22% corridor crossing reduction refers to all six intersections after June
adjustments. The report supplies no individual-length worksheet. Our independent
two-site aerial traces show shorter crossings but cannot replicate that exact
six-site statistic. Aerial capture date is unspecified. The survey's slower-turn
finding is anecdotal; measured turning speeds, crossing times, conflicts and
collision-reduction targets are absent.

{tab(g)}

## Agent sequence

The requested collision-reward gate has not passed, so no intervention agent was
trained or represented as validated. `intervention_candidates.csv` preserves
the plan: unchanged reference, consultant pilot **package** benchmark, and individual
curb-extension, median/refuge, posted-speed and signal-clearance candidates. The
package contains multiple changes; it must not be mislabeled one isolated change.

The next data needed are dated pre/post installed dimensions and the consultants'
crossing-length worksheet; actual Hillcrest controller settings; and independent
turning-speed, crossing-time and yielding/conflict observations. A crash-probability
reward additionally needs a tested link from simulated outcomes to observed safety
outcomes. Exact desired-speed response to a changed sign is not learned here.

## Reproducibility and sources

`East_Avenue_Independent_Validation.ipynb` embeds inputs, code and results and runs
six fresh simulations on a CPU. `East_Avenue_Independent_Validation.zip` is the
portable companion. The full protocol, native observations, error tables, source
audit, and numerical checks remain inspectable. Colab compatible; executed locally.

- [City Tactical East Avenue final report](https://www.livermoreca.gov/home/showpublisheddocument/12943/638887914440930000): PDF p.7 findings; appendices for counts and speeds.
- [April 2025 memo](https://library.livermoreca.gov/home/showpublisheddocument/12945/638887914731000000): existing pilot aerial raster on PDF pp.18/21 only; future design overlays excluded.

The midblock speed component treats the observed flow as a passenger-vehicle stream
with calibrated speed variation. It checks aggregate operating speeds, not vehicle
class effects. The separate junction component retains the native heavy-vehicle,
bicycle and pedestrian counts.
'''
    (ROOT/'East_Avenue_Independent_Validation.md').write_text(text)
    print(g[['test','status']].to_string(index=False))

if __name__=='__main__':main()
