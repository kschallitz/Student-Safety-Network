"""Do not select an unknown detector position to improve the post fit."""
from concurrent.futures import ProcessPoolExecutor
import pandas as pd
from .experiment import source, SEEDS
from .speed import run, ROOT, OUT, setup

def main():
    d=source(); d=d[d.split.eq('post_may') & d.hour.isin([7,8,14,15])]
    tasks=[(r.observation_date,r.travel_direction,int(r.hour),int(r.sample_count),SEEDS[0]+int(r.hour)*17,piece)
           for r in d.itertuples() for piece in [3,12]]
    with ProcessPoolExecutor(max_workers=2) as pool: rows=list(pool.map(run,tasks))
    for task,row in zip(tasks,rows):row['detector_piece']=task[-1]
    result=pd.DataFrame(rows);main=pd.read_csv(OUT/'speed_hours.csv');main=main[main.seed.eq(SEEDS[0]+main.hour*17)]
    result=result.merge(main[['date','direction','hour','mean_mph','p85_mph']],on=['date','direction','hour'],suffixes=('','_main'),validate='many_to_one')
    result['mean_change_from_middle_mph']=result.mean_mph-result.mean_mph_main
    result['p85_change_from_middle_mph']=result.p85_mph-result.p85_mph_main
    assert result.detected.eq(result.requested).all() and result.pending.eq(0).all()
    result.to_csv(OUT/'detector_sensitivity.csv',index=False)
    print('Detector sensitivity runs',len(result),'max mean difference',result.mean_change_from_middle_mph.abs().max())

if __name__=='__main__':main()
