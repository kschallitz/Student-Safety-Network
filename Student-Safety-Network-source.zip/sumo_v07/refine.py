"""Apply the finer integration to the entire ensemble, never only to a failed run."""
import argparse,json
from concurrent.futures import ProcessPoolExecutor,as_completed
import pandas as pd
from .replay import ROOT,OUT,SEEDS,run

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--fine',action='store_true');ap.add_argument('--workers',type=int,default=4);a=ap.parse_args()
    d=pd.read_csv(ROOT/'data/sumo_v02/junction_demand_15min.csv');sessions=sorted(d.session_id.unique())
    if a.fine:sessions=[s for s in sessions if s.startswith('2023-05-18') and s.endswith(('07:00','14:00'))]
    tasks=[(sid,phase,seed,.025 if a.fine else .05,False) for sid in sessions for seed in (SEEDS[:2] if a.fine else SEEDS) for phase in ['before','pilot']]
    label='refined_fine' if a.fine else 'refined';pd.DataFrame(tasks,columns=['session_id','layout','seed','step','record']).to_csv(OUT/(label+'_schedule.csv'),index=False)
    rows=[]
    with ProcessPoolExecutor(max_workers=a.workers) as pool:
        for job in as_completed([pool.submit(run,t) for t in tasks]):
            r=job.result();rows.append(r);pd.DataFrame(rows).to_csv(OUT/(label+'_runs.csv'),index=False)
            if len(rows)%16==0:print(label,len(rows),'/',len(tasks),'incomplete',sum(not x['complete'] for x in rows),flush=True)
    assert len(rows)==len(tasks)

if __name__=='__main__':main()
