"""Independent detector check on the mapped Jensen–Estates block."""
import argparse,hashlib,json,os,time,xml.etree.ElementTree as E
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np,pandas as pd,sumolib
from functools import lru_cache
@lru_cache(maxsize=1)
def context():
 return sumolib.net.readNet(str(ROOT/'outputs/sumo_v03/east_joined.net.xml'),withInternal=True,withPedestrianConnections=True),None
from sumo_v02.calibrate import xml
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'outputs/sumo_v07'; MPH=.44704

@lru_cache(maxsize=8)
def setup(detector_piece=8):
 n,_=context(); routes={}; sensors={}
 # Stay within the named Jensen–Estates block; no signalized Hillcrest crossing.
 for dr,ends,det in [('eastbound',('1046369274#0','1046369274#13'),f'1046369274#{detector_piece}'),('westbound',('-1046369274#13','-1046369274#0'),f'-1046369274#{detector_piece}')]:
  path,_=n.getShortestPath(n.getEdge(ends[0]),n.getEdge(ends[1]),vClass='passenger')
  routes[dr]=' '.join(e.getID() for e in path)
  sensors[dr]={'edge':det,'lanes':[l.getID() for l in n.getEdge(det).getLanes() if l.allows('passenger')], 'pos':n.getEdge(det).getLength()/2}
  xy=sumolib.geomhelper.positionAtShapeOffset(n.getEdge(det).getShape(),sensors[dr]['pos']);sensors[dr]['lon'],sensors[dr]['lat']=n.convertXY2LonLat(*xy)
 return routes,sensors

def run(task,parameters=None):
 import libsumo as sim
 date,dr,hour,count,seed=task[:5];routes,sensors=setup(task[5] if len(task)>5 else 8);model=parameters or json.loads((OUT/'calibration.json').read_text())[dr]
 net=ROOT/'outputs/sumo_v03/east_joined.net.xml';digest=hashlib.sha256(net.read_bytes()+Path(__file__).read_bytes()).hexdigest()
 key=hashlib.sha256(json.dumps([digest,task,model]).encode()).hexdigest()[:20];p=OUT/'speed_runs'/key;p.mkdir(parents=True,exist_ok=True)
 if (p/'result.json').exists():return json.loads((p/'result.json').read_text())
 rng=np.random.default_rng(seed);r=E.Element('routes');E.SubElement(r,'vType',id='car',vClass='passenger',accel='2.6',decel='4.5',sigma='.5',tau='1.2',minGap='2.5',length='5',maxSpeed='60',speedDev='0',actionStepLength='.2');E.SubElement(r,'route',id='r',edges=routes[dr])
 warm=int(round(count/12));deps=[(float(t),'w'+str(i)) for i,t in enumerate(rng.uniform(0,300,warm))]+[(float(t),'s'+str(i)) for i,t in enumerate(rng.uniform(300,3900,count))]
 for t,vid in sorted(deps):
  factor=max(.2,rng.normal(model['desired_mean_mph'],model['desired_sd_mph'])/30)
  E.SubElement(r,'vehicle',id=vid,type='car',route='r',depart=f'{t:.3f}',departLane='free',departSpeed='max',speedFactor=str(factor))
 xml(r,p/'demand.rou.xml');a=E.Element('additional')
 for i,lane in enumerate(sensors[dr]['lanes']):E.SubElement(a,'inductionLoop',id='d'+str(i),lane=lane,pos=str(sensors[dr]['pos']),file='detector.xml',period='3600')
 xml(a,p/'detector.add.xml');cfg=E.Element('configuration');inp=E.SubElement(cfg,'input')
 for k,v in [('net-file',os.path.relpath(net,p)),('route-files','demand.rou.xml'),('additional-files','detector.add.xml')]:E.SubElement(inp,k,value=v)
 tm=E.SubElement(cfg,'time');E.SubElement(tm,'step-length',value='.2');E.SubElement(tm,'end',value='4800');pr=E.SubElement(cfg,'processing');E.SubElement(pr,'time-to-teleport',value='-1');E.SubElement(pr,'step-method.ballistic',value='true');ran=E.SubElement(cfg,'random_number');E.SubElement(ran,'seed',value=str(seed));xml(cfg,p/'run.sumocfg')
 tick=time.monotonic();speeds={};sim.start([sumolib.checkBinary('sumo'),'-c',str(p/'run.sumocfg'),'--no-step-log','true','--duration-log.disable','true','--no-warnings','true'])
 try:
  while sim.simulation.getTime()<4800:
   sim.simulationStep()
   for i in range(len(sensors[dr]['lanes'])):
    for vid,length,entry,leave,_ in sim.inductionloop.getVehicleData('d'+str(i)):
     if vid.startswith('s') and leave>entry and vid not in speeds:speeds[vid]=length/(leave-entry)/MPH
   if sim.simulation.getMinExpectedNumber()==0:break
  pending=sim.simulation.getMinExpectedNumber()
 finally:sim.close()
 pd.DataFrame({'vehicle_id':speeds.keys(),'mph':speeds.values()}).to_csv(p/'speeds.csv',index=False)
 result={'date':date,'direction':dr,'hour':hour,'requested':count,'detected':len(speeds),'pending':pending,'seed':seed,'mean_mph':float(np.mean(list(speeds.values()))),'p85_mph':float(np.quantile(list(speeds.values()),.85)),'parameters':model,'path':str(p.relative_to(ROOT)),'input_digest':digest,'seconds':time.monotonic()-tick}
 (p/'result.json').write_text(json.dumps(result,indent=2));return result
