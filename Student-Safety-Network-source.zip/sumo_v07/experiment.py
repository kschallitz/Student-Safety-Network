"""Fit using pre-installation outcomes only, then lock and evaluate."""
import argparse, hashlib, json
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from .speed import ROOT, OUT, run, setup

FIT = ['2023-02-01', '2023-02-02', '2023-02-03']
SEEDS = [910001, 920003, 930007]

def source():
    d = pd.read_csv(ROOT/'data/traffic_exposure/normalized/speed_observations.csv')
    d = d[d.observation_date.str.startswith('2023') & d.eligible_for_automatic_aggregation].copy()
    d['hour'] = d.interval_start.str[11:13].astype(int)
    d['split'] = np.select([d.observation_date.isin(FIT), d.observation_date.str.startswith('2023-02'),
                           d.observation_date.str.startswith('2023-05')],
                          ['fit', 'pre_holdout', 'post_may'], default='post_june')
    assert len(d) == 720 and not d.duplicated(['observation_date','travel_direction','hour']).any()
    assert d.sample_count.notna().all() and (d.sample_count >= 0).all()
    daily = pd.read_csv(ROOT/'data/traffic_exposure/normalized/speed_daily_summaries.csv')
    for (date, dr), g in d.groupby(['observation_date','travel_direction']):
        assert g.sample_count.sum() == daily[(daily.observation_date==date)&(daily.travel_direction==dr)].iloc[0].sample_count
    return d

def fit_direction(dr):
    g = source(); g = g[(g.split=='fit') & (g.travel_direction==dr) & g.mean_mph.notna() & g.p85_mph.notna() & (g.sample_count>=40)].sort_values('sample_count')
    levels = np.unique(np.quantile(g.sample_count,np.linspace(0,1,6)).round().astype(int))
    trace = []
    def objective(x):
        reps = [run(('fit',dr,i,int(n),700001), {'desired_mean_mph':float(x[0]),'desired_sd_mph':float(x[1])}) for i,n in enumerate(levels)]
        if any(r['detected']!=r['requested'] or r['pending'] for r in reps): raise RuntimeError('Incomplete fitting replay')
        mean = np.interp(g.sample_count,levels,[z['mean_mph'] for z in reps])
        p85 = np.interp(g.sample_count,levels,[z['p85_mph'] for z in reps])
        loss = float(np.average((mean-g.mean_mph)**2+(p85-g.p85_mph)**2,weights=g.sample_count))
        trace.append({'direction':dr,'mu':float(x[0]),'sd':float(x[1]),'loss':loss})
        return loss
    opt = minimize(objective,[36.,4.8],method='Nelder-Mead',bounds=[(27,45),(1,10)],
                   options={'maxiter':60,'xatol':.05,'fatol':.005})
    model = {'desired_mean_mph':float(opt.x[0]),'desired_sd_mph':float(opt.x[1]),
             'fit_dates':FIT,'fit_hours':len(g),'fit_loss':float(opt.fun),
             'optimizer_success':bool(opt.success),'flow_levels':levels.tolist(),
             'post_outcomes_used':False,'fit_method':'weighted hourly mean and p85; 6 simulated flow levels interpolated during fit only'}
    g.to_csv(OUT/f'fit_inputs_{dr}.csv',index=False)
    pd.DataFrame(trace).to_csv(OUT/f'fit_trace_{dr}.csv',index=False)
    print('Fitted',dr,model,flush=True)
    return dr,model

def fit():
    OUT.mkdir(parents=True,exist_ok=True)
    with ProcessPoolExecutor(max_workers=2) as pool: models=dict(pool.map(fit_direction,['eastbound','westbound']))
    (OUT/'calibration.json').write_text(json.dumps(models,indent=2))
    paths = [OUT/f'fit_inputs_{dr}.csv' for dr in models] + [OUT/'calibration.json', ROOT/'sumo_v07/protocol.md',ROOT/'sumo_v07/speed.py',ROOT/'sumo_v07/experiment.py', ROOT/'outputs/sumo_v03/east_joined.net.xml']
    freeze={'stage':'frozen_before_v07_post_simulations','post_outcomes_used_in_fit':False,
            'retrospective_test_not_blind':True,'files':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
    (OUT/'freeze.json').write_text(json.dumps(freeze,indent=2))

def evaluate(workers=4):
    d=source(); d.to_csv(OUT/'hourly_inputs.csv',index=False)
    frozen=json.loads((OUT/'freeze.json').read_text())
    for p,sha in frozen['files'].items(): assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==sha,p
    tasks=[(r.observation_date,r.travel_direction,int(r.hour),int(r.sample_count),seed+int(r.hour)*17)
           for r in d.itertuples() for seed in (SEEDS[:1] if r.split=='fit' else SEEDS)]
    (OUT/'detector_locations.json').write_text(json.dumps(setup()[1],indent=2))
    pd.DataFrame(tasks,columns=['date','direction','hour','n','seed']).to_csv(OUT/'speed_schedule.csv',index=False)
    results=[]
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for job in as_completed([pool.submit(run,t) for t in tasks]):
            results.append(job.result())
            if len(results)%48==0:
                print('Independent speed replays',len(results),'/',len(tasks),flush=True)
                pd.DataFrame(results).to_csv(OUT/'speed_hours.csv',index=False)
    pd.DataFrame(results).to_csv(OUT/'speed_hours.csv',index=False)
    assert len(results)==len(tasks)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['fit','evaluate']);ap.add_argument('--workers',type=int,default=4);a=ap.parse_args()
    fit() if a.stage=='fit' else evaluate(a.workers)
