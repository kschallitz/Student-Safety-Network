"""Preserve the stalled run and inspect it without teleporting participants."""
import json,xml.etree.ElementTree as E
from pathlib import Path
import libsumo as sim,sumolib
from .speed import ROOT,OUT

def main():
    src=OUT/'runs/5fbf21b613ae1d7be7';dest=OUT/'incomplete_diagnostic';dest.mkdir(exist_ok=True)
    root=E.parse(src/'run.sumocfg').getroot()
    for tag in ['net-file','route-files','additional-files']:
        v=root.find('input/'+tag);v.set('value',str((src/v.get('value')).resolve()))
    for v in root.find('output'):v.set('value',str(dest/Path(v.get('value')).name))
    root.find('time/end').set('value','12000');E.ElementTree(root).write(dest/'run.sumocfg')
    sim.start([sumolib.checkBinary('sumo'),'-c',str(dest/'run.sumocfg'),'--no-step-log','true','--duration-log.disable','true','--no-warnings','true'])
    snapshots=[]
    try:
        for t in [8200,9000,10200,12000]:
            sim.simulationStep(t)
            people=[{'id':v,'edge':sim.person.getRoadID(v),'pos':sim.person.getPosition(v),'speed':sim.person.getSpeed(v),'waiting':sim.person.getWaitingTime(v)} for v in sim.person.getIDList()]
            cars=[{'id':v,'lane':sim.vehicle.getLaneID(v),'pos':sim.vehicle.getPosition(v),'speed':sim.vehicle.getSpeed(v),'waiting':sim.vehicle.getWaitingTime(v),'route':sim.vehicle.getRoute(v)} for v in sim.vehicle.getIDList() if sim.vehicle.getRoadID(v).startswith(':')]
            snapshots.append({'time':t,'pending':sim.simulation.getMinExpectedNumber(),'people':people,'junction_vehicles':cars})
    finally:sim.close()
    (dest/'snapshots.json').write_text(json.dumps(snapshots,indent=2));print(json.dumps(snapshots[-1],indent=2))

if __name__=='__main__':main()
