"""Held-out error, baseline comparison, and native-bin distribution checks."""
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .experiment import ROOT, OUT, source, FIT

def main():
    h=pd.read_csv(OUT/'speed_hours.csv');h['base_seed']=h.seed-h.hour*17
    obs=pd.read_csv(ROOT/'data/traffic_exposure/normalized/speed_daily_summaries.csv')
    bins=pd.read_csv(ROOT/'data/traffic_exposure/normalized/speed_distributions.csv')
    meta=source()[['observation_date','travel_direction','split']].drop_duplicates()
    baseline={dr:{'mean':float(np.average(g.mean_mph,weights=g.sample_count)),
                  'p85':float(g.p85_mph.mean())} for dr,g in obs[obs.observation_date.isin(FIT)].groupby('travel_direction')}
    rows=[];cdfrows=[];period_speeds={}
    for (date,dr,seed),g in h.groupby(['date','direction','base_seed']):
        target=obs[(obs.observation_date==date)&(obs.travel_direction==dr)].iloc[0]
        ss=np.concatenate([pd.read_csv(ROOT/r.path/'speeds.csv').mph.to_numpy() for r in g.itertuples()])
        period_speeds.setdefault((date[:7],dr,seed),[]).append(ss)
        complete=bool(g.requested.sum()==len(ss)==target.sample_count and g.pending.sum()==0 and len(g)==24)
        assert complete,(date,dr,seed)
        split=meta[(meta.observation_date==date)&(meta.travel_direction==dr)].iloc[0].split
        row={'date':date,'direction':dr,'seed':seed,'split':split,'observed_n':int(target.sample_count),
             'simulated_n':len(ss),'source_page':int(target.source_page),'complete':complete}
        for m,om,sm in [('mean',target.mean_mph,float(ss.mean())),('p85',target.p85_mph,float(np.quantile(ss,.85)))]:
            row.update({f'observed_{m}_mph':om,f'sim_{m}_mph':sm,f'{m}_error_mph':sm-om,
                        f'baseline_{m}_mph':baseline[dr][m],f'baseline_{m}_error_mph':baseline[dr][m]-om})
        native=bins[(bins.observation_date==date)&(bins.travel_direction==dr)]
        pre=bins[bins.observation_date.isin(FIT)&(bins.travel_direction==dr)]
        differences=[]
        for boundary in range(10,81,5):
            measured=float(native[native.speed_bin_upper_mph.le(boundary)]['count'].sum()/native['count'].sum())
            predicted=float((ss<boundary).mean())
            constant=float(pre[pre.speed_bin_upper_mph.le(boundary)]['count'].sum()/pre['count'].sum())
            cdfrows.append({'date':date,'direction':dr,'seed':seed,'split':split,'upper_bin_boundary_mph':boundary,
                            'observed_cumulative_fraction':measured,'sim_cumulative_fraction':predicted,'baseline_cumulative_fraction':constant})
            differences.append(abs(measured-predicted))
        row['maximum_binned_cdf_error']=max(differences)
        rows.append(row)
    d=pd.DataFrame(rows);d.to_csv(OUT/'daily_seed_validation.csv',index=False)
    # Compare the original report's whole-campaign summaries using pooled
    # individual speeds. February seeds 2/3 omit fit days, so exclude them here.
    campaign_targets=pd.read_csv(OUT/'source_audit/speed_period_targets.csv');campaign=[]
    for (period,dr,seed),arrays in period_speeds.items():
        target=campaign_targets[(campaign_targets.period==period)&(campaign_targets.direction==dr)].iloc[0]
        values=np.concatenate(arrays)
        if len(values)!=target.vehicles:continue
        campaign.append({'period':period,'direction':dr,'seed':seed,'vehicles':len(values),
                         'observed_mean_mph':float(target.source_mean_mph),'sim_mean_mph':float(values.mean()),
                         'observed_p85_mph':float(target.source_p85_mph),'sim_p85_mph':float(np.quantile(values,.85)),
                         'source_page':int(target.source_pdf_page)})
    pd.DataFrame(campaign).to_csv(OUT/'campaign_validation.csv',index=False)
    cdf=pd.DataFrame(cdfrows);cdf.to_csv(OUT/'binned_distribution_validation.csv',index=False)
    group=d.groupby(['date','direction','split'])
    daily=group.agg(observed_n=('observed_n','first'),source_page=('source_page','first'),seed_count=('seed','size'),
          observed_mean_mph=('observed_mean_mph','first'),observed_p85_mph=('observed_p85_mph','first'),
          sim_mean_mph=('sim_mean_mph','mean'),sim_mean_min=('sim_mean_mph','min'),sim_mean_max=('sim_mean_mph','max'),
          sim_p85_mph=('sim_p85_mph','mean'),sim_p85_min=('sim_p85_mph','min'),sim_p85_max=('sim_p85_mph','max'),
          baseline_mean_mph=('baseline_mean_mph','first'),baseline_p85_mph=('baseline_p85_mph','first'),
          max_binned_cdf_error=('maximum_binned_cdf_error','mean')).reset_index()
    daily['mean_error_mph']=daily.sim_mean_mph-daily.observed_mean_mph
    daily['p85_error_mph']=daily.sim_p85_mph-daily.observed_p85_mph
    daily['screening_pass']=(daily.mean_error_mph.abs()<=2)&(daily.p85_error_mph.abs()<=3)
    daily['mean_within_1_mph']=daily.mean_error_mph.abs()<=1
    daily.to_csv(OUT/'daily_validation.csv',index=False)
    scores=[];changes=[]
    for (split,dr),g in daily.groupby(['split','direction']):
        for stat in ['mean','p85']:
            for model in ['sim','baseline']:
                err=g[f'{model}_{stat}_mph']-g[f'observed_{stat}_mph']
                scores.append({'split':split,'direction':dr,'statistic':stat,'model':'SUMO' if model=='sim' else 'February constant',
                               'day_direction_n':len(g),'mae_mph':float(err.abs().mean()),'bias_mph':float(err.mean()),
                               'rmse_mph':float(np.sqrt(np.square(err).mean()))})
        pre=daily[(daily.split=='fit')&(daily.direction==dr)]
        if split in ['post_may','post_june']:
            # A weekday restriction removes weekends; it does not match the
            # exact day-of-week mix (May Wed/Thu, fit Wed/Thu/Fri).
            for mask,label in [(g.date.notna(),'all_collection_days'),(pd.to_datetime(g.date).dt.dayofweek<5,'weekdays')]:
                gg=g[mask]
                actual_pre=float(np.average(pre.observed_mean_mph,weights=pre.observed_n));actual_post=float(np.average(gg.observed_mean_mph,weights=gg.observed_n))
                sim_pre=float(np.average(pre.sim_mean_mph,weights=pre.observed_n));sim_post=float(np.average(gg.sim_mean_mph,weights=gg.observed_n))
                changes.append({'period':split,'direction':dr,'day_selection':label,'pre_mean_mph':actual_pre,'post_mean_mph':actual_post,
                                'observed_change_mph':actual_post-actual_pre,'sim_pre_mph':sim_pre,'sim_post_mph':sim_post,
                                'sim_change_mph':sim_post-sim_pre,'change_error_mph':(sim_post-sim_pre)-(actual_post-actual_pre),
                                'interpretation':'descriptive change; not a controlled treatment effect'})
    pd.DataFrame(scores).to_csv(OUT/'error_scores.csv',index=False);pd.DataFrame(changes).to_csv(OUT/'observed_simulated_changes.csv',index=False)
    post=daily[daily.split.str.startswith('post')];hold=daily[daily.split!='fit']
    summary={'hourly_replays':len(h),'source_hours':h[['date','direction','hour']].drop_duplicates().shape[0],
             'source_collection_days':daily.date.nunique(),'heldout_day_direction_n':len(hold),'post_day_direction_n':len(post),
             'all_complete':bool(d.complete.all()),'post_mean_mae_mph':float(post.mean_error_mph.abs().mean()),
             'post_p85_mae_mph':float(post.p85_error_mph.abs().mean()),
             'post_constant_mean_mae_mph':float((post.baseline_mean_mph-post.observed_mean_mph).abs().mean()),
             'post_constant_p85_mae_mph':float((post.baseline_p85_mph-post.observed_p85_mph).abs().mean()),
             'post_screening_pass_n':int(post.screening_pass.sum()),'post_mean_within_1_mph_n':int(post.mean_within_1_mph.sum()),
             'holdout_screening_pass_n':int(hold.screening_pass.sum()),
             'post_max_mean_error_mph':float(post.mean_error_mph.abs().max()),
             'post_max_p85_error_mph':float(post.p85_error_mph.abs().max()),
             'interval_scope':'Three simulation seeds, shown as min/max; not field confidence intervals',
             'fit_dates':FIT,'post_fit_leakage':False,'validation_scope':'conditional midblock speed only; no measured turning, crossing-time, or crash-effect target'}
    (OUT/'speed_summary.json').write_text(json.dumps(summary,indent=2))
    plots(daily,cdf)
    print(json.dumps(summary,indent=2));print(daily.to_string(index=False))

def plots(daily,cdf):
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold'})
    fig,axs=plt.subplots(2,2,figsize=(13,8),layout='constrained')
    for row,dr in enumerate(['eastbound','westbound']):
        g=daily[(daily.direction==dr)&daily.split.ne('fit')].sort_values('date');x=np.arange(len(g))
        for col,stat in enumerate(['mean','p85']):
            ax=axs[row,col];v=g[f'sim_{stat}_mph'];ax.plot(x,g[f'observed_{stat}_mph'],'o-',color='#172f41',label='Observed');ax.errorbar(x,v,yerr=[v-g[f'sim_{stat}_min'],g[f'sim_{stat}_max']-v],fmt='s--',color='#087887',capsize=3,label='SUMO, frozen February fit');ax.plot(x,g[f'baseline_{stat}_mph'],':',color='#b76315',label='February constant')
            ax.set_xticks(x,g.date.str[5:],rotation=45);ax.set_ylabel('mph');ax.set_title(f'{dr.title()} · '+('average speed' if stat=='mean' else '85th percentile'));ax.grid(axis='y',alpha=.2);ax.axvline(3.5,color='#becacb',lw=1);ax.axvline(5.5,color='#becacb',lw=1)
    handles,labels=axs[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='outside lower center',ncol=3,fontsize=10)
    fig.suptitle('Measured versus predicted speeds: pre holdout, May, and June\nSeed ranges quantify simulation randomness only',fontsize=14)
    fig.savefig(OUT/'speed_validation.png',dpi=160);plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(11,4),layout='constrained')
    for ax,(dr,g) in zip(axs,cdf[cdf.split.str.startswith('post')].groupby('direction')):
        for split,color in [('post_may','#087887'),('post_june','#b76315')]:
            z=g[g.split==split].groupby('upper_bin_boundary_mph')[['observed_cumulative_fraction','sim_cumulative_fraction']].mean()
            ax.plot(z.index,100*z.observed_cumulative_fraction,'o-',color=color,label=split.replace('post_','').title()+' observed');ax.plot(z.index,100*z.sim_cumulative_fraction,'--',color=color,label=split.replace('post_','').title()+' SUMO')
        ax.set_xlim(20,55);ax.set_ylim(0,101);ax.set_title(dr.title());ax.set_xlabel('Speed-bin upper boundary (mph)');ax.set_ylabel('Cumulative percentage');ax.legend(fontsize=8);ax.grid(alpha=.2)
    fig.suptitle('Whole speed-distribution check · daily CDFs averaged within campaign\nReported bin boundaries are preserved; this is not a statistical KS test',fontsize=12)
    fig.savefig(OUT/'speed_distributions.png',dpi=160);plt.close(fig)

if __name__=='__main__':main()
