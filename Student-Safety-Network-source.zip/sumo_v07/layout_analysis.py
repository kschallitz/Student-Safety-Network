"""Paired, conditional layout estimates with seed and engineering uncertainty."""
import json,hashlib,sys,platform,xml.etree.ElementTree as E
import numpy as np,pandas as pd
from sumo_v06.network import ROOT
OUT=ROOT/'outputs/sumo_v07'
METRICS={'crossing_occupancy_mean_s':('Crossing occupancy','seconds',.5),'right_turn_mean_mph':('Right-turn speed','mph',.3),'left_turn_mean_mph':('Left-turn speed','mph',.3),'motor_time_loss_s':('Motor delay','seconds',1.),'midblock_mean_mph':('Approach speed','mph',.3)}
def pairs(d):
 keys=['site','session_id','seed'];a=d[d.layout.eq('before')];b=d[d.layout.eq('pilot')];return a.merge(b,on=keys,suffixes=('_before','_pilot'),validate='one_to_one')
def main():
 d=pd.read_csv(OUT/'refined_runs.csv');fine=pd.read_csv(OUT/'refined_fine_runs.csv');g=pd.read_csv(ROOT/'outputs/sumo_v06/geometry_measurements.csv');counts=pd.read_csv(ROOT/'data/sumo_v02/junction_demand_15min.csv');p=pairs(d)
 checks={'main_runs_240':len(d)==240,'fine_runs_16':len(fine)==16,'no_wrong_crossing':int(d.wrong_crossing_count.sum()+fine.wrong_crossing_count.sum())==0,'paired_demands_byte_identical':bool((p.demand_sha256_before==p.demand_sha256_pilot).all()),'compiled_geometry_checks':bool(pd.read_csv(ROOT/'outputs/sumo_v06/compiled_network_checks.csv').passed.all()),'crossing_geometry_checks':bool(pd.read_csv(ROOT/'outputs/sumo_v06/geometry_checks.csv')['pass'].all())}
 assert all(checks.values()),checks
 failed=d[~d.complete].copy();failed.to_csv(OUT/'incomplete_runs.csv',index=False)
 rows=[];rng=np.random.default_rng(240929)
 for sid,t in p.groupby('session_id'):
  for col,(name,unit,tol) in METRICS.items():
   if not (t.complete_before & t.complete_pilot).all():
    rows.append(dict(site=t.iloc[0].site,session_id=sid,demand_phase=t.iloc[0].demand_phase_before,metric=col,label=name,units=unit,before=None,pilot=None,change=None,change_percent=None,seed_interval_low=None,seed_interval_high=None,seed_count=len(t),interval_scope='Unavailable: incomplete runs invalidate the whole session comparison; no failed seed is silently dropped'))
    continue
   delta=(t[col+'_pilot']-t[col+'_before']).dropna().to_numpy();v=float(delta.mean());samples=rng.choice(delta,(10000,len(delta)),replace=True).mean(axis=1);lo,hi=np.quantile(samples,[.025,.975]);before=float(t[col+'_before'].mean());after=float(t[col+'_pilot'].mean())
   rows.append(dict(site=t.iloc[0].site,session_id=sid,demand_phase=t.iloc[0].demand_phase_before,metric=col,label=name,units=unit,before=before,pilot=after,change=v,change_percent=100*v/before if before else None,seed_interval_low=float(lo),seed_interval_high=float(hi),seed_count=len(delta),interval_scope='95% paired seed-bootstrap interval; excludes geometry, demand, control and behavior uncertainty'))
 summary=pd.DataFrame(rows);summary.to_csv(OUT/'paired_results.csv',index=False)
 changes=[]
 for (s,a),q in g.groupby(['site','leg']):
  b=q[q.layout.eq('before')].iloc[0];t=q[q.layout.eq('pilot')].iloc[0];B=b.length_m;T=t.length_m;fixed=abs(B-T)<.00001
  # Shared scale uncertainty cancels in percent reduction. Independent endpoint
  # sensitivity applies to each line; unchanged shared endpoints cancel exactly.
  low=0 if fixed else 100*(1-(T+1.2)/(B-1.2));high=0 if fixed else 100*(1-max(0,T-1.2)/(B+1.2))
  changes.append(dict(site=s,leg=a,before_m=B,pilot_m=T,before_ft=B/.3048,pilot_ft=T/.3048,reduction_pct=100*(1-T/B),reduction_sensitivity_low=low,reduction_sensitivity_high=high,before_length_sensitivity_low=max(0,B*.97-1.2),before_length_sensitivity_high=B*1.03+1.2,pilot_length_sensitivity_low=max(0,T*.97-1.2),pilot_length_sensitivity_high=T*1.03+1.2,uncertainty='Engineering sensitivity: endpoints +/-0.6 m; shared scale +/-3%; not statistical confidence',source_pdf_page=int(t.source_pdf_page),notes=t.notes))
 pd.DataFrame(changes).to_csv(OUT/'crossing_changes.csv',index=False)
 finepairs=pairs(fine);fp=finepairs.merge(p,on=['site','session_id','seed'],suffixes=('_fine','_main'));num=[]
 for (s,sid),t in fp.groupby(['site','session_id']):
  for col,(name,unit,tol) in METRICS.items():
   main=float((t[col+'_pilot_main']-t[col+'_before_main']).mean());f=float((t[col+'_pilot_fine']-t[col+'_before_fine']).mean());num.append(dict(site=s,session_id=sid,metric=col,main_paired_change=main,fine_paired_change=f,discrepancy=abs(f-main),tolerance=tol,passed=abs(f-main)<=tol))
 numerical=pd.DataFrame(num);numerical.to_csv(OUT/'numerical_check.csv',index=False)
 # Preserve the prespecified two-seed result as well as the selected follow-up.
 initialpairs=pairs(pd.read_csv(OUT/'fine_runs_initial.csv')).merge(pairs(pd.read_csv(OUT/'main_runs.csv')),on=['site','session_id','seed'],suffixes=('_fine','_main'));initialrows=[]
 for (site,sid),t in initialpairs.groupby(['site','session_id']):
  for col,(name,unit,tol) in METRICS.items():
   a=float((t[col+'_pilot_main']-t[col+'_before_main']).mean());b=float((t[col+'_pilot_fine']-t[col+'_before_fine']).mean())
   initialrows.append({'site':site,'session_id':sid,'metric':col,'discrepancy':abs(a-b),'tolerance':tol,'passed':abs(a-b)<=tol})
 initialcheck=pd.DataFrame(initialrows);initialcheck.to_csv(OUT/'numerical_check_initial.csv',index=False)
 # Native interval table stays unchanged, with original status/provenance columns.
 counts.to_csv(OUT/'observed_15min_counts.csv',index=False)
 grouped=counts.groupby(['site','session_id','phase','mode'])['count'].sum().unstack(fill_value=0).reset_index();grouped.to_csv(OUT/'observed_sessions.csv',index=False)
 contacts=[]
 for _,r in d[d.raw_contact_pairs.gt(0)].iterrows():
  for z in E.parse(ROOT/r.path/'contacts.xml').getroot():
   if not 900<=float(z.get('time'))<8100:continue
   contacts.append({'site':r.site,'layout':r.layout,'session_id':r.session_id,'seed':int(r.seed),**z.attrib,'interpretation':'SUMO overlap diagnostic, not a field crash or calibrated collision probability'})
 pd.DataFrame(contacts).to_csv(OUT/'contact_diagnostics.csv',index=False)
 saved={'implementation_checks':checks,'all_requested_crossings_seen':bool((d.pedestrians_crossing_seen==d.pedestrians_requested).all() and (fine.pedestrians_crossing_seen==fine.pedestrians_requested).all()),'completed_primary_runs':int(d.complete.sum()),'completion_gate_passed':bool(d.complete.all() and fine.complete.all()),'incomplete_runs':failed.to_dict('records'),'invalid_sessions':sorted(failed.session_id.unique().tolist()),'integration_step_s':.05,'fine_integration_step_s':.025,'coarser_failed_runs':pd.read_csv(OUT/'main_runs.csv').query('complete == False').to_dict('records'),'primary_runs':len(d),'matched_pairs':len(p),'native_sessions':counts.session_id.nunique(),'seeds_per_session':8,'fine_runs':len(fine),'numerical_checks':len(numerical),'initial_numerical_flags':initialcheck[~initialcheck.passed].to_dict('records'),'numerical_followup':'Original 0.1-second batch had one stalled run; entire ensemble rerun at 0.05 seconds, with 0.025-second checks. Prior borderline turning check and all failures preserved.','numerical_flags':numerical[~numerical.passed].to_dict('records'),'raw_contact_pairs':int(d.raw_contact_pairs.sum()),'runs_with_contacts':int(d.raw_contact_pairs.gt(0).sum()),'claim':'Source-traced operational layout reconstruction; not field-validated collision probability','clock_period':'Two-hour counted sessions plus 15-minute warmup and drain; repetitions are not independent calendar days','scope':'Existing pilot shown in April 2025 memo with unspecified aerial date; not certified May 2023 as-built','engine':{'python':platform.python_version(),'sumo':'1.27.1'},'source_hashes':{str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [ROOT/'data/sumo_v06/traces.json',ROOT/'data/sumo_v02/junction_demand_15min.csv',ROOT/'outputs/sumo_v02/calibration.json',ROOT/'outputs/sumo_v07/calibration.json',ROOT/'sumo_v07/replay.py',ROOT/'sumo_v06/network.py',ROOT/'sumo_v06/demand.py']}}
 (OUT/'summary.json').write_text(json.dumps(saved,indent=2));print(json.dumps(saved,indent=2));print(summary[summary.session_id.str.startswith('2023-05-18') & summary.session_id.str.endswith('14:00')][['site','label','before','pilot','change','seed_interval_low','seed_interval_high']].round(3).to_string(index=False))
if __name__=='__main__':main()
