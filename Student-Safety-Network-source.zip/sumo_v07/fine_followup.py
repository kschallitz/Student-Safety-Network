"""Expand the one borderline numerical discrepancy; do not change tolerances."""
from concurrent.futures import ProcessPoolExecutor
import pandas as pd
from .replay import OUT, SEEDS, run

def main():
    original=OUT/'fine_runs_initial.csv'
    if not original.exists():original.write_bytes((OUT/'fine_runs.csv').read_bytes())
    initial=pd.read_csv(original);assert len(initial)==16
    tasks=[('2023-05-18_Estates St_14:00',phase,seed,.05,False)
           for seed in SEEDS[2:] for phase in ['before','pilot']]
    with ProcessPoolExecutor(max_workers=2) as pool: extra=list(pool.map(run,tasks))
    final=pd.concat([initial,pd.DataFrame(extra)],ignore_index=True)
    assert len(final)==28 and not final.duplicated(['session_id','layout','seed']).any()
    final.to_csv(OUT/'fine_runs.csv',index=False)
    print('Expanded numerical check',len(final),'runs; original 16 retained separately')

if __name__=='__main__':main()
