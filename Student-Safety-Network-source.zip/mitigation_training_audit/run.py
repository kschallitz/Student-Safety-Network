"""Extend v0.16 learning, without silently counting replay as fresh simulation."""
import json,time,hashlib
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np,pandas as pd,torch
from torch import nn
from mitigation_rl.learn import features,key,values
from mitigation_batch.learn import scored,batches
from mitigation_batch.config import ROOT,DATA,ACTIONS,sha

OUT=ROOT/'outputs/mitigation_training_audit'
CHECKPOINTS=[6000,30000,100000,300000]

def performance(model,c,b):
    predictions=values(model,c)
    matrix=b.pivot(index='context_id',columns='action',values='score').loc[c.context_id,ACTIONS].to_numpy()
    choices=predictions.argmax(1);selected=matrix[np.arange(len(c)),choices]
    mapping=dict(zip(c.context_id,[ACTIONS[i] for i in choices]))
    rows=b[b.action.eq(b.context_id.map(mapping))]
    return {'total_score':float(selected.sum()),
            'mean_batch_score':float(selected.mean()),
            'mean_regret_to_hindsight_choice':float((matrix.max(1)-selected).mean()),
            'q_rmse_points':float(np.sqrt(np.mean((predictions-matrix)**2))),
            'eligible':bool(rows.complete.all() and rows.base_complete.all() and (rows.delay-rows.base_delay).mean()<=30),
            'choices':mapping}

def train(task):
    family,seed=task;name=f'{family}_{seed}';start=time.monotonic()
    contexts=pd.read_csv(DATA/'contexts.csv')
    c=contexts[contexts.split.eq('train')].reset_index(drop=True)
    vc=contexts[contexts.split.eq('validation')].reset_index(drop=True)
    tr=batches(scored('train'));va=batches(scored('validation'))
    assert tr.complete.all() and va.complete.all()
    feedback=tr.assign(seed=0,reward=tr.score/100)[['context_id','action','seed','reward']]
    rng=np.random.default_rng(seed);torch.set_num_threads(1);torch.manual_seed(seed)
    mu=features(c).mean(0);sd=features(c).std(0);sd[sd<1e-6]=1;x=(features(c)-mu)/sd
    blocks=feedback.pivot(index=['context_id','seed'],columns='action',values='reward')[ACTIONS].dropna()
    rewards=blocks.to_numpy();indices=c.reset_index().set_index('context_id')['index'];ix=np.array([indices[k[0]] for k in blocks.index]);keys=[key(z) for z in c.to_dict('records')]
    table={k:np.zeros(4) for k in keys};fallback=np.zeros(4);counts=np.zeros(4);w=np.zeros((x.shape[1]+1,4))
    net=nn.Sequential(nn.Linear(7,32),nn.Tanh(),nn.Linear(32,32),nn.Tanh(),nn.Linear(32,4));opt=torch.optim.Adam(net.parameters(),lr=.001)
    records=[];exports={};published=json.loads((ROOT/'outputs/mitigation_batch/models.json').read_text())[name]
    for step in range(max(CHECKPOINTS)):
        j=int(rng.integers(len(rewards)));i=ix[j];xx=x[i];epsilon=max(.08,1-step/4500)
        if family=='tabular':q=table[keys[i]]
        elif family=='linear':q=np.r_[xx,1.]@w
        else:
            with torch.no_grad():q=net(torch.tensor(xx,dtype=torch.float32)).numpy()
        a=int(rng.integers(4)) if rng.random()<epsilon else int(np.argmax(q));r=float(rewards[j,a])
        counts[a]+=1;fallback[a]+=(r-fallback[a])/counts[a]
        if family=='tabular':table[keys[i]][a]+=.08*(r-q[a])
        elif family=='linear':w[:,a]+=.01*(r-q[a])*np.r_[xx,1.]/max(1,float(np.dot(xx,xx)))
        else:
            pred=net(torch.tensor(xx,dtype=torch.float32))[a];loss=(pred-r)**2;opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),10);opt.step()
        if (step+1)%10000==0:
            (OUT/f'{name}_progress.json').write_text(json.dumps({'updates':step+1,'seconds':time.monotonic()-start}))
        if step+1 not in CHECKPOINTS:continue
        model={'family':family,'seed':seed,'mean':mu.tolist(),'std':sd.tolist(),'actions':ACTIONS,'steps':step+1}
        if family=='tabular':model.update(table={k:(v*100).tolist() for k,v in table.items()},fallback=(fallback*100).tolist())
        elif family=='linear':model['weights']=(w*100).tolist()
        else:
            model['layers']=[{'weight':layer.weight.detach().numpy().tolist(),'bias':layer.bias.detach().numpy().tolist(),'activation':'linear' if n==4 else 'tanh'} for n,layer in enumerate(net) if isinstance(layer,nn.Linear)]
            model['layers'][-1]['weight']=(np.array(model['layers'][-1]['weight'])*100).tolist();model['layers'][-1]['bias']=(np.array(model['layers'][-1]['bias'])*100).tolist()
        if step+1==6000:
            assert np.allclose(values(model,c),values(published,c),atol=1e-9,rtol=1e-12),f'{name}: initial checkpoint did not reproduce'
        identifier=f'{name}_u{step+1}';exports[identifier]=model
        metrics={'agent':name,'family':family,'seed':seed,'updates':step+1,'seconds':time.monotonic()-start,'action_update_counts':counts.astype(int).tolist()}
        for split,cc,bb in [('train',c,tr),('validation',vc,va)]:
            z=performance(model,cc,bb)
            metrics.update({split+'_'+k:v for k,v in z.items() if k!='choices'})
        records.append(metrics)
        (OUT/f'{name}_checkpoints.json').write_text(json.dumps({'models':exports,'metrics':records},indent=2))
        print(f'{name}: {step+1:,} updates; training score {metrics["train_total_score"]:,.0f}; validation {metrics["validation_total_score"]:,.0f}',flush=True)
    return name,exports,records

def main():
    OUT.mkdir(exist_ok=True);start=time.monotonic()
    original={p:sha(ROOT/p) for p in ['outputs/mitigation_batch/models.json','outputs/mitigation_batch/policy_freeze.json','outputs/mitigation_batch/train_runs.csv','outputs/mitigation_batch/validation_runs.csv','mitigation_rl/learn.py']}
    jobs=[(f,s) for f in ['tabular','linear','neural'] for s in [41,73,109]];models={};metrics=[]
    with ProcessPoolExecutor(max_workers=3) as pool:
        for future in as_completed([pool.submit(train,t) for t in jobs]):
            _,m,r=future.result();models.update(m);metrics+=r
    pd.DataFrame(metrics).to_csv(OUT/'learning_checkpoints.csv',index=False)
    ranking=sorted(metrics,key=lambda r:(not r['validation_eligible'],-r['validation_total_score'],r['updates'],r['agent']))
    best=ranking[0];chosen=f'{best["agent"]}_u{best["updates"]}'
    (OUT/'models.json').write_text(json.dumps(models))
    freeze={'selected_checkpoint':chosen,'selection':'validation score, eligible first, fewer updates then lexical ties','checkpoints':CHECKPOINTS,'updates_per_agent':300000,'agent_count':9,'total_learning_updates':2700000,'fresh_sumo_runs':0,'training_simulator_records_reused':2880,'training_action_window_targets':96,'protocol_sha256':sha(ROOT/'mitigation_training_audit/protocol.md'),'models_sha256':sha(OUT/'models.json'),'original_sources':original}
    (OUT/'freeze.json').write_text(json.dumps(freeze,indent=2))
    # Test data are opened only after every learning run and validation selection.
    c=pd.read_csv(DATA/'contexts.csv');c=c[c.split.eq('test')].reset_index(drop=True)
    b=batches(scored('test'));test=[]
    for name,m in models.items():
        test.append({'model':name,**{k:v for k,v in performance(m,c,b).items() if k!='choices'}})
    pd.DataFrame(test).to_csv(OUT/'retrospective_test.csv',index=False)
    matrix=b.pivot(index='context_id',columns='action',values='score')
    ceiling={'scope':'Hindsight upper bound on these 32 saved test batches only','unchanged':float(matrix.A0.sum()),'best_of_available_four_with_hindsight':float(matrix[ACTIONS].max(1).sum()),'consultant_pilot':float(matrix.H.sum()),'gap_even_with_perfect_four_action_selection':float(matrix.H.sum()-matrix[ACTIONS].max(1).sum())}
    assert all(sha(ROOT/p)==h for p,h in original.items())
    result={'freeze':freeze,'action_menu_ceiling':ceiling,'selected_test':next(r for r in test if r['model']==chosen),'original_files_unchanged':True,'all_6000_checkpoints_reproduced':True,'wall_seconds':time.monotonic()-start}
    (OUT/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':main()
