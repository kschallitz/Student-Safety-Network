"""Learning-budget diagnostic; preserves the published experiment."""
