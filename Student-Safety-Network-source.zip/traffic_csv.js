/* Browser-local intake only: schema-valid observations still require route mapping. */
(function(root){
 const HEADERS=['intersection_id','intersection_name','count_date','start_local','duration_minutes','approach_road','destination_road_or_crossing_leg','mode','count','measurement_status','source','notes'];
 function parse(text){
  text=text.replace(/^\uFEFF/,'');
  if(text.length>2_000_000)throw Error('Use a CSV smaller than 2 MB.');
  const rows=[];let row=[],field='',quoted=false,closed=false;
  const cell=()=>{row.push(field);field='';closed=false;};
  const line=()=>{cell();if(row.some(x=>x.trim()!==''))rows.push(row);row=[];};
  for(let i=0;i<text.length;i++){
   const ch=text[i];
   if(quoted){if(ch==='"'){if(text[i+1]==='"'){field+='"';i++;}else{quoted=false;closed=true;}}else field+=ch;continue;}
   if(ch===','){cell();continue;}
   if(ch==='\r'||ch==='\n'){if(ch==='\r'&&text[i+1]==='\n')i++;line();continue;}
   if(ch==='"'){if(field.length||closed)throw Error('Unexpected quote in CSV field.');quoted=true;continue;}
   if(closed)throw Error('Unexpected text after a closing quote.');
   field+=ch;
  }
  if(quoted)throw Error('Unclosed quoted field.');
  if(field.length||row.length||closed)line();
  return rows;
 }
 function validate(text,junctionId){
  const errors=[],warnings=[],records=[];let table;
  try{table=parse(text);}catch(e){return {ok:false,errors:[e.message],warnings,records:[]};}
  if(table.length<2)return {ok:false,errors:['Add observation rows below the header. Empty templates are not traffic data.'],warnings,records:[]};
  const header=table.shift().map(x=>x.trim());
  if(new Set(header).size!==header.length)errors.push('Duplicate column names.');
  for(const h of HEADERS.filter(h=>!['intersection_name','notes'].includes(h)))if(!header.includes(h))errors.push('Missing column: '+h);
  if(table.length>10000)errors.push('Use at most 10,000 observation rows per upload.');
  if(errors.length)return {ok:false,errors,warnings,records:[]};
  const seen=new Set(),modes=new Set(),intervals=new Set(),statuses=new Set();
  table.forEach((cells,i)=>{
   const line=i+2;if(cells.length!==header.length){errors.push(`Row ${line}: ${cells.length} fields; expected ${header.length}.`);return;}
   const r=Object.fromEntries(header.map((h,k)=>[h,cells[k].trim()])),bad=message=>errors.push(`Row ${line}: ${message}`);
   if(r.intersection_id!==junctionId)bad('intersection_id must match the selected intersection ('+junctionId+').');
   const date=new Date(r.count_date+'T00:00:00Z');
   if(!/^\d{4}-\d{2}-\d{2}$/.test(r.count_date)||!Number.isFinite(date.valueOf())||date.toISOString().slice(0,10)!==r.count_date)bad('count_date must be a valid YYYY-MM-DD date.');
   if(!/^([01]\d|2[0-3]):(00|15|30|45)$/.test(r.start_local))bad('start_local must be HH:MM at a 15-minute boundary.');
   if(r.duration_minutes!=='15')bad('duration_minutes must be 15; do not divide larger totals without labeling them estimated.');
   if(!r.approach_road||!r.destination_road_or_crossing_leg)bad('identify the approach and destination, or the pedestrian origin and crossing leg.');
   if(!['passenger','heavy','bicycle','pedestrian'].includes(r.mode))bad('mode must be passenger, heavy, bicycle or pedestrian.');
   if(!/^\d+$/.test(r.count)||!Number.isSafeInteger(Number(r.count)))bad('count must be a nonnegative integer; blanks are unknown, not zero.');
   if(!['observed','adjusted','estimated','modeled'].includes(r.measurement_status))bad('measurement_status must be observed, adjusted, estimated or modeled.');
   if(!r.source)bad('include the observation source.');
   const key=[r.count_date,r.start_local,r.approach_road.toUpperCase(),r.destination_road_or_crossing_leg.toUpperCase(),r.mode].join('|');
   if(seen.has(key))bad('duplicate movement/mode/time row; reconcile counts before upload.');seen.add(key);
   modes.add(r.mode);intervals.add(r.count_date+' '+r.start_local);statuses.add(r.measurement_status);
   records.push({...r,count:Number(r.count),duration_minutes:15});
  });
  if(errors.length)return {ok:false,errors:errors.slice(0,30),additionalErrors:Math.max(0,errors.length-30),warnings,records:[]};
  const missing=['passenger','heavy','bicycle','pedestrian'].filter(m=>!modes.has(m));
  if(missing.length)warnings.push('No rows for '+missing.join(', ')+'. Missing modes are not zero counts.');
  if([...statuses].some(s=>s!=='observed'))warnings.push('Includes non-observed values. Keep these separate from observed calibration data.');
  warnings.push('Route/crossing mapping and complete movement coverage have not been checked. These rows do not yet make this site simulation-ready.');
  const totals=Object.fromEntries([...modes].map(m=>[m,records.filter(r=>r.mode===m).reduce((sum,r)=>sum+r.count,0)]));
  const totalsByStatus=Object.fromEntries([...statuses].map(s=>[s,Object.fromEntries([...modes].map(m=>{const rows=records.filter(r=>r.mode===m&&r.measurement_status===s);return [m,rows.length?rows.reduce((sum,r)=>sum+r.count,0):null];}))]));
  return {ok:true,errors,warnings,records,intervals:intervals.size,totals,totalsByStatus,simulationReady:false};
 }
 const API={HEADERS,parse,validate};if(typeof module!=='undefined'&&module.exports)module.exports=API;else root.TrafficCSV=API;
})(typeof globalThis!=='undefined'?globalThis:this);
