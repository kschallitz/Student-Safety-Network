"""Conditional model-stability ranges, not calibrated local-risk coverage claims."""
from pathlib import Path
import json,re,time,warnings
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPRegressor
from sklearn.linear_model import PoissonRegressor
from sklearn.exceptions import ConvergenceWarning
from threadpoolctl import threadpool_limits
from intersection_prediction import OUT,CRS,PROTOCOL,load_prepared,feature_year,export_model,predict_export,probability


def bootstrap_models(replicates=40):
    j,counts,unknown=load_prepared();models=json.loads((OUT/'model.json').read_text())
    xy=j.to_crs(CRS)
    blocks=np.c_[np.floor(xy.geometry.x/2000),np.floor(xy.geometry.y/2000)]
    _,block_index=np.unique(blocks,axis=0,return_inverse=True);nblocks=block_index.max()+1
    xs=[];ys=[];bs=[]
    from historical_speed_features import eligible
    for year in PROTOCOL['training_years']:
        mask=eligible(j,unknown,year)
        xs.append(feature_year(j,counts,unknown,year)[mask]);ys.append(counts[:,year-2014,:].reshape(-1)[mask])
        bs.append(np.repeat(block_index,6)[mask])
    x=np.concatenate(xs);y=np.concatenate(ys);row_block=np.concatenate(bs)
    scaler=StandardScaler();scaler.mean_=np.array(models['nn']['mean']);scaler.scale_=np.array(models['nn']['scale']);scaler.n_features_in_=x.shape[1]
    sx=scaler.transform(x)
    unique,inverse=np.unique(sx,axis=0,return_inverse=True)
    hidden=len(models['nn']['biases'][0]);alpha=float(re.search(r'penalty ([\d.]+)',models['nn']['name'])[1])
    glm_alpha=float(re.search(r'penalty ([\d.]+)',models['glm']['name'])[1])
    ensemble={'nn':[],'glm':[]};logs=[];rng=np.random.default_rng(82026);start=time.monotonic()
    active_blocks=np.unique(row_block)
    for replicate in range(replicates):
        draws=rng.choice(active_blocks,size=len(active_blocks),replace=True)
        multiplicity=np.bincount(draws,minlength=nblocks)
        row_weight=multiplicity[row_block].astype(float)
        row_weight*=len(y)/row_weight.sum()  # Keep the regularization scale fixed.
        weights=np.bincount(inverse,weights=row_weight,minlength=len(unique))
        total=np.bincount(inverse,weights=row_weight*y,minlength=len(unique))
        used=weights>0;target=total[used]/weights[used]
        net=MLPRegressor(loss='poisson',hidden_layer_sizes=(hidden,),activation='tanh',solver='lbfgs',
            alpha=alpha,max_iter=1000,max_fun=5000,tol=1e-5,random_state=42)
        tick=time.monotonic()
        with warnings.catch_warnings(record=True) as caught,threadpool_limits(limits=2):
            warnings.simplefilter('always');net.fit(unique[used],target,sample_weight=weights[used])
        convergence=[str(w.message) for w in caught if issubclass(w.category,ConvergenceWarning)]
        if convergence:
            net.set_params(warm_start=True,max_iter=1000)
            with warnings.catch_warnings(record=True) as caught,threadpool_limits(limits=2):
                warnings.simplefilter('always');net.fit(unique[used],target,sample_weight=weights[used])
            convergence=[str(w.message) for w in caught if issubclass(w.category,ConvergenceWarning)]
        glm=PoissonRegressor(alpha=glm_alpha,max_iter=500,tol=1e-7)
        with threadpool_limits(limits=2):glm.fit(unique[used],target,sample_weight=weights[used])
        ensemble['nn'].append(export_model(net,scaler,f'Bootstrap {replicate+1}'))
        ensemble['glm'].append(export_model(glm,scaler,f'Bootstrap {replicate+1}'))
        logs.append({'replicate':replicate+1,'seconds':time.monotonic()-tick,'nn_iterations':int(net.n_iter_),'convergence_warnings':convergence})
        print('Spatial bootstrap',replicate+1,'/',replicates,'seconds',round(logs[-1]['seconds'],1),flush=True)
    if any(r['convergence_warnings'] for r in logs):raise RuntimeError('Unconverged fits; do not publish uncertainty ranges.')
    ensemble['metadata']={'replicates':replicates,'spatial_block_metres':2000,'training_spatial_blocks':len(active_blocks),
        'quantiles':[.05,.95],'nominal_percent':90,'seed':82026,
        'meaning':'Central 90% range of model predictions under spatial-block resampling of training data. NOT a verified 90% confidence level for true local risk.',
        'conditioning':'Fixed matched data, current road geometry, assumed annual speed histories, transition-year exclusions, lagged histories, feature scaling, model family and selected hyperparameters.',
        'not_included':['Missing/unreported crashes','Coordinate errors','Historical road and speed errors','Exposure and omitted variables','Future distribution shifts','Model selection uncertainty','Causal intervention uncertainty'],
        'elapsed_seconds':time.monotonic()-start,'logs':logs}
    (OUT/'bootstrap_models.json').write_text(json.dumps(ensemble))
    # Store annual and per-band ranges for the unchanged baseline as an audit table.
    fx=np.load(OUT/'map_features.npz')['x']
    import pandas as pd
    frames=[]
    for kind in ['nn','glm']:
        ps=np.array([predict_export(m,fx).reshape(len(j),6) for m in ensemble[kind]])
        annual=probability(ps.sum(axis=2));lo,hi=np.quantile(annual,[.05,.95],axis=0)
        center=probability(predict_export(models[kind],fx).reshape(len(j),6).sum(axis=1))
        frames.append(pd.DataFrame({'junction_id':j.junction_id,'model':kind,'point_probability':center,'model_range_low':lo,'model_range_high':hi,'coverage_complete':j.coverage_complete}))
    pd.concat(frames).to_csv(OUT/'probability_ranges.csv',index=False)
    (OUT/'uncertainty_method.json').write_text(json.dumps(ensemble['metadata'],indent=2))
    print('Uncertainty models saved',flush=True)
    return ensemble


if __name__=='__main__':bootstrap_models()
