"""Matched physical-layout experiments on observed movements."""
import json,hashlib,os,math,time,argparse,xml.etree.ElementTree as E
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import pandas as pd,numpy as np,sumolib
from .demand import make_demand
from .network import ROOT,OUT,DATA,TRACE,xml
EXPERIMENT_REVISION = "source_geometry_2_full_turn_paths"
SEEDS=[610021+997*i for i in range(8)]

def signals(net,site,p):
 r=E.parse(net).getroot();root=E.Element('additional');links=[z for z in r.findall('connection') if z.get('tl')==site]
 if links:
  size=max(int(z.get('linkIndex')) for z in links)+1;cross={z.get('id'):z.get('crossingEdges','').split()[0][0] for z in r.findall('edge') if z.get('function')=='crossing'}
  logic=E.SubElement(root,'tlLogic',id=site,type='static',programID='same_historical_prior',offset='0')
  for stage,dur in [('EW_left',4),('EW_through',36),('northbound',20),('southbound',16)]:
   state=['r']*size
   for z in links:
    v='r';a=z.get('from','')[0];turn=z.get('dir');i=int(z.get('linkIndex'))
    if z.get('to') in cross:
     leg=cross[z.get('to')];v='G' if (stage=='EW_through' and leg in 'NS') or (stage in ['northbound','southbound'] and leg in 'EW') else 'r'
    elif stage=='EW_left' and a in 'EW' and turn in ['l','t']:v='G'
    elif stage=='EW_through' and a in 'EW' and turn in ['s','r']:v='G' if turn=='s' else 'g'
    elif (stage=='northbound' and a=='S') or (stage=='southbound' and a=='N'):v='G' if turn=='s' else 'g'
    state[i]=v
   # Close pedestrian entry ahead of the conflicting motor phase. Keep total
   # motor green and cycle unchanged; 2023 field clearance settings unknown.
   ped_indices=[int(z.get('linkIndex')) for z in links if z.get('to') in cross]
   no_peds=state.copy()
   for i in ped_indices:no_peds[i]='r'
   if stage in ['EW_through','northbound']:
    walk=12 if stage=='EW_through' else 6
    E.SubElement(logic,'phase',duration=str(walk),state=''.join(state));E.SubElement(logic,'phase',duration=str(dur-walk),state=''.join(no_peds))
   else:E.SubElement(logic,'phase',duration=str(dur),state=''.join(no_peds))
   yellow=['y' if s in 'Gg' else 'r' for s in state]
   for z in links:
    if z.get('to') in cross:yellow[int(z.get('linkIndex'))]='r'
   E.SubElement(logic,'phase',duration='3',state=''.join(yellow));E.SubElement(logic,'phase',duration='1.5',state='r'*size)
 xml(root,p/'control.add.xml')

def run(task):
 import libsumo as sim
 sid,phase,seed,step,record=task;data=pd.read_csv(ROOT/'data/sumo_v02/junction_demand_15min.csv');rows=data[data.session_id.eq(sid)];site=rows.iloc[0].site
 src=OUT/'networks'/site/phase;net=src/'network.net.xml';n=sumolib.net.readNet(str(net),withInternal=True,withPedestrianConnections=True);ports=json.loads((src/'ports.json').read_text())
 digest=hashlib.sha256(net.read_bytes()+Path(__file__).read_bytes()+(ROOT/'sumo_v06/demand.py').read_bytes()+(ROOT/'outputs/sumo_v02/calibration.json').read_bytes()+(ROOT/'outputs/sumo_v05/calibration.json').read_bytes()+(ROOT/'data/sumo_v02/junction_demand_15min.csv').read_bytes()).hexdigest();key=hashlib.sha256(json.dumps([task,digest]).encode()).hexdigest()[:18];p=OUT/'runs'/key;p.mkdir(parents=True,exist_ok=True)
 if (p/'result.json').exists():return json.loads((p/'result.json').read_text())
 study,total=make_demand(rows,seed,p,n,ports)
 routes=E.parse(p/'demand.rou.xml').getroot();old=json.loads((ROOT/'outputs/sumo_v02/calibration.json').read_text());new=json.loads((ROOT/'outputs/sumo_v05/calibration.json').read_text())
 for v in routes.findall('vType'):
  if v.get('vClass')!='pedestrian':v.set('actionStepLength','.2')
 for v in routes.findall('vehicle'):
  dr={'W_in':'eastbound','E_in':'westbound'}.get(v.find('route').get('edges').split()[0])
  if dr and v.get('type')!='bicycle':
   z=(float(v.get('speedFactor'))*30-old[dr]['desired_mean_mph'])/old[dr]['desired_sd_mph'];v.set('speedFactor',str(max(.2,(new[dr]['desired_mean_mph']+z*new[dr]['desired_sd_mph'])/30)))
 xml(routes,p/'demand.rou.xml');signals(net,site,p)
 add=E.parse(p/'control.add.xml').getroot()
 for z in list(add.findall('tlLogic')):add.remove(z)
 for arm in ['E','W']:
  for lane in n.getEdge(arm+'_in').getLanes():
   if lane.allows('passenger'):E.SubElement(add,'instantInductionLoop',id=lane.getID(),lane=lane.getID(),pos='70',file='midblock.xml')
 xml(add,p/'control.add.xml')
 cfg=E.Element('configuration');inp=E.SubElement(cfg,'input')
 for k,v in [('net-file',os.path.relpath(net,p)),('route-files','demand.rou.xml'),('additional-files','control.add.xml')]:E.SubElement(inp,k,value=v)
 tm=E.SubElement(cfg,'time');E.SubElement(tm,'step-length',value=str(step));E.SubElement(tm,'end',value='10200');ran=E.SubElement(cfg,'random_number');E.SubElement(ran,'seed',value=str(seed));proc=E.SubElement(cfg,'processing')
 for k,v in [('step-method.ballistic','true'),('pedestrian.striping.reserve-oncoming','.5'),('pedestrian.striping.reserve-oncoming.junctions','.5'),('pedestrian.striping.reserve-oncoming.max','2'),('pedestrian.striping.jamtime','-1'),('pedestrian.striping.jamtime.crossing','-1'),('pedestrian.striping.jamtime.narrow','-1'),('time-to-teleport','-1'),('collision.action','warn'),('intermodal-collision.action','warn'),('collision.check-junctions','true'),('collision.mingap-factor','0')]:E.SubElement(proc,k,value=v)
 out=E.SubElement(cfg,'output')
 for k,v in [('tripinfo-output','trips.xml'),('collision-output','contacts.xml')]:E.SubElement(out,k,value=v)
 xml(cfg,p/'run.sumocfg')
 nr=E.parse(net).getroot();crossing={e.get('id'):e.get('crossingEdges').split()[0][0] for e in nr.findall('edge') if e.get('function')=='crossing'}
 dirs={}
 for z in nr.findall('connection'):
  lane=z.get('from')+'_'+z.get('fromLane')
  if z.get('from','').startswith(':') and n.getLane(lane).allows('passenger') and n.getLane(lane).getEdge().getFunction()=='internal':dirs[lane]=z.get('dir')
 person_stats={};turn_stats={};frames=[];cross_errors=[];tick=time.monotonic()
 sim.start([sumolib.checkBinary('sumo'),'-c',str(p/'run.sumocfg'),'--no-step-log','true','--duration-log.disable','true','--no-warnings','true','--error-log',str(p/'warnings.log')])
 try:
  # Sample all crossing occupancy at 0.2 s irrespective of integration step.
  for tt in np.arange(.2,10200.01,.2):
   sim.simulationStep(float(tt))
   for person in sim.person.getIDList():
    if not person.startswith('s'):continue
    edge=sim.person.getRoadID(person)
    if edge in crossing:
     leg=crossing[edge];expect=person.rsplit('_',1)[1]
     if leg!=expect:cross_errors.append([person,expect,leg])
     stat=person_stats.setdefault(person,{'leg':leg,'occupied_s':0.0,'entered':float(tt),'last':float(tt)})
     stat['occupied_s']+=.2;stat['last']=float(tt)
   # Sample the full internal connection, including SUMO split internal lanes.
   for lane,di in dirs.items():
    if di not in ['r','l']:continue
    for vid in sim.lane.getLastStepVehicleIDs(lane):
     if vid.startswith('s') and not vid.endswith('_bicycle'):
      z=turn_stats.setdefault(vid,{'sum':0.,'n':0,'turn':di});z['sum']+=sim.vehicle.getSpeed(vid)/.44704;z['n']+=1
   if record and 2700<=tt<=2880 and abs(tt-round(tt))<1e-6:
    vehicles=[{'id':v,'x':sim.vehicle.getPosition(v)[0],'y':sim.vehicle.getPosition(v)[1],'angle':sim.vehicle.getAngle(v),'type':sim.vehicle.getTypeID(v)} for v in sim.vehicle.getIDList() if sim.vehicle.getRoadID(v).startswith(':') or math.dist(sim.vehicle.getPosition(v),(250,250))<48]
    people=[{'id':v,'x':sim.person.getPosition(v)[0],'y':sim.person.getPosition(v)[1]} for v in sim.person.getIDList() if math.dist(sim.person.getPosition(v),(250,250))<48]
    frames.append({'time':round(float(tt),1),'vehicles':vehicles,'people':people})
   if tt>8100 and sim.simulation.getMinExpectedNumber()==0:break
  pending=sim.simulation.getMinExpectedNumber()
 finally:sim.close()
 trips=E.parse(p/'trips.xml').getroot();study_trips=[z for z in trips if z.get('id','').startswith('s')];motor=[z for z in study_trips if z.tag=='tripinfo' and z.get('vType') in ['passenger','heavy']];people=[z.find('walk') for z in study_trips if z.tag=='personinfo']
 def avg(x):return float(np.mean(x)) if len(x) else None
 events=[z.attrib for z in E.parse(p/'contacts.xml').getroot() if 900<=float(z.get('time'))<8100];pairs={tuple(sorted([z.get('collider',''),z.get('victim','')])) for z in events}
 mid=[]
 for _,z in E.iterparse(p/'midblock.xml',events=('end',)):
  a=z.attrib
  if a.get('state')=='enter' and a.get('vehID','').startswith('s') and a.get('type') in ['passenger','heavy']:mid.append(float(a['speed'])/.44704)
  z.clear()
 (p/'midblock.xml').unlink()
 result={'midblock_mean_mph':avg(mid),'midblock_n':len(mid),'site':site,'session_id':sid,'demand_phase':rows.iloc[0].phase,'layout':phase,'seed':seed,'step':step,'study_requested':study,'study_arrived':len(study_trips),'pending':pending,'complete':len(study_trips)==study and pending==0,'wrong_crossing_count':len({tuple(z) for z in cross_errors}),'pedestrians_requested':int(rows[rows['mode'].eq('pedestrian')]['count'].sum()),'pedestrians_crossing_seen':len(person_stats),'crossing_occupancy_mean_s':avg([z['occupied_s'] for z in person_stats.values()]),'right_turn_mean_mph':avg([z['sum']/z['n'] for z in turn_stats.values() if z['turn']=='r']),'left_turn_mean_mph':avg([z['sum']/z['n'] for z in turn_stats.values() if z['turn']=='l']),'motor_time_loss_s':avg([float(z.get('timeLoss')) for z in motor]),'motor_duration_s':avg([float(z.get('duration')) for z in motor]),'pedestrian_duration_s':avg([float(z.get('duration')) for z in people if z is not None]),'raw_contact_pairs':len(pairs),'seconds':time.monotonic()-tick,'demand_sha256':hashlib.sha256((p/'demand.rou.xml').read_bytes()).hexdigest(),'path':str(p.relative_to(ROOT))}
 pd.DataFrame([{'id':v,**z} for v,z in person_stats.items()]).to_csv(p/'crossing_passages.csv',index=False);(p/'wrong_crossings.json').write_text(json.dumps(cross_errors));(p/'result.json').write_text(json.dumps(result,indent=2))
 if record:(p/'animation.json').write_text(json.dumps({'site':site,'layout':phase,'frames':frames},separators=(',',':')))
 return result

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');ap.add_argument('--fine',action='store_true');ap.add_argument('--workers',type=int,default=2);args=ap.parse_args();d=pd.read_csv(ROOT/'data/sumo_v02/junction_demand_15min.csv');sessions=sorted(d.session_id.unique())
 if args.pilot:sessions=[s for s in sessions if s.startswith('2023-05-18') and s.endswith('14:00')]
 if args.fine:sessions=[s for s in sessions if s.startswith('2023-05-18') and (s.endswith('07:00') or s.endswith('14:00'))]
 seeds=SEEDS[:1] if args.pilot else SEEDS[:2] if args.fine else SEEDS
 tasks=[(s,ph,seed,.1 if args.fine else .2,args.pilot) for s in sessions for seed in seeds for ph in ['before','pilot']]
 name='pilot' if args.pilot else 'fine' if args.fine else 'main';pd.DataFrame(tasks,columns=['session','layout','seed','step','record']).to_csv(OUT/(name+'_schedule.csv'),index=False);results=[];errors=[]
 with ProcessPoolExecutor(max_workers=args.workers) as pool:
  jobs={pool.submit(run,t):t for t in tasks}
  for job in as_completed(jobs):
   try:
    z=job.result();results.append(z);print(json.dumps({k:z[k] for k in ['site','layout','session_id','seed','complete','wrong_crossing_count','raw_contact_pairs','seconds']}),flush=True)
   except Exception as e:errors.append({'task':jobs[job],'error':repr(e)});print(errors[-1],flush=True)
   pd.DataFrame(results).to_csv(OUT/(name+'_runs.csv'),index=False);(OUT/(name+'_errors.json')).write_text(json.dumps(errors,indent=2))
 if errors:raise RuntimeError(errors)
if __name__=='__main__':main()
