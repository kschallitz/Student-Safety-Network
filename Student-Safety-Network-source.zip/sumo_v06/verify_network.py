"""Verify compiled paths, not only the requested drawing."""
import json,math,xml.etree.ElementTree as E
import pandas as pd,sumolib
from shapely.geometry import LineString,Polygon
from shapely.ops import unary_union
from .network import OUT,ROOT,TRACE,xy

def main():
 checks=[];d=pd.read_csv(ROOT/'data/sumo_v02/junction_demand_15min.csv')
 def check(site,layout,test,key,value,ok):checks.append(dict(site=site,layout=layout,check=test,movement=key,value=value,passed=bool(ok)))
 for site in ['Estates','Hillcrest']:
  for layout in ['before','pilot']:
   p=OUT/'networks'/site/layout;spec=TRACE[site];r=E.parse(p/'network.net.xml').getroot();n=sumolib.net.readNet(str(p/'network.net.xml'),withInternal=True,withPedestrianConnections=True)
   blocks=unary_union([Polygon(xy(site,v[layout])) for v in spec['corners'].values()]+([Polygon(xy(site,v)) for v in spec['medians']] if layout=='pilot' else []))
   cs=r.findall('connection');external=[c for c in cs if not c.get('from').startswith(':') and c.get('via')];turns=json.loads((p/'path_audit.json').read_text())
   bykey={(c.get('from')[0],c.get('to')[0],int(c.get('fromLane')),int(c.get('toLane'))):c for c in external}
   successors={c.get('from')+'_'+c.get('fromLane'):c for c in cs if c.get('from').startswith(':')}
   for t in turns:
    key=(t['from_arm'],t['to_arm'],t['from_lane'],t['to_lane']);c=bykey[key];lane=c.get('via');coords=[];segments=[]
    while lane:
     segments.append(lane);coords.extend(n.getLane(lane).getShape());nxt=successors[lane];lane=nxt.get('via')
    curve=LineString(coords);expected=LineString(t['path_xy']);err=curve.hausdorff_distance(expected);label=str(key)
    check(site,layout,'compiled_path_matches_trace_constrained_path',label,err,err<.03)
    clear=curve.distance(blocks);required=1.05 if t['turn']=='t' else 1.3;check(site,layout,'compiled_centerline_boundary_clearance_m',label,clear,clear>=required-.015)
    a=n.getLane(c.get('from')+'_'+c.get('fromLane'));b=n.getLane(c.get('to')+'_'+c.get('toLane'))
    gaps=[math.dist(a.getShape()[-1],coords[0]),math.dist(coords[-1],b.getShape()[0])]
    check(site,layout,'compiled_path_endpoint_continuity_m',label,max(gaps),max(gaps)<.04)
   motor=d[d.site.eq(site)&~d['mode'].eq('pedestrian')&d['count'].gt(0)]
   for (a,b),rows in motor.groupby(['from_arm','to_arm']):
    found=[c for c in external if c.get('from')[0]==a and c.get('to')[0]==b];check(site,layout,'observed_motor_movement_connected',a+'->'+b,len(found),bool(found))
    if site=='Hillcrest':
     phases=r.find('tlLogic').findall('phase');green=any(any(ph.get('state')[int(c.get('linkIndex'))] in 'Gg' for ph in phases) for c in found);check(site,layout,'observed_movement_receives_green',a+'->'+b,green,green)
   if site=='Hillcrest':
    logic=r.findall('tlLogic');cycle=sum(float(z.get('duration')) for z in logic[0].findall('phase'));check(site,layout,'only_intended_94_second_signal_program','signal',cycle,len(logic)==1 and logic[0].get('programID')=='same_historical_prior' and cycle==94)
 out=pd.DataFrame(checks);out.to_csv(OUT/'compiled_network_checks.csv',index=False);bad=out[~out.passed];print(json.dumps({'checks':len(out),'failed':bad.to_dict('records')},indent=2));assert not len(bad)
if __name__=='__main__':main()
