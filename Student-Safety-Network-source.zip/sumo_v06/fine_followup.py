"""Expand the flagged Estates AM numerical check from two to all eight seeds."""
from concurrent.futures import ProcessPoolExecutor
import pandas as pd
from .replay import run,SEEDS
from .network import OUT

def main():
 d=pd.read_csv(OUT/'fine_runs.csv');tasks=[('2023-05-18_Estates St_07:00',phase,seed,.1,False) for seed in SEEDS[2:] for phase in ['before','pilot']]
 with ProcessPoolExecutor(max_workers=2) as p:extra=list(p.map(run,tasks))
 allruns=pd.concat([d,pd.DataFrame(extra)],ignore_index=True);assert len(allruns)==28 and not allruns.duplicated(['session_id','layout','seed']).any();allruns.to_csv(OUT/'fine_runs_extended.csv',index=False);print('Expanded fine-step checks:',len(allruns))
if __name__=='__main__':main()
