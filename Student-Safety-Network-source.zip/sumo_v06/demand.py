"""Native count replay, preserved from v03; no GIS dependency required."""
import json,xml.etree.ElementTree as E
from pathlib import Path
import pandas as pd,numpy as np
ROOT=Path(__file__).resolve().parents[1]
def xml(x,p):E.indent(x);E.ElementTree(x).write(p,encoding="utf-8",xml_declaration=True)

def chain(n,eid,direction,minlength=110):
 e=n.getEdge(eid);path=[e];length=e.getLength()
 while length<minlength:
  candidates=e.getIncoming() if direction=='in' else e.getOutgoing()
  same=[v for v in candidates if not v.getFunction() and v.getName()==e.getName() and v.allows('passenger') and v not in path and ((direction=='in' and v.getFromNode()!=e.getToNode()) or (direction=='out' and v.getToNode()!=e.getFromNode()))]
  # Avoid traversing another multi-road motor junction just to lengthen a route.
  if len(same)!=1:break
  e=same[0];path.append(e);length+=e.getLength()
 if direction=='in':path.reverse()
 return path

def make_demand(rows,seed,p,n,ports):
 rng=np.random.default_rng(seed);root=E.Element('routes');site=rows.iloc[0].site;port=ports[site];model=json.loads((ROOT/'outputs/sumo_v02/calibration.json').read_text())
 for typ,extra in [('passenger',{'vClass':'passenger','length':'5','accel':'2.6','decel':'4.5'}),('heavy',{'vClass':'truck','length':'10','accel':'1.3','decel':'4'}),('bicycle',{'vClass':'bicycle','length':'1.6','maxSpeed':'5.56','accel':'1.2','decel':'3'}),('walker',{'vClass':'pedestrian','maxSpeed':'1.4'})]:
  E.SubElement(root,'vType',id=typ,**extra,speedDev='0',**({} if typ=='walker' else {'tau':'1.2','minGap':'2.5'}))
 rows=rows.copy();start=pd.to_datetime(rows.interval_start).min();rows['offset']=(pd.to_datetime(rows.interval_start)-start).dt.total_seconds()+900
 warm=rows[rows.offset.eq(900)].copy();warm['offset']=0;both=pd.concat([warm,rows]);els=[];seq=0;routes={};audit=[]
 for _,r in both.iterrows():
  if int(r['count'])==0:continue
  key=(r['mode'],r.from_arm,r.to_arm,r.crossing_leg)
  if r['mode']!='pedestrian' and key not in routes:
   a,b=port[r.from_arm]['in'],port[r.to_arm]['out'];mid,cost=n.getShortestPath(n.getEdge(a),n.getEdge(b),vClass='bicycle' if r['mode']=='bicycle' else 'truck' if r['mode']=='heavy' else 'passenger')
   if not mid or not any(e.getToNode().getID()==site for e in mid):raise ValueError(f'Movement not routed through required junction: {key}')
   path=chain(n,a,'in')[:-1]+list(mid)+chain(n,b,'out')[1:];routes[key]=[e.getID() for e in path]
   audit.append({'site':site,'mode':r['mode'],'from_arm':r.from_arm,'to_arm':r.to_arm,'edges':' '.join(routes[key])})
  for _ in range(int(r['count'])):
   depart=float(r.offset+rng.uniform(0,900));prefix='w' if r.offset==0 else 's';vid=f'{prefix}{seq}';seq+=1
   if r['mode']=='pedestrian':
    leg=r.crossing_leg;forward=bool(rng.random()<.5)
    if leg in port:a,b=port[leg]['in'],port[leg]['out']
    elif site=='Estates' and leg=='S':a,b=port['W']['in'],port['E']['out']
    else:raise ValueError(f'Unknown pedestrian leg {site} {leg}')
    if not forward:a,b=b,a
    la=n.getEdge(a).getLength();lb=n.getEdge(b).getLength()
    # Start/end near the selected junction. Reversing walk order doesn't reverse edge coordinates.
    dep=max(.1,la-8) if n.getEdge(a).getToNode().getID()==site else min(8,la-.1)
    arr=min(8,lb-.1) if n.getEdge(b).getFromNode().getID()==site else max(.1,lb-8)
    z=E.Element('person',id=vid+'_ped_'+leg,type='walker',depart=f'{depart:.3f}',departPos=str(dep));E.SubElement(z,'walk',edges=f'{a} {b}',arrivalPos=str(arr))
   else:
    dr='eastbound' if r.from_arm=='W' else 'westbound' if r.from_arm=='E' else None
    factor=max(.2,rng.normal(model[dr]['desired_mean_mph'],model[dr]['desired_sd_mph'])/30) if dr else float(np.clip(rng.normal(1,.1),.7,1.3))
    z=E.Element('vehicle',id=vid+'_'+r['mode'],type=r['mode'],depart=f'{depart:.3f}',departLane='best',departSpeed='max',speedFactor='1' if r['mode']=='bicycle' else str(factor));E.SubElement(z,'route',edges=' '.join(routes[key]))
   els.append((depart,z))
 for _,z in sorted(els,key=lambda v:v[0]):root.append(z)
 xml(root,p/'demand.rou.xml');pd.DataFrame(audit).to_csv(p/'route_audit.csv',index=False);return int(rows['count'].sum()),len(els)
