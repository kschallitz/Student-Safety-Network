"""Independent geometry assertions and source/trajectory overlays."""
import json,math,xml.etree.ElementTree as E
import numpy as np,pandas as pd,sumolib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as Patch
from shapely.geometry import Polygon,LineString
from .network import ROOT,OUT,DATA,TRACE,SCALE,xy

def main():
 rows=[];checks=[]
 for site in ['Estates','Hillcrest']:
  spec=TRACE[site];fig,axes=plt.subplots(1,2,figsize=(14,7),constrained_layout=True)
  for ax,phase in zip(axes,['before','pilot']):
   p=OUT/'networks'/site/phase;n=sumolib.net.readNet(str(p/'network.net.xml'),withInternal=True,withPedestrianConnections=True);rt=E.parse(p/'network.net.xml').getroot();cross={e.get('crossingEdges').split()[0][0]:e for e in rt.findall('edge') if e.get('function')=='crossing'}
   for a,c in spec['crossings'].items():
    points=xy(site,c[phase]);length=math.dist(*points);edge=cross[a];actual=float(edge.find('lane').get('length'));err=abs(length-actual)
    checks.append({'site':site,'layout':phase,'check':'crossing_length', 'arm':a,'error_m':err,'pass':err<.03})
    rows.append({'site':site,'layout':phase,'leg':a,'source_pdf_page':spec['page'],'source_url':TRACE['source_url'],'source_pixel_endpoints':json.dumps(c[phase]),'length_m':length,'sumo_length_m':actual,'length_ft':length/.3048,'endpoint_sensitivity_m':.6,'scale_sensitivity_pct':3,'measurement_status':'derived from scaled aerial trace; not field survey','date_status':TRACE['date_status'],'notes':c.get('status','Retained curb for before; visible pilot edge for after')})
    ax.plot(*points.T,lw=5,color='#117b89');mid=points.mean(axis=0);ax.text(*mid,f'{a} {length:.1f} m',fontsize=9,bbox=dict(facecolor='white',alpha=.8,edgecolor='none'))
   for key,corner in spec['corners'].items():ax.add_patch(Patch(xy(site,corner[phase]),facecolor='#e4c995' if phase=='pilot' else '#d4d8dc',edgecolor='#8b744b'))
   if phase=='pilot':
    for poly in spec['medians']:ax.add_patch(Patch(xy(site,poly),facecolor='#e4c995',edgecolor='#8b744b'))
   paths=json.loads((p/'path_audit.json').read_text())
   for z in paths:
    q=np.array(z['path_xy']);ax.plot(*q.T,color='#b53b49' if z['turn']=='r' else '#58758d',lw=1.4,alpha=.65)
   # Every explicit vehicular connection must begin/end on the corresponding lane.
   for z in rt.findall('connection'):
    if z.get('from','').startswith(':') or not z.get('via'):continue
    a=n.getLane(z.get('from')+'_'+z.get('fromLane'));b=n.getLane(z.get('via'));gap=math.dist(a.getShape()[-1],b.getShape()[0]);checks.append({'site':site,'layout':phase,'check':'lane_connection_continuity','arm':z.get('from')+'->'+z.get('to'),'error_m':gap,'pass':gap<.04})
   ax.set(xlim=(222,277) if site=='Hillcrest' else (231,269),ylim=(229,272),aspect='equal',title=f'{site}: {"before pilot" if phase=="before" else "documented pilot"}',xlabel='Local metres',ylabel='Local metres');ax.grid(alpha=.15)
  fig.suptitle('Source-traced crossing endpoints and simulated vehicle paths',fontsize=16);fig.savefig(OUT/f'geometry_{site}.png',dpi=160);plt.close(fig)
  # Trace overlay is a source-verification figure, not a fabricated after photograph.
  img=plt.imread(OUT/(site.lower()+'_aerial.png'));fig,ax=plt.subplots(figsize=(12,8));ax.imshow(img)
  for a,c in spec['crossings'].items():
   for ph,col in [('before','#15c2e0'),('pilot','#ef6e18')]:q=np.array(c[ph]);ax.plot(q[:,0],q[:,1],color=col,lw=3,marker='o',ms=4)
   q=np.array(c['pilot']);ax.text(*q.mean(axis=0),a,fontsize=12,bbox=dict(facecolor='white',alpha=.9))
  ax.set_xlim((480,1150) if site=='Estates' else (930,1610));ax.set_ylim(930,180);ax.set_title(f'{site}: cyan = retained curb; orange = pilot crossing\nTrace-derived dimensions; aerial capture date unspecified');ax.axis('off');fig.savefig(OUT/f'source_trace_{site}.png',dpi=150,bbox_inches='tight');plt.close(fig)
 pd.DataFrame(rows).to_csv(OUT/'geometry_measurements.csv',index=False);pd.DataFrame(checks).to_csv(OUT/'geometry_checks.csv',index=False)
 failures=[r for r in checks if not r['pass']];print(json.dumps({'checks':len(checks),'failures':failures},indent=2))
 if failures:raise RuntimeError('Geometry continuity/length check failed')
if __name__=='__main__':main()
