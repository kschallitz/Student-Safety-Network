"""Retain original raster imagery; remove future-design overlay objects, not photo content.
Run with Python having pypdf and Poppler's pdftoppm installed.
"""
from pathlib import Path
import subprocess,json,hashlib
from pypdf import PdfReader,PdfWriter
from pypdf.generic import ContentStream,NameObject
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/sumo_v06';SRC=ROOT/'data/sumo_v06/raw/permanent_treatments_april_2025.pdf'
r=PdfReader(SRC);records=[]
for site,num in [('estates',18),('hillcrest',21)]:
 p=r.pages[num-1];stream=ContentStream(p.get_contents(),r);objects=p['/Resources']['/XObject']
 selected=[name for name,obj in objects.items() if obj.get_object().get('/Subtype')=='/Image' and obj.get_object().get('/Width',0)>5000 and obj.get_object().get('/Height',0)>100]
 stream.operations=[(args,op) for args,op in stream.operations if op in (b'q',b'Q',b'cm') or (op==b'Do' and args[0] in selected)]
 p[NameObject('/Contents')]=stream
 if '/Annots' in p:del p['/Annots']
 w=PdfWriter();w.add_page(p);w.write(OUT/f'{site}_aerial.pdf')
 subprocess.run(['pdftoppm','-scale-to','1800','-png','-singlefile',str(OUT/f'{site}_aerial.pdf'),str(OUT/f'{site}_aerial')],check=True)
 records.append({'site':site,'pdf_page':num,'retained_image_objects':selected,'method':'Retain large source raster XObjects with original page transforms; omit vector annotations, forms, and small overlay rasters. No image synthesis.','scale':'Original rotated sheet width 2448 points; 1 inch = 10 feet'})
(OUT/'source_manifest.json').write_text(json.dumps({'source':'https://library.livermoreca.gov/home/showpublisheddocument/12945/638887914731000000','sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'date':'2025-04-03','aerial_capture_date':'not specified','records':records},indent=2))
