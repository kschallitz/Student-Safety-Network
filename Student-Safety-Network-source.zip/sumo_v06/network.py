"""Build source-traced geometry; do not use collision outcomes to choose geometry."""
import json,math,subprocess,xml.etree.ElementTree as E
from pathlib import Path
import numpy as np,pandas as pd,sumolib
from shapely.geometry import Polygon,LineString
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/sumo_v06';DATA=ROOT/'data/sumo_v06'
TRACE=json.loads((DATA/'traces.json').read_text());SCALE=TRACE['metres_per_pixel'];MPH=.44704
D={'E':np.array([1.,0.]),'W':np.array([-1.,0.]),'N':np.array([0.,1.]),'S':np.array([0.,-1.])}
RIGHT={'E':'N','N':'W','W':'S','S':'E'};OPP={'E':'W','W':'E','N':'S','S':'N'}
def xy(s,pts):
 a=np.array(pts,dtype=float)-TRACE[s]['origin'];a[:,1]*=-1;return a*SCALE+250

def shape(pts):return ' '.join(f'{x:.4f},{y:.4f}' for x,y in pts)
def xml(x,p):E.indent(x);E.ElementTree(x).write(p,encoding='utf-8',xml_declaration=True)
def bezier(p0,p3,di,do,k):
 # Tangent intersection supplies control lengths, with exact endpoint continuity.
 a=np.column_stack([di,-do]);ts=np.linalg.solve(a,p3-p0);p1=p0+di*ts[0]*k;p2=p3-do*(-ts[1])*k
 t=np.linspace(0,1,101)[:,None];return (1-t)**3*p0+3*(1-t)**2*t*p1+3*(1-t)*t*t*p2+t**3*p3

def curve(p0,p3,arm,target,blocks):
 di=-D[arm];do=D[target]
 if target==OPP[arm]:
  t=np.linspace(0,1,101)[:,None];q=p0*(1-t)+p3*t
  if LineString(q).distance(blocks)>=1.3:return q,1.,LineString(q).distance(blocks)
  # Offset opposing approaches need an S curve, not a chord across a corner.
  length=abs((p3-p0)@di);candidates=[]
  for k1 in np.linspace(.05,.95,61):
   for k2 in np.linspace(.05,.95,61):
    p1=p0+di*length*k1;p2=p3-do*length*k2
    q=(1-t)**3*p0+3*(1-t)**2*t*p1+3*(1-t)*t*t*p2+t**3*p3
    candidates.append(([float(k1),float(k2)],q))
 else:candidates=[(float(k),bezier(p0,p3,di,do,k)) for k in np.linspace(.25,1.2,191)]
 good=[]
 for k,q in candidates:
  line=LineString(q);clear=line.distance(blocks)
  if clear<1.3:continue
  delta=np.diff(q,axis=0);head=np.unwrap(np.arctan2(delta[:,1],delta[:,0]));curv=np.abs(np.diff(head))/np.maximum((np.linalg.norm(delta,axis=1)[1:]+np.linalg.norm(delta,axis=1)[:-1])/2,1e-6)
  good.append((float(curv.max()),q,k,clear))
 if not good:raise ValueError(f'No boundary-clear path {arm}->{target}, {p0}->{p3}')
 _,q,k,clear=min(good,key=lambda v:v[0]);return q,k,clear

def build(site,phase):
 from shapely.ops import unary_union
 p=OUT/'networks'/site/phase;p.mkdir(parents=True,exist_ok=True);spec=TRACE[site]
 blocks=unary_union([Polygon(xy(site,z[phase])) for z in spec['corners'].values()]+([Polygon(xy(site,z)) for z in spec['medians']] if phase=='pilot' else []))
 bounds={a:xy(site,[v['in'][0]])[0] for a,v in spec['arms'].items()};west,east,south,north=bounds['W'][0],bounds['E'][0],bounds['S'][1],bounds['N'][1]
 nodes=E.Element('nodes');E.SubElement(nodes,'node',id=site,x='250',y='250',type='traffic_light' if site=='Hillcrest' else 'priority_stop',shape=shape([(west,south),(east,south),(east,north),(west,north)]))
 edges=E.Element('edges');connections=E.Element('connections');lanes={};ports={};audits=[]
 for arm,s in spec['arms'].items():
  endpoint=xy(site,[s['in'][0]])[0]+D[arm]*220;E.SubElement(nodes,'node',id=arm,x=str(endpoint[0]),y=str(endpoint[1]),type='dead_end');ports[arm]={}
  for dr in ['in','out']:
   eid=f'{arm}_{dr}';ports[arm][dr]=eid;inbound=dr=='in';points=xy(site,s[dr]);walk=xy(site,[s['sidewalk_'+dr]])[0];start=points.mean(axis=0)+D[arm]*220;end=points.mean(axis=0)
   pair=[start,end] if inbound else [end,start]
   ed=E.SubElement(edges,'edge',id=eid,**{'from':arm if inbound else site,'to':site if inbound else arm},name='East Avenue' if arm in ['E','W'] else site,priority='3' if arm in ['E','W'] else '1',numLanes=str(len(points)+1),speed=str(30*MPH if arm in ['E','W'] else 25*MPH),shape=shape(pair),spreadType='center')
   # Explicit lane centerlines retain measured shoulders and side-street offset.
   for i,pt in enumerate([walk,*points]):
    distant=pt+D[arm]*220;lanepts=[distant,pt] if inbound else [pt,distant];E.SubElement(ed,'lane',index=str(i),shape=shape(lanepts),width='2.0' if i==0 else '3.1',allow='pedestrian' if i==0 else 'passenger truck bicycle bus delivery emergency');lanes[(arm,dr,i)]=pt
 for arm,s in spec['arms'].items():
  for target in spec['arms']:
   if target==arm:
    i=len(s['in']);j=len(spec['arms'][target]['out']);p0=lanes[(arm,'in',i)];p3=lanes[(target,'out',j)];best=[]
    for reach in np.linspace(6,50,177):
     t=np.linspace(0,1,101)[:,None];p1=p0-D[arm]*reach;p2=p3-D[arm]*reach;q=(1-t)**3*p0+3*(1-t)**2*t*p1+3*(1-t)*t*t*p2+t**3*p3
     clear=LineString(q).distance(blocks)
     if clear>=1.05:best.append((reach,q,clear))
    if best:
     reach,q,clear=best[0];E.SubElement(connections,'connection',**{'from':f'{arm}_in','to':f'{target}_out','fromLane':str(i),'toLane':str(j),'shape':shape(q),'visibility':'30','speed':'2.5'});audits.append({'site':site,'phase':phase,'from_arm':arm,'to_arm':target,'from_lane':i,'to_lane':j,'turn':'t','clearance_m':clear,'path_xy':q.tolist()})
    continue
   if site=='Estates' and (arm=='S' or target=='S'):continue
   turn='s' if target==OPP[arm] else 'r' if target==RIGHT[arm] else 'l'
   n=len(s['in']);m=len(spec['arms'][target]['out'])
   if turn=='s':mapping=[(i,min(i,m)) for i in range(1,min(n,m)+1)]
   elif turn=='r':mapping=[(1,1)]
   else:mapping=[(n,m)]
   for i,j in mapping:
    q,k,clear=curve(lanes[(arm,'in',i)],lanes[(target,'out',j)],arm,target,blocks)
    delta=np.diff(q,axis=0);head=np.unwrap(np.arctan2(delta[:,1],delta[:,0]));curv=np.abs(np.diff(head))/np.maximum((np.linalg.norm(delta,axis=1)[1:]+np.linalg.norm(delta,axis=1)[:-1])/2,1e-6);cap=min(30*MPH,float(np.sqrt(1.8/max(curv.max(),1e-6)))) if curv.max()>1e-6 else 30*MPH
    E.SubElement(connections,'connection',**{'from':f'{arm}_in','to':f'{target}_out','fromLane':str(i),'toLane':str(j),'shape':shape(q),'visibility':'30','speed':str(cap)})
    audits.append({'site':site,'phase':phase,'from_arm':arm,'to_arm':target,'from_lane':i,'to_lane':j,'turn':turn,'clearance_m':clear,'bezier_control_fraction':k,'speed_cap_mps':cap,'path_xy':q.tolist()})
 for arm,c in spec['crossings'].items():
  q=xy(site,c[phase]);# Counterclockwise: E south->north; N east->west; W north->south; S west->east.
  if arm in ['E','N']:q=q[::-1]
  E.SubElement(connections,'crossing',node=site,edges=f'{arm}_in {arm}_out',priority='false' if site=='Estates' and arm in ['W','S'] else 'true',shape=shape(q),width=str(c['width_px']*SCALE))
 xml(nodes,p/'nodes.xml');xml(edges,p/'edges.xml');xml(connections,p/'connections.xml')
 args=[sumolib.checkBinary('netconvert'),'-n',str(p/'nodes.xml'),'-e',str(p/'edges.xml'),'-x',str(p/'connections.xml'),'-o',str(p/'network.net.xml'),'--walkingareas','true','--no-turnarounds','true','--junctions.limit-turn-speed','1.8','--junctions.limit-turn-speed.min-angle','0','--junctions.corner-detail','12','--junctions.internal-link-detail','20','--offset.disable-normalization','true']
 run=subprocess.run(args,text=True,capture_output=True);(p/'build.log').write_text(run.stdout+run.stderr)
 if run.returncode:raise RuntimeError(run.stderr)
 # Rebuild yielding relationships for the actual g/G plan, as required by SUMO.
 if site=='Hillcrest':
  from .replay import signals
  signals(p/'network.net.xml',site,p)
  cmd=[sumolib.checkBinary('netconvert'),'-s',str(p/'network.net.xml'),'--tllogic-files',str(p/'control.add.xml'),'-o',str(p/'controlled.net.xml'),'--offset.disable-normalization','true']
  c=subprocess.run(cmd,text=True,capture_output=True);(p/'control_build.log').write_text(c.stdout+c.stderr)
  if c.returncode:raise RuntimeError(c.stderr)
  final=E.parse(p/'controlled.net.xml').getroot()
  for z in list(final.findall('tlLogic')):
   if z.get('programID')!='same_historical_prior':final.remove(z)
  xml(final,p/'network.net.xml')
 (p/'path_audit.json').write_text(json.dumps(audits,indent=2));(p/'ports.json').write_text(json.dumps({site:ports},indent=2));return p
if __name__=='__main__':
 for site in ['Estates','Hillcrest']:
  for phase in ['before','pilot']:
   try:print(build(site,phase))
   except Exception as ex:print(site,phase,repr(ex));raise
