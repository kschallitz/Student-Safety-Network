"""Package the reviewed layout lab, leaving other map features intact."""
import json,shutil,xml.etree.ElementTree as E
import pandas as pd
from .network import ROOT,OUT,TRACE,xy
from website_release import version

def main():
 dest=ROOT/'hosted_map/out';summary=json.loads((OUT/'summary.json').read_text());assert all(summary['implementation_checks'].values())
 def records(name):return json.loads(pd.read_csv(OUT/name).to_json(orient='records'))
 data={'summary':summary,'results':records('paired_results.csv'),'crossings':records('crossing_changes.csv'),'sessions':records('observed_sessions.csv'),'source':TRACE['source_url'],'networks':{}}
 for s in ['Estates','Hillcrest']:
  data['networks'][s]={}
  for ph in ['before','pilot']:
   rt=E.parse(OUT/'networks'/s/ph/'network.net.xml').getroot();lanes=[];cross=[]
   for e in rt.findall('edge'):
    for l in e.findall('lane'):
     q={'shape':[[float(v) for v in p.split(',')] for p in l.get('shape').split()],'width':float(l.get('width','3.1')),'ped':l.get('allow')=='pedestrian','kind':e.get('function','road')};lanes.append(q)
     if e.get('function')=='crossing':cross.append(q)
   spec=TRACE[s];data['networks'][s][ph]={'lanes':lanes,'crossings':cross,'blocks':[xy(s,v[ph]).tolist() for v in spec['corners'].values()]+([xy(s,v).tolist() for v in spec['medians']] if ph=='pilot' else [])}
   rows=pd.read_csv(OUT/'pilot_runs.csv');p=ROOT/rows[rows.site.eq(s)&rows.layout.eq(ph)].iloc[0].path/'animation.json';a=json.loads(p.read_text());assert len(a['frames'])==181;shutil.copyfile(p,dest/f'east-layout-replay_{s}_{ph}.json')
 old=dest/'east-avenue-lab.html';archive=dest/'east-avenue-speed-lab-v012.html'
 if not archive.exists():shutil.copyfile(old,archive)
 html=(ROOT/'sumo_v06/lab.html').read_text().replace('__SITE_VERSION__',version()).replace('__LAYOUT_DATA__',json.dumps(data,separators=(',',':'),allow_nan=False).replace('</','<\\/'));old.write_text(html)
 for file in ['observed_15min_counts.csv','crossing_changes.csv','paired_results.csv','main_runs.csv','numerical_check.csv','contact_diagnostics.csv','source_trace_Estates.png','source_trace_Hillcrest.png','geometry_Estates.png','geometry_Hillcrest.png']:
  shutil.copyfile(OUT/file,dest/('east-layout-'+file))
 shutil.copyfile(ROOT/'sumo_v06/protocol.md',dest/'east-layout-protocol.md')
 for f in ['East_Avenue_Physical_Layout.ipynb','East_Avenue_Physical_Layout.zip']:
  if (ROOT/f).exists():shutil.copyfile(ROOT/f,dest/f)
 print(old)
if __name__=='__main__':main()
