"""Auditable TIMS intake. Keeps crash and victim grains separate; no model fitting."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import pandas as pd

REGIONS = {"alameda": 14149, "tracy": 360}
AGE_MIN, AGE_MAX = 5, 18
CODEBOOK = "https://tims.berkeley.edu/help/crashdata/switrs-codebook.php"


def read_strings(path):
    frame = pd.read_csv(path, dtype="string")
    frame.columns = frame.columns.str.strip()
    return frame.apply(lambda col: col.str.strip())


def prepare_victims(victims):
    v = victims.copy()
    age = pd.to_numeric(v["VICTIM_AGE"], errors="coerce")
    v["age_years"] = age.where(age.between(0, 125)).astype("Int64")
    # SWITRS age 0 is valid. Codes 998 (not stated) and 999 (fatal fetus)
    # are not literal ages. Keep the raw field and leave the band unknown.
    v["school_age_5_18"] = v.age_years.between(AGE_MIN, AGE_MAX).astype("boolean")
    v["pedestrian_or_bicyclist"] = v.VICTIM_ROLE.isin(["3", "4"])
    v["victim_role_label"] = v.VICTIM_ROLE.map({"1": "driver", "2": "passenger",
        "3": "pedestrian", "4": "bicyclist", "5": "other", "6": "non-injured party"})
    v["injury_level_harmonized"] = v.VICTIM_DEGREE_OF_INJURY.map({
        "0": "no injury", "1": "fatal", "2": "serious", "5": "serious",
        "3": "minor/visible", "6": "minor/visible", "4": "possible/pain", "7": "possible/pain"})
    v["injured_or_killed"] = v.VICTIM_DEGREE_OF_INJURY.isin(list("1234567"))
    return v


def summarize_victims(v):
    """One row per case; unknown ages do not become negative labels."""
    base = v.groupby("CASE_ID").size().rename("victim_rows").to_frame()
    pb = v[v.pedestrian_or_bicyclist].copy()
    pb["known_school_age"] = pb.school_age_5_18.fillna(False)
    pb["school_age_injured"] = pb.known_school_age & pb.injured_or_killed
    pb["age_unknown"] = pb.age_years.isna()
    g = pb.groupby("CASE_ID").agg(
        pedbike_victim_rows=("CASE_ID", "size"),
        pedbike_victims_age_unknown=("age_unknown", "sum"),
        pedbike_victims_age_5_18=("known_school_age", "sum"),
        injured_pedbike_victims_age_5_18=("school_age_injured", "sum"),
    )
    out = base.join(g)
    cols = list(g.columns)
    out[cols] = out[cols].fillna(0).astype(int)
    flag = out.pedbike_victims_age_5_18.gt(0).astype("boolean")
    unknown = flag.eq(False) & ((out.pedbike_victim_rows == 0) | (out.pedbike_victims_age_unknown > 0))
    out["recorded_pedbike_age_5_18"] = flag.mask(unknown, pd.NA)
    return out.reset_index()


def prepare_tims_exports(raw, output):
    raw, output = Path(raw), Path(output)
    output.mkdir(parents=True, exist_ok=True)
    crash_frames, victim_frames, files = [], [], []
    for region, expected in REGIONS.items():
        for kind in ["crashes", "victims"]:
            p = raw / f"{region}_pedbike_{kind}_2014_2025.csv"
            frame = read_strings(p)
            frame["export_region"] = region
            files.append({"file": p.name, "bytes": p.stat().st_size,
                "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
                "saved_at_utc": datetime.fromtimestamp(p.stat().st_mtime, timezone.utc).isoformat(),
                "rows": len(frame), "source_url": "https://tims.berkeley.edu/tools/query/",
                "query": {"start_date": "2014-01-01", "end_date": "2025-12-31",
                          "county": "Alameda" if region == "alameda" else "San Joaquin",
                          "city": "All" if region == "alameda" else "Tracy",
                          "party_type_OR": ["2 - Pedestrian", "4 - Bicyclist"],
                          "age_filter": None, "export": kind}})
            if kind == "crashes":
                assert len(frame) == expected, f"{region}: CSV differs from observed query total"
                crash_frames.append(frame)
            else:
                victim_frames.append(frame)
    c, v = pd.concat(crash_frames, ignore_index=True), pd.concat(victim_frames, ignore_index=True)
    assert c.CASE_ID.notna().all() and c.CASE_ID.is_unique
    assert not v.duplicated(["CASE_ID", "PARTY_NUMBER", "VICTIM_NUMBER"]).any()
    assert set(v.CASE_ID) == set(c.CASE_ID), "Missing cases or orphan victim rows"
    ped = c.PEDESTRIAN_ACCIDENT.eq("Y").fillna(False)
    bike = c.BICYCLE_ACCIDENT.eq("Y").fillna(False)
    assert (ped | bike).all(), "Crash outside selected mode union"
    c["pedestrian_involved"], c["bicycle_involved"] = ped, bike
    c["collision_date"] = pd.to_datetime(c.COLLISION_DATE, errors="coerce")
    assert c.collision_date.between("2014-01-01", "2025-12-31").all()
    c["year"] = c.collision_date.dt.year
    c["provisional_year"] = c.year.ge(2024)
    time = pd.to_numeric(c.COLLISION_TIME, errors="coerce")
    clock_valid = time.between(0, 2359) & (time % 100).lt(60) & time.mod(1).eq(0)
    c["hour"] = (time // 100).where(clock_valid).astype("Int64")
    c["time_band"] = pd.cut(c.hour.astype(float), [-1, 5, 8, 13, 17, 21, 23],
        labels=["00:00–05:59", "06:00–08:59", "09:00–13:59", "14:00–17:59", "18:00–21:59", "22:00–23:59"])
    x, y = pd.to_numeric(c.POINT_X, errors="coerce"), pd.to_numeric(c.POINT_Y, errors="coerce")
    present = x.notna() & y.notna() & x.ne(0) & y.ne(0)
    plausible = x.between(-123, -120) & y.between(36, 39)
    c["coordinate_status"] = "missing_or_zero"
    c.loc[present, "coordinate_status"] = "outside_broad_region"
    c.loc[present & plausible, "coordinate_status"] = "passes_broad_region_screen"
    c["longitude"], c["latitude"] = x.where(plausible & present), y.where(plausible & present)
    c["geocode_available"] = present
    c["coordinate_screen_pass"] = plausible & present
    v = prepare_victims(v)
    c = c.merge(summarize_victims(v), on="CASE_ID", how="left", validate="one_to_one")
    assert len(c) == sum(REGIONS.values())
    annual = c.groupby("year").agg(crashes=("CASE_ID", "size"),
        coordinates_available=("geocode_available", "sum"),
        coordinates_screen_pass=("coordinate_screen_pass", "sum"),
        valid_time=("hour", "count"),
        recorded_age_5_18_cases=("recorded_pedbike_age_5_18", "sum"))
    cities = c.groupby(["COUNTY", "CITY"]).agg(crashes=("CASE_ID", "size"),
        coordinates_screen_pass=("coordinate_screen_pass", "sum"),
        valid_time=("hour", "count"),
        recorded_age_5_18_cases=("recorded_pedbike_age_5_18", "sum"))
    age_pb = v[v.pedestrian_or_bicyclist]
    summary = {
        "crashes": len(c), "victim_rows": len(v), "distinct_cases": c.CASE_ID.nunique(),
        "coordinates_present": int(present.sum()), "coordinates_screen_pass": int(c.coordinate_screen_pass.sum()),
        "coordinates_missing_or_zero": int((~present).sum()),
        "coordinates_outside_broad_region": int((present & ~plausible).sum()),
        "valid_time_cases": int(c.hour.notna().sum()),
        "pedestrian_involved_cases": int(ped.sum()), "bicycle_involved_cases": int(bike.sum()),
        "both_modes_cases": int((ped & bike).sum()),
        "pedbike_victim_rows": len(age_pb), "pedbike_victims_known_age": int(age_pb.age_years.notna().sum()),
        "pedbike_victims_age_5_18": int(age_pb.school_age_5_18.sum()),
        "pedbike_victims_age_18": int(age_pb.age_years.eq(18).sum()),
        "injured_pedbike_victims_age_5_18": int((age_pb.school_age_5_18.fillna(False)&age_pb.injured_or_killed).sum()),
        "cases_with_recorded_pedbike_age_5_18": int(c.recorded_pedbike_age_5_18.sum()),
        "cases_age_band_unknown": int(c.recorded_pedbike_age_5_18.isna().sum()),
        "school_age_definition": "Recorded victim age 5–18 inclusive; not confirmed enrollment or trip purpose",
        "victim_codebook": CODEBOOK,
        "crash_key": "SWITRS CASE_ID, not CCRS Collision Id",
        "coverage": "Reported injury/fatal crashes; excludes property-damage-only crashes",
        "geocode_limit": "Broad rectangle screen only; street/intersection matching remains unverified",
        "latest_years": "2024–2025 provisional per TIMS UI; partial 2026 excluded",
        "model_retrained": False,
    }
    c.to_csv(output / "regional_tims_crashes_2014_2025.csv", index=False)
    v.to_csv(output / "regional_tims_victims_2014_2025.csv", index=False)
    annual.to_csv(output / "coverage_by_year.csv")
    cities.to_csv(output / "coverage_by_city.csv")
    c.loc[~c.coordinate_screen_pass].to_csv(output / "coordinate_review_queue.csv", index=False)
    (output / "summary.json").write_text(json.dumps(summary, indent=2))
    (output / "source_manifest.json").write_text(json.dumps(files, indent=2))
    return c, v, annual, cities, summary


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw", default="data/tims/raw")
    parser.add_argument("--output", default="tims_intake_output")
    args = parser.parse_args()
    print(json.dumps(prepare_tims_exports(args.raw, args.output)[-1], indent=2))
