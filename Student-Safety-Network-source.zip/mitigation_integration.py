"""Join checked simulator evidence to a specific map site, without refitting either model."""
from pathlib import Path
import csv
import hashlib
import json
import io

ROOT = Path(__file__).resolve().parent


def read(relative):
    return json.loads((ROOT / relative).read_text())


def hillcrest_inputs():
    """Recover direct observations; old simulator outcomes are never inputs here."""
    path = ROOT / 'data/sumo_v02/junction_demand_15min.csv'
    with path.open() as f:
        rows = [r for r in csv.DictReader(f) if r['site'] == 'Hillcrest']
    raw = {}
    for name in ('turning_movements', 'nonmotorized_crossings'):
        with (ROOT / f'data/traffic_exposure/normalized/{name}.csv').open() as f:
            raw.update({r['observation_id']: r for r in csv.DictReader(f)})
    assert len(rows) == 2688 and len({r['interval_id'] for r in rows}) == 56
    summary, keys = {}, set()
    arms = {'E': 'East Avenue — east leg', 'W': 'East Avenue — west leg',
            'N': 'Hillcrest Avenue — north leg', 'S': 'Hillcrest Avenue — south leg'}
    incoming = dict(eastbound='W', westbound='E', northbound='S', southbound='N')
    destinations = {'UT': dict(E='E', W='W', N='N', S='S'),
                    'LT': dict(E='S', W='N', N='E', S='W'),
                    'TH': dict(E='W', W='E', N='S', S='N'),
                    'RT': dict(E='N', W='S', N='W', S='E')}
    url = 'https://www.livermoreca.gov/home/showpublisheddocument/12943/638887914440930000'
    output = io.StringIO(newline='')
    writer = csv.writer(output)
    writer.writerow(['intersection_id', 'intersection_name', 'count_date', 'start_local',
                     'duration_minutes', 'approach_road', 'destination_road_or_crossing_leg',
                     'mode', 'count', 'measurement_status', 'source', 'notes'])
    for r in rows:
        original = raw[r['source_observation']]
        assert original['site_name'] == 'East Ave / Hillcrest Ave'
        assert original['measurement_status'] == r['measurement_status'] == 'observed'
        assert original['eligible_for_automatic_aggregation'] == r['session_complete'] == 'True'
        assert original['interval_start'] == r['interval_start']
        if r['mode'] == 'pedestrian':
            assert r['crossing_leg'] == original['crossing_leg'][0].upper()
        else:
            arm = incoming[original['approach_direction']]
            movement = original['movement'].replace('_including_UT', '')
            assert r['from_arm'] == arm and r['to_arm'] == destinations[movement][arm]
        count = int(r['count'])
        expected = float(original['count'])
        if r['mode'] == 'passenger':
            heavy = raw[r['supporting_source_observation']]
            assert heavy['mode_or_class'] == 'heavy_vehicles_subset'
            assert heavy['measurement_status'] == 'observed' and heavy['eligible_for_automatic_aggregation'] == 'True'
            assert all(heavy[k] == original[k] for k in ('site_name', 'interval_start', 'movement', 'approach_direction'))
            expected -= float(heavy['count'])
        assert count == expected and count >= 0
        key = tuple(r[k] for k in ('interval_id', 'mode', 'from_arm', 'to_arm', 'crossing_leg'))
        assert key not in keys
        keys.add(key)
        day = summary.setdefault(r['date'], dict(date=r['date'], phase=r['phase'], intervals=set(),
                                               passenger=0, heavy=0, bicycle=0, pedestrian=0))
        day['intervals'].add(r['interval_id']); day[r['mode']] += count
        pedestrian = r['mode'] == 'pedestrian'
        notes = f"{r['phase']}; {r['processing_status']}; source observation {r['source_observation']}."
        if original.get('movement') == 'LT_including_UT':
            notes += ' Source groups bicycle left turns with U-turns; their split is unknown. Destination denotes the left-turn grouping, not a verified individual path.'
        if r['mode'] == 'passenger':
            notes += f" Motor total minus heavy subset {r['supporting_source_observation']}; do not add raw motor total again."
        if pedestrian:
            notes += ' Crossing-leg total; walking direction not recorded.'
        writer.writerow(['J02019', 'East Avenue / Hillcrest Avenue', r['date'], r['interval_start'][11:16],
                         15, 'Crossing' if pedestrian else arms[r['from_arm']],
                         arms[r['crossing_leg']] if pedestrian else arms[r['to_arm']],
                         r['mode'], count, 'observed', f"{url}#page={r['source_page']}", notes])
    assert all(sum(r['interval_id'] == key for r in rows) == 48 for key in {r['interval_id'] for r in rows})
    days = [{**d, 'intervals': len(d['intervals'])} for _, d in sorted(summary.items())]
    text = output.getvalue()
    geometry = read('data/metadrive_school/geometry.json')
    assert set(geometry['Hillcrest']['arms']) == {'N', 'S', 'E', 'W'}
    junction = next(j for j in read('intersection_prediction_output/map_payload.json')['junctions'] if j['id'] == 'J02019')
    assert junction['name'] == 'E AV / HILLCREST AV' and junction['city'] == 'LIVERMORE'
    metadata = dict(junctionId='J02019', ll=junction['ll'], name='East Avenue / Hillcrest Avenue',
                    kind='direct_observed_counts', intervalMinutes=15, intervals=56, rows=len(rows),
                    dates=days, totals={k: sum(d[k] for d in days) for k in ('passenger', 'heavy', 'bicycle', 'pedestrian')},
                    csvPath='hillcrest_observed_counts.csv', csvSha256=hashlib.sha256(text.encode()).hexdigest(),
                    sourceUrl=url, sourcePages=sorted({int(r['source_page']) for r in rows}),
                    inputSha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                    simulationReady=False, liveSimulationAvailable=False,
                    countLimitations=['Bicycle left-turn groups include U-turns; their split is unknown.',
                                      'Individual arrival seconds and pedestrian crossing direction are not recorded.',
                                      'The export contains 56 complete-session periods out of 64 recorded periods. The March 2, 4–6 pm session is excluded from this existing prepared subset because its 4:45 pm eastbound right-turn heavy-vehicle cell is blank (PDF page 163). Other observations in that session remain in the source tables; none are filled with zero.'],
                    geometryStatus='Before/pilot source tracing is available for four approaches and four crossings; MetaDrive routes are not built.',
                    controlStatus='Signalized. A historical phase structure is available; current timing is unverified and the MetaDrive signal controller is not implemented.',
                    speedStatus='Nearby corridor speed distributions are available; transferring them to Hillcrest is an assumption. Site yielding is not measured.',
                    remainingWork=['Build Hillcrest lane routes, including the observed heavy-vehicle U-turn.',
                                   'Implement and check signal phases, turning permissions and pedestrian clearance.',
                                   'Compare feasible treatments with matched arrivals; train and evaluate the site policy.',
                                   'Connect a simulation worker before enabling a live Run button.'])
    return metadata, text


def build_evidence():
    sources = {
        'episodes': 'outputs/metadrive_school/pilot_runs.csv',
        'policy': 'outputs/metadrive_school/pilot_policy_freeze.json',
        'quality': 'outputs/metadrive_school/pilot_quality.json',
        'evaluation': 'outputs/metadrive_school/pilot_evaluation.json',
        'geometry': 'data/metadrive_school/geometry.json',
        'candidates': 'data/metadrive_school/candidates.json',
    }
    policy, quality, evaluation = (read(sources[k]) for k in ('policy', 'quality', 'evaluation'))
    candidates = read(sources['candidates'])
    with (ROOT / sources['episodes']).open() as f:
        raw = list(csv.DictReader(f))
    assert len(raw) == quality['completed_runs'] == quality['planned_runs'] == 96
    assert quality['physics_fail_runs'] == 0 and quality['physics_pass_runs'] == len(raw)
    assert quality['software_checks_passed'] and quality['crossing_grid_passed']
    assert policy['recommendation_released'] and quality['recommendation_released']
    assert not policy['release_blockers'] and not quality['release_blockers']
    assert not policy['consultant_identity_used'] and not policy['test_outcomes_used']
    assert policy['scoring_version'] == quality['scoring_version'] == 'motor-vru-v1'
    assert hashlib.sha256((ROOT / sources['policy']).read_bytes()).hexdigest() == evaluation['policy_freeze_sha256']
    assert not quality['bicycle_near_misses_measured']
    ids = {c['id'] for c in candidates}
    episodes, keys = [], set()
    for r in raw:
        key = (r['context_id'], r['action'])
        assert key not in keys and r['action'] in ids
        keys.add(key)
        assert r['complete'] == 'True' and r['requested'] == r['arrived'] and int(r['pending']) == 0
        assert r['snapshot'] == policy['snapshot'] == quality['snapshot']
        assert r['scoring_version'] == quality['scoring_version']
        assert r['scoring_source_sha256'] == policy['scoring_source_sha256'] == quality['scoring_source_sha256']
        assert r['motor_bicycle_near_pairs'] == '' and r['bicycle_near_misses_measured'] == 'False'
        contacts = int(r['motor_pedestrian_collision_pairs']) + int(r['motor_bicycle_collision_pairs'])
        near = int(r['motor_pedestrian_near_pairs'])
        assert contacts == int(r['collision_pairs']) and near == int(r['near_pairs'])
        assert float(r['score']) == -1000 * contacts - 5 * near
        expected_split = ('train' if r['context_id'] in policy['train_contexts'] else
                          'validation' if r['context_id'] in policy['validation_contexts'] else 'test')
        assert r['split'] == expected_split
        episodes.append(dict(context=r['context_id'], action=r['action'], split=r['split'],
                             contacts=contacts, near=near, bicycleNear=None, reward=int(float(r['score'])),
                             travelers=int(r['arrived']), vehicleContacts=int(r['motor_vehicle_collision_pairs_diagnostic']),
                             delaySeconds=float(r['mean_delay_s'])))
    contexts = sorted({r['context_id'] for r in raw})
    assert len(contexts) == 12
    for context in contexts:
        matched = [r for r in raw if r['context_id'] == context]
        assert {r['action'] for r in matched} == ids
        assert len({(r['demand_sha256'], r['seed'], r['realization'], r['requested']) for r in matched}) == 1
    # Explicit identity binding: no proximity-based transfer to neighboring intersections.
    junction = next(j for j in read('intersection_prediction_output/map_payload.json')['junctions'] if j['id'] == 'J01145')
    assert junction['city'] == 'LIVERMORE' and junction['name'] == 'E AV / ESTATES ST'
    assert abs(junction['ll'][0] - 37.67994) < .0001 and abs(junction['ll'][1] + 121.75175) < .0001
    agents = [{k: a[k] for k in ('family', 'fixed_action', 'validation_score', 'replayed_samples')}
              for a in policy['agents'].values()]
    choice = policy['agents'][policy['champion']]['fixed_action']
    for e in evaluation['comparison']:
        rows = [r for r in episodes if r['split'] == 'test' and r['action'] == e['action']]
        for ours, theirs in [('contacts', 'contacts'), ('near', 'pedestrian_near_pairs'), ('reward', 'score'), ('travelers', 'arrived')]:
            assert sum(r[ours] for r in rows) == e[theirs]
    assert evaluation['recommendation_endorsed']
    site = dict(junctionId=junction['id'], name='East Avenue / Estates Street', ll=junction['ll'],
                schoolId='01612006001242', snapshot=policy['snapshot'], scoringVersion=policy['scoring_version'],
                selected=choice, champion=policy['champion'], consultant='C07', baseline='C01',
                agents=agents, candidates=candidates, episodes=episodes, releaseChecked=True,
                bicycleNearMeasured=False, annualProbabilityValidated=False,
                replayActions=['C01', 'C02', 'C07', 'C08'],
                sourceHashes={k: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for k, path in sources.items()})
    sites={junction['id']:site}
    for name in ('Estates','Hillcrest'):
        path=ROOT/f'outputs/metadrive_intersections/{name}/pilot_site_evidence.json'
        if not path.exists():continue
        fresh=json.loads(path.read_text())
        assert fresh['releaseChecked'] and fresh['bicycleNearMeasured'] and fresh['scoringVersion']=='motor-vru-v2'
        assert fresh['junctionId']=={'Estates':'J01145','Hillcrest':'J02019'}[name]
        quality=read(f'outputs/metadrive_intersections/{name}/pilot_quality.json')
        assert quality['recommendation_released'] and quality['snapshot']==fresh['snapshot']
        sites[fresh['junctionId']]=fresh
    inputs=hillcrest_inputs()[0]
    motion_path=ROOT/'outputs/metadrive_intersections/Hillcrest/motion_validation.json'
    motion=json.loads(motion_path.read_text()) if motion_path.exists() else {}
    protocol_path=ROOT/'outputs/metadrive_intersections/Hillcrest/pilot_protocol.json'
    protocol=json.loads(protocol_path.read_text()) if protocol_path.exists() else {}
    ready=bool(motion.get('passed') and motion.get('snapshot')==protocol.get('snapshot'))
    if 'J02019' in sites or ready:
        inputs.update(simulationReady=True,liveSimulationAvailable=True,
            geometryStatus='Four-way routes and before/pilot curb geometries built and checked.',
            controlStatus='Signal phases and crossing clearance implemented. Timing is an explicit assumption, not a recovered 2023 timing plan.',
            setupSnapshot=motion.get('snapshot'),movementChecks=len(motion.get('checks',[])),
            candidates=read('data/metadrive_intersections/Hillcrest/candidates.json'),
            recommendationPending='J02019' not in sites,
            remainingWork=[] if 'J02019' in sites else ['Complete the matched candidate batch, then train and evaluate the three agents.'])
    return dict(schemaVersion=2,sites=sites,availableInputs={'J02019':inputs})


def inject(document):
    """Called by both the lightweight UI release and full notebook/map builder."""
    evidence = build_evidence()
    code = (ROOT / 'mitigation_planner.js').read_text() + '\n' + (ROOT / 'traffic_csv.js').read_text() + '\n' + (ROOT / 'mitigation_jobs.js').read_text()
    ui = (ROOT / 'mitigation_panel.js').read_text()
    data = json.dumps(evidence, separators=(',', ':'), allow_nan=False).replace('</', '<\\/')
    return document.replace('/*MITIGATION_INTEGRATION*/',
                            code + '\nconst MITIGATION_EVIDENCE=' + data + ';\n' + ui)


def build_map():
    from website_release import stamp_map
    payload_path = ROOT / 'intersection_prediction_output/map_payload.json'
    payload = payload_path.read_text().replace('</', '<\\/')
    document = stamp_map((ROOT / 'intersection_map_template.html').read_text())
    document = document.replace('/*MODEL_CODE*/', (ROOT / 'intersection_model.js').read_text() + '\n' + (ROOT / 'speed_response.js').read_text())
    document = document.replace('/*PAYLOAD*/', payload)
    document = document.replace('const $=id=>', 'DATA.junctions.forEach(j=>{j.x=Array.from({length:6},(_,b)=>[...j.base,j.historyBand[b],j.knownBand[b],...Array.from({length:6},(_,i)=>+(i===b)),j.region]);});\nconst $=id=>')
    document = document.replace('/*MAPPED_FEATURES*/', (ROOT / 'outputs/sumo_v03/map_overlay.js').read_text())
    document = inject(document)
    for path in ['intersection_prediction_output/school_intersection_predictions.html', 'hosted_map/out/index.html']:
        (ROOT / path).write_text(document)
    evidence = build_evidence()
    (ROOT / 'hosted_map/out/mitigation-evidence.json').write_text(json.dumps(evidence, indent=2) + '\n')
    metadata, counts = hillcrest_inputs()
    (ROOT / 'hosted_map/out' / metadata['csvPath']).write_text(counts)
    (ROOT / 'intersection_prediction_output' / metadata['csvPath']).write_text(counts)
    return evidence


if __name__ == '__main__':
    evidence = build_map()
    print('Integrated map built:', {k:len(v['episodes']) for k,v in evidence['sites'].items()})
