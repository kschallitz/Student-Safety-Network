"""Ten-year local history pooled with regional count models; temporal calibration.

Historical counts remain distinct from missing labels. This is a prediction
experiment, not an exposure-adjusted HSM SPF or a causal intervention model.
"""
from pathlib import Path
import copy, json, time, warnings
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPRegressor
from sklearn.linear_model import PoissonRegressor
from sklearn.exceptions import ConvergenceWarning
from threadpoolctl import threadpool_limits
from intersection_prediction import (OUT, CRS, BANDS, BASE_FEATURES, load_prepared,
    feature_year as previous_feature_year, predict_export, probability, metrics)
from historical_speed_features import eligible, year_features

REGIONAL_FEATURES = BASE_FEATURES[:10] + [f'time_band_{b}' for b in range(6)]
FEATURES = BASE_FEATURES[:10] + ['prior10_usable_band_count', 'prior10_usable_band_years'] + [f'time_band_{b}' for b in range(6)] + ['city_index']
PROTOCOL = {
    'version': 'ten-year-pooled-v1', 'history_years': 10,
    'target': 'At least one geocoded reported pedestrian/bicycle injury or fatal collision within 500 feet over 12 months',
    'candidate_fit_years': [2017,2018,2019,2020], 'selection_year': 2021,
    'training_years': [2017,2018,2019,2020,2021], 'calibration_year': 2022,
    'diagnostic_years': [2023,2024,2025], 'provisional_years': [2024,2025],
    'selection_metric': 'Annual binary log loss on complete 2021 outcomes; no diagnostic-year selection',
    'default_model_rule': 'Choose the lower 2021 annual log-loss regional model (NN versus regression); keep both for comparison. Later diagnostic outcomes do not choose the default.',
    'pool_strength_candidates_years': [0.5,1,3,10,30],
    'nn_candidates': [{'hidden':8,'alpha':10},{'hidden':16,'alpha':100}],
    'glm_candidates': [0.001,0.01], 'city_prior_rows': 600,
    'formula': 'mu_band = (usable local count + strength * regional mean) / (usable local years + strength); annual hazard = exp(a) * sum(mu_band)**b; all six band hazards rescaled by the same factor; p = 1-exp(-hazard)',
    'regional_mean': 'Road/school attributes and time band, plus a city multiplier shrunk toward the all-region fit; local crash history is not a regional-network input.',
    'calibrator': 'Two-parameter monotone complementary-log-log annual map fitted only on complete 2022 outcomes, after model/strength selection; positive slope constrained to [0.25,3].',
    'history_rule': 'For target Y use max(2014,Y-10)..Y-1. Current 2026 scenario uses 2016-2025. Unresolved year/band labels contribute neither counts nor exposure-years to pooling. Their recorded cases remain visible. Historical adoption years may supply observed crash history, while target-year adoption labels remain excluded.',
    'coverage': 'Earlier backtests have shorter source history: 2021 has 7 years, 2022 has 8, 2023 has 9; 2024-2025 have 10. Known-year support is displayed; current geometry does not establish a junction existed throughout history.',
    'dependence': 'Overlapping 500-ft areas share crashes. Never sum their records as distinct regional crashes. Calibration sampling intervals use 2-km spatial block resampling; block edges and repeated city gaps can retain dependence.',
    'test_reuse': 'All historical years were inspected in earlier project iterations. The new split prevents computational leakage but is a reused temporal diagnostic, not a fresh untouched prospective test.',
    'limits': 'No continuous travel exposure, complete historical road geometry, calibrated individual-risk interval coverage, or causal speed-limit effect.',
    'seed':42, 'bootstrap_replicates':40,
}


def history_window(counts, unknown, year):
    stop = year - 2014
    if not 0 <= stop <= counts.shape[1]:
        raise ValueError('Target year is outside the saved source history')
    start = max(0, stop - 10)
    known = ~unknown[:, start:stop, :]
    return (counts[:, start:stop, :] * known).sum(axis=1), known.sum(axis=1), (2014+start,year-1)


def feature_year(j, counts, unknown, year, cities):
    c,e,_ = history_window(counts,unknown,year)
    static=j[BASE_FEATURES[:10]].to_numpy(float)
    if 'junction_id' in j: static[:,:3]=year_features(j,year)
    city_lookup={name:i for i,name in enumerate(cities)}
    city=np.array([city_lookup.get(s,-1) for s in j.city])
    return np.c_[np.repeat(static,6,axis=0),c.ravel(),e.ravel(),np.tile(np.eye(6),(len(j),1)),np.repeat(city,6)]


def regional_x(x):
    return np.c_[x[:,:10],x[:,12:18]]


def regional_rate(model,x):
    r=predict_export(model['regional'],regional_x(x))
    city=x[:,18].astype(int)
    factors=np.r_[model['city_factors'],1.]
    idx=np.where((city>=0)&(city<len(model['city_factors'])),city,len(model['city_factors']))
    return r*factors[idx]


def pooled_raw(model,x):
    k=model['prior_years']
    return (x[:,10]+k*regional_rate(model,x))/(x[:,11]+k)


def calibrated_rates(model,x):
    if len(x)%6: raise ValueError('Annual calibration requires all six ordered time bands per area')
    raw=pooled_raw(model,np.asarray(x)).reshape(-1,6)
    total=np.maximum(raw.sum(axis=1),1e-12)
    a,b=model.get('calibration',[0.,1.])
    adjusted=np.exp(a)*total**b
    return (raw*(adjusted/total)[:,None]).ravel()


def calibration_fit(total,y,weights=None):
    total=np.maximum(total,1e-12);positive=np.asarray(y)>0
    w=np.ones(len(y)) if weights is None else np.asarray(weights)
    def loss(z):
        hazard=np.exp(z[0])*total**z[1]
        ll=np.where(positive,-np.log(np.maximum(-np.expm1(-hazard),1e-14)),hazard)
        return np.average(ll,weights=w)
    result=minimize(loss,[0.,1.],method='L-BFGS-B',bounds=[(-5,5),(.25,3)],options={'ftol':1e-12,'gtol':1e-8})
    if not result.success: raise RuntimeError('Annual calibration did not converge: '+result.message)
    return result.x.tolist()


def export_regional(est,scaler,name):
    d={'name':name,'features':REGIONAL_FEATURES,'mean':scaler.mean_.tolist(),'scale':scaler.scale_.tolist()}
    if isinstance(est,MLPRegressor):d.update(kind='mlp',weights=[w.tolist() for w in est.coefs_],biases=[b.tolist() for b in est.intercepts_])
    else:d.update(kind='poisson_glm',weights=est.coef_.tolist(),intercept=float(est.intercept_))
    return d


def fit_regional(x,y,cities,kind,params,row_weight=None):
    rx=regional_x(x);w=np.ones(len(y)) if row_weight is None else row_weight
    scaler=StandardScaler().fit(rx,sample_weight=w)
    sx=scaler.transform(rx)
    unique,inv=np.unique(sx,axis=0,return_inverse=True)
    weight=np.bincount(inv,weights=w,minlength=len(unique));total=np.bincount(inv,weights=w*y,minlength=len(unique))
    used=weight>0;target=total[used]/weight[used]
    if kind=='nn':
        est=MLPRegressor(loss='poisson',hidden_layer_sizes=(params['hidden'],),activation='tanh',solver='lbfgs',alpha=params['alpha'],max_iter=1600,max_fun=10000,tol=1e-5,random_state=42)
    else:est=PoissonRegressor(alpha=params['alpha'],max_iter=800,tol=1e-7)
    with warnings.catch_warnings(record=True) as caught,threadpool_limits(limits=2):
        warnings.simplefilter('always');est.fit(unique[used],target,sample_weight=weight[used])
    convergence=[str(v.message) for v in caught if issubclass(v.category,ConvergenceWarning)]
    if convergence:raise RuntimeError('Unconverged regional fit: '+'; '.join(convergence))
    reg=export_regional(est,scaler,kind+' regional '+json.dumps(params))
    mu=predict_export(reg,rx);city=x[:,18].astype(int)
    obs=np.bincount(city,weights=w*y,minlength=len(cities));pred=np.bincount(city,weights=w*mu,minlength=len(cities))
    pseudo=PROTOCOL['city_prior_rows']*np.average(y,weights=w)
    factors=(obs+pseudo)/(pred+pseudo)
    return {'kind':'ten_year_pooled','name':kind+' with ten-year pooling','regional':reg,'city_factors':factors.tolist(),'cities':cities,'prior_years':1.,'calibration':[0.,1.],'params':params,'features':FEATURES}


def spatial_blocks(j):
    projected=j.to_crs(CRS)
    _,block=np.unique(np.c_[np.floor(projected.geometry.x/2000),np.floor(projected.geometry.y/2000)],axis=0,return_inverse=True)
    return block


def fit_model_candidates(j,c,u,cities):
    datasets={year:(feature_year(j,c,u,year,cities),c[:,year-2014,:].ravel().astype(float),eligible(j,u,year)) for year in range(2017,2026)}
    def train_rows(years):
        return np.concatenate([datasets[z][0][datasets[z][2]] for z in years]),np.concatenate([datasets[z][1][datasets[z][2]] for z in years])
    x,y=train_rows(PROTOCOL['candidate_fit_years']);vx,vy,vm=datasets[2021]
    annual=vm.reshape(-1,6).all(axis=1);annual_y=vy.reshape(-1,6).sum(axis=1)
    candidates=[];chosen={}
    for kind,params_list in [('nn',PROTOCOL['nn_candidates']),('glm',[{'alpha':a} for a in PROTOCOL['glm_candidates']])]:
        for params in params_list:
            model=fit_regional(x,y,cities,kind,params)
            for strength in PROTOCOL['pool_strength_candidates_years']:
                model['prior_years']=strength
                mu=pooled_raw(model,vx).reshape(-1,6).sum(axis=1)
                score=metrics(annual_y[annual],mu[annual])
                row={'family':kind,'params':json.dumps(params),'prior_years':strength,**score}
                candidates.append(row)
            print('Selection fit',kind,params,flush=True)
        chosen[kind]=min([r for r in candidates if r['family']==kind],key=lambda r:r['log_loss'])
    pd.DataFrame(candidates).to_csv(OUT/'ten_year_selection.csv',index=False)
    x,y=train_rows(PROTOCOL['training_years']);models={}
    for kind in ['nn','glm']:
        row=chosen[kind];models[kind]=fit_regional(x,y,cities,kind,json.loads(row['params']))
        models[kind]['prior_years']=row['prior_years']
        cx,cy,cm=datasets[2022];annual=cm.reshape(-1,6).all(axis=1)
        mu=pooled_raw(models[kind],cx).reshape(-1,6).sum(axis=1)
        models[kind]['calibration']=calibration_fit(mu[annual],cy.reshape(-1,6).sum(axis=1)[annual])
        print('Selected',kind,row['params'],'prior years',row['prior_years'],'calibration',models[kind]['calibration'],flush=True)
    bands=np.argmax(x[:,12:18],axis=1);rates=np.array([y[bands==b].mean() for b in range(6)])
    return models,datasets,x,y,rates,chosen


def make_baseline(rates,cities,strength):
    # Time-band-only regional prior with the same pooling mechanism, no neural fit.
    weights=np.r_[np.zeros(10),np.log(rates)]
    regional={'kind':'poisson_glm','name':'Regional time-band rate','mean':[0.]*16,'scale':[1.]*16,'weights':weights.tolist(),'intercept':0.,'features':REGIONAL_FEATURES}
    return {'kind':'ten_year_pooled','name':'Ten-year pooled baseline','regional':regional,'city_factors':[1.]*len(cities),'cities':cities,'prior_years':strength,'calibration':[0.,1.],'features':FEATURES}


def train(bootstrap_replicates=40):
    start=time.monotonic();j,c,u=load_prepared();cities=sorted(j.city.unique())
    (OUT/'ten_year_protocol.json').write_text(json.dumps(PROTOCOL,indent=2))
    models,datasets,x,y,rates,chosen=fit_model_candidates(j,c,u,cities)
    # Select the plain-history comparator on 2021 too, using 2017-2020 rates.
    tx=np.concatenate([datasets[z][0][datasets[z][2]] for z in PROTOCOL['candidate_fit_years']]);ty=np.concatenate([datasets[z][1][datasets[z][2]] for z in PROTOCOL['candidate_fit_years']])
    bands=np.argmax(tx[:,12:18],axis=1);selection_rates=np.array([ty[bands==b].mean() for b in range(6)])
    vx,vy,vm=datasets[2021];vm=vm.reshape(-1,6).all(axis=1);vy=vy.reshape(-1,6).sum(axis=1)
    choices=[]
    for strength in PROTOCOL['pool_strength_candidates_years']:
        m=make_baseline(selection_rates,cities,strength);pred=pooled_raw(m,vx).reshape(-1,6).sum(axis=1)
        choices.append((metrics(vy[vm],pred[vm])['log_loss'],strength))
    baseline=make_baseline(rates,cities,min(choices)[1]);cx,cy,cm=datasets[2022];valid=cm.reshape(-1,6).all(axis=1)
    baseline['calibration']=calibration_fit(pooled_raw(baseline,cx).reshape(-1,6).sum(axis=1)[valid],cy.reshape(-1,6).sum(axis=1)[valid])
    bundle={**models,'default_model':min(chosen,key=lambda k:chosen[k]['log_loss']),'pooled_baseline':baseline,'baseline_rates':rates.tolist(),'bands':BANDS,'protocol':PROTOCOL,'cities':cities}
    (OUT/'model.json').write_text(json.dumps(bundle));(OUT/'protocol.json').write_text(json.dumps(PROTOCOL,indent=2))
    fx=feature_year(j,c,u,2026,cities);np.savez_compressed(OUT/'map_features.npz',x=fx)
    summary={'train_rows':len(y),'train_events':int(y.sum()),'features':FEATURES,'regional_features':REGIONAL_FEATURES,'selected_nn':models['nn']['name'],'selected_glm':models['glm']['name'],'selection':chosen,'calibration_year':2022,'history_years':10,'map_history':[2016,2025],'all_training_on':'Local Mac CPU','elapsed_seconds':time.monotonic()-start,'test_used_for_selection':False}
    (OUT/'training_summary.json').write_text(json.dumps(summary,indent=2))
    evaluate(bundle,j,c,u,datasets)
    if bootstrap_replicates:bootstrap(bundle,j,c,u,x,y,datasets,bootstrap_replicates)
    print('Ten-year pipeline complete',round(time.monotonic()-start,1),'seconds',flush=True)
    return bundle


def evaluate(bundle,j,c,u,datasets):
    old=json.loads((OUT/'previous_three_year_model.json').read_text());block=spatial_blocks(j)
    members=pd.read_csv(OUT/'case_area_membership.csv');mapped=np.zeros(c.shape[:2],int)
    for (ix,year),n in members.groupby(['junction_index','year']).size().items():mapped[ix,year-2014]=n
    annual_rows=[];band_rows=[];predictions=[];reliability=[];cohorts=[];city_support=[];city_scores=[]
    for year in [2021,2022,2023,2024,2025]:
        valid=datasets[year][2].reshape(-1,6).all(axis=1)
        for city,g in j.groupby('city'):
            ix=g.index[valid[g.index]]
            city_support.append({'city':city,'year':year,'complete_area_outcomes':len(ix),'positive_areas':int((c[ix,year-2014].sum(axis=1)>0).sum())})
    for year in [2022,2023,2024,2025]:
        x,y,mask=datasets[year];annual_mask=mask.reshape(-1,6).all(axis=1);annual_y=y.reshape(-1,6).sum(axis=1)
        oldx=previous_feature_year(j,c,u,year)
        raw=pooled_raw(bundle['nn'],x)
        predictions_by_model={
            'Previous 3-year NN':predict_export(old['nn'],oldx),
            'Ten-year NN before calibration':raw,
            'Ten-year pooled NN':calibrated_rates(bundle['nn'],x),
            'Ten-year pooled regression':calibrated_rates(bundle['glm'],x),
            'Ten-year pooled baseline':calibrated_rates(bundle['pooled_baseline'],x),
            'Regional time-band baseline':np.tile(bundle['baseline_rates'],len(j))}
        stop=year-2014;start=max(0,stop-10);zero=mapped[:,start:stop].sum(axis=1)==0
        for label,mu in predictions_by_model.items():
            band_rows.append({'year':year,'model':label,**metrics(y[mask],mu[mask])})
            total=mu.reshape(-1,6).sum(axis=1);p=probability(total)
            annual_rows.append({'year':year,'model':label,**metrics(annual_y[annual_mask],total[annual_mask]),'mean_probability':float(p[annual_mask].mean()),'observed_fraction':float((annual_y[annual_mask]>0).mean())})
            frame=pd.DataFrame({'year':year,'junction_index':np.where(annual_mask)[0],'block':block[annual_mask],'model':label,'observed_count':annual_y[annual_mask],'probability':p[annual_mask],'zero_mapped_history':zero[annual_mask],'usable_band_years_min':x.reshape(len(j),6,-1)[annual_mask,:,11].min(axis=1)})
            predictions.append(frame)
            if year>=2023:
                for city,g in j.groupby('city'):
                    fg=frame.loc[frame.junction_index.isin(g.index)]
                    if len(fg):city_scores.append(cohort_summary(fg,year,label,city))
                for group,fg in [('All eligible areas',frame),('No mapped collisions in prior window',frame.loc[frame.zero_mapped_history])]:
                    cohorts.append(cohort_summary(fg,year,label,group))
                edges=np.array([0,.01,.025,.05,.1,.15,.2,.3,.5,.75,1.0000001]);bins=np.digitize(frame.probability,edges)-1
                for b in np.unique(bins):
                    fg=frame.loc[bins==b]
                    reliability.append({**cohort_summary(fg,year,label,'Calibration bin'),'bin_low':edges[b],'bin_high':min(1.,edges[b+1])})
    annual=pd.DataFrame(annual_rows);annual.to_csv(OUT/'annual_calibration_evaluation.csv',index=False)
    pd.DataFrame(band_rows).to_csv(OUT/'time_band_calibration_evaluation.csv',index=False)
    pd.concat(predictions).to_csv(OUT/'annual_calibration_predictions.csv.gz',index=False)
    pd.DataFrame(reliability).to_csv(OUT/'annual_reliability.csv',index=False)
    pd.DataFrame(cohorts).to_csv(OUT/'history_calibration_cohorts.csv',index=False)
    pd.DataFrame(city_support).to_csv(OUT/'annual_city_support.csv',index=False)
    pd.DataFrame(city_scores).to_csv(OUT/'annual_city_calibration.csv',index=False)
    names={'Ten-year pooled NN':'Neural network','Ten-year pooled regression':'Poisson regression','Regional time-band baseline':'Time-band baseline'}
    ev=pd.DataFrame(band_rows);ev=ev.loc[ev.model.isin(names)].copy();ev['model']=ev.model.map(names);ev.to_csv(OUT/'evaluation.csv',index=False)
    fx=np.load(OUT/'map_features.npz')['x'];new=calibrated_rates(bundle['nn'],fx).reshape(-1,6)
    oldfx=np.load(OUT/'previous_three_year_map_features.npz')['x'];oldmu=predict_export(old['nn'],oldfx).reshape(-1,6)
    hc,hy,window=history_window(c,u,2026)
    pred=j[['junction_id','name','city','coverage_complete']].copy()
    pred['annual_probability']=probability(new.sum(axis=1));pred['previous_probability']=probability(oldmu.sum(axis=1));pred['expected_annual_count']=new.sum(axis=1)
    pred['mapped_cases_2016_2025']=mapped[:,2:].sum(axis=1);pred['usable_history_cases']=hc.sum(axis=1);pred['known_band_years_min']=hy.min(axis=1);pred['known_band_years_max']=hy.max(axis=1)
    pred['recorded_cases_2014_2025']=mapped.sum(axis=1);pred.to_csv(OUT/'map_predictions.csv',index=False)
    pred.loc[pred.recorded_cases_2014_2025.eq(0)&pred.coverage_complete].sort_values('previous_probability',ascending=False).to_csv(OUT/'ten_year_zero_history_changes.csv',index=False)
    print(annual.loc[annual.year.ge(2023),['year','model','log_loss','brier','mean_probability','observed_fraction']].to_string(index=False),flush=True)


def cohort_summary(frame,year,label,group):
    y=frame.observed_count.gt(0).to_numpy();p=frame.probability.to_numpy()
    if not len(frame):return {'year':year,'model':label,'group':group,'rows':0}
    # Resample spatial blocks, not overlapping circles independently.
    data=pd.DataFrame({'block':frame.block,'n':1,'yes':y.astype(int),'p':p}).groupby('block').sum()
    rng=np.random.default_rng(72026);values=data.to_numpy();ratios=[]
    for _ in range(400):
        sample=values[rng.integers(0,len(values),size=len(values))].sum(axis=0)
        ratios.append(sample[1]/sample[0])
    lo,hi=np.quantile(ratios,[.025,.975])
    return {'year':year,'model':label,'group':group,'rows':len(frame),'spatial_blocks':len(data),'positive_areas':int(y.sum()),'mean_probability':float(p.mean()),'observed_fraction':float(y.mean()),'calibration_gap':float(p.mean()-y.mean()),'observed_low':float(lo),'observed_high':float(hi)}


def bootstrap(bundle,j,c,u,x,y,datasets,replicates):
    block=spatial_blocks(j);nblocks=int(block.max()+1)
    rowblocks=np.concatenate([np.repeat(block,6)[datasets[z][2]] for z in PROTOCOL['training_years']])
    active=np.unique(rowblocks);rng=np.random.default_rng(92026);ensemble={'nn':[],'glm':[]};logs=[];start=time.monotonic()
    cx,cy,cm=datasets[2022];valid=cm.reshape(-1,6).all(axis=1);cal_y=cy.reshape(-1,6).sum(axis=1)[valid]
    for r in range(replicates):
        tick=time.monotonic();mult=np.bincount(rng.choice(active,len(active),replace=True),minlength=nblocks)
        weights=mult[rowblocks].astype(float);weights*=len(y)/weights.sum()
        for kind in ['nn','glm']:
            m=fit_regional(x,y,bundle['cities'],kind,bundle[kind]['params'],weights)
            m['prior_years']=bundle[kind]['prior_years']
            mu=pooled_raw(m,cx).reshape(-1,6).sum(axis=1)
            m['calibration']=calibration_fit(mu[valid],cal_y,mult[block[valid]])
            ensemble[kind].append(m)
        logs.append({'replicate':r+1,'seconds':time.monotonic()-tick})
        print('Ten-year spatial bootstrap',r+1,'/',replicates,round(logs[-1]['seconds'],1),'sec',flush=True)
    ensemble['metadata']={'replicates':replicates,'spatial_block_metres':2000,'quantiles':[.05,.95],'meaning':'Central 90% variation across regional models, city adjustments and 2022 calibrators refitted with spatial block weights. Local history, selected hyperparameters and pooling strength fixed. Not a calibrated true-risk interval.','elapsed_seconds':time.monotonic()-start,'logs':logs}
    (OUT/'bootstrap_models.json').write_text(json.dumps(ensemble));(OUT/'uncertainty_method.json').write_text(json.dumps(ensemble['metadata'],indent=2))
    fx=np.load(OUT/'map_features.npz')['x'];frames=[]
    for kind in ['nn','glm']:
        mus=np.array([calibrated_rates(m,fx).reshape(len(j),6) for m in ensemble[kind]])
        lo,hi=np.quantile(probability(mus.sum(axis=2)),[.05,.95],axis=0)
        center=probability(calibrated_rates(bundle[kind],fx).reshape(len(j),6).sum(axis=1))
        frames.append(pd.DataFrame({'junction_id':j.junction_id,'model':kind,'point_probability':center,'model_range_low':lo,'model_range_high':hi}))
    pd.concat(frames).to_csv(OUT/'probability_ranges.csv',index=False)


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--bootstrap',type=int,default=40);args=p.parse_args();train(args.bootstrap)
