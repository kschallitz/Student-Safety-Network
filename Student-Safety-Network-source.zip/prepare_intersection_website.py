"""Stage a checked two-site release without bumping or publishing it."""
from pathlib import Path
import json
import shutil
from mitigation_integration import build_map
from website_release import version

ROOT=Path(__file__).resolve().parent

def build():
    for name in ('Estates','Hillcrest'):
        p=ROOT/'outputs/metadrive_intersections'/name/'pilot_site_evidence.json'
        if not p.exists():continue
        result=json.loads(p.read_text())
        assert result['releaseChecked'] and result['bicycleNearMeasured']
        assert result['scoringVersion']=='motor-vru-v2'
    build_map()
    out=ROOT/'hosted_map/out';public=ROOT/'hosted_map/public'
    for source,dest in [('intersection_metadrive_lab.html','metadrive-lab.html'),
                        ('intersection_workflow.html','intersection-workflow.html')]:
        text=(ROOT/'templates'/source).read_text().replace('__SITE_VERSION__',version())
        (out/dest).write_text(text)
    for name in ['index.html','mitigation-evidence.json','hillcrest_observed_counts.csv',
                 'metadrive-lab.html','intersection-workflow.html']:
        shutil.copy2(out/name,public/name)
    source=ROOT/'hosted_map/source'
    for name in ['mitigation_integration.py','mitigation_panel.js','mitigation_planner.js',
                 'mitigation_jobs.js','traffic_csv.js','website_release.py','website_version.json',
                 'intersection_map_template.html','INTERSECTION_SIMULATION.md',
                 'build_intersection_release.py','prepare_intersection_website.py']:
        shutil.copy2(ROOT/name,source/name)
    for name in ['intersection_workflow.html','intersection_metadrive_lab.html']:
        shutil.copy2(ROOT/'templates'/name,source/name)
    for name in ['test_mitigation_integration.cjs','test_traffic_csv.cjs','test_bicycle_conflicts.py','test_hillcrest_signals.py','test_simulation_api.mjs']:
        shutil.copy2(ROOT/'tests'/name,source/name)
    (source/'README.txt').write_text(
        f'v{version()} authoring-source snapshot. The website serves public/ through a Sites Worker. '
        'The authenticated job API stores work and results in D1; the local Mac runs MetaDrive. '
        'No worker credentials are included. The reproduction ZIP contains the simulator code, '
        'source counts and available checked episodes. Pending recommendations are explicitly labeled. Run these build scripts '
        'from the SCHOOL-COLLISIONS workspace, which supplies the original datasets and outputs.\n')
    print(f'Staged v{version()} with checked results and explicit pending states; not published.')

if __name__=='__main__':build()
