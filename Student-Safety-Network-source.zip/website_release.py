"""One version counter for the map title, browser tab and hosted companions."""
from pathlib import Path
import argparse,json,re

VERSION_FILE=Path(__file__).resolve().parent/'website_version.json'

def version():
    release=json.loads(VERSION_FILE.read_text())['release']
    if not isinstance(release,int) or isinstance(release,bool) or release<1:
        raise ValueError('Website release must be a positive integer')
    return f'0.{release:02d}'

def stamp_map(document):
    value=version()
    document=document.replace('__SITE_VERSION__',value)
    document,n=re.subn(r'<title>School intersection explorer[^<]*</title>',
                      f'<title>School intersection explorer · v{value}</title>',document,count=1)
    if n!=1:raise ValueError('Missing map browser title')
    document,n=re.subn(r'<h1>School intersection explorer(?:\s*<span class="site-version">[^<]*</span>)?</h1>',
                      f'<h1>School intersection explorer <span class="site-version">v{value}</span></h1>',document,count=1)
    if n!=1:raise ValueError('Missing map heading')
    return document

def bump():
    value=json.loads(VERSION_FILE.read_text());version() # Validate before changing it.
    value['release']+=1
    VERSION_FILE.write_text(json.dumps(value,indent=2)+'\n')
    return version()

if __name__=='__main__':
    parser=argparse.ArgumentParser(description='Read or advance the website release number.')
    parser.add_argument('--bump',action='store_true',help='Advance once when preparing a new published update; do not repeat for deployment retries.')
    args=parser.parse_args();print('v'+(bump() if args.bump else version()))
