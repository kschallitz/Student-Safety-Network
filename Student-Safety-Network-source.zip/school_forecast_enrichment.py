"""Public age bands, road-reference recovery queue, and clearly separated citation evidence."""
from school_forecast_preparation import checked_ids, RADIUS_METRES, METRIC_CRS
# %% enrichment_imports
import html
import re
from pathlib import Path
import json
import pandas as pd
import geopandas as gpd
import folium
from folium.plugins import MarkerCluster
from branca.element import Element, MacroElement, Template

CITATION_COLUMNS=['citation_id','agency','issued_date','violation_code','violation_description',
                  'latitude','longitude','location_precision','location_role','source_url']
AGE_COLUMNS=['age_1_4','age_5_17','age_18_19','age_20_plus','age_unknown']

# %% enrichment
def enrich_public_crashes(crashes, enrichment):
    roads=pd.DataFrame(enrichment['roads']).rename(columns={'Collision Id':'case_id'})
    ages=pd.DataFrame(enrichment['ages'])
    modes=pd.DataFrame(enrichment['modes'])
    for frame in [roads,ages,modes]:
        frame['case_id']=checked_ids(frame.case_id,'enrichment crash')
        if frame.case_id.duplicated().any():raise ValueError('Duplicate enrichment crash IDs')
        if not set(crashes.case_id)<=set(frame.case_id):raise ValueError('Enrichment is missing frozen-snapshot cases')
    extra_roads=len(set(roads.case_id)-set(crashes.case_id))
    extra_ages=len(set(ages.case_id)-set(crashes.case_id))
    report_check=crashes[['case_id','Report Number']].merge(roads[['case_id','Report Number']],on='case_id',validate='one_to_one')
    same_report=report_check['Report Number_x'].astype('string').eq(report_check['Report Number_y'].astype('string')).fillna(False)
    both_unknown=report_check['Report Number_x'].isna() & report_check['Report Number_y'].isna()
    if not (same_report | both_unknown).all():
        raise ValueError('Report identifiers changed between source snapshots; reconcile first')
    for col in ['pedbike_parties','distinct_party_ids']+AGE_COLUMNS:
        ages[col]=pd.to_numeric(ages[col],errors='raise')
        if (ages[col].isna() | ages[col].lt(0) | ages[col].mod(1).ne(0)).any():raise ValueError('Invalid age-band counts')
    if not ages.pedbike_parties.eq(ages.distinct_party_ids).all():raise ValueError('Duplicate or missing party IDs')
    if not ages[AGE_COLUMNS].sum(axis=1).eq(ages.pedbike_parties).all():raise ValueError('Age bands do not reconcile')
    out=crashes.merge(roads.drop(columns='Report Number'),on='case_id',validate='one_to_one').merge(ages,on='case_id',validate='one_to_one')
    for col in ['mode_parties','mode_distinct_party_ids','pedestrian_parties','bicycle_parties']:
        modes[col]=pd.to_numeric(modes[col],errors='raise')
        if (modes[col].isna() | modes[col].lt(0) | modes[col].mod(1).ne(0)).any():raise ValueError('Invalid mode counts')
    if not modes.mode_parties.eq(modes.mode_distinct_party_ids).all():raise ValueError('Duplicate/missing mode party IDs')
    if (modes[['pedestrian_parties','bicycle_parties']].sum(axis=1).lt(modes.mode_parties) |
        modes.pedestrian_parties.gt(modes.mode_parties) | modes.bicycle_parties.gt(modes.mode_parties) |
        modes.mode_parties.eq(0)).any():raise ValueError('Mode counts do not reconcile')
    out=out.merge(modes,on='case_id',validate='one_to_one')
    if not out.mode_parties.eq(out.pedbike_parties).all():raise ValueError('Party inventory changed between enrichment snapshots')
    out['pedestrian_involved']=out.pedestrian_parties.gt(0)
    out['bicycle_involved']=out.bicycle_parties.gt(0)
    out['collision_modes']=out.apply(lambda r:'Pedestrian + bicycle' if r.pedestrian_involved and r.bicycle_involved
                                    else ('Pedestrian' if r.pedestrian_involved else 'Bicycle'),axis=1)
    missing_text={'','NOT STATED','UNKNOWN','UNKN','UNK','NONE','N/A','NA','-','NOT APPLICABLE'}
    for col in ['PrimaryRoad','SecondaryRoad']:
        normalized=out[col].astype('string').str.strip().str.upper()
        out[col+'_usable']=normalized.notna() & ~normalized.isin(missing_text)
    both=out.PrimaryRoad_usable & out.SecondaryRoad_usable
    distance=pd.to_numeric(out.SecondaryDistance,errors='coerce')
    direction=out.SecondaryDirection.astype('string').str.upper()
    units=out.SecondaryUnitOfMeasure.astype('string').str.upper()
    out['location_recovery_status']='Road/address reference only; review required'
    out.loc[both,'location_recovery_status']='Road pair; offset unresolved'
    out.loc[both & distance.eq(0),'location_recovery_status']='Road pair with explicit zero distance; intersection candidate'
    out.loc[both & distance.gt(0) & direction.isin(['N','S','E','W']) & units.isin(['F','M']),
            'location_recovery_status']='Road pair with distance/direction; offset candidate'
    out.loc[~out.PrimaryRoad_usable,'location_recovery_status']='Insufficient road reference'
    out['reported_pedbike_age_5_17']=pd.Series(pd.NA,index=out.index,dtype='boolean')
    out.loc[out.age_unknown.eq(0),'reported_pedbike_age_5_17']=False
    out.loc[out.age_5_17.gt(0),'reported_pedbike_age_5_17']=True
    out['student_status']=pd.Series(pd.NA,index=out.index,dtype='string')
    cited=out.PrimaryCollisionFactorIsCited.astype('string').str.lower()
    if not cited.dropna().isin(['true','false']).all():raise ValueError('Unreviewed cited flag')
    out['crash_factor_marked_cited']=cited.map({'true':True,'false':False}).astype('boolean')
    unlocated=out.loc[~out.valid_coordinates].copy()
    no_gps=out.loc[out.missing_coordinates]
    summary={'frozen_crashes':len(out),'missing_gps':int(out.missing_coordinates.sum()),
        'missing_gps_with_usable_road_pair':int((no_gps.PrimaryRoad_usable & no_gps.SecondaryRoad_usable).sum()),
        'location_recovery_queue':len(unlocated),'locations_recovered':0,
        'pedbike_parties':int(out.pedbike_parties.sum()),'parties_age_unknown':int(out.age_unknown.sum()),
        'parties_age_5_17':int(out.age_5_17.sum()),'crashes_with_recorded_age_5_17':int(out.age_5_17.gt(0).sum()),
        'crash_factor_marked_cited':int(out.crash_factor_marked_cited.fillna(False).sum()),
        'located_crashes_marked_cited':int((out.crash_factor_marked_cited.fillna(False) & out.valid_coordinates).sum()),
        'cited_flag_unknown':int(out.crash_factor_marked_cited.isna().sum()),
        'new_live_road_cases_excluded_to_preserve_snapshot':extra_roads,
        'new_live_age_cases_excluded_to_preserve_snapshot':extra_ages,
        'local_report_number_unknown':int(out['Report Number'].isna().sum()),
        'pedestrian_involved_crashes':int(out.pedestrian_involved.sum()),
        'bicycle_involved_crashes':int(out.bicycle_involved.sum()),
        'both_modes_crashes':int((out.pedestrian_involved & out.bicycle_involved).sum()),
        'located_pedestrian_crashes':int((out.pedestrian_involved & out.valid_coordinates).sum()),
        'located_bicycle_crashes':int((out.bicycle_involved & out.valid_coordinates).sum()),
        'located_both_modes_crashes':int((out.pedestrian_involved & out.bicycle_involved & out.valid_coordinates).sum()),
        'new_live_mode_cases_excluded_to_preserve_snapshot':len(set(modes.case_id)-set(crashes.case_id)),
        'all_enforcement_citations_available':False,
        'age_definition':'Recorded pedestrian/bicyclist party age 5–17 inclusive; not verified student or school trip. Age zero/blank is unknown per CCRS dictionary.',
        'location_definition':'Road references are geocoding candidates; no approximate point is substituted for a verified location.',
        'citation_definition':'CCRS primary crash factor marked cited; not all tickets, not a conviction, and not evidence of no citation when false/unknown.'}
    return out,unlocated,summary


def load_traffic_citations(path=''):
    """One row per agency/citation event; list multiple violation codes in that row."""
    if not path:return pd.DataFrame(columns=CITATION_COLUMNS)
    frame=pd.read_csv(path,dtype='string')
    missing=set(CITATION_COLUMNS)-set(frame.columns)
    if missing:raise ValueError(f'Missing citation columns: {sorted(missing)}')
    for col in ['citation_id','agency','issued_date','violation_code','location_precision','location_role','source_url']:
        frame[col]=checked_ids(frame[col],col)
    if frame.duplicated(['agency','citation_id']).any():raise ValueError('Duplicate agency/citation IDs; consolidate violations without double counting')
    frame['issued_date']=pd.to_datetime(frame.issued_date,format='%Y-%m-%d',errors='raise')
    for col in ['latitude','longitude']:frame[col]=pd.to_numeric(frame[col],errors='coerce')
    if not (frame.latitude.between(37,38.3) & frame.longitude.between(-123,-120.8)).fillna(False).all():
        raise ValueError('Citation coordinates missing/outside study bounds; retain unlocated records separately')
    if not frame.location_precision.isin(['reported_coordinate','intersection','block']).all():raise ValueError('Unreviewed location precision')
    if not frame.location_role.isin(['offense','stop','unknown']).all():raise ValueError('Unreviewed location role')
    if not frame.source_url.str.match(r'^https?://',na=False).all():raise ValueError('Citation source must be an HTTP(S) link')
    return frame


def add_collision_type_control(m,cluster_entries,pedestrian_count,bicycle_count):
    """One marker per case/layer; selecting both modes uses a union, not a sum."""
    groups=[]
    for cluster,entries in cluster_entries:
        markers=','.join(f'[{marker.get_name()},{str(ped).lower()},{str(bike).lower()}]' for marker,ped,bike in entries)
        groups.append('{cluster:'+cluster.get_name()+',entries:['+markers+']}')
    control=MacroElement()
    control._name='CollisionTypeControl'
    control.map_name=m.get_name();control.groups='['+','.join(groups)+']'
    control.pedestrian_count=pedestrian_count;control.bicycle_count=bicycle_count
    control._template=Template('''{% macro script(this, kwargs) %}
    (function(){
      const groups={{this.groups|safe}};
      const control=L.control({position:'topright'});
      control.onAdd=function(){
        const box=L.DomUtil.create('div','leaflet-bar collision-type-control');
        box.style.cssText='background:white;padding:12px;width:285px;font:13px/1.5 Arial;box-sizing:border-box';
        box.innerHTML='<b>Collision types</b><br>'+
          '<label><input type="checkbox" data-mode="pedestrian" checked> Pedestrian collisions ({{this.pedestrian_count}})</label><br>'+
          '<label><input type="checkbox" data-mode="bicycle" checked> Bicycle collisions ({{this.bicycle_count}})</label><br>'+
          '<span data-count></span><br><small>Applies to all crash layers. Cases flagged with both types count once per layer.<br>Teal: pedestrian · Orange: bicycle · Gray: both</small>';
        L.DomEvent.disableClickPropagation(box);L.DomEvent.disableScrollPropagation(box);
        const ped=box.querySelector('[data-mode="pedestrian"]');
        const bike=box.querySelector('[data-mode="bicycle"]');
        function update(){
          let uniqueCount=0;
          groups.forEach(function(group,index){
            const visible=group.entries.filter(e=>(ped.checked && e[1]) || (bike.checked && e[2])).map(e=>e[0]);
            group.cluster.clearLayers();group.cluster.addLayers(visible);
            if(index===0)uniqueCount=visible.length;
          });
          box.querySelector('[data-count]').textContent=uniqueCount.toLocaleString()+' unique located cases match';
        }
        ped.addEventListener('change',update);bike.addEventListener('change',update);update();
        return box;
      };
      control.addTo({{this.map_name}});
    })();
    {% endmacro %}''')
    m.add_child(control)


def make_regional_evidence_map(crashes,schools,selected_school_id,citations=None):
    school=schools.loc[schools.school_id.eq(selected_school_id)]
    if len(school)!=1:raise ValueError('Select one unique school')
    origin=school.iloc[0].geometry
    m=folium.Map([origin.y,origin.x],zoom_start=14,tiles='OpenStreetMap',control_scale=True)
    esc=lambda value:html.escape('Unknown' if pd.isna(value) else str(value))
    loaded=citations is not None and len(citations)>0
    note=(f'{len(citations):,} imported citation records; source coverage may be incomplete.' if loaded else
          'All-enforcement traffic citations: location dataset not yet available.')
    title=f'''<div style="position:absolute;top:12px;left:55px;z-index:999;background:white;padding:12px;border:1px solid #ddd;max-width:500px;font:13px/1.45 Arial">
    <b>School-area public evidence · 2020–2025 crashes</b><br>{esc(school.iloc[0].school_name)} · one-mile circle<br>
    Age 5–17 means recorded age, not confirmed student status.<br>{esc(note)}<br>
    <small>Only located crashes are plotted. Cited-crash flags are a separate, incomplete subset.</small></div>'''
    m.get_root().html.add_child(Element(title))
    school_layer=folium.FeatureGroup(name='Public school sites · 2025–26').add_to(m)
    for _,s in schools.iterrows():
        enrollment=s.get('enrollment')
        enrollment_note=(f'{int(enrollment):,} ({esc(s.get("enrollment_year"))})'
                         if pd.notna(enrollment) else 'Not loaded for this school')
        text=(f'<div style="font:13px/1.5 Arial"><b>{esc(s.school_name)}</b><br>'
              f'{esc(s.get("SchoolType"))} · {esc(s.city)}, {esc(s.county)} County<br>'
              f'Status: {esc(s.get("Status"))} · School inventory: {esc(s.get("Year"))}<br>'
              f'CDS school ID: {esc(s.school_id)}<br>'
              f'<b>Enrollment:</b> {enrollment_note}<br>'
              f'<b>Travel evidence:</b> {esc(s.get("travel_availability", "Not reviewed in this snapshot"))}<br>'
              '<small>Enrollment is not a daily walking or biking count.</small><br>'
              '<a href="https://services3.arcgis.com/fdvHcZVgB2QSRNkL/arcgis/rest/services/SchoolSites2526/FeatureServer/0" '
              'target="_blank" rel="noopener">CDE school-site source · 2025–26</a>')
        travel_url=s.get('travel_source_url')
        if pd.notna(travel_url) and str(travel_url).startswith(('https://','http://')):
            text+=f'<br><a href="{esc(travel_url)}" target="_blank" rel="noopener">School travel report · {esc(s.get("travel_report_year"))}</a>'
        text+='</div>'
        folium.Marker([s.geometry.y,s.geometry.x],tooltip=esc(s.school_name),
            popup=folium.Popup(text,max_width=360),
            icon=folium.Icon(color='darkblue' if s.school_id==selected_school_id else 'blue',
                             icon='graduation-cap',prefix='fa'),keyboard=True).add_to(school_layer)
    area=folium.FeatureGroup(name='Selected school · one mile').add_to(m)
    folium.Circle([origin.y,origin.x],radius=RADIUS_METRES,color='#174f86',fill=False,
        tooltip='Straight-line radius; not an attendance boundary').add_to(area)
    located=crashes.loc[crashes.valid_coordinates & ~crashes.is_deleted & crashes.date_matches_source_year]
    specs=[('Located pedestrian/bicycle crashes','#167b82',located,True),
           ('Recorded ped/bike age 5–17 · student status unknown','#ad6418',located.loc[located.age_5_17.gt(0)],False),
           ('Crash factor marked cited · incomplete CCRS subset','#70528b',located.loc[located.crash_factor_marked_cited.fillna(False)],False)]
    cluster_entries=[]
    for label,color,records,show in specs:
        group=folium.FeatureGroup(name=f'{label} ({len(records):,})',show=show).add_to(m)
        cluster=MarkerCluster().add_to(group)
        entries=[]
        for _,c in records.iterrows():
            cited_label='Unknown' if pd.isna(c.crash_factor_marked_cited) else ('Marked cited' if c.crash_factor_marked_cited else 'Not marked cited')
            text=(f'<b>{esc(c.collision_modes)} · {c.date:%Y-%m-%d}</b><br>{esc(c.documented_severity)}<br>'
                f'{esc(c.PrimaryRoad)} / {esc(c.SecondaryRoad)}<br>'
                f'CCRS ID: {esc(c.case_id)}<br>Agency (NCIC): {esc(c["NCIC Code"])}<br>Local report: {esc(c["Report Number"])}<br>'
                f'Recorded ped/bike parties age 5–17: {int(c.age_5_17)}<br>Ped/bike parties with unknown age: {int(c.age_unknown)}<br>'
                f'Student / school trip: unknown<br>Crash factor: {esc(cited_label)}<br>{esc(c["Primary Collision Factor Violation"])}<br>'
                'A crash factor code alone does not establish a citation or conviction.')
            marker_color=({'Pedestrian':'#167b82','Bicycle':'#b05f14','Pedestrian + bicycle':'#5b5b5b'}[c.collision_modes]
                          if label=='Located pedestrian/bicycle crashes' else color)
            marker=folium.CircleMarker([c.Latitude,c.Longitude],radius=5,color=marker_color,fill=True,fill_opacity=.8,
                tooltip=f'{esc(c.collision_modes)} · {c.date:%Y-%m-%d} · {esc(c.PrimaryRoad)}',
                popup=folium.Popup(text,max_width=360)).add_to(cluster)
            entries.append((marker,bool(c.pedestrian_involved),bool(c.bicycle_involved)))
        cluster_entries.append((cluster,entries))
    if loaded:
        group=folium.FeatureGroup(name=f'Imported traffic citations · source-limited ({len(citations):,})',show=False).add_to(m)
        cluster=MarkerCluster().add_to(group)
        for _,c in citations.iterrows():
            text=(f'<b>{esc(c.agency)} · {c.issued_date:%Y-%m-%d}</b><br>{esc(c.violation_code)} · {esc(c.violation_description)}<br>'
                  f'Location: {esc(c.location_role)} / {esc(c.location_precision)}<br>'
                  'Citation issued; disposition/conviction not established.<br>'
                  f'<a href="{esc(c.source_url)}" target="_blank" rel="noopener">Source</a>')
            folium.CircleMarker([c.latitude,c.longitude],radius=6,color='#864329',fill=False,
                tooltip=f'{esc(c.violation_code)} · {esc(c.location_precision)}',popup=folium.Popup(text,max_width=340)).add_to(cluster)
    folium.LayerControl(collapsed=False).add_to(m)
    add_collision_type_control(m,cluster_entries,int(located.pedestrian_involved.sum()),int(located.bicycle_involved.sum()))
    return m


def export_public_enrichment(result,output_dir):
    output=Path(output_dir);output.mkdir(exist_ok=True,parents=True)
    crashes,queue,summary=result
    crashes.to_csv(output/'enriched_public_crashes.csv',index=False)
    queue.to_csv(output/'location_recovery_queue_NOT_GEOCODED.csv',index=False)
    (output/'enrichment_summary.json').write_text(json.dumps(summary,indent=2))
    pd.DataFrame(columns=CITATION_COLUMNS).to_csv(output/'traffic_citations_template.csv',index=False)
