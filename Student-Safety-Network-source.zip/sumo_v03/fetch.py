"""Cache public OSM responses with source hashes; no credentials required."""
from pathlib import Path
import datetime,hashlib,json,requests,xml.etree.ElementTree as E
ROOT=Path(__file__).resolve().parents[1];RAW=ROOT/'data/sumo_v03/raw';RAW.mkdir(parents=True,exist_ok=True)
def download(name,url,params=None):
 p=RAW/name
 if p.exists():return p
 r=requests.get(url,params=params,headers={'User-Agent':'SchoolCollisionResearch/0.3'},timeout=120);r.raise_for_status();x=E.fromstring(r.content)
 if x.tag!='osm' or x.findall('remark'):raise ValueError(r.text[:500])
 p.write_bytes(r.content);p.with_suffix('.source.json').write_text(json.dumps({'url':r.url,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sha256':hashlib.sha256(r.content).hexdigest(),'bytes':len(r.content),'status':'community_mapped_not_surveyed'},indent=2));print(name,len(r.content),flush=True);return p
if __name__=='__main__':
 # Covers both school sites and immediate school access corridors; not a complete two-mile disk.
 download('north_current.osm.xml','https://api.openstreetmap.org/api/0.6/map',{'bbox':'-121.746,37.715,-121.710,37.734'})
 # A historical map snapshot is a history of mapping, not proof of physical installation dates.
 for name,date in [('east_pre','2023-03-01T00:00:00Z'),('east_post','2023-07-01T00:00:00Z')]:
  q=f'[out:xml][timeout:60][date:"{date}"];(way[highway](37.677,-121.757,37.683,-121.744);node[highway](37.677,-121.757,37.683,-121.744););(._;>;);out meta;'
  try:download(name+'.osm.xml','https://overpass.openstreetmap.fr/api/interpreter',{'data':q})
  except Exception as e:print(name,type(e).__name__,str(e)[:250],flush=True)
