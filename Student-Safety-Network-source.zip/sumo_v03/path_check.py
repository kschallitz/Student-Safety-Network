"""Independently match simulated crossing trajectories to the observed crossing leg."""
import json,xml.etree.ElementTree as E,collections
import pandas as pd
from .prepare import DATA,OUT,ROOT

def main():
 old=pd.read_csv(OUT/'pedestrian_path_audit.csv');ports=json.loads((DATA/'ports.json').read_text());root=E.parse(OUT/'east_joined.net.xml').getroot();expected={}
 for site,arms in ports.items():
  for e in root.findall('edge'):
   if e.get('function')!='crossing' or not e.get('id').startswith(':'+site+'_c'):continue
   roadids=set(e.get('crossingEdges').split())
   for a,p in arms.items():
    if roadids & set(p.values()):expected[(site,a)]=e.get('id')
   if site=='Estates' and any('993182482' in x for x in roadids):expected[(site,'S')]=e.get('id')
 rows=[]
 for (site,path),g in old.groupby(['site','run_path']):
  seen=collections.defaultdict(set);cross=collections.defaultdict(set)
  for _,x in E.iterparse(ROOT/path/'trajectories.xml',events=['end']):
   if x.tag=='person' and x.get('id','').startswith('s'):
    id=x.get('id');leg=id.rsplit('_',1)[-1];seen[leg].add(id)
    if x.get('edge','').startswith(':'+site+'_c'):cross[(leg,id)].add(x.get('edge'))
   elif x.tag=='timestep':x.clear()
  for leg,ids in seen.items():
   want=expected[(site,leg)];matches=sum(cross[(leg,id)]=={want} for id in ids)
   rows.append({'site':site,'leg':leg,'observed_study_people':len(ids),'people_with_exactly_one_junction_crossing':sum(len(cross[(leg,id)])==1 for id in ids),'expected_crossing':want,'people_using_expected_crossing_only':matches,'max_distinct_crossings':max(len(cross[(leg,id)]) for id in ids),'passed':matches==len(ids),'run_path':path})
 df=pd.DataFrame(rows);df.to_csv(OUT/'pedestrian_path_audit.csv',index=False);print(df[['site','leg','observed_study_people','expected_crossing','passed']].to_string(index=False));assert df.passed.all()
if __name__=='__main__':main()
