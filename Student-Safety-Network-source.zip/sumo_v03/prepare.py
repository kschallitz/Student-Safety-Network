"""Source-preserving OSM/GIS integration and explicit SUMO import assumptions."""
from pathlib import Path
import json,gzip,copy,re,hashlib
import xml.etree.ElementTree as ET
import pandas as pd,numpy as np,geopandas as gpd
from shapely.geometry import Point,LineString,box
ROOT=Path(__file__).resolve().parents[1];DATA=ROOT/'data/sumo_v03';OUT=ROOT/'outputs/sumo_v03';CRS=32610
BBOX={'east':(-121.758,37.677,-121.744,37.683),'north':(-121.746,37.715,-121.710,37.734)}
MOTOR={'residential','secondary','secondary_link','tertiary','tertiary_link','primary','primary_link','unclassified','living_street','service'}
KEYS=['highway','name','lanes','lanes:forward','lanes:backward','lanes:both_ways','oneway','maxspeed','width','width:lanes','turn:lanes','turn:lanes:forward','turn:lanes:backward','sidewalk','sidewalk:both','cycleway','crossing','crossing:markings','crossing:signals','traffic_sign','traffic_signals','traffic_signals:direction','stop','direction']
def tags(x):return {z.get('k'):z.get('v') for z in x.findall('tag')}
def tree(area):return ET.parse(DATA/'raw'/f'{area}_current.osm.xml').getroot()
def xml(x,p):ET.indent(x);ET.ElementTree(x).write(p,encoding='utf-8',xml_declaration=True)
def features():
 rows=[]
 for area in BBOX:
  r=tree(area);ns={x.get('id'):x for x in r.findall('node')};boundary=box(*BBOX[area])
  for typ in ['node','way']:
   for x in r.findall(typ):
    t=tags(x)
    if not(t.get('highway') or t.get('traffic_sign')):continue
    if typ=='node':g=Point(float(x.get('lon')),float(x.get('lat')))
    else:
     coords=[(float(ns[z.get('ref')].get('lon')),float(ns[z.get('ref')].get('lat'))) for z in x.findall('nd') if z.get('ref') in ns]
     if len(coords)<2:continue
     g=LineString(coords)
    if not g.intersects(boundary):continue
    rows.append({'area':area,'osm_type':typ,'osm_id':x.get('id'),'version':int(x.get('version')),'mapping_timestamp':x.get('timestamp'),'physical_effective_date':None,'source_url':f'https://www.openstreetmap.org/{typ}/{x.get("id")}','status':'community_mapped_current','tags_json':json.dumps(t),**{k:t.get(k) for k in KEYS},'geometry':g})
 f=gpd.GeoDataFrame(rows,crs=4326);f.to_file(DATA/'mapped_features.geojson',driver='GeoJSON');f.drop(columns='geometry').to_csv(DATA/'mapped_features.csv',index=False)
 # Restore useful raw county attributes, without changing existing predictions or backdating current tags.
 roads=gpd.read_file(ROOT/'intersection_prediction_output/road_inventory.geojson');roads=roads[roads.geometry.intersects(box(-121.765,37.674,-121.706,37.737))].copy()
 with gzip.open(ROOT/'data/regional_roads/raw/alameda_county_streets.geojson.gz','rt') as h:raw=json.load(h)
 props={f'AC-{x["properties"]["OBJECTID"]}':x['properties'] for x in raw['features']}
 for field in ['NumberOfLanes','Oneway','RevDate','FunctionalClass']:
  roads[field]=[props.get(s,{}).get(field) for s in roads.sid]
 roads['attribute_epoch']='current county inventory; RevDate is not physical installation date';roads.to_file(DATA/'county_road_attributes.geojson',driver='GeoJSON');roads.drop(columns='geometry').to_csv(DATA/'county_road_attributes.csv',index=False)
 # Join mapped context to each Explorer intersection in the downloaded bounds; counts are mapped features, not completeness guarantees.
 js=gpd.read_file(ROOT/'intersection_prediction_output/junctions.geojson');js=js[js.geometry.intersects(box(*BBOX['east']))|js.geometry.intersects(box(*BBOX['north']))].copy().to_crs(CRS)
 fm=f.to_crs(CRS);rm=roads.to_crs(CRS);pred=pd.read_csv(ROOT/'intersection_prediction_output/map_predictions.csv');out=[]
 for _,j in js.iterrows():
  nearby=fm[fm.geometry.distance(j.geometry)<=60];points=nearby[nearby.osm_type.eq('node')];ways=nearby[nearby.osm_type.eq('way') & nearby.highway.isin(MOTOR)];county=rm[rm.geometry.distance(j.geometry)<=35]
  row={'junction_id':j.junction_id,'name':j['name'],'city':j.city,'lat':j.to_frame().T if False else j.geometry.y,'context_radius_m':60,'mapped_crossing_nodes':int(points.highway.eq('crossing').sum()),'mapped_signal_nodes':int(points.highway.eq('traffic_signals').sum()),'mapped_stop_nodes':int(points.highway.eq('stop').sum()),'mapped_sign_nodes':int(points.traffic_sign.notna().sum()),'nearby_mapped_road_ways':len(ways),'osm_lane_tagged_ways':int(ways.lanes.notna().sum()),'osm_width_tagged_ways':int(ways.width.notna().sum()),'osm_oneway_tagged_ways':int(ways.oneway.notna().sum()),'osm_turn_lane_tagged_ways':int(ways[['turn:lanes','turn:lanes:forward','turn:lanes:backward']].notna().any(axis=1).sum()),'county_lane_count_values':json.dumps(sorted(set(str(x) for x in county.NumberOfLanes.dropna()))),'county_oneway_values':json.dumps(sorted(set(str(x) for x in county.Oneway.dropna()))),'missing_tag_meaning':'unknown; mapped node counts are not physical counts','historical_use':'not backfilled into historical training','probability_use':'comparison only; not training target or safety reward'}
  lon,lat=gpd.GeoSeries([j.geometry],crs=CRS).to_crs(4326).iloc[0].coords[0];row['lat']=lat;row['lon']=lon;out.append(row)
 table=pd.DataFrame(out).merge(pred[['junction_id','annual_probability','recorded_cases_2014_2025']],on='junction_id',how='left',validate='one_to_one');table.to_csv(DATA/'explorer_feature_comparison.csv',index=False)
 stats=[]
 for area,g in f.groupby('area'):
  ways=g[g.osm_type.eq('way') & g.highway.isin(MOTOR)];pts=g[g.osm_type.eq('node')]
  stats.append({'area':area,'mapped_road_ways':len(ways),'lanes_tagged':int(ways.lanes.notna().sum()),'width_tagged':int(ways.width.notna().sum()),'crossing_nodes':int(pts.highway.eq('crossing').sum()),'signal_nodes':int(pts.highway.eq('traffic_signals').sum()),'stop_nodes':int(pts.highway.eq('stop').sum()),'explicit_sign_nodes':int(pts.traffic_sign.notna().sum())})
 pd.DataFrame(stats).to_csv(OUT/'feature_coverage.csv',index=False)
 return f

def simulation_osm(area='east'):
 r=tree(area);ns={x.get('id'):x for x in r.findall('node')};out=ET.Element('osm',version='0.6');ways=[];ids=set();audit=[];boundary=box(*BBOX[area])
 for w in r.findall('way'):
  t=tags(w);refs=[z.get('ref') for z in w.findall('nd')]
  if t.get('highway') not in MOTOR or not all(k in ns for k in refs):continue
  coords=[(float(ns[k].get('lon')),float(ns[k].get('lat'))) for k in refs]
  if not LineString(coords).intersects(boundary):continue
  w=copy.deepcopy(w)
  def put(k,v,status,reason):
   old=t.get(k)
   for e in list(w.findall('tag')):
    if e.get('k')==k:w.remove(e)
   ET.SubElement(w,'tag',k=k,v=str(v));audit.append({'area':area,'osm_way_id':w.get('id'),'name':t.get('name'),'attribute':k,'input_value':old,'simulation_value':v,'status':status,'reason':reason})
  # East Avenue 30mph is supported by the city corridor report; missing OSM speed must not default to 100km/h.
  if t.get('name')=='East Avenue':put('maxspeed','30 mph','documented_city_corridor_prior','Phase I p22; school conditional restrictions not scheduled')
  elif not t.get('maxspeed'):put('maxspeed','25 mph','assumed_missing_speed','Local/service street scenario default; not a field observation')
  # Use attached sidewalks as the SUMO representation. Separate mapped footpaths stay in the evidence inventory.
  if t.get('sidewalk') not in ['no','none']:
   put('sidewalk','both','representation_assumption','Attached sidewalks replace separate footpath network for junction replay; widths unknown')
   for e in list(w.findall('tag')):
    if e.get('k','').startswith('sidewalk:'):w.remove(e)
  ways.append(w);ids.update(refs)
 out.extend(copy.deepcopy(ns[i]) for i in sorted(ids));out.extend(ways);xml(out,DATA/f'{area}_simulation.osm.xml');pd.DataFrame(audit).to_csv(DATA/f'{area}_import_assumptions.csv',index=False)
 return DATA/f'{area}_simulation.osm.xml'
if __name__=='__main__':
 features();simulation_osm();simulation_osm('north');print('Saved mapped feature inventory, county attributes, Explorer join and SUMO import inputs.')
