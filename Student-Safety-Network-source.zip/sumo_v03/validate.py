"""Targeted regression checks for real routes, speed actions and portable runs."""
import json,xml.etree.ElementTree as E,collections
import pandas as pd
from .prepare import DATA,ROOT,OUT
from .replay import run

def main():
 df=pd.read_csv(ROOT/'data/sumo_v02/junction_demand_15min.csv');audit=[];trajectory=[]
 for site in ['Estates','Hillcrest']:
  g=df[df.site.eq(site)&df.date.eq('2023-05-18')&df.interval_start.str[11:13].astype(int).lt(9)]
  for action in ['mapped_baseline','posted_25','posted_35']:audit.append(run(g,action,2029,step=.1))
  r=run(g,'mapped_baseline',2029,fcd=True);edges=collections.defaultdict(set);people=collections.defaultdict(set)
  for _,x in E.iterparse(ROOT/r['path']/'trajectories.xml',events=['end']):
   if x.tag=='person' and x.get('id','').startswith('s'):
    leg=x.get('id').rsplit('_',1)[-1];people[leg].add(x.get('id'))
    if x.get('edge','').startswith(':'+site+'_c'):edges[(leg,x.get('id'))].add(x.get('edge'))
   elif x.tag=='timestep':x.clear()
  # Each recorded crossing leg should take one junction crossing, not route around three sides.
  for leg,ids in people.items():
   used=[len(edges[(leg,id)]) for id in ids];trajectory.append({'site':site,'leg':leg,'observed_study_people':len(ids),'people_with_exactly_one_junction_crossing':sum(n==1 for n in used),'max_distinct_crossings':max(used),'passed':all(n==1 for n in used),'run_path':r['path']})
 pd.DataFrame(audit).to_csv(OUT/'time_step_audit.csv',index=False);pd.DataFrame(trajectory).to_csv(OUT/'pedestrian_path_audit.csv',index=False);print(pd.DataFrame(trajectory).to_string(index=False))
if __name__=='__main__':main()
