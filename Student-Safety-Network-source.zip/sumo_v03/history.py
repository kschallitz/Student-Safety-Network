"""Check OSM edit histories for relevant existing objects; not a complete historical extract."""
import json,datetime,xml.etree.ElementTree as ET
import pandas as pd,geopandas as gpd
from shapely.geometry import Point
from .prepare import DATA,OUT,CRS,tags
from .fetch import download

def main():
 f=gpd.read_file(DATA/'mapped_features.geojson').to_crs(CRS);centers=gpd.GeoSeries([Point(-121.7517466,37.6799404),Point(-121.7484960,37.6799255)],crs=4326).to_crs(CRS)
 f=f[f['area'].eq('east') & f.geometry.distance(centers.union_all()).le(120)]
 f=f[f.highway.isin(['crossing','traffic_signals','stop','residential','secondary'])]
 rows=[]
 for _,x in f.iterrows():
  if pd.Timestamp(x.mapping_timestamp)>pd.Timestamp('2023-03-01T00:00:00Z'):
   try:p=download(f'history_{x.osm_type}_{x.osm_id}.xml',f'https://api.openstreetmap.org/api/0.6/{x.osm_type}/{x.osm_id}/history');versions=ET.parse(p).getroot().findall(x.osm_type)
   except Exception as e:rows.append({'osm_type':x.osm_type,'osm_id':x.osm_id,'status':'history_fetch_failed','detail':str(e)[:150]});continue
  else:
   rows.append({'osm_type':x.osm_type,'osm_id':x.osm_id,'status':'current_object_unchanged_since_before_pilot','last_edit':x.mapping_timestamp,'note':'Object edit date does not verify physical condition or its component nodes'});continue
  for cutoff in ['2023-03-01T00:00:00Z','2023-05-20T23:59:59Z','2023-07-01T00:00:00Z']:
   eligible=[z for z in versions if z.get('timestamp')<=cutoff];v=max(eligible,key=lambda z:int(z.get('version'))) if eligible else None
   rows.append({'osm_type':x.osm_type,'osm_id':x.osm_id,'status':'version_at_cutoff' if v is not None else 'not_yet_mapped','cutoff':cutoff,'version':v.get('version') if v is not None else None,'last_edit':v.get('timestamp') if v is not None else None,'tags':json.dumps(tags(v)) if v is not None else None,'note':'Mapping history only; current-object selection cannot recover deleted objects'})
 pd.DataFrame(rows).to_csv(DATA/'osm_history_audit.csv',index=False)
 print('historical audit rows',len(rows))
if __name__=='__main__':main()
