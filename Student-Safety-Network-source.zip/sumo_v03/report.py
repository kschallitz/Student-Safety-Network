"""Summarize mapped-network tests without promoting simulated events to field risk."""
import json,hashlib,os,xml.etree.ElementTree as E
from pathlib import Path
import pandas as pd,numpy as np,sumolib
from .prepare import ROOT,DATA,OUT
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.mplconfig'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
EXPECTED_MODEL_SHA='12d19ef2f8bd7ab047e50f3fa435c29c8a8bada6ff5d26fdd85c8ebf1f4c3818'

def recompute_motor_metrics():
 # Recompute directly from saved trip records; bicycles are excluded from motor summaries.
 for name in ['mapped_replays.csv','time_step_audit.csv','smoke_replays.csv']:
  table=pd.read_csv(OUT/name)
  for i,r in table.iterrows():
   motor=[z for z in E.parse(ROOT/r['path']/'trips.xml').getroot() if z.tag=='tripinfo' and z.get('id','').startswith('s') and z.get('vType') in ['passenger','heavy']]
   for col,attr in [('motor_mean_duration_s','duration'),('motor_mean_wait_s','waitingTime')]:table.at[i,col]=float(np.mean([float(z.get(attr)) for z in motor]))
   result=ROOT/r['path']/'result.json';d=json.loads(result.read_text());d.update({col:float(table.at[i,col]) for col in ['motor_mean_duration_s','motor_mean_wait_s']});d['motor_summary_population']='study passenger and heavy vehicles; excludes bicycles';result.write_text(json.dumps(d,indent=2))
  table.to_csv(OUT/name,index=False)

def main():
 recompute_motor_metrics()
 rows=pd.read_csv(OUT/'mapped_replays.csv');obs=pd.read_csv(ROOT/'data/sumo_v02/junction_demand_15min.csv');groups=rows.groupby(['site','action']);summary=groups.agg(runs=('seed','size'),study_movements_requested=('study_requested','sum'),study_movements_completed=('study_arrived','sum'),incomplete_runs=('pending',lambda s:int((s>0).sum())),simulated_vru_collision_pairs=('vru_collision_pairs','sum'),mean_motor_travel_seconds=('motor_mean_duration_s','mean'),mean_motor_wait_seconds=('motor_mean_wait_s','mean')).reset_index();summary.to_csv(OUT/'replay_summary.csv',index=False)
 pairs=rows.pivot(index=['session_id','seed'],columns='action',values='motor_mean_duration_s');pairs['posted_25_minus_baseline_s']=pairs.posted_25-pairs.mapped_baseline;pairs['posted_35_minus_baseline_s']=pairs.posted_35-pairs.mapped_baseline;pairs.to_csv(OUT/'speed_scenario_pairs.csv')
 checks=[]
 def add(k,ok,detail):checks.append({'check':k,'passed':bool(ok),'detail':str(detail)})
 add('15 sessions x 3 actions x 2 seeds',len(rows)==90,len(rows))
 add('Every requested study movement completed',(rows.study_requested==rows.study_arrived).all(),f'{int((rows.study_requested!=rows.study_arrived).sum())} incomplete study runs')
 add('No pending people or vehicles at end',rows.pending.eq(0).all(),int(rows.pending.gt(0).sum()))
 add('Input counts match source sessions',all(int(r.study_requested)==int(obs[obs.session_id.eq(r.session_id)]['count'].sum()) for r in rows.itertuples()),'Native 15-minute sums; repeated seeds are not new field observations')
 add('Identical demand across speed scenarios',rows.groupby(['session_id','seed']).demand_sha256.nunique().eq(1).all(),'Same departures, modes and driver draws')
 features=pd.read_csv(DATA/'explorer_feature_comparison.csv');add('Explorer feature join one-to-one',not features.junction_id.duplicated().any(),len(features))
 sha=hashlib.sha256((ROOT/'intersection_prediction_output/model.json').read_bytes()).hexdigest();add('Production probability model unchanged',sha==EXPECTED_MODEL_SHA,sha)
 control=pd.read_csv(DATA/'signal_control.csv');add('Every Hillcrest motor and crossing link receives green',control.groupby('link').state.apply(lambda s:s.isin(['G','g']).any()).all(),'Fixed 2020-derived phase structure, timing still assumed')
 numerical=OUT/'time_step_audit.csv'
 if numerical.exists():
  q=pd.read_csv(numerical);add('Finer-step replay completes',q.pending.eq(0).all(),f'{len(q)} finer-step runs; not a distributional convergence study')
 paths=pd.read_csv(OUT/'pedestrian_path_audit.csv');add('Sampled pedestrians use intended single crossing',paths.passed.all(),f'{paths.observed_study_people.sum()} people in two sampled school-arrival sessions')
 pd.DataFrame(checks).to_csv(OUT/'validation_checks.csv',index=False)
 gate={'version':'0.3','mapped_network_integration':all(x['passed'] for x in checks),'mapped_road_features':True,'replay_runs':len(rows),'incomplete_runs':int(rows.pending.gt(0).sum()),'field_probability_release':False,'rl_reward_validated':False,'exact_2023_treatment_reconstructed':False,'reason':'Mapped geometry and controls are integrated and replayed. Exact 2023 curb dimensions, controller timings and observed conflict/yield trajectories remain unavailable. Current mapping is not an as-built historical survey.','production_probability_model_unchanged':sha==EXPECTED_MODEL_SHA}
 (OUT/'release_gate.json').write_text(json.dumps(gate,indent=2))
 # Inspect the actual compiled network geometry; draw motor centerlines, crossings and controls.
 n=sumolib.net.readNet(str(OUT/'east_joined.net.xml'),withInternal=True,withPedestrianConnections=True);fig,axes=plt.subplots(1,2,figsize=(12,5.2))
 for ax,site in zip(axes,['Estates','Hillcrest']):
  cx,cy=n.getNode(site).getCoord()
  for e in n.getEdges(withInternal=True):
   pts=np.array(e.getShape());
   if not len(pts) or np.min(np.linalg.norm(pts-np.array([cx,cy]),axis=1))>180:continue
   cross=e.getFunction()=='crossing';walk=e.getFunction()=='walkingarea'
   if walk:continue
   if cross:ax.plot(pts[:,0]-cx,pts[:,1]-cy,color='#a44d20',lw=3,zorder=5)
   elif not e.getFunction() and e.allows('passenger'):ax.plot(pts[:,0]-cx,pts[:,1]-cy,color='#1c7188',lw=2)
  ax.scatter([0],[0],c='#17364d',s=35);ax.set(xlim=(-150,150),ylim=(-145,145),aspect='equal',title=f'East Avenue / {site}',xlabel='Meters east of junction',ylabel='Meters north of junction');ax.grid(alpha=.15)
 axes[0].legend(handles=[plt.Line2D([0],[0],color='#1c7188',lw=2,label='Mapped road alignment'),plt.Line2D([0],[0],color='#a44d20',lw=3,label='Modeled crossing')],loc='lower left',fontsize=9)
 fig.suptitle('Mapped road alignments and modeled crossing connections',fontsize=15);fig.text(.5,.015,'OSM centerlines; lane/crossing widths and controller timings are not surveyed measurements.',ha='center',fontsize=10);fig.tight_layout(rect=(0,.05,1,.94));fig.savefig(OUT/'mapped_network.png',dpi=170);plt.close(fig)
 fig,ax=plt.subplots(figsize=(8,4));a=rows.groupby(['site','action']).motor_mean_duration_s.mean().unstack();a[['posted_25','mapped_baseline','posted_35']].rename(columns={'posted_25':'25 mph scenario','mapped_baseline':'30 mph baseline','posted_35':'35 mph scenario'}).plot.bar(ax=ax,color=['#b76321','#1c7188','#607d8a'],rot=0);ax.set(ylabel='Mean simulated vehicle trip duration (seconds)',xlabel='',title='Speed control is applied inside SUMO');ax.legend(fontsize=9);fig.text(.5,.01,'Same observed demand and seeds; not collision-reduction percentages. Driver compliance is assumed.',ha='center',fontsize=9);fig.tight_layout(rect=(0,.055,1,1));fig.savefig(OUT/'speed_scenarios.png',dpi=160);plt.close(fig)
 intervention=pd.DataFrame([
 ['Estates','2023-04-10','2023-04-14','high-visibility crossings','documented','present','City final report p3; OSM ladder tag appears May16; mapping date is not installation date'],
 ['Estates','2023-04-10','2023-04-14','painted median refuge','documented','present','City final report p3; dimensions unavailable'],
 ['Estates','2023-04-10','2023-04-14','protected curb extensions','documented','present','City final report p3; as-built dimensions unavailable'],
 ['Hillcrest','2023-04-10','2023-04-14','protected curb extensions','documented','present','City final report p3; as-built dimensions unavailable'],
 ['all six pilot intersections','2023-06-01','2023-06-30','bollard repositioning','documented month','present','City final report p6; exact site dates and radii unavailable'],
 ['all six pilot intersections','2023-06-01','2023-06-30','crossing distance reduction','observed corridor summary','22% average','Final report p7 after adjustments; not a measured per-site reduction'],
 ['Estates and Hillcrest',None,None,'posted speed limit change','not established',None,'Pilot report describes geometric/visibility changes; no measured 30-to-25 sign experiment']
 ],columns=['site','earliest_date','latest_date','feature','status','value','source_note']);intervention.to_csv(DATA/'intervention_evidence.csv',index=False)
 report=f'''# Mapped SUMO integration · experiment v0.3

The schematic East Avenue road network has been replaced by mapped road alignments, lane arrangements and crossing/control locations. **This is a completed integration and replay experiment, not a validated collision-probability model.** The website's existing ten-year estimates remain unchanged.

## What changed

- Downloaded public OSM extracts around East Avenue, Christensen and Altamont Creek; retained original tags, versions, source links and retrieval hashes.
- Joined mapped context to **{len(features)} Explorer intersections**. The estimates are comparisons only, not simulated ground truth or reward targets.
- Restored county lane-count and one-way attributes and preserved them in future road preparation.
- Built East Avenue and northern school-corridor SUMO networks. East Avenue uses real mapped centerlines and lane/turn arrangements; Estates/Hillcrest crossing locations are consolidated into modeled junctions. The observed Estates south-leg tally uses the mapped school-service access.
- Kept the existing February speed calibration frozen and used the existing 15-minute vehicle/heavy/bicycle/pedestrian measurements. Approach demand starts roughly 110 meters or more upstream where the mapped segments permit it; geometry and queued traffic continue across quarters.
- Applied 25/30/35 mph scenarios inside SUMO with identical demand and fixed driver factors. This is an assumed compliance response, not an estimated treatment effect.

## Checks and results

{summary.to_markdown(index=False,floatfmt='.2f')}

Runs and movement totals include repeated scenarios and seeds, **not additional independent observations**. Across {len(rows)} runs, {int(rows.pending.gt(0).sum())} ended with pending traffic. All simulation warnings and event files remain in the downloadable bundle.

![Mapped road geometry](mapped_network.png)

![Speed scenario response](speed_scenarios.png)

The original v0.2 had two incomplete junction episodes in its 120-run, four-action experiment. This v0.3 uses three speed scenarios and different geometry, so those totals are not a controlled accuracy comparison. Completed demand establishes a functioning replay, not faithful field behavior.

## Historical reconstruction: what the sources actually establish

OSM object histories confirm that the Estates east crossing's `ladder` marking tag was added in May 2023. That supports documenting a changed mapped feature. It does not supply a measured curb extension or driver response. The city report dates installation April 10–14 and adjustments to June. Its 22% crossing-distance reduction is a six-intersection average after adjustments; applying 22% at each intersection would invent site measurements.

The dated Overpass extracts could not be retrieved (403/406/rate-limit responses). The main OSM API supplied current maps and nine relevant object histories instead. This audits selected current objects; it is not a complete historical network and cannot recover deleted objects. Object edit dates are not physical installation dates. Accordingly, the same mapped geometry is replayed against pre/post demand to isolate the data integration; it is **not labeled an exact treatment replay**.

## Calibration and transfer

The frozen speed component retains the earlier out-of-fitting test. This update does not refit to post-installation speeds or claim that matching supplied vehicle counts predicts demand. The report found no substantial midblock speed decrease. Actual before/after crash comparisons remain the separate TIMS descriptive audit, with very wide uncertainty.

Christensen/Altamont now have mapped road features and a compiled network, and use the same source schema. They still lack equivalent current arrival/dismissal turning/crossing observations and measured interaction behavior. East Avenue's calibrated driver parameters have **not** been silently transferred there as validated estimates.

## What remains assumed or unverified

No explicit road-width tags were present among the downloaded motor-road ways. SUMO defaults therefore still supply lane/crosswalk/sidewalk dimensions, all labeled. Separate footpaths are represented as attached sidewalks in the replay; the original footpaths stay in the evidence inventory. Hillcrest's signal structure follows the historical report, but the phase durations are not verified 2023 controller records. Background traffic outside the measured junction movements is not synthesized as observed demand.

Yielding, gaps, turning speeds, and observed near-conflicts have not been calibrated against field trajectories. Neither literal SUMO collisions nor the Explorer's existing probabilities is a validated safety reward. **No new collision-reducing RL policy is released.** The simulation can now test behavior using mapped context, but claiming a collision-reduction percentage still requires that validation.

## Sources

- [City Tactical East Avenue report](https://www.livermoreca.gov/home/showpublisheddocument/12943/638887914440930000): installation, adjustments, observed counts/speeds and corridor summary.
- [OpenStreetMap](https://www.openstreetmap.org/copyright): community map snapshot, September 28, 2026; individual feature links in CSV.
- [County street inventory](https://gis.dublin.ca.gov/arcgis/rest/services/EnerGov/EnerGov_DisplayMap/MapServer/6): lane/one-way fields, current inventory.
- [SUMO OSM import](https://sumo.dlr.de/docs/Networks/Import/OpenStreetMap.html) and [pedestrian network guidance](https://sumo.dlr.de/docs/Simulation/Pedestrians.html): import behavior and defaults.

CSV exports, the Colab-compatible notebook, raw source snapshots and runnable configurations accompany this experiment.
'''
 (ROOT/'Mapped_SUMO_Integration_Readme.md').write_text(report);print(json.dumps(gate,indent=2))
if __name__=='__main__':main()
