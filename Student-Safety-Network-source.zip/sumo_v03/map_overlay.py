"""Expose downloaded OSM evidence without silently changing model probabilities."""
import json,math
import pandas as pd,geopandas as gpd
from .prepare import DATA,OUT,ROOT

def payload():
 f=json.loads((DATA/'mapped_features.geojson').read_text());nodes=[];ways=[]
 for x in f['features']:
  p=x['properties'];g=x['geometry'];tags=json.loads(p['tags_json']) if isinstance(p['tags_json'],str) else p['tags_json']
  if g['type']=='Point' and (p['highway'] in ['crossing','traffic_signals','stop','give_way'] or p['traffic_sign']):nodes.append({'id':p['osm_type']+'/'+p['osm_id'],'ll':list(reversed(g['coordinates'])),'kind':p['highway'],'tags':tags,'url':p['source_url'],'updated':str(p['mapping_timestamp'])[:10]})
  if g['type']=='LineString' and p['highway'] not in ['footway','path','steps']:
   ways.append({'id':p['osm_id'],'ll':[list(reversed(c)) for c in g['coordinates']],'name':p['name'],'tags':{k:v for k,v in tags.items() if k in ['highway','lanes','oneway','width','maxspeed','turn:lanes:forward','turn:lanes:backward','lanes:forward','lanes:backward','sidewalk']},'url':p['source_url']})
 table=pd.read_csv(DATA/'explorer_feature_comparison.csv').fillna('');return {'version':'0.3','nodes':nodes,'roads':ways,'junctions':{r['junction_id']:r for r in table.to_dict('records')},'coverage':'East Avenue corridor and immediate Christensen/Altamont access corridors; not full two-mile disks','retrieved':'2026-09-28'}

def install():
 p=payload();(OUT/'mapped_context.json').write_text(json.dumps(p,separators=(',',':'),allow_nan=False))
 js=r'''
const MAPPED_CONTEXT=__DATA__;
const mappedNodes=L.layerGroup(),mappedRoads=L.layerGroup();
map.createPane('mapped-road-pane').style.zIndex=350;
map.createPane('mapped-node-pane').style.zIndex=450;
for(const f of MAPPED_CONTEXT.nodes){const color=f.kind==='traffic_signals'?'#a74b00':f.kind==='stop'?'#b33636':'#6c43a0';L.circleMarker(f.ll,{pane:'mapped-node-pane',radius:7,color:'#fff',weight:1.4,fillColor:color,fillOpacity:.95}).bindPopup(`<b>${esc(f.kind==='crossing'?'Mapped crossing':f.kind==='traffic_signals'?'Mapped traffic signal':f.kind==='stop'?'Mapped stop control':'Mapped road feature')}</b><br>${Object.entries(f.tags).filter(([k])=>!k.startsWith('tiger:')).map(([k,v])=>esc(k)+': '+esc(v)).join('<br>')}<br><a href="${f.url}" target="_blank" rel="noopener">OpenStreetMap source</a><br>Map edit: ${f.updated}. Installation date unverified.`).addTo(mappedNodes);}
for(const f of MAPPED_CONTEXT.roads){L.polyline(f.ll,{pane:'mapped-road-pane',color:'#7654a1',weight:4,opacity:.55}).bindPopup(`<b>${esc(f.name||'Mapped road')}</b><br>${Object.entries(f.tags).map(([k,v])=>esc(k)+': '+esc(v)).join('<br>')}<br><a href="${f.url}" target="_blank" rel="noopener">OpenStreetMap source</a><br>Missing tags mean unknown.`).addTo(mappedRoads);}
$('mapped-nodes').addEventListener('change',()=>{$('mapped-nodes').checked?mappedNodes.addTo(map):map.removeLayer(mappedNodes);});
$('mapped-roads').addEventListener('change',()=>{$('mapped-roads').checked?mappedRoads.addTo(map):map.removeLayer(mappedRoads);});
function mappedDetail(j){const d=MAPPED_CONTEXT.junctions[j.id];$('mapped-context-detail').innerHTML=d?`<h3>Mapped road context</h3><p class="small">Within 60 meters: ${d.mapped_crossing_nodes} crossing tags · ${d.mapped_signal_nodes} signal tags · ${d.mapped_stop_nodes} stop-control tags. These count map objects; several may describe one junction.</p><p class="small">${d.osm_lane_tagged_ways} of ${d.nearby_mapped_road_ways} nearby mapped road ways have lane counts; ${d.osm_width_tagged_ways} have widths. County lane values: ${esc(d.county_lane_count_values)}; 0 or empty means unspecified.</p><p class="notice">These features now support the mapped SUMO experiment. The displayed collision estimate is still the existing ten-year model; these current tags have not been backdated into its training.</p>`:'<p class="small">Detailed OSM features have not been downloaded for this intersection. That does not mean crossings or signals are absent.</p>';const labSite={J01145:'Estates',J02019:'Hillcrest'}[j.id];if(labSite)$('mapped-context-detail').innerHTML+=`<p><a href="east-avenue-lab.html?site=${labSite}" target="_blank" rel="noopener">Open the ${labSite} SUMO speed experiment and traffic replay</a></p>`;}
const originalSelect=select;select=function(j){originalSelect(j);mappedDetail(j);};
if(selected)mappedDetail(selected);
'''.replace('__DATA__',json.dumps(p,separators=(',',':'),allow_nan=False).replace('</','<\\/'))
 (OUT/'map_overlay.js').write_text(js)
 # Keep the reusable template and current output aligned without rebuilding any fits.
 template=ROOT/'intersection_map_template.html';s=template.read_text()
 if 'id="mapped-context-detail"' not in s:s=s.replace('<h3>Recorded history · within 500 feet</h3>','<div id="mapped-context-detail"></div><h3>Recorded history · within 500 feet</h3>')
 if 'id="mapped-nodes"' not in s:s=s.replace('<details><summary>Historical speed changes', '<details><summary>Mapped road features · new</summary><div class="checks"><label><input id="mapped-nodes" type="checkbox">Crossings, signals and stop controls</label><label><input id="mapped-roads" type="checkbox">Mapped road details and lanes</label></div><p class="small">Available near East Avenue, Christensen and Altamont Creek. OSM snapshot: September 28, 2026. Missing tags mean unknown; coverage is not a complete two-mile disk.</p><p><a href="mapped-simulation.html" target="_blank" rel="noopener">Mapped SUMO experiment and downloads</a></p></details><details><summary>Historical speed changes')
 if '/*MAPPED_FEATURES*/' not in s:s=s.replace('</body>','<script>/*MAPPED_FEATURES*/</script></body>')
 template.write_text(s)
 compiled=ROOT/'intersection_prediction_output/school_intersection_predictions.html'
 from website_release import stamp_map
 model=(ROOT/'intersection_model.js').read_text();oldpayload=(ROOT/'intersection_prediction_output/map_payload.json').read_text()
 html=stamp_map(s).replace('/*MODEL_CODE*/',model).replace('/*PAYLOAD*/',oldpayload.replace('</','<\\/')).replace('/*MAPPED_FEATURES*/',js)
 html=html.replace('const $=id=>','DATA.junctions.forEach(j=>{j.x=Array.from({length:6},(_,b)=>[...j.base,j.historyBand[b],j.knownBand[b],...Array.from({length:6},(_,i)=>+(i===b)),j.region]);});\nconst $=id=>')
 compiled.write_text(html);print('Updated map evidence layers and intersection feature details. Prediction weights unchanged.')
if __name__=='__main__':install()
