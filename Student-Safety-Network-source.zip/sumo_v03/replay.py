"""Replay native observed demands on mapped geometry; no field-probability reward."""
import json,os,hashlib,time,math,argparse,xml.etree.ElementTree as E
from pathlib import Path
import pandas as pd,numpy as np,sumolib
from .prepare import ROOT,DATA,OUT,xml
MPH=.44704

def context():
 n=sumolib.net.readNet(str(OUT/'east_joined.net.xml'),withInternal=True,withPedestrianConnections=True);ports=json.loads((DATA/'ports.json').read_text());return n,ports

def chain(n,eid,direction,minlength=110):
 e=n.getEdge(eid);path=[e];length=e.getLength()
 while length<minlength:
  candidates=e.getIncoming() if direction=='in' else e.getOutgoing()
  same=[v for v in candidates if not v.getFunction() and v.getName()==e.getName() and v.allows('passenger') and v not in path and ((direction=='in' and v.getFromNode()!=e.getToNode()) or (direction=='out' and v.getToNode()!=e.getFromNode()))]
  # Avoid traversing another multi-road motor junction just to lengthen a route.
  if len(same)!=1:break
  e=same[0];path.append(e);length+=e.getLength()
 if direction=='in':path.reverse()
 return path

def make_demand(rows,seed,p,n,ports):
 rng=np.random.default_rng(seed);root=E.Element('routes');site=rows.iloc[0].site;port=ports[site];model=json.loads((ROOT/'outputs/sumo_v02/calibration.json').read_text())
 for typ,extra in [('passenger',{'vClass':'passenger','length':'5','accel':'2.6','decel':'4.5'}),('heavy',{'vClass':'truck','length':'10','accel':'1.3','decel':'4'}),('bicycle',{'vClass':'bicycle','length':'1.6','maxSpeed':'5.56','accel':'1.2','decel':'3'}),('walker',{'vClass':'pedestrian','maxSpeed':'1.4'})]:
  E.SubElement(root,'vType',id=typ,**extra,speedDev='0',**({} if typ=='walker' else {'tau':'1.2','minGap':'2.5'}))
 rows=rows.copy();start=pd.to_datetime(rows.interval_start).min();rows['offset']=(pd.to_datetime(rows.interval_start)-start).dt.total_seconds()+900
 warm=rows[rows.offset.eq(900)].copy();warm['offset']=0;both=pd.concat([warm,rows]);els=[];seq=0;routes={};audit=[]
 for _,r in both.iterrows():
  if int(r['count'])==0:continue
  key=(r['mode'],r.from_arm,r.to_arm,r.crossing_leg)
  if r['mode']!='pedestrian' and key not in routes:
   a,b=port[r.from_arm]['in'],port[r.to_arm]['out'];mid,cost=n.getShortestPath(n.getEdge(a),n.getEdge(b),vClass='bicycle' if r['mode']=='bicycle' else 'truck' if r['mode']=='heavy' else 'passenger')
   if not mid or not any(e.getToNode().getID()==site for e in mid):raise ValueError(f'Movement not routed through required junction: {key}')
   path=chain(n,a,'in')[:-1]+list(mid)+chain(n,b,'out')[1:];routes[key]=[e.getID() for e in path]
   audit.append({'site':site,'mode':r['mode'],'from_arm':r.from_arm,'to_arm':r.to_arm,'edges':' '.join(routes[key])})
  for _ in range(int(r['count'])):
   depart=float(r.offset+rng.uniform(0,900));prefix='w' if r.offset==0 else 's';vid=f'{prefix}{seq}';seq+=1
   if r['mode']=='pedestrian':
    leg=r.crossing_leg;forward=bool(rng.random()<.5)
    if leg in port:a,b=port[leg]['in'],port[leg]['out']
    elif site=='Estates' and leg=='S':a,b=port['W']['in'],port['E']['out']
    else:raise ValueError(f'Unknown pedestrian leg {site} {leg}')
    if not forward:a,b=b,a
    la=n.getEdge(a).getLength();lb=n.getEdge(b).getLength()
    # Start/end near the selected junction. Reversing walk order doesn't reverse edge coordinates.
    dep=max(.1,la-8) if n.getEdge(a).getToNode().getID()==site else min(8,la-.1)
    arr=min(8,lb-.1) if n.getEdge(b).getFromNode().getID()==site else max(.1,lb-8)
    z=E.Element('person',id=vid+'_ped_'+leg,type='walker',depart=f'{depart:.3f}',departPos=str(dep));E.SubElement(z,'walk',edges=f'{a} {b}',arrivalPos=str(arr))
   else:
    dr='eastbound' if r.from_arm=='W' else 'westbound' if r.from_arm=='E' else None
    factor=max(.2,rng.normal(model[dr]['desired_mean_mph'],model[dr]['desired_sd_mph'])/30) if dr else float(np.clip(rng.normal(1,.1),.7,1.3))
    z=E.Element('vehicle',id=vid+'_'+r['mode'],type=r['mode'],depart=f'{depart:.3f}',departLane='best',departSpeed='max',speedFactor='1' if r['mode']=='bicycle' else str(factor));E.SubElement(z,'route',edges=' '.join(routes[key]))
   els.append((depart,z))
 for _,z in sorted(els,key=lambda v:v[0]):root.append(z)
 xml(root,p/'demand.rou.xml');pd.DataFrame(audit).to_csv(p/'route_audit.csv',index=False);return int(rows['count'].sum()),len(els)

def run(rows,action='mapped_baseline',seed=2029,step=.5,fcd=False):
 import libsumo as sim
 n,ports=context();site=rows.iloc[0].site;session=rows.iloc[0].session_id;net=OUT/'east_joined.net.xml';signal=DATA/'fixed_signal.add.xml';ident=['mapped_v03_1',hashlib.sha256(net.read_bytes()+signal.read_bytes()+Path(__file__).read_bytes()).hexdigest(),session,action,seed,step,fcd];key=hashlib.sha256(json.dumps(ident).encode()).hexdigest()[:16];p=OUT/'runs'/key;p.mkdir(parents=True,exist_ok=True)
 if (p/'result.json').exists():return json.loads((p/'result.json').read_text())
 study,total=make_demand(rows,seed,p,n,ports)
 # Persist the posted-speed scenario in an additional variable speed sign, preserving all other parameters.
 add=E.parse(signal).getroot();changed=[]
 if action!='mapped_baseline':
  mph=int(action.split('_')[-1]);z=n.getNode(site);cx,cy=z.getCoord()
  for edge in n.getEdges():
   if edge.getFunction() or edge.getName()!='East Avenue' or min(math.dist((cx,cy),pt) for pt in edge.getShape())>160:continue
   lanes=[l.getID() for l in edge.getLanes() if l.allows('passenger')]
   if lanes:v=E.SubElement(add,'variableSpeedSign',id='speed_'+edge.getID(),lanes=' '.join(lanes));E.SubElement(v,'step',time='0',speed=str(mph*MPH));changed.append(edge.getID())
 xml(add,p/'scenario.add.xml');(p/'scenario.json').write_text(json.dumps({'action':action,'changed_edges':changed,'behavior':'fixed driver speed factors; proportional compliance assumed','interpretation':'simulation sensitivity, not real collision probability'},indent=2))
 cfg=E.Element('configuration');inp=E.SubElement(cfg,'input')
 for tag,value in [('net-file',os.path.relpath(net,p)),('route-files','demand.rou.xml'),('additional-files','scenario.add.xml')]:E.SubElement(inp,tag,value=value)
 tm=E.SubElement(cfg,'time');E.SubElement(tm,'step-length',value=str(step));E.SubElement(tm,'end',value='9900');rand=E.SubElement(cfg,'random_number');E.SubElement(rand,'seed',value=str(seed));proc=E.SubElement(cfg,'processing')
 for k,v in [('pedestrian.striping.jamtime','-1'),('pedestrian.striping.jamtime.crossing','-1'),('time-to-teleport','-1'),('collision.action','warn'),('intermodal-collision.action','warn'),('collision.check-junctions','true'),('collision.mingap-factor','0')]:E.SubElement(proc,k,value=v)
 output=E.SubElement(cfg,'output')
 for k,v in [('collision-output','collisions.xml'),('tripinfo-output','trips.xml'),('summary-output','summary.xml')]+([('fcd-output','trajectories.xml')] if fcd else []):E.SubElement(output,k,value=v)
 xml(cfg,p/'run.sumocfg');start=time.monotonic()
 sim.start([sumolib.checkBinary('sumo'),'-c',str(p/'run.sumocfg'),'--no-step-log','true','--duration-log.disable','true','--no-warnings','true','--error-log',str(p/'warnings.log')])
 try:sim.simulationStep(9900);pending=sim.simulation.getMinExpectedNumber()
 finally:sim.close()
 trips=E.parse(p/'trips.xml').getroot();arrived={z.get('id') for z in trips if z.tag in ['tripinfo','personinfo']};collisions=[z.attrib for z in E.parse(p/'collisions.xml').getroot() if float(z.get('time'))>=900 and any('_ped' in z.get(a,'') or '_bicycle' in z.get(a,'') for a in ['victim','collider']) and any(z.get(a,'').startswith('s') for a in ['victim','collider'])];pairs={tuple(sorted([x['victim'],x['collider']])) for x in collisions};(p/'vru_collision_details.json').write_text(json.dumps(collisions,indent=2));motor=[z for z in trips if z.tag=='tripinfo' and z.get('id','').startswith('s') and z.get('vType') in ['passenger','heavy']]
 result={'site':site,'session_id':session,'date':rows.iloc[0].date,'phase':rows.iloc[0].phase,'action':action,'seed':seed,'step':step,'study_requested':study,'study_arrived':sum(x.startswith('s') for x in arrived),'total_requested':total,'total_arrived':len(arrived),'pending':pending,'vru_collision_pairs':len(pairs),'motor_mean_duration_s':float(np.mean([float(x.get('duration')) for x in motor])),'motor_mean_wait_s':float(np.mean([float(x.get('waitingTime')) for x in motor])),'wall_seconds':time.monotonic()-start,'path':str(p.relative_to(ROOT)),'demand_sha256':hashlib.sha256((p/'demand.rou.xml').read_bytes()).hexdigest()}
 (p/'result.json').write_text(json.dumps(result,indent=2));return result

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--smoke',action='store_true');args=parser.parse_args();df=pd.read_csv(ROOT/'data/sumo_v02/junction_demand_15min.csv');out=[]
 if args.smoke:
  df=df[df.site.eq('Estates') & df.date.eq('2023-05-18') & df.interval_start.str[11:13].astype(int).lt(9)]
 for sid,g in df.groupby('session_id'):
  for action in (['mapped_baseline'] if args.smoke else ['mapped_baseline','posted_25','posted_35']):
   for seed in ([2029] if args.smoke else [2029,2039]):
    z=run(g,action,seed,fcd=args.smoke);out.append(z);print(sid,action,seed,z['study_arrived'],z['study_requested'],'pending',z['pending'],flush=True)
  pd.DataFrame(out).to_csv(OUT/('smoke_replays.csv' if args.smoke else 'mapped_replays.csv'),index=False)
if __name__=='__main__':main()
