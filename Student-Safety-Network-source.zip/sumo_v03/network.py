"""Mapped geometry with explicit import assumptions and a fixed historical control prior."""
from pathlib import Path
import subprocess,json,math,xml.etree.ElementTree as ET
import sumolib,pandas as pd
from .prepare import ROOT,DATA,OUT,xml
CENTERS={'Estates':(-121.7517466,37.6799404),'Hillcrest':(-121.748496,37.6799255)}
def command(args,log):
 p=subprocess.run([sumolib.checkBinary('netconvert'),*map(str,args)],capture_output=True,text=True);log.write_text(p.stdout+'\n'+p.stderr)
 if p.returncode:raise RuntimeError(f'Network conversion failed; see {log}: {p.returncode}')
def arm(x,y,cx,cy):return ('E' if x>cx else 'W') if abs(x-cx)>abs(y-cy) else ('N' if y>cy else 'S')
def build():
 OUT.mkdir(exist_ok=True,parents=True)
 joins=ET.Element('nodes')
 ET.SubElement(joins,'join',nodes='2973960495 5373888653 7044823679 9175696041 9622723920',id='Estates',type='priority_stop',reset='true')
 ET.SubElement(joins,'join',nodes='2973960499 2973960502 2973960504 53024459 766216982',id='Hillcrest',type='traffic_light',reset='true')
 xml(joins,DATA/'junction_joins.nod.xml')
 args=['--osm-files',DATA/'east_simulation.osm.xml','--node-files',DATA/'junction_joins.nod.xml','--output-file',OUT/'east_joined.net.xml','--plain-output-prefix',OUT/'east_joined','--osm.sidewalks','true','--osm.crossings','true','--osm.turn-lanes','true','--osm.all-attributes','true','--osm.annotate-defaults','true','--output.original-names','true','--output.street-names','true','--walkingareas','true','--no-turnarounds','false']
 command(args,OUT/'east_joined.log')
 # Explicitly restore mapped crossings after node consolidation. SUMO drops
 # interior crossing nodes when a cluster is joined; they must remain modeled.
 net0=sumolib.net.readNet(str(OUT/'east_joined.net.xml'))
 c=ET.Element('connections');crossing_sources=[]
 source_nodes={'Estates':{'N':'2973960495','E':'7044823679','W':'9622723920','S':None},'Hillcrest':{'N':'2973960504','E':'2973960502','S':'766216982','W':'2973960499'}}
 for site in CENTERS:
  z=net0.getNode(site);cx,cy=z.getCoord();byarm={}
  for direction,edges in [('in',z.getIncoming()),('out',z.getOutgoing())]:
   for e in edges:
    if e.getFunction() or not (e.allows('passenger') or e.allows('delivery')):continue
    other=e.getFromNode() if direction=='in' else e.getToNode();a=arm(*other.getCoord(),cx,cy);byarm.setdefault(a,[]).append(e.getID())
  for a,origin in source_nodes[site].items():
   ET.SubElement(c,'crossing',node=site,edges=' '.join(byarm[a]),priority='true')
   crossing_sources.append({'site':site,'arm':a,'source_osm_node':origin,'source_url':f'https://www.openstreetmap.org/node/{origin}' if origin else 'East Avenue observed pedestrian count sheets: south dead leg','mapping':'Consolidated mapped crossing; exact curb width unmeasured' if origin else 'Observed south-leg tally represented across mapped private service access; crossing marking unknown'})
 xml(c,DATA/'mapped_crossings.con.xml');pd.DataFrame(crossing_sources).to_csv(DATA/'crossing_sources.csv',index=False)
 command(['-s',OUT/'east_joined.net.xml','-x',DATA/'mapped_crossings.con.xml','-o',OUT/'east_final.net.xml','--walkingareas','true','--plain-output-prefix',OUT/'east_final'],OUT/'crossing_conversion.log')
 (OUT/'east_joined.net.xml').write_bytes((OUT/'east_final.net.xml').read_bytes())
 n=sumolib.net.readNet(str(OUT/'east_joined.net.xml'),withInternal=True,withPedestrianConnections=True)
 rows=[];cross=[];ports={}
 for site in CENTERS:
  z=n.getNode(site);cx,cy=z.getCoord();ports[site]={}
  for direction,edges in [('in',z.getIncoming()),('out',z.getOutgoing())]:
   for edge in edges:
    if edge.getFunction() or not edge.allows('passenger'):continue
    other=edge.getFromNode() if direction=='in' else edge.getToNode();a=arm(*other.getCoord(),cx,cy)
    ports[site].setdefault(a,{})[direction]=edge.getID()
    rows.append({'site':site,'arm':a,'direction':direction,'sumo_edge':edge.getID(),'name':edge.getName(),'motor_lanes':sum(l.allows('passenger') for l in edge.getLanes()),'length_m':edge.getLength(),'speed_mph':edge.getSpeed()/.44704,'shape_xy':json.dumps(edge.getShape()),'geometry_source':'OSM current mapped centerline','lane_width_status':'SUMO default; unmapped width'})
  for e in n.getEdges(withInternal=True):
   if e.getFunction()=='crossing' and e.getID().startswith(':'+site+'_'):cross.append({'site':site,'sumo_edge':e.getID(),'length_m':e.getLength(),'width_m':e.getLanes()[0].getWidth(),'width_status':'SUMO default; unmapped','shape_xy':json.dumps(e.getShape())})
 pd.DataFrame(rows).to_csv(DATA/'mapped_approaches.csv',index=False);pd.DataFrame(cross).to_csv(DATA/'mapped_crossings.csv',index=False);(DATA/'ports.json').write_text(json.dumps(ports,indent=2))
 signals(n,ports)
 return n,ports

def signals(n,ports):
 tree=ET.parse(OUT/'east_joined.net.xml').getroot();links=[x for x in tree.findall('connection') if x.get('tl')=='Hillcrest'];size=max(int(x.get('linkIndex')) for x in links)+1
 cross={x.get('id'):x.get('crossingEdges','').split() for x in tree.findall('edge') if x.get('function')=='crossing'}
 portarm={v['in']:a for a,v in ports['Hillcrest'].items()};allarms={e:a for a,v in ports['Hillcrest'].items() for e in v.values()};root=ET.Element('additional');logic=ET.SubElement(root,'tlLogic',id='Hillcrest',type='static',programID='historical_control_prior',offset='0');audit=[]
 for stage,duration in [('EW_left',4),('EW_through',36),('northbound',20),('southbound',16)]:
  states=['r']*size
  for z in links:
   i=int(z.get('linkIndex'));a=portarm.get(z.get('from'));turn=z.get('dir');v='r'
   if z.get('to') in cross:
    legs={allarms.get(e) for e in cross[z.get('to')]};v='G' if (stage=='EW_through' and legs <= {'N','S'}) or (stage in ['northbound','southbound'] and legs <= {'E','W'}) else 'r'
   elif stage=='EW_left' and a in ['W','E'] and turn in ['l','t']:v='G'
   elif stage=='EW_through' and a in ['W','E'] and turn in ['s','r']:v='G' if turn=='s' else 'g'
   elif (stage=='northbound' and a=='S') or (stage=='southbound' and a=='N'):v='G' if turn=='s' else 'g'
   states[i]=v;audit.append({'stage':stage,'link':i,'from':z.get('from'),'to':z.get('to'),'state':v,'status':'2020 HCM structure; timing assumption, not observed 2023'})
  ET.SubElement(logic,'phase',duration=str(duration),state=''.join(states));yellow=['y' if v in 'Gg' else 'r' for v in states]
  for z in links:
   if z.get('to') in cross:yellow[int(z.get('linkIndex'))]='r'
  ET.SubElement(logic,'phase',duration='3',state=''.join(yellow));ET.SubElement(logic,'phase',duration='1.5',state='r'*size)
 xml(root,DATA/'fixed_signal.add.xml');pd.DataFrame(audit).to_csv(DATA/'signal_control.csv',index=False)
if __name__=='__main__':
 n,p=build();print('Mapped network:',len(n.getEdges()),'edges; ports',p)
