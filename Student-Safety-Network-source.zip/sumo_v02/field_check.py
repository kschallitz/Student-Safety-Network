"""Descriptive crash audit: equal calendar follow-up, no causal attribution."""
from .calibrate import *
from scipy.stats import beta,chi2

def main():
 x=pd.read_csv(ROOT/'data/tims/raw/alameda_pedbike_crashes_2014_2025.csv',low_memory=False);x=x[x.CITY.eq('LIVERMORE')].drop_duplicates('CASE_ID').copy();x['date']=pd.to_datetime(x.COLLISION_DATE)
 # Shared county centerline vertices, not a selected crash's geocode.
 anchors={'Estates':(-121.75174663230632,37.67994037412871),'Hillcrest':(-121.74849602545012,37.679925529983414)}
 pd.DataFrame([{'site':k,'lon':v[0],'lat':v[1],'source':'Alameda County street centerline shared vertices','status':'derived_junction_center'} for k,v in anchors.items()]).to_csv(DATA/'field_check_centers.csv',index=False)
 x['geocode_valid']=x.POINT_X.between(-122,-121)&x.POINT_Y.between(37,38)
 for name,(lon,lat) in anchors.items():
  a=np.radians(x.POINT_Y);b=np.radians(lat);dl=np.radians(x.POINT_X-lon)
  x[name+'_distance_m']=6371008.8*2*np.arcsin(np.sqrt(np.sin((a-b)/2)**2+np.cos(a)*np.cos(b)*np.sin(dl/2)**2))
 x['assigned_site']=x[[k+'_distance_m' for k in anchors]].fillna(float('inf')).idxmin(axis=1).str.replace('_distance_m','');x['distance_m']=x[[k+'_distance_m' for k in anchors]].min(axis=1)
 local=x[x.geocode_valid & x.distance_m.le(152.4)].copy();local['period']=np.select([local.date.lt('2023-04-10'),local.date.lt('2023-04-15')],['pre','installation'],default='post')
 cols=['CASE_ID','COLLISION_DATE','COLLISION_TIME','PRIMARY_RD','SECONDARY_RD','DISTANCE','DIRECTION','POINT_X','POINT_Y','COLLISION_SEVERITY','PEDESTRIAN_ACCIDENT','BICYCLE_ACCIDENT','assigned_site','distance_m','period']
 local[cols].sort_values('COLLISION_DATE').to_csv(DATA/'observed_crash_audit.csv',index=False)
 missing=x[~x.geocode_valid & (x.PRIMARY_RD.str.contains(r'EAST AV|ESTATES|HILLCREST',na=False)|x.SECONDARY_RD.str.contains(r'EAST AV|ESTATES|HILLCREST',na=False))]
 missing.to_csv(DATA/'unlocated_potential_corridor_cases.csv',index=False)
 results=[]
 for after_start in [pd.Timestamp('2023-04-15'),pd.Timestamp('2023-07-01')]:
  end=pd.Timestamp('2026-01-01');days=(end-after_start).days;before_end=pd.Timestamp('2023-04-10');before_start=before_end-pd.Timedelta(days=days)
  for radius in [30.48,91.44,152.4]:
   for site in ['Estates','Hillcrest','Both sites (deduplicated)']:
    g=local[local.distance_m.le(radius)]
    if site!='Both sites (deduplicated)':g=g[g.assigned_site.eq(site)]
    before=g[g.date.ge(before_start)&g.date.lt(before_end)];after=g[g.date.ge(after_start)&g.date.lt(end)];a=len(after);b=len(before);n=a+b
    # Conditional Poisson equal-period rate ratio: exact binomial interval, then odds transform.
    lo=beta.ppf(.025,a,b+1) if a else 0;hi=beta.ppf(.975,a+1,b) if b else 1
    rr=a/b if b else (float('inf') if a else None)
    results.append({'site':site,'radius_feet':round(radius/.3048),'before_start':before_start.date().isoformat(),'before_end_exclusive':before_end.date().isoformat(),'after_start':after_start.date().isoformat(),'after_end_exclusive':end.date().isoformat(),'days_each':days,'pre_cases':b,'post_cases':a,'pre_cases_per_year':b/days*365.25,'post_cases_per_year':a/days*365.25,'unadjusted_rate_ratio':rr,'rr_95_low':lo/(1-lo),'rr_95_high':hi/(1-hi) if hi<1 else float('inf'),'status':'descriptive_time_rate_not_causal_or_traveler_risk'})
 pd.DataFrame(results).to_csv(OUT/'observed_crash_comparison.csv',index=False)
 (OUT/'field_check_metadata.json').write_text(json.dumps({'source_export':'Alameda TIMS pedestrian/bicycle injury/fatal crashes, 2014-2025; downloaded 2026-09-26','coverage':'Available export, final annual completeness not established; no property-damage-only or unreported collisions','crash_population':'all recorded ages; not school-student-only','nearby_cases_2014_2025':len(local),'missing_geocode_potential_cases':len(missing),'assignment':'nearest of two county centerline junction centers within radius; deduplicate CASE_ID','limitations':['equal calendar time, not person/vehicle exposure normalization','before window includes pandemic period','no untreated matched control or adjustment for regression to mean','sparse observations and multiple exploratory radii','June adjustment day unknown; July sensitivity excludes April-June transition','neighborhood radius can include a nearby side intersection']},indent=2))
 print(pd.DataFrame(results).query('radius_feet==500 and after_start=="2023-04-15"').to_string(index=False))
if __name__=='__main__':main()
