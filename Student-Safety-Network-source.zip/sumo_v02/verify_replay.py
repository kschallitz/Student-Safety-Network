"""Verify final source conservation and standalone SUMO reproducibility."""
from .calibrate import *
import tempfile

def main():
 checks=[];runs=pd.read_csv(OUT/'junction_replays.csv')
 # Independent XML input count, including warmup, vs CSV study counts.
 for _,r in runs.iterrows():
  p=ROOT/r.path;routes=ET.parse(p/'demand.rou.xml').getroot();people=[x for x in routes if x.tag in ['vehicle','person']];assert len(people)==r.total_requested;assert sum(x.get('id').startswith('s') for x in people)==r.study_requested
 checks.append({'check':'XML demand matches result counts in every junction run','passed':True,'runs':len(runs)})
 target=runs[(runs.vru_collision_pairs>0)&runs.pending.eq(0)].iloc[0];p=ROOT/target.path
 with tempfile.TemporaryDirectory() as tmp:
  tmp=Path(tmp);command=[sumolib.checkBinary('sumo'),'-c',str(p/'run.sumocfg'),'--collision-output',str(tmp/'collisions.xml'),'--tripinfo-output',str(tmp/'trips.xml'),'--no-step-log','true','--duration-log.disable','true','--no-warnings','true']
  r=subprocess.run(command,capture_output=True,text=True,check=True)
  actual=[x.attrib for x in ET.parse(tmp/'collisions.xml').getroot().findall('collision')];original=[x.attrib for x in ET.parse(p/'collisions.xml').getroot().findall('collision')]
  assert actual==original, (actual,original)
  arrivals={x.get('id') for x in ET.parse(tmp/'trips.xml').getroot() if x.tag in ['tripinfo','personinfo']}
  assert len(arrivals)==target.total_arrived
  checks.append({'check':'Standalone SUMO replays all collision details and arrivals exactly','passed':True,'episode':target.path,'vru_pairs':int(target.vru_collision_pairs)})
 (OUT/'reproducibility_checks.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
if __name__=='__main__':main()
