"""A mandatory gate before any new safety-policy training.
The old RL research code remains in sumo_rl; its saved policy is superseded.
"""
from pathlib import Path
import json

def require_validated_safety_reward():
 p=Path(__file__).resolve().parents[1]/'outputs/sumo_v02/release_gate.json'
 if not p.exists():raise RuntimeError('Run the v0.2 calibration and validation first.')
 gate=json.loads(p.read_text())
 if not gate.get('rl_training_authorized_by_evidence'):
  raise RuntimeError('Safety RL training withheld: '+gate['reason'])
 return gate
if __name__=='__main__':print(require_validated_safety_reward())
