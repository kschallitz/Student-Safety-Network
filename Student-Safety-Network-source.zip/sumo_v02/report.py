"""Conservation checks, empirical validation and a hard safety-training gate."""
from .calibrate import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def main():
 speed=pd.read_csv(OUT/'speed_predictions.csv');metrics=pd.read_csv(OUT/'speed_validation.csv');daily=pd.read_csv(OUT/'daily_speed_validation.csv');j=pd.read_csv(OUT/'junction_replays.csv');num=pd.read_csv(OUT/'numerical_audit.csv');obs=pd.read_csv(DATA/'junction_demand_15min.csv');old=pd.read_csv(ROOT/'data/sumo_rl/east_avenue_observations_15min.csv');old=old[old.session_complete]
 checks=[]
 def check(name,ok,detail):checks.append({'check':name,'passed':bool(ok),'detail':detail})
 check('fitting/test date separation',set(speed[speed.split=='fit'].observation_date).isdisjoint(speed[speed.split=='pre_holdout'].observation_date),'All tests retrospective, not blinded; fitting dates Feb 1-3 only')
 params=json.loads((OUT/'calibration.json').read_text());check('optimizer convergence',all(v['optimizer_success'] for v in params.values()),'Both directions fit pre-period observations only')
 check('hourly detector count conservation',(speed.sample_count==speed.sim_detected_count).all(),'Every admitted measurement-cohort vehicle detected once; volumes are inputs')
 check('midblock clearance',(speed.sim_pending==0).all(),'No unfinished midblock demand')
 a=obs.groupby('session_id')['count'].sum();b=old.groupby('session_id')['count'].sum();check('heavy vehicles replace motor subset',(a==b).all(),'Source totals conserved after passenger/heavy split')
 check('paired intervention demand',j.groupby(['session_id','seed','step']).demand_sha256.nunique().eq(1).all(),'Identical departures, travelers and desired-speed factors across actions')
 control=[]
 for act in ['no_change','posted_25','curb_extensions_proxy','curbs_and_25']:
  p=OUT/'junction_networks'/f'Hillcrest_{act}_m1.8_r5.5_c1.0'/'movement_control.csv';x=pd.read_csv(p).sort_values(['stage','from','to','movement','state']).reset_index(drop=True);control.append(x)
 check('movement-level signal equality',all(x.equals(control[0]) for x in control[1:]),'Identical phase order, durations and movement states; historical approximate control prior')
 hold=metrics[(metrics.split=='pre_holdout')&(metrics.model=='SUMO')];speed_pass=(hold[hold.statistic=='mean_mph'].mae_mph<=2).all() and (hold[hold.statistic=='p85_mph'].mae_mph<=3).all()
 check('pre-period speed screening thresholds',speed_pass,'Declared component screen: mean MAE<=2, p85 MAE<=3 mph; not safety certification')
 check('junction clearance',(j.pending==0).all(),f'{int(j.pending.gt(0).sum())} of {len(j)} runs unfinished; never score these as safe')
 idx=['session_id','action','seed'];paired=num[num.step.eq(.5)].merge(num[num.step.eq(.1)],on=idx,suffixes=('_05','_01'));paired['collision_difference']=paired.vru_collision_pairs_01-paired.vru_collision_pairs_05;paired.to_csv(OUT/'numerical_pairs.csv',index=False)
 check('numerical convergence established',False,f'{int(paired.collision_difference.ne(0).sum())}/{len(paired)} same-demand pairs differ; too few seeds for distributional convergence, and step changes alter stochastic draws')
 check('field crash/conflict reward calibration',False,'No fitted, out-of-fit validated relationship from these simulator events to field collision probability')
 check('exact 2023 as-built treatment',False,'Lane/control prior improved; 2023 geometry, yielding, signal records and June modifications remain unverified')
 check('production model preserved',hashlib.sha256((ROOT/'intersection_prediction_output/model.json').read_bytes()).hexdigest()=='12d19ef2f8bd7ab047e50f3fa435c29c8a8bada6ff5d26fdd85c8ebf1f4c3818','No unvalidated RL policy substituted in existing map') if (ROOT/'intersection_prediction_output/model.json').exists() else None
 pd.DataFrame(checks).to_csv(OUT/'validation_checks.csv',index=False)
 gate={'version':'0.2','status':'midblock_speed_screen_passed' if speed_pass else 'speed_component_needs_revision','speed_screen_pass':bool(speed_pass),'rl_training_authorized_by_evidence':False,'field_probability_release':False,'reason':'Junction field behavior and safety reward have not passed validation; simulation events cannot be treated as real crash probabilities.','junction_unfinished_runs':int(j.pending.gt(0).sum()),'junction_runs':len(j),'numerical_changed_pairs':int(paired.collision_difference.ne(0).sum()),'numerical_pairs':len(paired),'source_population':'motor speed station plus reported pedestrian/bicycle injury/fatal crashes; not student-only'}
 (OUT/'release_gate.json').write_text(json.dumps(gate,indent=2))
 # Residuals by time band and day type reveal limits hidden by aggregate MAE.
 residuals=[]
 for (dr,weekend,band),g in speed[speed.split.eq('pre_holdout') & speed.mean_mph.notna()].assign(weekend=lambda z: pd.to_datetime(z.observation_date).dt.dayofweek>=5,band=lambda z: pd.cut(z.hour,[-1,5,8,13,17,23],labels=['00-06','06-09','09-14','14-18','18-24'])).groupby(['travel_direction','weekend','band'],observed=True):
  err=g.sim_mean_mph-g.mean_mph;residuals.append({'direction':dr,'weekend':weekend,'time_band':str(band),'hours':len(g),'observed_mean_mph':np.average(g.mean_mph,weights=g.sample_count),'bias_mph':np.average(err,weights=g.sample_count),'mae_mph':np.average(abs(err),weights=g.sample_count)})
 pd.DataFrame(residuals).to_csv(OUT/'time_band_residuals.csv',index=False)
 # All figures use executed results, not built-in illustrative values.
 plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white'})
 fig,axs=plt.subplots(1,2,figsize=(11,4),constrained_layout=True)
 for ax,dr in zip(axs,['eastbound','westbound']):
  z=speed[speed.split.eq('pre_holdout') & speed.travel_direction.eq(dr) & speed.mean_mph.notna()];ax.scatter(z.mean_mph,z.sim_mean_mph,s=np.maximum(12,z.sample_count/10),alpha=.45,color='#167c85');ax.plot([25,44],[25,44],color='#8a8a8a',ls='--');ax.set(xlim=(25,44),ylim=(25,44),xlabel='Reported hourly mean (mph)',ylabel='SUMO detector mean (mph)',title=dr.title()+' · Feb 4–7, 2023')
 fig.suptitle('Out-of-fitting speed check • bubble size = observed vehicle count');fig.savefig(OUT/'speed_validation.png',dpi=150);plt.close(fig)
 fig,axs=plt.subplots(1,2,figsize=(11,4),constrained_layout=True)
 for ax,stat in zip(axs,['mean_mph','p85_mph']):
  z=metrics[metrics.split.eq('pre_holdout') & metrics.statistic.eq(stat)];labels=[]
  for i,(_,r) in enumerate(z.iterrows()):
   ax.barh(i,r.mae_mph,color='#167c85' if r.model=='SUMO' else '#a9a9a9');ax.errorbar(r.mae_mph,i,xerr=[[r.mae_mph-r.day_bootstrap_mae_low],[r.day_bootstrap_mae_high-r.mae_mph]],fmt='none',ecolor='#243a44',capsize=3);labels.append(r.direction+' · '+('SUMO' if r.model=='SUMO' else 'constant'))
  ax.set(yticks=range(len(labels)),yticklabels=labels,xlabel='Count-weighted MAE (mph)',title='Mean speed' if stat=='mean_mph' else '85th-percentile speed',xlim=(0,3));ax.invert_yaxis()
 fig.suptitle('Error bars: 95% day-bootstrap range for MAE (only four test days)');fig.savefig(OUT/'baseline_comparison.png',dpi=150);plt.close(fig)
 fig,axs=plt.subplots(1,2,figsize=(11,4),constrained_layout=True)
 for ax,dr in zip(axs,['eastbound','westbound']):
  z=daily[daily.direction.eq(dr)];periods=['fit','pre_holdout','historical_check','post_may','post_june'];means=z.groupby('split')[['observed_mean_mph','sim_mean_mph']].mean().reindex(periods);xx=np.arange(5);ax.plot(xx,means.observed_mean_mph,'o-',label='Reported daily speed',color='#167c85');ax.plot(xx,means.sim_mean_mph,'s--',label='Frozen midblock model',color='#c27020');ax.set(xticks=xx,xticklabels=['Feb fit','Feb test','Jun 2022','May 2023','Jun 2023'],ylabel='Mean of daily means (mph)',ylim=(30,39),title=dr.title());ax.tick_params(axis='x',rotation=25);ax.legend(fontsize=8)
 fig.suptitle('Post-period check • measured flows supplied; no intervention-effect claim');fig.savefig(OUT/'post_speed_check.png',dpi=150);plt.close(fig)
 fig,ax=plt.subplots(figsize=(9,4),constrained_layout=True);summary=num.groupby(['step','action']).vru_collision_pairs.sum().unstack('step');xx=np.arange(len(summary));ax.bar(xx-.17,summary[.5],.34,label='0.5-second step',color='#167c85');ax.bar(xx+.17,summary[.1],.34,label='0.1-second step',color='#c27020');ax.set(xticks=xx,xticklabels=['Curbs proxy','Curbs + 25','Unchanged','25 mph'],ylabel='SUMO VRU collision pairs',title='Same demand and seeds • numerical safety diagnostic');ax.legend();fig.savefig(OUT/'numerical_safety.png',dpi=150);plt.close(fig)
 print(json.dumps(gate,indent=2));print(pd.DataFrame(checks).to_string(index=False))
if __name__=='__main__':main()
