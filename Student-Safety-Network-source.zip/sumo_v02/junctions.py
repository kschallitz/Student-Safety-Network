"""Corrected, explicitly approximate junction replay; no probability calibration."""
from pathlib import Path
import os,json,hashlib,subprocess,time
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
import sumolib
from .calibrate import ROOT,OUT,DATA,MPH,xml
from sumo_rl.experiment import SITES,DIR,END,ACTIONS

def network(site,action,margin=1.8,radius=5.5,cycle_scale=1.):
 p=OUT/'junction_networks'/f'{site}_{action}_m{margin}_r{radius}_c{cycle_scale}';p.mkdir(parents=True,exist_ok=True);f=p/'network.net.xml'
 if f.exists() and (p/'fixed_signal.add.xml').exists():return f,p/'fixed_signal.add.xml'
 n=ET.Element('nodes');e=ET.Element('edges');c=ET.Element('connections');curb='curb' in action;info=SITES[site]
 ET.SubElement(n,'node',id='J',x='0',y='0',type=info['control'],radius=str(radius if curb else 9))
 counts={};base={}
 for arm,(x,y) in {'W':(-250,0),'E':(250,0),'N':(0,250),'S':(0,-250)}.items():
  if arm not in info['arms']:continue
  ET.SubElement(n,'node',id=arm,x=str(x),y=str(y));ET.SubElement(n,'node',id=arm+'near',x=str(x/5),y=str(y/5),radius='0')
  for seg,a,b in [('in',arm+'near','J'),('out','J',arm+'near'),('far_in',arm,arm+'near'),('far_out',arm+'near',arm)]:
   main=arm in 'WE';near=seg in ['in','out'];shoulder=margin if main and not(curb and near) else 0
   motor=(2 if main else 1)+(1 if site=='Hillcrest' and seg=='in' else 0)
   edgeid=arm+'_'+seg;counts[edgeid]=motor;base[edgeid]=1+int(bool(shoulder))
   z=ET.SubElement(e,'edge',id=edgeid,attrib={'from':a,'to':b},numLanes=str(motor+int(bool(shoulder))),speed=str((25 if '25' in action and main else 30 if main else 25)*MPH),priority=str(3 if main else 1),width='3.2',sidewalkWidth='2',disallow='pedestrian')
   if shoulder:ET.SubElement(z,'lane',index='0',width=str(shoulder),allow='authority')
 # Explicit motor connections exclude the unused margin; sidewalk is index 0 after conversion.
 for arm in info['arms']:
  start=arm+'_in';src=base[start];num=counts[start]
  for movement,to in END[arm].items():
   if to not in info['arms']:continue
   dest=to+'_out';dst=base[dest]
   if site=='Hillcrest':
    pairs=[(src+num-1,dst+counts[dest]-1)] if movement in ['LT','UT'] else [(src,dst)] if movement=='RT' else [(src+i,dst+min(i,counts[dest]-1)) for i in range(num-1)]
   else:
    pairs=[(src+num-1,dst+counts[dest]-1)] if movement in ['LT','UT'] else [(src,dst)] if movement=='RT' else [(src+i,dst+min(i,counts[dest]-1)) for i in range(num)]
   for a,b in pairs:ET.SubElement(c,'connection',attrib={'from':start,'to':dest,'fromLane':str(a),'toLane':str(b)})
  ET.SubElement(c,'crossing',node='J',edges=f'{arm}_in {arm}_out',priority='true',width='3')
 xml(n,p/'nodes.nod.xml');xml(e,p/'edges.edg.xml');xml(c,p/'connections.con.xml')
 proc=subprocess.run([sumolib.checkBinary('netconvert'),'-n',str(p/'nodes.nod.xml'),'-e',str(p/'edges.edg.xml'),'-x',str(p/'connections.con.xml'),'-o',str(f),'--walkingareas','true','--junctions.corner-detail','5','--no-turnarounds','false'],capture_output=True,text=True)
 (p/'netconvert.log').write_text(proc.stdout+proc.stderr)
 if proc.returncode:raise RuntimeError(proc.stderr)
 r=ET.parse(f).getroot();extra=ET.Element('additional');audit=[]
 if site=='Hillcrest':
  # 2020 HCM confirms protected main-road lefts and split side phases. This is
  # an approximate AM-derived fixed plan, NOT the unknown 2023 actuated plan.
  links=[z for z in r.findall('connection') if z.get('tl')=='J'];length=max(int(z.get('linkIndex')) for z in links)+1
  cross={z.get('id'):z.get('crossingEdges')[0] for z in r.findall('edge') if z.get('function')=='crossing'}
  logic=ET.SubElement(extra,'tlLogic',id='J',type='static',programID='fixed_control_prior',offset='0')
  for stage,duration in [('EW_left',4),('EW_through',36),('northbound',20),('southbound',16)]:
   green=['r']*length
   for z in links:
    k=int(z.get('linkIndex'));arm=z.get('from')[0];turn=z.get('dir');v='r'
    if z.get('to') in cross:
     leg=cross[z.get('to')];v='G' if (stage=='EW_through' and leg in 'NS') or (stage in ['northbound','southbound'] and leg in 'EW') else 'r'
    elif stage=='EW_left' and arm in 'EW' and turn in ['l','t']:v='G'
    elif stage=='EW_through' and arm in 'EW' and turn in ['s','r']:v='G' if turn=='s' else 'g'
    elif (stage=='northbound' and arm=='S') or (stage=='southbound' and arm=='N'):v='G' if turn=='s' else 'g'
    green[k]=v
    audit.append({'stage':stage,'duration':duration*cycle_scale,'from':z.get('from') if arm!=':' else 'ped_'+cross.get(z.get('to'),'?'),'to':z.get('to') if arm!=':' else 'crossing','movement':turn,'state':v})
   ET.SubElement(logic,'phase',duration=str(duration*cycle_scale),state=''.join(green))
   yellow=['y' if ch in 'Gg' else 'r' for ch in green]
   for z in links:
    if z.get('to') in cross:yellow[int(z.get('linkIndex'))]='r'
   ET.SubElement(logic,'phase',duration='3',state=''.join(yellow));ET.SubElement(logic,'phase',duration='1.5',state='r'*length)
 xml(extra,p/'fixed_signal.add.xml');pd.DataFrame(audit).to_csv(p/'movement_control.csv',index=False)
 return f,p/'fixed_signal.add.xml'

def observations():
 rows=pd.read_csv(ROOT/'data/sumo_rl/east_avenue_observations_15min.csv');heavy=pd.read_csv(ROOT/'data/traffic_exposure/normalized/turning_movements.csv');h={}
 for _,r in heavy[heavy.mode_or_class.eq('heavy_vehicles_subset') & heavy.eligible_for_automatic_aggregation & heavy['count'].notna()].iterrows():
  arm=DIR[r.approach_direction];to=END[arm][r.movement.replace('_including_UT','')];h[(r.session_id,r.interval_start,arm,to)]=(int(r['count']),r.observation_id,int(r.source_page))
 out=[]
 for _,r in rows[rows.session_complete].iterrows():
  z=r.to_dict()
  if r['mode']=='motor':
   heavy_info=h.get((r.session_id,r.interval_start,r.from_arm,r.to_arm))
   if heavy_info is None:raise ValueError('Missing heavy cell '+str(z))
   nh,heavy_id,heavy_page=heavy_info
   z['supporting_source_observation']=heavy_id;z['processing_status']='derived_motor_total_minus_observed_heavy_subset'
   assert 0<=nh<=r['count'];z['count']=int(r['count'])-nh;z['mode']='passenger';out.append(z)
   z=dict(z);z['count']=nh;z['mode']='heavy';z['source_observation']=heavy_id;z['source_page']=heavy_page;z['supporting_source_observation']='';z['processing_status']='transcribed_observed_heavy_subset';out.append(z)
  else:out.append(z)
 df=pd.DataFrame(out);df.to_csv(DATA/'junction_demand_15min.csv',index=False);return df

def demand(rows,site,seed,p,model):
 rng=np.random.default_rng(seed);root=ET.Element('routes')
 for typ,extra in [('passenger',{'vClass':'passenger','length':'5','accel':'2.6','decel':'4.5'}),('heavy',{'vClass':'truck','length':'10','accel':'1.3','decel':'4'}),('bicycle',{'vClass':'bicycle','length':'1.6','maxSpeed':'5.56','accel':'1.2','decel':'3'}),('walker',{'vClass':'pedestrian','maxSpeed':'1.4'})]:
  ET.SubElement(root,'vType',id=typ,**extra,speedDev='0',**({} if typ=='walker' else {'tau':'1.2','minGap':'2.5'}))
 rows=rows.copy();start=pd.to_datetime(rows.interval_start).min();rows['offset']=(pd.to_datetime(rows.interval_start)-start).dt.total_seconds()+900
 warm=rows[rows.offset.eq(900)].copy();warm['offset']=0;both=pd.concat([warm,rows]);els=[];seq=0
 for _,r in both.iterrows():
  for i in range(int(r['count'])):
   depart=float(r.offset+rng.uniform(0,900));prefix='w' if r.offset==0 else 's';vid=f'{prefix}{seq}';seq+=1
   if r['mode']=='pedestrian':
    arm=r.crossing_leg;forward=rng.random()<.5;a,b=(f'{arm}_in',f'{arm}_out') if forward else (f'{arm}_out',f'{arm}_in')
    if site=='Estates' and arm=='S':a,b=('W_in','E_out') if forward else ('E_out','W_in')
    z=ET.Element('person',id=vid+'_ped',type='walker',depart=f'{depart:.3f}',departPos='-10' if forward else '10');ET.SubElement(z,'walk',edges=f'{a} {b}',arrivalPos='10' if forward else '-10')
   else:
    a,b=r.from_arm,r.to_arm;dr='eastbound' if a=='W' else 'westbound' if a=='E' else None
    factor=max(.2,rng.normal(model[dr]['desired_mean_mph'],model[dr]['desired_sd_mph'])/30) if dr else float(np.clip(rng.normal(1,.1),.7,1.3))
    z=ET.Element('vehicle',id=vid+'_'+r['mode'],type=r['mode'],depart=f'{depart:.3f}',departLane='best',departSpeed='max',speedFactor='1' if r['mode']=='bicycle' else str(factor));ET.SubElement(z,'route',edges=f'{a}_far_in {a}_in {b}_out {b}_far_out')
   els.append((depart,z))
 for _,z in sorted(els,key=lambda t:t[0]):root.append(z)
 xml(root,p/'demand.rou.xml');return int(rows['count'].sum()),len(els)

def run(rows,action,seed=2029,step=.5,margin=1.8,radius=5.5,cycle_scale=1.):
 import libsumo as sim
 site=rows.iloc[0].site;session=rows.iloc[0].session_id;ident=['v02_ped_defaults',hashlib.sha256((OUT/'calibration.json').read_bytes()).hexdigest(),session,action,seed,step,margin,radius,cycle_scale];key=hashlib.sha256(json.dumps(ident).encode()).hexdigest()[:16];p=OUT/'junction_runs'/key;p.mkdir(parents=True,exist_ok=True)
 if (p/'result.json').exists():return json.loads((p/'result.json').read_text())
 net,signal=network(site,action,margin,radius,cycle_scale);models=json.loads((OUT/'calibration.json').read_text());study,total=demand(rows,site,seed,p,models)
 cfg=ET.Element('configuration');inp=ET.SubElement(cfg,'input')
 for tag,value in [('net-file',os.path.relpath(net,p)),('route-files','demand.rou.xml'),('additional-files',os.path.relpath(signal,p))]:ET.SubElement(inp,tag,value=value)
 tm=ET.SubElement(cfg,'time');ET.SubElement(tm,'step-length',value=str(step));ET.SubElement(tm,'end',value='9900')
 random=ET.SubElement(cfg,'random_number');ET.SubElement(random,'seed',value=str(seed));processing=ET.SubElement(cfg,'processing')
 for k,v in [('pedestrian.striping.jamtime','-1'),('pedestrian.striping.jamtime.crossing','-1'),('time-to-teleport','-1'),('collision.action','warn'),('intermodal-collision.action','warn'),('collision.check-junctions','true'),('collision.mingap-factor','0')]:ET.SubElement(processing,k,value=v)
 output=ET.SubElement(cfg,'output');ET.SubElement(output,'collision-output',value='collisions.xml');ET.SubElement(output,'tripinfo-output',value='trips.xml');xml(cfg,p/'run.sumocfg')
 sim.start([sumolib.checkBinary('sumo'),'-c',str(p/'run.sumocfg'),'--no-step-log','true','--duration-log.disable','true','--no-warnings','true','--pedestrian.striping.jamtime','-1','--pedestrian.striping.jamtime.crossing','-1','--error-log',str(p/'warnings.log')])
 start=time.monotonic();arrived=set();teleports=0
 try:
  # Advance in C++; per-step Python work is unnecessary for trip/collision output.
  sim.simulationStep(9900)
  pending=sim.simulation.getMinExpectedNumber();end=sim.simulation.getTime()
 finally:sim.close()
 trips=ET.parse(p/'trips.xml').getroot();arrived={z.get('id') for z in trips if z.tag in ['tripinfo','personinfo']}
 collisions=[x.attrib for x in ET.parse(p/'collisions.xml').getroot().findall('collision') if float(x.get('time'))>=900 and any('_ped' in x.get(a,'') or '_bicycle' in x.get(a,'') for a in ['victim','collider'])]
 # Warmup-only events excluded; require at least one study entity, retain clearance events.
 collisions=[x for x in collisions if x.get('victim','').startswith('s') or x.get('collider','').startswith('s')]
 unique={tuple(sorted([x['victim'],x['collider']])) for x in collisions};(p/'vru_collision_details.json').write_text(json.dumps(collisions,indent=2))
 result={'site':site,'session_id':session,'date':rows.iloc[0].date,'action':action,'seed':seed,'step':step,'margin':margin,'radius':radius,'cycle_scale':cycle_scale,'study_requested':study,'study_arrived':sum(x.startswith('s') for x in arrived),'total_requested':total,'total_arrived':len(arrived),'pending':pending,'teleports':teleports,'teleport_basis':'disabled_by_configuration','vru_collision_pairs':len(unique),'collision_event':int(bool(unique)),'end_seconds':end,'wall_seconds':round(time.monotonic()-start,3),'path':str(p.relative_to(ROOT)),'demand_sha256':hashlib.sha256((p/'demand.rou.xml').read_bytes()).hexdigest()}
 (p/'result.json').write_text(json.dumps(result,indent=2));return result

def main():
 rows=observations();out=[]
 for sid,g in rows.groupby('session_id'):
  for action in ACTIONS:
   for seed in [2029,2039]:out.append(run(g,action,seed))
  pd.DataFrame(out).to_csv(OUT/'junction_replays.csv',index=False);print(sid,len(out),flush=True)
 # Matched numerical diagnostics across busy school sessions; include exact base.
 selected=rows[rows.date.eq('2023-05-18') & rows.interval_start.str[11:13].astype(int).isin([7,8])];audit=[]
 for sid,g in selected.groupby('session_id'):
  for a in ACTIONS:
   for seed in [2029,2039]:
    for step in [.5,.1]:audit.append(run(g,a,seed,step))
 pd.DataFrame(audit).to_csv(OUT/'numerical_audit.csv',index=False)
if __name__=='__main__':main()
