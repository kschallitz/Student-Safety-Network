"""Out-of-fit validation of concurrent-flow conditional midblock speed.
This component cannot predict junction crash probability or treatment efficacy.
"""
from pathlib import Path
import os,sys,json,hashlib,time,subprocess,argparse
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
from scipy.optimize import minimize
import sumolib
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'outputs/sumo_v02'; DATA=ROOT/'data/sumo_v02'; OBS=ROOT/'data/traffic_exposure/normalized'; MPH=.44704
FIT=['2023-02-01','2023-02-02','2023-02-03']
def xml(root,p):
 ET.indent(root); ET.ElementTree(root).write(p,encoding='utf-8',xml_declaration=True)
def source():
 d=pd.read_csv(OBS/'speed_observations.csv');d['hour']=d.interval_start.str[11:13].astype(int)
 d['split']=np.select([d.observation_date.isin(FIT),d.observation_date.str.startswith('2023-02'),d.observation_date.str.startswith('2022'),d.observation_date.str.startswith('2023-05')],['fit','pre_holdout','historical_check','post_may'],default='post_june')
 d['target_status']=np.where(d.mean_mph.notna(),'reported','unavailable_hourly_mean')
 d.to_csv(DATA/'concurrent_speed_flow.csv',index=False)
 return d
def net():
 p=OUT/'midblock';p.mkdir(parents=True,exist_ok=True);f=p/'network.net.xml'
 if not f.exists():
  n=ET.Element('nodes');ET.SubElement(n,'node',id='W',x='0',y='0');ET.SubElement(n,'node',id='E',x='600',y='0')
  e=ET.Element('edges')
  for name,a,b in [('eb','W','E'),('wb','E','W')]:ET.SubElement(e,'edge',id=name,attrib={'from':a,'to':b},numLanes='2',speed=str(30*MPH),width='3.2')
  xml(n,p/'nodes.nod.xml');xml(e,p/'edges.edg.xml')
  subprocess.run([sumolib.checkBinary('netconvert'),'-n',str(p/'nodes.nod.xml'),'-e',str(p/'edges.edg.xml'),'-o',str(f)],capture_output=True,check=True)
 return f
def run(n,mu,sd,seed=613,step=.5,keep=False):
 import libsumo as sim
 key=hashlib.sha256(json.dumps([int(n),round(mu,5),round(sd,5),seed,step]).encode()).hexdigest()[:16]
 p=OUT/'midblock'/'runs'/key;p.mkdir(parents=True,exist_ok=True);result=p/'result.json'
 if result.exists() and not keep:return json.loads(result.read_text())
 rng=np.random.default_rng(seed);r=ET.Element('routes')
 ET.SubElement(r,'vType',id='car',vClass='passenger',accel='2.6',decel='4.5',sigma='.5',tau='1.2',minGap='2.5',length='5',maxSpeed='60',speedDev='0')
 ET.SubElement(r,'route',id='route',edges='eb')
 warm=int(round(n/12)); departures=[(float(t),'w'+str(i)) for i,t in enumerate(rng.uniform(0,300,warm))]+[(float(t),'v'+str(i)) for i,t in enumerate(rng.uniform(300,3900,int(n)))]
 for t,vid in sorted(departures):
  speed=float(np.clip(rng.normal(mu,sd),5,85))
  ET.SubElement(r,'vehicle',id=vid,type='car',route='route',depart=f'{t:.3f}',departLane='free',departSpeed='max',speedFactor=f'{speed/30:.7f}')
 xml(r,p/'demand.rou.xml');a=ET.Element('additional')
 for lane in range(2):ET.SubElement(a,'inductionLoop',id=f'd{lane}',lane=f'eb_{lane}',pos='300',file='detector.xml',period='3600')
 xml(a,p/'detectors.add.xml');c=ET.Element('configuration');i=ET.SubElement(c,'input')
 for tag,value in [('net-file',os.path.relpath(net(),p)),('route-files','demand.rou.xml'),('additional-files','detectors.add.xml')]:ET.SubElement(i,tag,value=value)
 tm=ET.SubElement(c,'time');ET.SubElement(tm,'step-length',value=str(step));ET.SubElement(tm,'end',value='4800')
 processing=ET.SubElement(c,'processing');ET.SubElement(processing,'time-to-teleport',value='-1')
 random=ET.SubElement(c,'random_number');ET.SubElement(random,'seed',value=str(seed));xml(c,p/'run.sumocfg')
 sim.start([sumolib.checkBinary('sumo'),'-c',str(p/'run.sumocfg'),'--no-step-log','true','--duration-log.disable','true','--no-warnings','true','--time-to-teleport','-1'])
 speeds={};arrived=0;max_pending=0
 try:
  while sim.simulation.getTime()<4800:
   sim.simulationStep();arrived+=sim.simulation.getArrivedNumber()
   for lane in range(2):
    for vid,length,entry,leave,vtype in sim.inductionloop.getVehicleData(f'd{lane}'):
     if vid.startswith('v') and leave>entry and vid not in speeds:speeds[vid]=length/(leave-entry)/MPH
   if sim.simulation.getMinExpectedNumber()==0:break
  pending=sim.simulation.getMinExpectedNumber()
 finally:sim.close()
 ss=list(speeds.values());res={'input_count':int(n),'desired_mean':mu,'desired_sd':sd,'seed':seed,'step':step,'detected_count':len(ss),'mean_mph':float(np.mean(ss)) if ss else None,'p85_mph':float(np.quantile(ss,.85)) if ss else None,'pending':pending,'arrived':arrived,'expected':int(n)+warm,'path':str(p.relative_to(ROOT))}
 result.write_text(json.dumps(res));
 if keep:pd.DataFrame({'vehicle_id':list(speeds),'speed_mph':ss}).to_csv(p/'detected_speeds.csv',index=False)
 return res

def fit(d):
 models={};trace=[];selected=[]
 for dr,g in d[(d.split=='fit') & d.eligible_for_automatic_aggregation & d.p85_mph.notna() & (d.sample_count>=40)].groupby('travel_direction'):
  # Select six demand levels only; ALL eligible fitting-hour targets enter loss.
  # Linear interpolation is a computational approximation between SUMO runs.
  g=g.sort_values('sample_count');levels=np.unique(np.quantile(g.sample_count,np.linspace(0,1,6)).round().astype(int))
  selected.extend(g.to_dict('records'))
  def objective(x):
   reps=[run(n,float(x[0]),float(x[1])) for n in levels]
   pm=np.interp(g.sample_count,levels,[z['mean_mph'] for z in reps]);pp=np.interp(g.sample_count,levels,[z['p85_mph'] for z in reps])
   loss=float(np.average((pm-g.mean_mph)**2+(pp-g.p85_mph)**2,weights=g.sample_count));trace.append({'direction':dr,'mu':x[0],'sd':x[1],'loss':loss});return loss
  initial=np.array([36.,5.]);res=minimize(objective,initial,method='Nelder-Mead',bounds=[(25,45),(1,10)],options={'maxiter':100,'xatol':.08,'fatol':.01})
  models[dr]={'desired_mean_mph':float(res.x[0]),'desired_sd_mph':float(res.x[1]),'objective':float(res.fun),'optimizer_success':bool(res.success),'fit_dates':FIT,'fitting_hours':len(g),'simulation_flow_levels':levels.tolist(),'objective_interpolation':'piecewise_linear_in_hourly_count'}
  print('fitted',dr,models[dr],flush=True)
 pd.DataFrame(selected).to_csv(DATA/'calibration_hours.csv',index=False);pd.DataFrame(trace).to_csv(OUT/'calibration_trace.csv',index=False)
 (OUT/'calibration.json').write_text(json.dumps(models,indent=2));return models

def evaluate(d,models):
 out=[];start=time.monotonic()
 for _,r in d[d.eligible_for_automatic_aggregation & (d.sample_count>0)].iterrows():
  m=models[r.travel_direction];seed=7919+int(hashlib.sha256(r.observation_id.encode()).hexdigest()[:7],16)%100000
  z=run(r.sample_count,m['desired_mean_mph'],m['desired_sd_mph'],seed)
  out.append({**r.to_dict(),**{'sim_'+k:v for k,v in z.items()}})
  if len(out)%120==0:print('validated hours',len(out),round(time.monotonic()-start,1),'s',flush=True)
 e=pd.DataFrame(out);e.to_csv(OUT/'speed_predictions.csv',index=False);return e

def summarize(d,e):
 base=d[d.split.eq('fit')];bs={}
 for dr,g in base.groupby('travel_direction'):
  bs[dr]={key:float(np.average(g[g[key].notna()][key],weights=g[g[key].notna()].sample_count)) for key in ['mean_mph','p85_mph']}
 results=[];rng=np.random.default_rng(981)
 for (split,dr),g in e.groupby(['split','travel_direction']):
  for stat in ['mean_mph','p85_mph']:
   valid=g[g[stat].notna()]
   if not len(valid):continue
   for model in ['SUMO','constant_fit_baseline']:
    pred=valid['sim_'+stat] if model=='SUMO' else np.full(len(valid),bs[dr][stat]);err=np.asarray(pred)-valid[stat].to_numpy();w=valid.sample_count.to_numpy()
    perday=pd.DataFrame({'day':valid.observation_date,'abs_sum':abs(err)*w,'bias_sum':err*w,'n':w}).groupby('day').sum()
    boot=[]
    for i in range(1000):
     b=perday.iloc[rng.integers(0,len(perday),len(perday))];boot.append(b.abs_sum.sum()/b.n.sum())
    results.append({'split':split,'direction':dr,'statistic':stat,'model':model,'hours':len(valid),'days':len(perday),'mae_mph':np.average(abs(err),weights=w),'bias_mph':np.average(err,weights=w),'day_bootstrap_mae_low':np.quantile(boot,.025),'day_bootstrap_mae_high':np.quantile(boot,.975)})
 pd.DataFrame(results).to_csv(OUT/'speed_validation.csv',index=False)
 # Reported daily means are the authoritative post targets; aggregate simulated hourly means by detected counts.
 daily=pd.read_csv(OBS/'speed_daily_summaries.csv');vals=[]
 for (date,dr),g in e.groupby(['observation_date','travel_direction']):
  obs=daily[daily.observation_date.eq(date)&daily.travel_direction.eq(dr)].iloc[0]
  vals.append({'date':date,'direction':dr,'split':g.iloc[0].split,'observed_mean_mph':obs.mean_mph,'sim_mean_mph':np.average(g.sim_mean_mph,weights=g.sim_detected_count),'observed_n':int(obs.sample_count),'sim_n':int(g.sim_detected_count.sum()),'source_page':int(obs.source_page),'measurement_status':'reported_daily_vs_simulated_hourly_cohort'})
 pd.DataFrame(vals).to_csv(OUT/'daily_speed_validation.csv',index=False)
 (OUT/'constant_baseline.json').write_text(json.dumps(bs,indent=2))
 return pd.DataFrame(results)

def main():
 OUT.mkdir(parents=True,exist_ok=True);DATA.mkdir(parents=True,exist_ok=True)
 d=source();m=fit(d) if not (OUT/'calibration.json').exists() else json.loads((OUT/'calibration.json').read_text());e=evaluate(d,m);summary=summarize(d,e);print(summary.to_string(index=False))
if __name__=='__main__':main()
