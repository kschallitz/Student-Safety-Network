from pathlib import Path
import os

ROOT = Path(__file__).resolve().parents[1]
SITE = os.environ.get("SCHOOL_SIM_SITE", "Estates")
if SITE not in ("Estates", "Hillcrest"): raise ValueError("Unsupported site")
DATA = ROOT / "data/metadrive_intersections" / SITE
OUT = ROOT / "outputs/metadrive_intersections" / SITE
SEED = 1400000
MPH = 0.44704
# Reaction, compliance and gap choices are assumptions, not observed quantities.
BEHAVIOR = dict(reaction_s=0.8, comfortable_decel=3.0, emergency_decel=6.0,
                time_headway_s=1.4, min_gap_m=2.0, pedestrian_gap_s=4.0,
                walk_speed_mps=1.4, bike_speed_mps=5.0, lateral_accel=1.8,
                near_miss_pet_s=1.5)
CANDIDATES = [
    dict(id="C01", label="Unchanged", curbs="before", medians=False, mph=30),
    dict(id="C02", label="25 mph operating response", curbs="before", medians=False, mph=25),
    dict(id="C03", label="Crossings shortened 1.5 m", curbs="small", medians=False, mph=30),
    dict(id="C04", label="Shorter crossings + 25 mph", curbs="small", medians=False, mph=25),
    dict(id="C05", label="Protected curbs + shorter crossings", curbs="pilot", medians=False, mph=30),
    dict(id="C06", label="Painted median channelization", curbs="before", medians=True, mph=30),
    dict(id="C07", label="Protected curbs + median channelization", curbs="pilot", medians=True, mph=30),
    dict(id="C08", label="Protected curbs + medians + 25 mph", curbs="pilot", medians=True, mph=25),
]
if SITE == 'Hillcrest':
    # Hillcrest's traced treatment has no median; avoid duplicate candidate designs.
    CANDIDATES = [c for c in CANDIDATES if c['id'] in ('C01','C02','C03','C04','C05','C08')]
    for c in CANDIDATES:
        c['medians'] = False
        if c['id']=='C08':c['label']='Protected curbs + shorter crossings + 25 mph'
ACTION_IDS = [c["id"] for c in CANDIDATES]

def candidate(action):
    return next(c for c in CANDIDATES if c["id"] == action)
