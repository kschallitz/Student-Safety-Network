"""Check every source movement, crossing, signal permissions and fixed-seed replay."""
import json
import pandas as pd
import numpy as np
from panda3d.core import Point3
from shapely.geometry import Polygon
from .bicycle_conflicts import polygon
from .checks import traveler
from .config import SITE,OUT,ACTION_IDS
if SITE=='Hillcrest':
    from .hillcrest_engine import World
else:
    from .engine import World

def main():
    results=[];w=World()
    def record(label,r):
        ok=r['complete'] and r['collision_pairs']==0 and r['precontact_boundary_violations']==0 and r['precontact_max_route_deviation_m']<.6
        results.append(dict(name=label,passed=bool(ok),complete=r['complete'],contacts=r['collision_pairs'],curbs=r['precontact_boundary_violations'],deviation=r['precontact_max_route_deviation_m']))
        print(label,results[-1],flush=True)
    try:
        # Compare actual Bullet box corners with the observer's footprint,
        # including headings in both axes. Centerline tracking alone misses
        # a bicycle body accidentally rotated 90 degrees.
        w.reset('C01')
        for arm,target in [('W','E'),('E','W'),('N','E')]+([('S','W')] if SITE=='Hillcrest' else []):
            r=traveler('box_'+arm,'bicycle',arm,target,desired=5)
            a=w.spawn(r,w.route(r));o=a['obj'];shape=o.body.getShape(0)
            half=shape.getHalfExtentsWithMargin();matrix=o.origin.getMat()
            corners=[matrix.xformPoint(Point3(x*half.x,y*half.y,0)) for x,y in [(1,1),(1,-1),(-1,-1),(-1,1)]]
            native=Polygon([(p.x,p.y) for p in corners])
            expected=polygon(np.asarray(o.position),o.heading_theta,o.LENGTH,o.WIDTH)
            error=native.symmetric_difference(expected).area
            results.append(dict(name='Bicycle native/observed footprint '+arm,passed=error<.0001,area_error_m2=error))
        for action in ['C01','C05'] if SITE=='Hillcrest' else ['C01','C07']:
            w.reset(action)
            keys=list(w.geometry['routes'])
            for mode in ('passenger','heavy','bicycle'):
                for key in keys:
                    arm,target,lane=key.split('_')
                    if SITE=='Estates' and mode=='heavy' and arm==target:continue
                    lanes=[k for k in keys if k.startswith(arm+'_'+target+'_')]
                    r=traveler('isolated',mode,arm,target,desired=15.3 if mode!='bicycle' else 5)
                    r['lane_draw']=(sorted(lanes).index(key)+.1)/len(lanes)
                    w.reset(action);res=w.run('isolated',custom=[r],max_time=360)
                    record(f'{action} {mode} {key}',res)
            for leg in w.geometry['crossings']:
                for forward in (True,False):
                    p=traveler('ped','pedestrian',leg=leg,desired=1.0);p['forward']=forward
                    w.reset(action);record(f'{action} ped {leg} {forward}',w.run('ped',custom=[p],max_time=360))
        if w.signal:
            from types import SimpleNamespace
            from .hillcrest_engine import following_body
            # Native first-contact snapshot: the stopped right turn's center
            # is outside the old 1.6 m threshold, but its rear corner is not.
            body=SimpleNamespace(LENGTH=4.515,WIDTH=1.852)
            alignment=float(np.cos(2.624290456335796-3.1389476019951266))
            _,lateral_limit,_=following_body(body,{'obj':body,'v':.004630019534842528},alignment)
            results.append(dict(name='Turning rear corner remains a following obstacle after its center leaves the lane',
                passed=bool(lateral_limit>2.38 and lateral_limit<3.5),lateral_limit_m=lateral_limit))
            s=w.signal
            checks=[s.vehicle_green(traveler('c',arm='E',target='S'),0),not s.vehicle_green(traveler('c',arm='E',target='W'),0),not s.pedestrian_walk('E',0)]
            results.append(dict(name='Protected left permission and no conflicting walking phase',passed=all(checks)))
            for leg in 'ENSW':
                results.append(dict(name=f'Crossing {leg} receives a clearance-compliant walking interval',passed=any(s.pedestrian_walk(leg,t) for t in range(int(s.cycle)))))
            # Reproduce the first observed red-queue/turning-car failure from
            # the dense March cohort. The former crosswalk-only stop point
            # placed the eastbound-side waiting left turn inside N->E's path.
            w.reset('C02')
            pair=[traveler('red_queue',arm='E',target='S',depart=72.66716550434268,desired=14.019526136868093),
                  traveler('green_turn',arm='N',target='E',depart=86.05632371260715,desired=9.691192733331224)]
            record('Red queue stays behind junction while conflicting green turn clears',w.run('red_queue_regression',custom=pair,max_time=360))
            w.reset('C02')
            pair=[traveler('right_turn',arm='N',target='W',depart=44.65506265179063,desired=9.058354875602879),
                  traveler('red_pedestrian','pedestrian',leg='N',depart=29.998927481237438,desired=1.4705890843183467)]
            record('Sidewalk waiting position avoids red-pedestrian/all-red deadlock',w.run('red_pedestrian_regression',custom=pair,max_time=360))
            w.reset('C02')
            walkers=[traveler('cross_S_1','pedestrian',leg='S',depart=19.34991021500273,desired=1.434113234516256),
                     traveler('cross_S_2','pedestrian',leg='S',depart=22.15949761995517,desired=1.4103720536845101),
                     traveler('wait_E','pedestrian',leg='E',depart=.5998099187771655,desired=1.338478054348272)]
            walkers[-1]['forward']=False
            record('Adjacent-crossing waiting queues leave sidewalk exits open',w.run('corner_queue_regression',custom=walkers,max_time=360))
        traces=[]
        for _ in range(2):
            w.reset('C02');r=w.run('repeat',custom=[traveler('c'),traveler('b','bicycle',arm='N',target='E',depart=4,desired=5)],record=True,max_time=360)
            traces.append(r['frames'])
        results.append(dict(name='Fixed inputs and seed repeat exactly',passed=traces[0]==traces[1]))
    finally:w.close()
    from .run import signature
    out=dict(site=SITE,snapshot=signature(),passed=all(r['passed'] for r in results),checks=results)
    OUT.mkdir(parents=True,exist_ok=True);(OUT/'motion_validation.json').write_text(json.dumps(out,indent=2))
    print('ALL PASSED',out['passed'],len(results))
    if not out['passed']:raise SystemExit(1)

if __name__=='__main__':main()
