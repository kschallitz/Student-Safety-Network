"""Versioned, site-specific direct observations; preserve the released Estates study."""
import json, shutil, hashlib
from pathlib import Path
import pandas as pd
from .config import ROOT, DATA, OUT, SITE, CANDIDATES

def main():
    DATA.mkdir(parents=True, exist_ok=True); OUT.mkdir(parents=True, exist_ok=True)
    legacy=ROOT/'data/metadrive_school'
    for file in ['geometry.json','speed_prior.json']:
        shutil.copyfile(legacy/file, DATA/file)
    if SITE=='Estates':
        for file in ['observations.csv','contexts.csv']:
            shutil.copyfile(legacy/file,DATA/file)
    else:
        from mitigation_integration import hillcrest_inputs
        metadata,_=hillcrest_inputs()  # Reconciles every count and movement to source tables.
        obs=pd.read_csv(ROOT/'data/sumo_v02/junction_demand_15min.csv').query("site == 'Hillcrest'").copy()
        obs['context_id']=pd.to_datetime(obs.interval_start).dt.strftime('%Y%m%dT%H%M%S')
        c=obs.pivot_table(index=['context_id','date','interval_start','phase'],columns='mode',values='count',aggfunc='sum').reset_index()
        c['hour']=pd.to_datetime(c.interval_start).dt.hour+pd.to_datetime(c.interval_start).dt.minute/60
        c['weekend']=(pd.to_datetime(c.date).dt.dayofweek>=5).astype(int)
        c['split']='train';c.loc[c.date>='2023-05-01','split']='test'
        c.loc[c.context_id.isin(['20230302T080000','20230302T084500','20230302T144500','20230302T154500']),'split']='validation'
        c['total']=c[['passenger','heavy','bicycle','pedestrian']].sum(axis=1)
        obs.to_csv(DATA/'observations.csv',index=False);c.to_csv(DATA/'contexts.csv',index=False)
        (DATA/'source_inventory.json').write_text(json.dumps(metadata,indent=2))
    (DATA/'candidates.json').write_text(json.dumps(CANDIDATES,indent=2))
    (DATA/'benchmark_key.json').write_text(json.dumps({'consultant_candidate':'C07' if SITE=='Estates' else 'C05'}))
    manifest=dict(site=SITE,input_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in DATA.glob('*') if p.name!='manifest.json'},
                  geometry_status='Source tracing from April 2025 memo; not a certified 2023 as-built survey',
                  signal_status='Hillcrest: 2020 phase structure, assumed timing; fixed across designs, pedestrian clearance uses the longest baseline crossing',
                  speed_status='Observed corridor pre-installation bins transferred to approaches; side-street distribution assumed',
                  source_url='https://www.livermoreca.gov/home/showpublisheddocument/12943/638887914440930000')
    (DATA/'manifest.json').write_text(json.dumps(manifest,indent=2))
    print(SITE,'inputs prepared')

if __name__=='__main__':main()
