"""Export only a fully reconciled, site-bound comparison for the website."""
import hashlib,json
import pandas as pd
from .config import ROOT,OUT,DATA,SITE,CANDIDATES
from .quality import assess

def build(suite='pilot'):
    quality,frame=assess(suite)
    if not quality['recommendation_released']:raise RuntimeError('; '.join(quality['release_blockers']))
    policy_file=OUT/f'{suite}_policy_freeze.json';policy=json.loads(policy_file.read_text())
    evaluation=json.loads((OUT/f'{suite}_evaluation.json').read_text())
    assert evaluation['policy_freeze_sha256']==hashlib.sha256(policy_file.read_bytes()).hexdigest()
    assert policy['snapshot']==quality['snapshot'] and not policy['test_outcomes_used'] and not policy['consultant_identity_used']
    junction_id={'Estates':'J01145','Hillcrest':'J02019'}[SITE]
    junction=next(j for j in json.loads((ROOT/'intersection_prediction_output/map_payload.json').read_text())['junctions'] if j['id']==junction_id)
    episodes=[]
    for r in frame.to_dict('records'):
        episodes.append(dict(context=r['context_id'],action=r['action'],realization=int(r['realization']),split=r['split'],
            contacts=int(r['collision_pairs']),near=int(r['near_pairs']),pedestrianNear=int(r['motor_pedestrian_near_pairs']),
            bicycleNear=int(r['motor_bicycle_near_pairs']),reward=int(r['score']),travelers=int(r['arrived']),
            vehicleContacts=int(r['motor_vehicle_collision_pairs_diagnostic']),delaySeconds=float(r['mean_delay_s'])))
    selected=policy['agents'][policy['champion']]['fixed_action']
    totals=frame[frame.split=='test'].groupby('action').score.sum()
    result=dict(junctionId=junction_id,name='East Avenue / '+('Estates Street' if SITE=='Estates' else 'Hillcrest Avenue'),ll=junction['ll'],
        schoolId='01612006001242',site=SITE,snapshot=quality['snapshot'],scoringVersion=quality['scoring_version'],
        selected=selected,champion=policy['champion'],consultant='C07' if SITE=='Estates' else 'C05',baseline='C01',
        agents=[{k:a[k] for k in ['family','fixed_action','validation_score','replayed_samples']} for a in policy['agents'].values()],
        candidates=CANDIDATES,episodes=episodes,releaseChecked=True,bicycleNearMeasured=True,annualProbabilityValidated=False,replayActions=[],
        recommendationEndorsed=evaluation['recommendation_endorsed'],evaluationStatus=evaluation['evaluation_status'],
        tiedBestEvaluationActions=totals[totals==totals.max()].index.tolist(),
        protocol=json.loads((OUT/f'{suite}_protocol.json').read_text()),
        sourceHashes={'policy':hashlib.sha256(policy_file.read_bytes()).hexdigest(),'runs':hashlib.sha256((OUT/f'{suite}_runs.csv').read_bytes()).hexdigest()})
    (OUT/f'{suite}_site_evidence.json').write_text(json.dumps(result,indent=2));return result

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--suite',default='pilot');a=p.parse_args();r=build(a.suite);print(r['name'],r['selected'],r['evaluationStatus'])
