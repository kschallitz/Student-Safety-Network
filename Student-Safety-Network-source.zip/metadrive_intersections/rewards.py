"""Score motor-vehicle interactions with pedestrians/cyclists from saved events.

Native episode records remain immutable. Vehicle/vehicle contacts remain
available as diagnostics but never supply an RL penalty under this objective.
The v2 observer measures both pedestrian and bicycle near misses.
"""
import hashlib
from functools import lru_cache
from pathlib import Path

SCORING_VERSION = 'motor-vru-v2'
MOTOR_MODES = frozenset(('passenger', 'heavy'))
VRU_MODES = frozenset(('pedestrian', 'bicycle'))
KNOWN_MODES = MOTOR_MODES | VRU_MODES
REWARD_DEFINITION = ('-1000 per distinct motor-vehicle/pedestrian or motor-vehicle/bicycle contact pair; '
                     '-5 per measured noncontact motor-vehicle/pedestrian or motor-vehicle/bicycle projected near-miss pair. '
                     'Motor-vehicle/motor-vehicle and nonmotorized-only events do not affect the reward. '
                     'Bicycle near misses use route-projected oriented footprints and actual passage times.')


def source_hash():
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def training_folder(snapshot):
    from .config import OUT
    return OUT/'rl_retraining'/snapshot/SCORING_VERSION


@lru_cache(maxsize=128)
def ledger_modes(context, seed, realization):
    from .demand import ledger
    demand, digest = ledger(context, seed, realization)
    return {a['id']: a['mode'] for a in demand}, digest


def score_episode(raw, modes=None):
    """Return a scored view; never mutate the saved physics record."""
    if modes is None:
        modes, digest = ledger_modes(raw['context_id'], raw['seed'], raw['realization'])
        if digest != raw['demand_sha256']:
            raise ValueError('Actor mode lookup does not match the recorded demand ledger')

    def pair_modes(event):
        pair = tuple(sorted(event['pair']))
        if len(pair) != 2 or pair[0] == pair[1]:
            raise ValueError('A scored event must name two different actors')
        values = tuple(modes[a] for a in pair)  # Unknown actor is an error, not an exclusion.
        if not set(values) <= KNOWN_MODES:
            raise ValueError('Unrecognized actor mode')
        for actor in event.get('actors', []):
            if actor['mode'] != modes[actor['id']]:
                raise ValueError('Contact actor mode disagrees with the demand ledger')
        return pair, values

    contacts = {}; motor_motor = {}; other = {}
    for event in raw['contacts']:
        pair, values = pair_modes(event)
        selected = any(m in MOTOR_MODES for m in values) and any(m in VRU_MODES for m in values)
        bucket = contacts if selected else motor_motor if all(m in MOTOR_MODES for m in values) else other
        bucket.setdefault(pair, event)
    near = {}; excluded_near = {}
    for event in raw['near_misses']:
        pair, values = pair_modes(event)
        selected = any(m in MOTOR_MODES for m in values) and any(m in VRU_MODES for m in values)
        if selected and pair not in contacts:
            if 'bicycle' in values and raw.get('safety_metric_version')!='route-ttc-pet-motor-bicycle-v2':
                raise ValueError('Cyclist near-miss coverage needs an explicit detector version')
            near.setdefault(pair, event)
        else:
            excluded_near.setdefault(pair, event)
    pedestrian_contacts = sum('pedestrian' in [modes[x] for x in pair] for pair in contacts)
    bicycle_contacts = sum('bicycle' in [modes[x] for x in pair] for pair in contacts)
    return {**raw, 'scoring_version': SCORING_VERSION, 'scoring_source_sha256': source_hash(),
            'native_all_contact_score': raw['score'], 'all_contact_pairs': len(contacts)+len(motor_motor)+len(other),
            'collision_pairs': len(contacts), 'near_pairs': len(near),
            'motor_pedestrian_collision_pairs': pedestrian_contacts,
            'motor_bicycle_collision_pairs': bicycle_contacts,
            'motor_vehicle_collision_pairs_diagnostic': len(motor_motor),
            'other_contact_pairs_diagnostic': len(other),
            'motor_pedestrian_near_pairs': sum('pedestrian' in [modes[x] for x in pair] for pair in near),
            'motor_bicycle_near_pairs': sum('bicycle' in [modes[x] for x in pair] for pair in near),
            'bicycle_near_misses_measured': raw.get('safety_metric_version')=='route-ttc-pet-motor-bicycle-v2',
            'excluded_near_pairs_diagnostic': len(excluded_near),
            'score': -1000*len(contacts)-5*len(near), 'reward_definition': REWARD_DEFINITION,
            'scored_contacts': list(contacts.values()), 'scored_near_misses': list(near.values()),
            'unscored_contacts': list(motor_motor.values())+list(other.values())}


def scalar_row(scored):
    return {k: v for k, v in scored.items() if not isinstance(v, (dict, list))}
