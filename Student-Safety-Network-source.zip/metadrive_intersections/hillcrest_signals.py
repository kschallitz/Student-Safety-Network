"""Hillcrest phase plan with pedestrian and occupied-junction clearance.

Phase order is the available historical HCM structure. Durations are scenario
assumptions, not recovered 2023 controller records. The exact same plan and
rules apply to every candidate. A pedestrian may start only while enough
green/clearance remains; existing walkers always finish. All-red extends until
committed traffic and walkers clear. No right turn on red.
"""
from .geometry import build
from .hillcrest_walks import walking_route
import numpy as np

LEFT={'E':'S','W':'N','N':'E','S':'W'}
class SignalPlan:
    def __init__(self):
        base=build('C01')
        # Fixed baseline geometry, not a treatment-dependent signal advantage.
        self.clearance={leg:max(walking_route('C01',leg,f).length for f in (True,False))/.8+2 for leg in base['crossings']}
        self.phases=[]
        for name,green,legs in [('EW_left',8,()),('EW_through',36,('N','S')),
                                ('northbound',20,('E','W')),('southbound',16,('E','W'))]:
            walk_clear=max([self.clearance[l] for l in legs],default=0)
            duration=max(green,7+walk_clear)
            self.phases.extend([(name,duration,legs),('yellow_'+name,3,()),('all_red',2,())])
        self.cycle=sum(p[1] for p in self.phases)
        self.index=0;self.end=self.phases[0][1];self.runtime_time=None
        self.hold_start=None;self.clearance_holds=[]

    def observe(self,t,actors):
        """Do not release a conflicting phase into traffic still clearing.

        Fixed all-red alone cannot clear a turning car that has had to yield
        at an exit crossing. This guard changes permissions, never actor poses.
        It is shared by all designs and its extensions are recorded.
        """
        occupied=any((a['record']['mode']=='pedestrian' and a['started']) or
                     (a['record']['mode']!='pedestrian' and a.get('signal_entered',False)
                      and a['s'] < a['route'].s[-2]+a['obj'].LENGTH/2+1.) for a in actors)
        while t>=self.end:
            if self.phases[self.index][0]=='all_red' and occupied:
                if self.hold_start is None:self.hold_start=self.end
                break
            start=self.end
            if self.hold_start is not None:
                self.clearance_holds.append(dict(start=self.hold_start,end=t,seconds=t-self.hold_start))
                start=t;self.hold_start=None
            self.index=(self.index+1)%len(self.phases)
            self.end=start+self.phases[self.index][1]
        self.runtime_time=t

    def phase(self,t):
        if self.runtime_time is not None and abs(self.runtime_time-t)<1e-7:
            name,_,legs=self.phases[self.index]
            return name,max(0.,self.end-t),legs
        elapsed=t%self.cycle
        for name,duration,legs in self.phases:
            if elapsed<duration:return name,duration-elapsed,legs
            elapsed-=duration
        raise AssertionError('Signal phase not found')

    def vehicle_green(self,r,t):
        name,_,_=self.phase(t);a=r['from_arm'];target=r['to_arm']
        left=target==LEFT[a] or target==a
        return ((name=='EW_left' and a in ('E','W') and left) or
                (name=='EW_through' and a in ('E','W') and not left) or
                (name=='northbound' and a=='S') or (name=='southbound' and a=='N'))

    def pedestrian_walk(self,leg,t):
        _,remaining,legs=self.phase(t)
        return leg in legs and remaining>=self.clearance[leg]

    def manifest(self):
        return dict(cycle_s=self.cycle,phases=self.phases,clearance_s=self.clearance,
                    status='Historical phase structure; assumed base greens and pedestrian clearance; all-red extends for occupied junctions; no right-on-red',
                    clearance_rule='Release the next phase only after committed motor vehicles/bicycles and started pedestrians clear. Base phase settings and this rule are identical across candidates.',
                    stop_line_rule='Stop before the swept crosswalk corridor and at least 1 m before the source-traced junction approach gate, whichever is earlier. This is a geometric control assumption, not a surveyed stop-line location.',
                    pedestrian_waiting_rule='Stage 2 m along the source-traced sidewalk direction from each crossing endpoint; keep separate right-side walking paths. Clearance allows the full baseline walking route at 0.8 m/s plus 2 s.')
