"""Individual travelers sampled from observed totals; identical ledgers per design."""
import hashlib, json
from functools import lru_cache
import numpy as np
import pandas as pd
from .config import DATA, SEED, MPH

@lru_cache()
def tables():
    return pd.read_csv(DATA/"observations.csv"),pd.read_csv(DATA/"contexts.csv")

def ledger(context_id, seed=SEED, realization=0, warmup=60.):
    rows=tables()[0]; rows=rows[rows.context_id.eq(context_id)]
    if rows.empty: raise ValueError(context_id)
    # A realization is an explicit different demand scenario, not an identical rerun.
    # The same (seed, realization) is always paired across all candidate designs.
    rng=np.random.default_rng(np.random.SeedSequence([seed,realization]))
    priors=json.loads((DATA/"speed_prior.json").read_text())
    records=[]
    def speed(arm):
        direction={"W":"eastbound","E":"westbound"}.get(arm)
        if direction is None: return float(np.clip(rng.normal(25,2),15,35))*MPH
        bins=priors[direction]; weights=np.array([b['count'] for b in bins],dtype=float)
        b=bins[int(rng.choice(len(bins),p=weights/weights.sum()))]
        lo=b['speed_bin_lower_mph'];hi=b['speed_bin_upper_mph']
        if hi is None or not np.isfinite(hi):hi=lo+5
        return float(rng.uniform(lo,hi))*MPH
    for phase in ("warmup","study"):
        for row in rows.to_dict('records'):
            n=int(row['count'])
            if phase=='warmup':
                # Warm-up demand is explicitly estimated from the same 15-min rate.
                n=int(rng.poisson(n*warmup/900))
            for j in range(n):
                mode=row['mode']; pedestrian=mode=='pedestrian'
                rec=dict(id=f"{phase[0]}{len(records):05d}",mode=mode,study=phase=='study',
                    depart=float(rng.uniform(0,warmup) if phase=='warmup' else warmup+rng.uniform(0,900)),
                    from_arm=None if pedestrian else row['from_arm'],to_arm=None if pedestrian else row['to_arm'],
                    crossing_leg=row['crossing_leg'] if pedestrian else None,
                    forward=bool(rng.integers(2)),lane_draw=float(rng.random()),
                    desired_mps=float(np.clip(rng.normal(1.4,.15),.8,2.0)) if pedestrian else float(np.clip(rng.normal(5,.6),2,7)) if mode=='bicycle' else speed(row['from_arm']),
                    source_observation=row['source_observation'])
                records.append(rec)
    records.sort(key=lambda r:(r['depart'],r['id']))
    digest=hashlib.sha256(json.dumps(records,sort_keys=True).encode()).hexdigest()
    return records,digest
