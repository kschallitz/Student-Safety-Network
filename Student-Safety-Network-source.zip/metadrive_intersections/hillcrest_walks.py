"""Walk from the source-traced sidewalks through the recorded crossing legs."""
import json
from functools import lru_cache
import numpy as np
from shapely.geometry import LineString
from .config import DATA
from .geometry import build,Route
WAIT_BACK_M=2.0

@lru_cache(maxsize=64)
def walking_route(action,leg,forward):
    trace=json.loads((DATA/'geometry.json').read_text());spec=trace['Hillcrest']
    origin=np.asarray(spec['origin']);scale=np.asarray([trace['metres_per_pixel'],-trace['metres_per_pixel']])
    anchors=np.asarray([spec['arms'][leg]['sidewalk_in'],spec['arms'][leg]['sidewalk_out']])
    anchors=(anchors-origin)*scale
    q=build(action)['crossings'][leg]
    first=int(np.argmin(np.linalg.norm(anchors-q[0],axis=1)))
    # Use the traced sidewalk direction, but stage close to the crossing.
    # Requiring pedestrians to walk all the way from a distant tracing anchor
    # would add unobserved approach travel to the signal clearance time.
    directions=np.vstack([anchors[first]-q[0],anchors[1-first]-q[1]])
    lengths=np.linalg.norm(directions,axis=1)
    waiting=q+directions*np.minimum(1.,WAIT_BACK_M/lengths)[:,None]
    line=np.vstack([waiting[0],q,waiting[1]])
    if not forward:line=line[::-1]
    # Right-side walking paths stay separated through the sidewalk corners,
    # rather than offsetting only the straight crosswalk section.
    path=LineString(line).offset_curve(-.45,join_style=1)
    if path.geom_type!='LineString' or path.is_empty:raise ValueError('Invalid sidewalk-to-crosswalk route')
    return Route(np.asarray(path.coords),f'ped_{leg}{forward}')
