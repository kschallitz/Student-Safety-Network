"""Observe projected crossing conflicts without changing any actor's motion.

PET measures the gap between passages; it does not establish a collision
course. Retain it separately. A scored pedestrian conflict additionally needs
projected body overlap within 1.5 s at current speed along the intended route.
The TTC/PET thresholds follow FHWA's SSAM convention, adapted here to a
pedestrian circle and vehicle rectangle; this is not a claim of SSAM pedestrian
validation. Native Bullet manifolds remain the sole contact counter.

Reference: https://www.fhwa.dot.gov/publications/research/safety/10038/003.cfm
"""
import math
import numpy as np

TTC_LIMIT_S = 1.5
PET_LIMIT_S = 5.0
PROJECTION_STEP_S = .025
METRIC_VERSION = 'route-ttc-pet-motor-bicycle-v2'


def projected_pose(route, position, heading, speed, times):
    """Follow the route curvature; preserve the current pose's route offset.

    A heading ray would send turning cars off their intended path. Conversely,
    snapping the present body to the route would hide actual tracking error.
    These arrays are observations only, never supplied to the physics engine.
    """
    position = np.asarray(position, dtype=float)
    s = route.project(position)
    samples = np.minimum(route.length, s + max(0., speed) * times)
    xy = np.column_stack([np.interp(samples, route.s, route.points[:, k]) for k in (0, 1)])
    indices = np.clip(np.searchsorted(route.s, samples, side='right') - 1, 0, len(route.headings)-1)
    angles = route.headings[indices]
    initial = route.heading(s)
    offset = position - route.position(s)
    rotation = angles - initial
    xy += np.column_stack([offset[0]*np.cos(rotation)-offset[1]*np.sin(rotation),
                           offset[0]*np.sin(rotation)+offset[1]*np.cos(rotation)])
    return xy, angles + heading - initial


def projected_ttc(vehicle_pose, pedestrian_pose, length, width, times, radius=.35):
    """First sampled circle/rectangle overlap, including the current pose.

    No PET buffer or extra clearance is added to the physical dimensions.
    The returned time has 0.025 s resolution, independent of operating speed.
    """
    vxy, angles = vehicle_pose
    pxy, _ = pedestrian_pose
    delta = pxy - vxy
    cs, sn = np.cos(angles), np.sin(angles)
    along = np.abs(delta[:, 0]*cs + delta[:, 1]*sn)
    across = np.abs(-delta[:, 0]*sn + delta[:, 1]*cs)
    distance2 = np.maximum(along-length/2, 0)**2 + np.maximum(across-width/2, 0)**2
    hits = np.flatnonzero(distance2 <= radius**2)
    return float(times[hits[0]]) if len(hits) else None


class CrossingConflicts:
    def __init__(self):
        self.times = np.linspace(0., TTC_LIMIT_S, round(TTC_LIMIT_S/PROJECTION_STEP_S)+1)
        self.events = {}

    def observe(self, actors, t, zones):
        projections = {}

        def pose(a):
            name = a['record']['id']
            if name not in projections:
                projections[name] = projected_pose(a['route'], a['pos'], a['obj'].heading_theta, a['v'], self.times)
            return projections[name]

        for pedestrian in actors:
            p = pedestrian['record']
            if p['mode'] != 'pedestrian':
                continue
            for vehicle in pedestrian['neighbors']:
                v = vehicle['record']
                if v['mode'] == 'pedestrian' or not(p['study'] or v['study']):
                    continue
                zone = (vehicle['route'].key, p['crossing_leg'])
                if zone not in zones:
                    continue
                obj = vehicle['obj']
                reach = (vehicle['v']+pedestrian['v'])*TTC_LIMIT_S + math.hypot(obj.LENGTH/2, obj.WIDTH/2) + .35
                separation = vehicle['pos'] - pedestrian['pos']
                if separation @ separation > reach**2:
                    continue
                ttc = projected_ttc(pose(vehicle), pose(pedestrian), obj.LENGTH, obj.WIDTH, self.times)
                if ttc is None:
                    continue
                pair = tuple(sorted((p['id'], v['id'])))
                key = (pair, zone)
                prior = self.events.get(key)
                if prior is None or ttc < prior['ttc_s']:
                    self.events[key] = dict(pair=list(pair), zone=list(zone), ttc_s=ttc,
                        time=float(t), vehicle_speed_mps=float(vehicle['v']), pedestrian_speed_mps=float(pedestrian['v']))

    def classify(self, pet_events, contacts):
        """Deduplicate pairs only after matching TTC and PET at the same zone."""
        near = {}
        for event in pet_events:
            pair = tuple(event['pair'])
            projected = self.events.get((pair, tuple(event['zone'])))
            if projected is None or event['pet_s'] > PET_LIMIT_S or pair in contacts:
                continue
            combined = {**event, **projected, 'pet_s': event['pet_s']}
            if pair not in near or combined['ttc_s'] < near[pair]['ttc_s']:
                near[pair] = combined
        return near
