"""Native MetaDrive/Bullet actors with reactive path-following controllers.

Vehicles use steering/throttle/brake and Bullet integration. No vehicle is
repositioned after spawning. Pedestrians/cyclists use MetaDrive velocity control.
Counts, gap parameters and motion diagnostics are exported independently.
"""
import os
os.environ.setdefault("MPLCONFIGDIR", "/tmp/school-metadrive-mpl")
os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
import json, math, time
from collections import deque
from types import SimpleNamespace
import numpy as np
from shapely.geometry import Point, LineString, Polygon
from scipy.spatial import cKDTree
from metadrive.envs.scenario_env import ScenarioEnv
from metadrive.engine.engine_utils import initialize_engine, close_engine
from metadrive.component.map.scenario_map import ScenarioMap
from metadrive.component.vehicle.vehicle_type import DefaultVehicle, XLVehicle
from metadrive.component.traffic_participants.pedestrian import Pedestrian
from metadrive.component.traffic_participants.cyclist import Cyclist
from metadrive.base_class.base_object import BaseObject
from panda3d.core import Vec3
from panda3d.bullet import BulletBoxShape
from .geometry import build, Route
from .config import SEED, BEHAVIOR, MPH, SITE, candidate
from .demand import ledger
from .conflicts import CrossingConflicts, METRIC_VERSION
from .bicycle_conflicts import BicycleConflicts

def wrap(a):return (a+np.pi)%(2*np.pi)-np.pi

def actor_name(node):
    tag=node.getPythonTag(node.getName())
    return getattr(tag,'base_object_name',None)

def dimensions(obj,mode):
    return (.7,.7) if mode=='pedestrian' else (obj.LENGTH,obj.WIDTH)

def vehicle_footprint(actor):
    """One oriented footprint per shared pre-step snapshot."""
    if actor.get('footprint') is None:
        obj=actor['obj'];pos=actor['pos'];heading=obj.heading_theta
        u=np.array([math.cos(heading),math.sin(heading)]);n=np.array([-u[1],u[0]])
        length,width=dimensions(obj,actor['record']['mode'])
        actor['footprint']=Polygon([pos+x*u*length/2+y*n*width/2 for x,y in [(1,1),(1,-1),(-1,-1),(-1,1)]])
    return actor['footprint']

def braking_limits(obj,dt,behavior):
    """Respect this Bullet vehicle's brake capacity, including controller lag.

    Bullet's maximum wheel brake is an impulse per physics step. Four wheels
    therefore give approximately 4 * brake / (mass * dt) m/s^2. Isolated full
    brake tests verify this bound for the installed car and truck classes.
    The truck's ~2.63 m/s^2 is below our formerly assumed 3/6 m/s^2 envelope.
    For every vehicle, also allow the proportional speed servo's
    response time, 1 / (gain * deceleration), before a turn or stopping point.
    This changes anticipation, not the native vehicle force or its position.
    """
    capacity=4*float(obj.config['max_brake_force'])/(float(obj.MASS)*dt)
    comfortable=min(behavior['comfortable_decel'],capacity)
    emergency=min(behavior['emergency_decel'],capacity)
    servo_lag=1/(.45*capacity)
    return comfortable,emergency,behavior['reaction_s']+servo_lag

def contact_pairs(world,active):
    pairs=[]
    for manifold in world.getManifolds():
        x=actor_name(manifold.getNode0());y=actor_name(manifold.getNode1())
        if x in active and y in active and any(p.getDistance()<=0 for p in manifold.getManifoldPoints()):
            pairs.append(tuple(sorted((x,y))))
    return sorted(set(pairs))

class World:
    def __init__(self, dt=.05):
        self.dt=dt; self.map=None
        from .signals import SignalPlan
        self.signal=SignalPlan() if SITE=='Hillcrest' else None
        c=ScenarioEnv.default_config()
        c.update(dict(use_render=False,image_observation=False,show_terrain=False,show_skybox=False,
                      show_interface=False,physics_world_step_size=dt,log_level=40,
                      need_lane_localization=False,force_destroy=True))
        c['vehicle_config'].update(dict(navigation_module=None,show_navi_mark=False,show_dest_mark=False,
            lidar=dict(num_lasers=0,distance=0),side_detector=dict(num_lasers=0,distance=0),
            lane_line_detector=dict(num_lasers=0,distance=0)))
        self.engine=initialize_engine(c)
        self.engine.map_manager=SimpleNamespace(current_map=None)
        self.engine.terrain.reset([0,0])

    def reset(self,action):
        self.engine.clear_objects(list(self.engine._spawned_objects),force_destroy=True)
        if self.map is not None:self.map.destroy()
        self.geometry=build(action);self.map=ScenarioMap(0,self.geometry['features'])
        self.map.attach_to_world();self.engine.map_manager.current_map=self.map
        self.action=candidate(action)
        self.conflicts={}
        self.crossing_stop_cache={}
        for key,route in self.geometry['routes'].items():
            for other_key,other in self.geometry['routes'].items():
                hit=route.line.intersection(other.line)
                def endpoints(shape):
                    if shape.is_empty:return []
                    if shape.geom_type=='Point':return [shape.coords[0]]
                    if shape.geom_type=='LineString':return [shape.coords[0],shape.coords[-1]]
                    return [p for part in getattr(shape,'geoms',[]) for p in endpoints(part)]
                points=[p for p in endpoints(hit) if route.project(p)>99]
                if not points:continue
                # Shared outbound lines are merge conflicts, too. Looking only
                # for a Point intersection omitted the minor-arm right turn.
                point=min(points,key=route.project)
                own=route.project(point);theirs=other.project(point)
                # Clearance from the approach decision line, starting stopped.
                # Use the same geometric curve-speed limit as the driver.
                samples=np.linspace(96,max(96,own+5),32);elapsed=0.;speed=.5
                for left,right in zip(samples[:-1],samples[1:]):
                    ds=right-left;limit=min(self.action['mph']*MPH,route.curve_limit(right,BEHAVIOR['lateral_accel']))
                    next_speed=min(limit,math.sqrt(speed*speed+2*2.6*ds))
                    elapsed+=2*ds/max(speed+next_speed,.1);speed=next_speed
                self.conflicts[(key,other_key)]=(own,theirs,elapsed)

    def crossing_stop(self, route, crossing_leg, obj, nominal):
        """Last safe center position before the body enters a walking corridor.

        Subtracting half a vehicle length from a centerline intersection is
        incorrect on a turn: the front corner can enter the crossing first.
        Sweep oriented vehicle rectangles along the route and retain 0.5 m
        beyond the walker's 0.35 m radius. This is independent of speed/action
        reward; the same geometric rule is used for every design.
        """
        key=(route.key,crossing_leg,float(obj.LENGTH),float(obj.WIDTH))
        if key in self.crossing_stop_cache:return self.crossing_stop_cache[key]
        # One stop boundary for BOTH walking directions: their paths lie
        # 0.45 m either side of the crossing centerline, with a 0.35 m body
        # radius and 0.5 m clearance. Per-walker boundaries differed by 0.9 m
        # and caused circular waits between opposing walkers and stopped cars.
        corridor=LineString(self.geometry['crossings'][crossing_leg]).buffer(.45+.35+.5)
        def overlaps(s):
            pos=route.position(s);heading=route.heading(s)
            u=np.array([math.cos(heading),math.sin(heading)]);n=np.array([-u[1],u[0]])
            body=Polygon([pos+x*u*obj.LENGTH/2+y*n*obj.WIDTH/2 for x,y in [(1,1),(1,-1),(-1,-1),(-1,1)]])
            return body.intersects(corridor)
        left=max(0.,nominal-30.)
        for right in np.arange(left+.5,min(route.length,nominal+10.)+.5,.5):
            if overlaps(right):
                for _ in range(12):
                    mid=(left+right)/2
                    if overlaps(mid):right=mid
                    else:left=mid
                self.crossing_stop_cache[key]=float(left)
                return float(left)
            left=right
        raise ValueError(f'No swept crossing found for {route.key} and crossing {crossing_leg}')

    def close(self):
        self.engine.clear_objects(list(self.engine._spawned_objects),force_destroy=True)
        if self.map is not None:self.map.destroy();self.map=None
        self.engine.map_manager.current_map=None;close_engine()

    def route(self,r):
        if SITE=='Estates' and r['mode']=='heavy' and r['from_arm']==r['to_arm']:
            raise ValueError('Heavy-vehicle U-turns need a truck-specific swept-path design; none occur in the source counts.')
        if r['mode']=='pedestrian':
            q=self.geometry['crossings'][r['crossing_leg']].copy()
            if not r['forward']:q=q[::-1]
            # Opposing walkers use separate halves of the observed crossing width.
            unit=(q[1]-q[0])/np.linalg.norm(q[1]-q[0]);q+=np.array([unit[1],-unit[0]])*.45
            return Route(q, 'ped_'+r['crossing_leg']+str(r['forward']))
        keys=sorted(k for k in self.geometry['routes'] if k.startswith(f"{r['from_arm']}_{r['to_arm']}_"))
        return self.geometry['routes'][keys[min(int(r['lane_draw']*len(keys)),len(keys)-1)]]

    def spawn(self,r,route):
        p=route.position(0);heading=route.heading(0)
        if r['mode']=='pedestrian':
            obj=self.engine.spawn_object(Pedestrian,position=p,heading_theta=heading,name=r['id'],random_seed=SEED)
        elif r['mode']=='bicycle':
            obj=self.engine.spawn_object(Cyclist,position=p,heading_theta=heading,name=r['id'],random_seed=SEED)
            # This Cyclist implementation reports heading along local X but
            # builds a box long along local Y. Align the native contact body
            # with that heading, matching its route and projected footprint.
            obj.body.removeShape(obj.body.getShape(0))
            obj.body.addShape(BulletBoxShape(Vec3(obj.LENGTH/2,obj.WIDTH/2,obj.HEIGHT/2)))
        else:
            cls=XLVehicle if r['mode']=='heavy' else DefaultVehicle
            obj=self.engine.spawn_object(cls,vehicle_config=dict(spawn_position_heading=(p,heading),navigation_module=None),name=r['id'],random_seed=SEED)
        if r['mode'] in ('pedestrian','bicycle'):
            obj.body.setAngularFactor(Vec3(0,0,1))
            obj.body.setDeactivationEnabled(False)
        return dict(record=r,obj=obj,route=route,s=0.,desired=r['desired_mps']*(self.action['mph']/30 if r['mode'] not in ('pedestrian','bicycle') else 1.),
                    delay_queue=deque(),started=False,previous=p.copy(),max_jump=0.,offroute=0.,spawn_time=0.)

    def run(self,context_id,seed=SEED,realization=0,behavior=None,record=False,custom=None,max_time=1200):
        b={**BEHAVIOR,**(behavior or {})};dt=self.dt
        demand,digest=ledger(context_id,seed,realization) if custom is None else (custom,'diagnostic')
        pending=[(r,self.route(r)) for r in demand];active={};finished=[];contacts={};warmup_contacts={};frames=[];boundary_events={}
        blocked_insertions=0;max_jump=0.;max_lateral=0.;boundary_hits=set();precontact_boundary_hits=set();precontact_lateral=0.;contact_actors=set()
        # Fixed conflict zones: intersection of route swept corridors with each crossing.
        zones={}
        for key,r in self.geometry['routes'].items():
            for leg,q in self.geometry['crossings'].items():
                hit=r.line.intersection(LineString(q))
                if hit.geom_type=='Point':
                    zones[(key,leg)] = (r.project(hit.coords[0]),np.asarray(hit.coords[0]))
        route_zones={key:[(zone,value) for zone,value in zones.items() if zone[0]==key] for key in self.geometry['routes']}
        leg_zones={leg:[(zone,value) for zone,value in zones.items() if zone[1]==leg] for leg in self.geometry['crossings']}
        crossing_conflicts=CrossingConflicts(); bicycle_conflicts=BicycleConflicts()
        t=0.;wall=time.monotonic();active_occupancy={};completed_occupancy={}
        while t<max_time and (pending or active):
            # Physical separation at insertion; delayed arrivals remain in queue.
            ready=[]
            while pending and pending[0][0]['depart']<=t:ready.append(pending.pop(0))
            retry=[]
            for r,path in ready:
                p=path.position(0);heading=path.heading(0)
                unit=np.array([math.cos(heading),math.sin(heading)]);normal=np.array([-unit[1],unit[0]])
                length,width={'pedestrian':(.7,.7),'bicycle':(1.75,.4),'heavy':(5.74,2.3),'passenger':(4.515,1.852)}[r['mode']]
                gap=.5 if r['mode']=='pedestrian' else 2.
                blocked=False
                for other in active.values():
                    delta=np.asarray(other['obj'].position)-p
                    if abs(delta[0])>12 or abs(delta[1])>12:continue
                    ol,ow=dimensions(other['obj'],other['record']['mode'])
                    angle=other['obj'].heading_theta-heading;cs=abs(math.cos(angle));sn=abs(math.sin(angle))
                    if abs(delta@unit)<(length+cs*ol+sn*ow)/2+gap and abs(delta@normal)<(width+sn*ol+cs*ow)/2+.2:
                        blocked=True;break
                # Oriented footprint clearance permits simultaneous arrivals in
                # adjacent lanes; a 9 m circle accidentally made two lanes one.
                if blocked:
                    retry.append((r,path));blocked_insertions+=1;continue
                a=self.spawn(r,path);a['spawn_time']=t;active[r['id']]=a
            pending=retry+pending
            # Snapshot: all agents decide against the same pre-step state.
            for a in active.values():
                a['pos']=np.asarray(a['obj'].position).copy();a['s']=a['route'].project(a['pos']);a['v']=float(a['obj'].speed)
                a['point']=Point(a['pos']);a['heading']=a['obj'].heading_theta
                a['route_xy']=a['route'].position(a['s'])
                a['footprint']=None
            actors=list(active.values());following_geometry={}
            tree=cKDTree([a['pos'] for a in actors]) if actors else None
            # Include the full observed approach: a tight turn can take longer
            # than a fast through vehicle takes to cover 65 m.
            neighbors=tree.query_ball_point([a['pos'] for a in actors],180) if actors else []
            for i,a in enumerate(actors):a['neighbors']=[actors[j] for j in neighbors[i]]
            # Observe before decisions; projection never changes positions,
            # controls, random draws, or the native contact detector.
            crossing_conflicts.observe(actors,t,zones)
            bicycle_conflicts.observe(actors,t)
            # Walkers continuously check their immediate path. Previously they
            # checked only on entry and then walked into cars stopped across
            # the crosswalk. Use current oriented vehicle footprints, not a
            # contact-count filter. This decision is shared by all controllers.
            for a in actors:
                a['blocked_by']=set()
                if a['record']['mode']!='pedestrian':continue
                ahead=a['route'].position(min(a['route'].length,a['s']+a['desired']*b['reaction_s']+.25))
                walking_path=LineString([a['pos'],ahead]).buffer(.35)
                for other in a['neighbors']:
                    # Following walkers must also stop for a queued walker.
                    # Otherwise their native bodies physically push a stopped
                    # person into a vehicle even when that person's target
                    # speed is zero. Opposing paths retain their own clearance.
                    if other is a:continue
                    obj=other['obj']
                    length,width=dimensions(obj,other['record']['mode']);pos=other['pos']
                    # Conservative bounding-circle rejection. A footprint
                    # cannot intersect this walking corridor outside this
                    # radius; avoid constructing polygons for distant traffic.
                    reach=math.hypot(length/2,width/2)+np.linalg.norm(ahead-a['pos'])+.5
                    delta=pos-a['pos']
                    if abs(delta[0])>reach or abs(delta[1])>reach or delta@delta>reach*reach:continue
                    body=vehicle_footprint(other)
                    if walking_path.intersects(body.buffer(.15)):
                        a['blocked_by'].add(other['record']['id'])
            for name,a in active.items():
                obj=a['obj'];r=a['record'];route=a['route'];s=a['s'];v=a['v'];desired=a['desired']
                mode=r['mode'];motor=mode not in ('pedestrian','bicycle')
                br,emergency_br,anticipation=braking_limits(obj,dt,b) if motor else (b['comfortable_decel'],b['emergency_decel'],b['reaction_s'])
                desired=min(desired,route.curve_limit(s,b['lateral_accel'],br,anticipation)) if mode!='pedestrian' else desired
                stop_distance=float('inf');emergency=False
                if self.signal is not None and mode!='pedestrian' and not a.get('signal_entered',False):
                    # Stop before the near-side crosswalk with actual body length.
                    zone=zones.get((route.key,r['from_arm']))
                    stop_s=self.crossing_stop(route,r['from_arm'],obj,zone[0]) if zone else 96.
                    if s>stop_s+.5:
                        a['signal_entered']=True
                    elif not self.signal.vehicle_green(r,t):
                        stop_distance=min(stop_distance,stop_s-s)
                signal_walk=self.signal is None or self.signal.pedestrian_walk(r.get('crossing_leg'),t)

                if mode=='pedestrian' and not a['started']:
                    # Wait for approaching traffic unless it is already yielding/stopped.
                    for other in a['neighbors']:
                        if other['record']['mode']=='pedestrian':continue
                        zone=zones.get((other['route'].key,r['crossing_leg']))
                        if zone:
                            ds=zone[0]-other['s']
                            # Entry uses the same immediate-path obstruction
                            # check as walking. Reserving the entire crossing
                            # deadlocks opposing walkers when stopped vehicles
                            # obstruct a far-side lane that they have not yet
                            # reached. They may approach it and wait safely.
                            occupied=other['record']['id'] in a['blocked_by']
                            if occupied or (-3<ds<max(8,other['v']*b['pedestrian_gap_s']) and other['v']>.5):desired=0.;break
                    if not signal_walk:desired=0.
                    if desired>0 and not a['blocked_by']:a['started']=True
                elif mode!='pedestrian':
                    # Car/bike following on actual forward path, including merging traffic.
                    for other in a['neighbors']:
                        if other is a:continue
                        if other['record']['mode']=='pedestrian':
                            zone=zones.get((route.key,other['record']['crossing_leg']))
                            if zone is None:continue
                            ds=zone[0]-s
                            if ds<=-3:continue
                            stop_s=self.crossing_stop(route,other['record']['crossing_leg'],obj,zone[0])
                            # Once a vehicle already occupies the crossing it
                            # must be able to clear past walkers outside its
                            # path, including followers behind a waiting walker.
                            # Letting only the first walker grant clearance
                            # creates a circular wait when a second approaches.
                            if s>=stop_s:
                                forward=np.array([math.cos(obj.heading_theta),math.sin(obj.heading_theta)])
                                side=np.array([-math.sin(obj.heading_theta),math.cos(obj.heading_theta)])
                                offset=other['pos']-a['pos']
                                if abs(offset@side)>obj.WIDTH/2+.5 or offset@forward< -obj.LENGTH/2-.5:
                                    continue
                            # Clear an already occupied crossing before yielding
                            # to a walker who has not entered it yet.
                            if not other['started'] and s>=stop_s:continue
                            # A waiting or crossing pedestrian requests priority; only
                            # the still-uncleared conflict point constrains this vehicle.
                            ps=other['route'].project(zone[1]);remaining=ps-other['s']
                            if remaining>=-1.1 and remaining<other['desired']*max(b['pedestrian_gap_s'],anticipation+v/br)+1:
                                stop_distance=min(stop_distance,stop_s-s)
                        else:
                            # Exact rejection: a point less than 60 m ahead
                            # along this route and within 1.6 m laterally must
                            # lie within 61.6 m of route.position(s). Alignment
                            # is another necessary original condition. Neither
                            # changes decisions; avoid costly impossible tests.
                            alignment=math.cos((other['obj'].heading_theta if other['record']['mode'] in ('pedestrian','bicycle') else other['heading'])-(obj.heading_theta if mode=='bicycle' else a['heading']))
                            if alignment<=.5:continue
                            separation=other['pos']-a['route_xy']
                            if abs(separation[0])>61.6 or abs(separation[1])>61.6:continue
                            pair_key=(route.key,other['record']['id'])
                            if pair_key not in following_geometry:
                                following_geometry[pair_key]=(float(route.line.project(other['point'])),route.line.distance(other['point']))
                            projected,lateral=following_geometry[pair_key]
                            ahead=projected-s
                            # Following is directional. An opposing or crossing
                            # vehicle's scalar speed is not a lead-vehicle speed.
                            if 0<ahead<60 and lateral<1.6 and alignment>.5:
                                gap=ahead-(obj.LENGTH+other['obj'].LENGTH)/2
                                safe=b['min_gap_m']+v*b['time_headway_s']+max(0,v*(v-other['v'])/(2*math.sqrt(2.6*br)))
                                desired=min(desired,max(0,other['v']+(gap-safe)*.7))
                                closing=max(0,v-other['v'])
                                if gap<1+closing*.1+closing**2/(2*emergency_br):emergency=True
                    # Minor arm and left/U turns yield at conflict points to priority traffic.
                    minor=r['from_arm']=='N' or r['from_arm']==r['to_arm'] or (r['from_arm']=='W' and r['to_arm']=='N')
                    # The approach ends at the first route vertex (100 m).
                    # A truck can brake past the 96 m decision line. Ending
                    # yielding at 98 m released its brake while it was still
                    # on the approach, despite the same oncoming conflict.
                    if self.signal is None and minor and 55<s<route.s[1]:
                        for other in a['neighbors']:
                            if other is a or other['record']['mode']=='pedestrian':continue
                            if other['record']['from_arm'] not in ('E','W'):continue
                            if other['record']['from_arm']==r['from_arm']:continue
                            conflict=self.conflicts.get((route.key,other['route'].key))
                            if conflict is None:continue
                            ours=conflict[0]-s;theirs=conflict[1]-other['s']
                            # A fixed time gap underestimates slow turning time.
                            # Integrate this route's curvature-limited traversal,
                            # including acceleration from the yielding position.
                            elapsed=conflict[2]+max(0,96-s)/max(v,1.)
                            incoming=max(other['v'],other['desired']*.75,1.)
                            arrives=theirs/incoming
                            clears=theirs+other['obj'].LENGTH/2+2.
                            if ours>0 and clears>0 and arrives<elapsed+b['reaction_s']+1.:
                                # Decide before entering the junction, rather than
                                # stopping with the vehicle body in opposing traffic.
                                stop_distance=min(stop_distance,96-s)
                if stop_distance<float('inf'):
                    # Stopping envelope includes the controller's reaction delay.
                    rt=anticipation
                    desired=min(desired,max(0,math.sqrt((br*rt)**2+2*br*max(0,stop_distance))-br*rt))
                    if stop_distance<.3:desired=0.
                    if stop_distance<v*(2*dt)+v*v/(2*emergency_br)+.3:emergency=True
                if mode=='pedestrian' and a['blocked_by']:desired=0.
                a['delay_queue'].append((t,desired))
                while len(a['delay_queue'])>1 and a['delay_queue'][1][0]<=t-b['reaction_s']:a['delay_queue'].popleft()
                target=a['delay_queue'][0][1] if motor else desired
                lookahead=max(2.,v*.35);aim=route.position(min(route.length,s+lookahead));delta=aim-a['pos']
                if motor:
                    alpha=wrap(math.atan2(delta[1],delta[0])-obj.heading_theta)
                    wheelbase=obj.FRONT_WHEELBASE+obj.REAR_WHEELBASE
                    steer=np.clip(math.atan2(2*wheelbase*math.sin(alpha),lookahead)/math.radians(obj.max_steering),-1,1)
                    error=target-v;throttle=-1. if emergency else np.clip(error*.45,-1,1)
                    obj.before_step([float(steer),float(throttle)])
                else:
                    direction=delta/(np.linalg.norm(delta)+1e-12)
                    # Avoid resetting the body transform each step: on this Bullet
                    # build that prevents pedestrian translation. Integrate heading.
                    yaw=wrap(math.atan2(direction[1],direction[0])-obj.heading_theta)
                    obj.body.setAngularVelocity(Vec3(0,0,float(np.clip(yaw/dt,-2,2))))
                    BaseObject.set_velocity(obj,direction,desired)
            self.engine.step_physics_world();t+=dt
            if int(t/dt)%4000==0:
                print(f"{self.action['id']} {context_id}: t={t:.0f}s active={len(active)} queued={len(pending)}",flush=True)
            # Native Bullet contact manifolds, rather than straight-line TTC predictions.
            for x,y in contact_pairs(self.engine.physics_world.dynamic_world,active):
                if all(active[k]['record']['mode']=='pedestrian' for k in (x,y)):continue
                pair=tuple(sorted((x,y)))
                # Warm-up contacts do not enter the study reward, but their
                # physical aftermath must not be mislabeled as pre-contact
                # controller error. Retain both sets for an auditable history.
                contact_actors.update(pair)
                contact_log=contacts if any(active[k]['record']['study'] for k in pair) else warmup_contacts
                contact_log.setdefault(pair,dict(time=t,pair=list(pair),speed_mph=max(active[k]['v'] for k in pair)/MPH,
                        actors=[dict(id=k,mode=active[k]['record']['mode'],route=active[k]['route'].key,
                                     position=active[k]['obj'].position.tolist(),speed_mps=active[k]['v'],
                                     route_progress=active[k]['s']) for k in pair]))
            for name,a in list(active.items()):
                pos=np.asarray(a['obj'].position);jump=float(np.linalg.norm(pos-a['previous']));a['previous']=pos.copy()
                a['max_jump']=max(a['max_jump'],jump);max_jump=max(max_jump,jump)
                lateral=a['route'].line.distance(Point(pos));a['offroute']=max(a['offroute'],lateral);max_lateral=max(max_lateral,lateral)
                if name not in contact_actors:precontact_lateral=max(precontact_lateral,lateral)
                if a['record']['mode'] not in ('pedestrian','bicycle') and int(round(t/dt))%max(1,int(.25/dt))==0:
                    obj=a['obj'];u=np.array([math.cos(obj.heading_theta),math.sin(obj.heading_theta)]);vperp=np.array([-u[1],u[0]])
                    footprint=Polygon([pos+sx*u*obj.LENGTH/2+sy*vperp*obj.WIDTH/2 for sx,sy in [(1,1),(1,-1),(-1,-1),(-1,1)]])
                    overlap=footprint.intersection(self.geometry['curb_blocks']).area
                    if overlap>.02:
                        boundary_hits.add(name)
                        if name not in contact_actors:precontact_boundary_hits.add(name)
                        boundary_events.setdefault(name,dict(id=name,time=t,mode=a['record']['mode'],route=a['route'].key,
                            study=a['record']['study'],position=pos.tolist(),overlap_m2=float(overlap),
                            prior_contact=name in contact_actors))
                # Store occupancy of small, fixed crossing conflict areas for PET.
                relevant_zones=leg_zones[a['record']['crossing_leg']] if a['record']['mode']=='pedestrian' else route_zones[a['route'].key]
                for (routekey,leg),(ss,point) in relevant_zones:
                    relevant=(a['record']['mode']=='pedestrian' and a['record']['crossing_leg']==leg) or (a['route'].key==routekey)
                    if not relevant:continue
                    obj=a['obj'];heading=obj.heading_theta;unit=np.array([math.cos(heading),math.sin(heading)]);d=point-pos
                    along=abs(d@unit);across=abs(d@np.array([-unit[1],unit[0]]))
                    length,width=dimensions(obj,a['record']['mode'])
                    inside=along<length/2+.4 and across<width/2+.4
                    k=(routekey,leg,name)
                    if inside and k not in active_occupancy:active_occupancy[k]=t
                    if not inside and k in active_occupancy:
                        completed_occupancy.setdefault((routekey,leg),[]).append(dict(id=name,mode=a['record']['mode'],study=a['record']['study'],enter=active_occupancy.pop(k),exit=t,speed_mph=a['v']/MPH))
                if record and int(round(t/dt))%max(1,int(.25/dt))==0:
                    length,width=dimensions(a['obj'],a['record']['mode'])
                    frames.append(dict(t=round(t,3),id=name,mode=a['record']['mode'],x=float(pos[0]),y=float(pos[1]),heading=float(a['obj'].heading_theta),speed=float(a['obj'].speed),length=float(length),width=float(width)))
                s=a['route'].project(pos)
                if s>=a['route'].length-.8 and np.linalg.norm(pos-a['route'].position(a['route'].length))<2.5:
                    finished.append(dict(id=name,mode=a['record']['mode'],study=a['record']['study'],duration=t-a['record']['depart'],free_time=a['route'].length/max(a['desired'],.1),max_lateral_m=a['offroute']))
                    self.engine.clear_objects([name],force_destroy=True);del active[name]
            if not active and pending:t=min(max_time,max(t,pending[0][0]['depart']))
        short_gaps={};pet_events=[]
        for zone,events in completed_occupancy.items():
            pedestrians=[z for z in events if z['mode']=='pedestrian'];vehicles=[z for z in events if z['mode']!='pedestrian']
            for p in pedestrians:
                for v in vehicles:
                    if not(p['study'] or v['study']):continue
                    pet=max(p['enter'],v['enter'])-min(p['exit'],v['exit'])
                    if pet<0:pet=0.
                    if pet>5:continue
                    pair=tuple(sorted((p['id'],v['id'])))
                    ev=dict(pair=list(pair),pet_s=float(pet),zone=list(zone),speed_mph=v['speed_mph'])
                    pet_events.append(ev)
                    if pet<=b['near_miss_pet_s'] and pair not in contacts:short_gaps[pair]=ev
        near=crossing_conflicts.classify(pet_events,contacts)
        near.update(bicycle_conflicts.classify(contacts))
        requested=sum(r['study'] for r in demand);arrived=sum(r['study'] for r in finished)
        result=dict(context_id=context_id,action=self.action['id'],seed=seed,realization=realization,
            demand_sha256=digest,requested=requested,arrived=arrived,pending=len(pending)+len(active),complete=arrived==requested and not pending and not active,
            collision_pairs=len(contacts),near_pairs=len(near),score=-1000*len(contacts)-5*len(near),
            short_gap_pairs=len(short_gaps),safety_metric_version=METRIC_VERSION,bicycle_near_misses_measured=True,bicycle_projected_conflicts=bicycle_conflicts.events,site=SITE,
            max_step_displacement_m=max_jump,max_route_deviation_m=max_lateral,
            precontact_max_route_deviation_m=precontact_lateral,precontact_boundary_violations=len(precontact_boundary_hits),
            mean_delay_s=float(np.mean([max(0,z['duration']-z['free_time']) for z in finished if z['study']])) if arrived else None,
            simulated_seconds=t,wall_seconds=time.monotonic()-wall,physics_dt=dt,
            boundary_violations=len(boundary_hits),warmup_contact_pairs=len(warmup_contacts),
            boundary_events=list(boundary_events.values()),warmup_contacts=list(warmup_contacts.values()),
            remaining_actors=[dict(id=k,mode=a['record']['mode'],route=a['route'].key,position=a['obj'].position.tolist(),speed=float(a['obj'].speed)) for k,a in active.items()],
            reward_definition="-1000 per distinct native contact pair; -5 per non-contact pedestrian pair with route-projected body overlap within 1.5s and PET <=5s at the same crossing zone; zero otherwise",
            short_gap_definition="Legacy diagnostic only: non-contact pedestrian PET <=1.5s pair. Not by itself a projected collision course.",
            short_gaps=list(short_gaps.values()),projected_conflicts=list(crossing_conflicts.events.values()),
            contacts=list(contacts.values()),near_misses=list(near.values()),pet_events=pet_events,frames=frames,finished=finished)
        return result
