import json
from .engine import World
from .config import OUT, SEED

def traveler(name,mode='passenger',arm='W',target='E',leg=None,depart=0,desired=13.4):
    return dict(id=name,mode=mode,study=True,depart=depart,from_arm=arm,to_arm=target,
                crossing_leg=leg,forward=True,lane_draw=0.,desired_mps=desired,source_observation='diagnostic_only')

def main():
    OUT.mkdir(exist_ok=True,parents=True);w=World();rows=[]
    try:
        for action in ['C01','C07']:
            for arm,target in [('W','E'),('E','W'),('E','N'),('W','N'),('N','W'),('N','E')]:
                w.reset(action)
                r=w.run('diagnostic',custom=[traveler('car',arm=arm,target=target)],record=True,max_time=90)
                frames=r.pop('frames');(OUT/f'trace_{action}_{arm}_{target}.json').write_text(json.dumps(frames))
                r.pop('finished');rows.append(r)
                print(action,arm,target,'complete',r['complete'],'deviation',round(r['max_route_deviation_m'],3),flush=True)
        w.reset('C01')
        r=w.run('diagnostic',custom=[traveler('ped','pedestrian',leg='E',desired=1.4)],record=True,max_time=60)
        (OUT/'pedestrian_trace.json').write_text(json.dumps(r.pop('frames')));rows.append(r)
    finally:w.close()
    (OUT/'motion_checks.json').write_text(json.dumps(rows,indent=2))

if __name__=='__main__':main()
