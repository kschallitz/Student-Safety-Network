"""East Avenue mitigation experiments using MetaDrive; no SUMO dependency."""
from pathlib import Path
import sys,os
os.environ.setdefault('MPLCONFIGDIR','/tmp/school-metadrive-mpl')
# Prefer the pinned project-local checkout when present. Colab may instead use
# the ordinary installed package pinned to the same commit.
_vendor=Path(__file__).resolve().parents[1]/"vendor/metadrive"
if (_vendor/"metadrive/__init__.py").exists():sys.path.insert(0,str(_vendor))
__version__ = "0.20.0"
