"""Release no ranking from an incomplete or physically invalid paired matrix."""
import json
import pandas as pd
from .config import SITE,OUT,ACTION_IDS
from .run import signature
from .rewards import SCORING_VERSION,source_hash
from .conflicts import METRIC_VERSION

def assess(suite='pilot',save=True):
    protocol=json.loads((OUT/f'{suite}_protocol.json').read_text())
    frame=pd.read_csv(OUT/f'{suite}_runs.csv')
    motion=json.loads((OUT/'motion_validation.json').read_text())
    reasons=[]
    valid=(frame.complete & frame.arrived.eq(frame.requested) & frame.pending.eq(0) &
           frame.precontact_boundary_violations.eq(0) & frame.precontact_max_route_deviation_m.le(1.5))
    frame=frame.assign(physics_pass=valid)
    if not motion['passed'] or motion.get('snapshot')!=signature():reasons.append('Site movement/signal checks have not passed for this source snapshot.')
    if len(frame)!=protocol['runs']:reasons.append('The paired matrix is incomplete.')
    if not valid.all():reasons.append('One or more episodes failed cohort or movement checks; all results are retained.')
    if frame.duplicated(['context_id','action','realization']).any():reasons.append('Duplicate episodes.')
    expected={(c['context_id'],action,r) for c in protocol['contexts'] for action in protocol['actions']
              for r in range(protocol['start_realization'],protocol['start_realization']+protocol['realizations'])}
    observed=set(frame[['context_id','action','realization']].itertuples(index=False,name=None))
    if observed!=expected:reasons.append('Episode identities do not match the declared period/design/realization matrix.')
    splits={c['context_id']:c['split'] for c in protocol['contexts']}
    if not frame.split.eq(frame.context_id.map(splits)).all():reasons.append('Training/evaluation split mismatch.')
    if not frame.seed.eq(protocol['seed']).all():reasons.append('Master seed mismatch.')
    if not(frame.snapshot.eq(signature()).all() and protocol['snapshot']==signature()):reasons.append('Input/physics source fingerprint changed.')
    if not(frame.scoring_version.eq(SCORING_VERSION).all() and frame.scoring_source_sha256.eq(source_hash()).all()):reasons.append('Reward version mismatch.')
    if not frame.safety_metric_version.eq(METRIC_VERSION).all():reasons.append('Detector version mismatch.')
    if not frame.score.eq(-1000*frame.collision_pairs-5*frame.near_pairs).all():reasons.append('Reward arithmetic mismatch.')
    if not(frame.near_pairs.eq(frame.motor_pedestrian_near_pairs+frame.motor_bicycle_near_pairs).all() and frame.bicycle_near_misses_measured.all()):reasons.append('Bicycle coverage/reward mismatch.')
    pairs=frame.groupby(['context_id','realization']).agg(actions=('action','nunique'),ledgers=('demand_sha256','nunique'),requested=('requested','nunique'))
    if not (pairs.actions.eq(len(ACTION_IDS)) & pairs.ledgers.eq(1) & pairs.requested.eq(1)).all():reasons.append('Candidates do not use complete matched traffic cohorts.')
    result=dict(site=SITE,snapshot=protocol['snapshot'],completed_runs=len(frame),planned_runs=protocol['runs'],
                recommendation_released=not reasons,release_blockers=reasons,bicycle_near_misses_measured=True,
                scoring_version=SCORING_VERSION,scoring_source_sha256=source_hash(),
                physics_pass_runs=int(valid.sum()),software_checks_passed=motion['passed'])
    if save:(OUT/f'{suite}_quality.json').write_text(json.dumps(result,indent=2))
    return result,frame
