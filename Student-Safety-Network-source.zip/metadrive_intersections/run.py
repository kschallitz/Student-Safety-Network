"""Run full matched treatment blocks; retain every failed/incomplete episode."""
import argparse,json,hashlib,time,shutil,re,os,fcntl
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import pandas as pd
from .config import SITE,DATA,OUT,ACTION_IDS,SEED
from .rewards import score_episode,scalar_row,SCORING_VERSION,source_hash
from .conflicts import METRIC_VERSION

MAX_COHORT_SECONDS=3600
_WORLD=None
def signature():
    h=hashlib.sha256()
    names=[('hillcrest_engine.py' if SITE=='Hillcrest' else 'engine.py'),'config.py','geometry.py','demand.py',('hillcrest_signals.py' if SITE=='Hillcrest' else 'signals.py'),'conflicts.py','bicycle_conflicts.py']
    if SITE=='Hillcrest':names.append('hillcrest_walks.py')
    for name in names:
        h.update(name.encode());h.update(Path(__file__).with_name(name).read_bytes())
    for p in sorted(DATA.glob('*')):h.update(p.name.encode());h.update(p.read_bytes())
    return h.hexdigest()[:16]

def contexts():
    c=pd.read_csv(DATA/'contexts.csv')
    splits={
      'train':['20230302T073000','20230302T074500','20230302T081500','20230302T143000'],
      'validation':['20230302T080000','20230302T084500','20230302T144500','20230302T154500'],
      'test':['20230518T073000','20230518T081500','20230518T141500','20230518T143000']}
    c=c[c.context_id.isin(sum(splits.values(),[]))].copy()
    assert len(c)==12
    c['split']=c.context_id.map({k:s for s,ks in splits.items() for k in ks})
    return c

def task(args):
    global _WORLD
    if SITE=='Hillcrest':
        from .hillcrest_engine import World
    else:
        from .engine import World
    context,action,realization,sig=args
    folder=OUT/'runs'/sig;folder.mkdir(parents=True,exist_ok=True)
    file=folder/f'{context}_{action}_{realization}.json'
    with file.with_suffix('.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        if file.exists():return json.loads(file.read_text())
        if _WORLD is None:_WORLD=World()
        _WORLD.reset(action)
        r=_WORLD.run(context,realization=realization,max_time=MAX_COHORT_SECONDS)
        r.pop('frames');r.update(snapshot=sig,time_limit_seconds=MAX_COHORT_SECONDS)
        temporary=file.with_suffix('.partial')
        temporary.write_text(json.dumps(r,indent=2));os.replace(temporary,file);return r

def main():
    p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=2);p.add_argument('--realizations',type=int,default=1)
    p.add_argument('--start-realization',type=int,default=0);p.add_argument('--suite',default='pilot')
    a=p.parse_args();assert 1<=a.realizations<=30 and a.start_realization>=0 and re.fullmatch(r'[A-Za-z0-9_-]+',a.suite)
    c=contexts();sig=signature();OUT.mkdir(parents=True,exist_ok=True)
    source=OUT/'source_snapshots'/sig
    if not source.exists():
        shutil.copytree(Path(__file__).parent,source/'code',ignore=shutil.ignore_patterns('__pycache__'))
        shutil.copytree(DATA,source/'data')
    tasks=[(s,act,r,sig) for r in range(a.start_realization,a.start_realization+a.realizations) for s in c.context_id for act in ACTION_IDS]
    protocol=dict(site=SITE,snapshot=sig,seed=SEED,contexts=c[['context_id','split']].to_dict('records'),
                  actions=ACTION_IDS,runs=len(tasks),realizations=a.realizations,start_realization=a.start_realization,
                  safety_metric_version=METRIC_VERSION,scoring_version=SCORING_VERSION,scoring_source_sha256=source_hash(),
                  physics_dt=.05,maximum_cohort_seconds=MAX_COHORT_SECONDS,started_at=time.time())
    if SITE=='Hillcrest':
        from .hillcrest_signals import SignalPlan
        protocol['signal']=SignalPlan().manifest()
    (OUT/f'{a.suite}_protocol.json').write_text(json.dumps(protocol,indent=2))
    c.to_csv(OUT/f'{a.suite}_contexts.csv',index=False)
    rows=[]
    with ProcessPoolExecutor(max_workers=a.workers) as pool:
        for future in as_completed([pool.submit(task,t) for t in tasks]):
            r=score_episode(future.result());rows.append(scalar_row(r))
            temporary=OUT/f'{a.suite}_runs.partial'
            pd.DataFrame(rows).merge(c[['context_id','split']],on='context_id',validate='many_to_one').to_csv(temporary,index=False)
            os.replace(temporary,OUT/f'{a.suite}_runs.csv')
            print(f"{SITE} {len(rows)}/{len(tasks)} {r['context_id']} {r['action']} complete={r['complete']} contacts={r['collision_pairs']} pedestrian_near={r['motor_pedestrian_near_pairs']} bicycle_near={r['motor_bicycle_near_pairs']} curbs={r['precontact_boundary_violations']}",flush=True)

if __name__=='__main__':main()
