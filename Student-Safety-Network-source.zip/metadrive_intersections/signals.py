"""Fixed Hillcrest signal plan with explicit pedestrian clearance.

Phase order is the available historical HCM structure. Durations are scenario
assumptions, not recovered 2023 controller records. The exact same plan and
offset apply to every candidate. A pedestrian may start only while enough
green/clearance remains; existing walkers always finish. No right turn on red.
"""
from .geometry import build
import numpy as np

LEFT={'E':'S','W':'N','N':'E','S':'W'}
class SignalPlan:
    def __init__(self):
        base=build('C01')
        # Fixed baseline geometry, not a treatment-dependent signal advantage.
        self.clearance={leg:float(np.linalg.norm(q[1]-q[0])/.8+2) for leg,q in base['crossings'].items()}
        self.phases=[]
        for name,green,legs in [('EW_left',8,()),('EW_through',36,('N','S')),
                                ('northbound',20,('E','W')),('southbound',16,('E','W'))]:
            walk_clear=max([self.clearance[l] for l in legs],default=0)
            duration=max(green,7+walk_clear)
            self.phases.extend([(name,duration,legs),('yellow_'+name,3,()),('all_red',2,())])
        self.cycle=sum(p[1] for p in self.phases)

    def phase(self,t):
        elapsed=t%self.cycle
        for name,duration,legs in self.phases:
            if elapsed<duration:return name,duration-elapsed,legs
            elapsed-=duration
        raise AssertionError('Signal phase not found')

    def vehicle_green(self,r,t):
        name,_,_=self.phase(t);a=r['from_arm'];target=r['to_arm']
        left=target==LEFT[a] or target==a
        return ((name=='EW_left' and a in ('E','W') and left) or
                (name=='EW_through' and a in ('E','W') and not left) or
                (name=='northbound' and a=='S') or (name=='southbound' and a=='N'))

    def pedestrian_walk(self,leg,t):
        _,remaining,legs=self.phase(t)
        return leg in legs and remaining>=self.clearance[leg]

    def manifest(self):
        return dict(cycle_s=self.cycle,phases=self.phases,clearance_s=self.clearance,
                    status='Historical phase structure; assumed fixed timing with baseline crossing clearance; no right-on-red')
