"""Owner's local worker for the private website's authenticated job queue.

Run with .venv-metadrive/bin/python -m metadrive_intersections.worker.
Credentials live in .private/simulation_worker.json (0600), never in web assets.
Only whitelisted site names and numeric workload settings enter subprocesses.
"""
import argparse,csv,json,os,re,subprocess,sys,time,urllib.request,urllib.error,fcntl,hashlib
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SITES={'J01145':'Estates','J02019':'Hillcrest'}

def completed(path):
    try:
        with path.open() as f:return sum(1 for _ in csv.DictReader(f))
    except (OSError,csv.Error):return 0

class Worker:
    def __init__(self,config):
        self.config=config
        self.origin=config['origin'].rstrip('/')
        if not self.origin.startswith(('https://','http://127.0.0.1:')):raise ValueError('Worker requires HTTPS outside localhost')

    def request(self,path,body):
        req=urllib.request.Request(self.origin+'/api/simulation'+path,data=json.dumps(body).encode(),headers={
            'Content-Type':'application/json','x-simulation-worker-key':self.config['workerKey'],
            'OAI-Sites-Authorization':'Bearer '+self.config['siteToken']})
        try:
            with urllib.request.urlopen(req,timeout=25) as response:return json.load(response)
        except urllib.error.HTTPError as e:
            # Do not log request headers or credentials.
            raise RuntimeError(f'Site API returned HTTP {e.code}') from None

    def run(self,job):
        name=SITES.get(job['junctionId'])
        if name!=job['site'] or not re.fullmatch(r'[0-9a-f-]{36}',job['id']):raise ValueError('Invalid site/job identity')
        count=int(job['realizations']);start=int(job['realizationStart'])
        if not 1<=count<=30 or start<0:raise ValueError('Invalid realization settings')
        suite='job_'+job['id'];out=ROOT/'outputs/metadrive_intersections'/name
        out.mkdir(parents=True,exist_ok=True)
        env={**os.environ,'PYTHONPATH':str(ROOT/'vendor/metadrive'),'SCHOOL_SIM_SITE':name}
        common={'id':job['id'],'lease':job['lease']}
        log_path=out/f'{suite}.log';runs=out/f'{suite}_runs.csv';n=0
        workers=min(4,max(1,int(self.config.get('workers',2))))
        steps=[('Checking lane and signal movements',['validate']),
               ('Simulating matched traffic',['run','--suite',suite,'--workers',str(workers),'--realizations',str(count),'--start-realization',str(start)]),
               ('Training and evaluating three agents',['learning','--suite',suite]),
               ('Checking and exporting results',['export','--suite',suite])]
        awake=subprocess.Popen(['caffeinate','-i','-w',str(os.getpid())]) if sys.platform=='darwin' else None
        try:
            with log_path.open('a',buffering=1) as log:
                for label,args in steps:
                    log.write('\n'+label+'\n')
                    command=[sys.executable,'-m','metadrive_intersections.'+args[0],*args[1:]]
                    process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
                    try:
                        while process.poll() is None:
                            n=max(n,completed(runs))
                            self.request('/worker/progress',{**common,'completed':n,'status':'running','message':label})
                            time.sleep(15)
                    except BaseException:
                        process.terminate();process.wait();raise
                    if process.returncode:raise RuntimeError(f'{label} failed. See {name}/{log_path.name}.')
                result=json.loads((out/f'{suite}_site_evidence.json').read_text())
                n=completed(runs)
                self.request('/worker/progress',{**common,'completed':n,'status':'completed','result':result,
                    'message':'Checked comparison saved. Bicycle and pedestrian near misses included.'})
                print(f'{name}: completed {n} episodes; saved {suite}',flush=True)
        except Exception as e:
            print(f'{name}: {type(e).__name__}: {e}',flush=True)
            self.request('/worker/progress',{**common,'completed':n,'status':'failed','message':str(e)[:700]})
        finally:
            if awake is not None:awake.terminate();awake.wait()

def main():
    p=argparse.ArgumentParser();p.add_argument('--config',type=Path,default=ROOT/'.private/simulation_worker.json');p.add_argument('--once',action='store_true')
    a=p.parse_args();worker=Worker(json.loads(a.config.read_text()))
    # One worker per destination. Separate local previews cannot consume live jobs.
    lock_path=a.config.parent/('worker-'+hashlib.sha256(worker.origin.encode()).hexdigest()[:12]+'.lock')
    lock=lock_path.open('w')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit('A worker is already running for this site.')
    lock.write(str(os.getpid()));lock.flush()
    while True:
        try:
            job=worker.request('/worker/claim',{})['job']
            if job:worker.run(job)
            if a.once:return
        except Exception as e:
            print(f'Worker connection: {e}',flush=True)
            if a.once:raise SystemExit(1)
        time.sleep(20)

if __name__=='__main__':main()
