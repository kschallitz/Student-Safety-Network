"""Motor/bicycle route-projected rectangle overlap, confirmed by actual passage.

Observe at the physics step without changing controls. A fixed conflict point
is anchored in the first projected footprint intersection for an encounter.
Both actors must actually visit it within 5 s PET. Following, merging and
crossing routes use the same test. Native contact pairs are excluded at the end.
Thresholds adapt the FHWA SSAM convention; they are not bicycle field labels.
"""
import math
import numpy as np
from shapely.geometry import Polygon
from .conflicts import projected_pose, TTC_LIMIT_S, PET_LIMIT_S, PROJECTION_STEP_S

def rectangle_ttc(a, b, size_a, size_b, times):
    """Separating-axis overlap of two rotating rectangles, vectorized in time."""
    pa, aa=a; pb, ab=b
    ua=np.column_stack((np.cos(aa),np.sin(aa))); va=np.column_stack((-np.sin(aa),np.cos(aa)))
    ub=np.column_stack((np.cos(ab),np.sin(ab))); vb=np.column_stack((-np.sin(ab),np.cos(ab)))
    delta=pb-pa;hit=np.ones(len(times),dtype=bool)
    for axis in (ua,va,ub,vb):
        distance=np.abs(np.sum(delta*axis,axis=1))
        reach=(size_a[0]/2*np.abs(np.sum(ua*axis,axis=1))+size_a[1]/2*np.abs(np.sum(va*axis,axis=1))+
               size_b[0]/2*np.abs(np.sum(ub*axis,axis=1))+size_b[1]/2*np.abs(np.sum(vb*axis,axis=1)))
        hit &= distance <= reach
    indices=np.flatnonzero(hit)
    return int(indices[0]) if len(indices) else None

def polygon(position, angle, length, width):
    u=np.array([math.cos(angle),math.sin(angle)]);v=np.array([-u[1],u[0]])
    return Polygon([position+x*u*length/2+y*v*width/2 for x,y in [(1,1),(1,-1),(-1,-1),(-1,1)]])

def at_point(actor, point):
    obj=actor['obj'];angle=obj.heading_theta
    delta=np.asarray(point)-actor['pos'];cs=math.cos(angle);sn=math.sin(angle)
    along=abs(delta[0]*cs+delta[1]*sn);across=abs(-delta[0]*sn+delta[1]*cs)
    return max(along-obj.LENGTH/2,0)**2+max(across-obj.WIDTH/2,0)**2 <= .1**2

class BicycleConflicts:
    def __init__(self):
        self.times=np.linspace(0,TTC_LIMIT_S,round(TTC_LIMIT_S/PROJECTION_STEP_S)+1)
        self.active={};self.events=[];self.near={}

    def observe(self, actors, t):
        by_id={a['record']['id']:a for a in actors};projections={}
        def pose(a):
            name=a['record']['id']
            if name not in projections:
                projections[name]=projected_pose(a['route'],a['pos'],a['obj'].heading_theta,a['v'],self.times)
            return projections[name]
        for bike in actors:
            b=bike['record']
            if b['mode']!='bicycle':continue
            for motor in bike['neighbors']:
                m=motor['record']
                if m['mode'] not in ('passenger','heavy') or not (b['study'] or m['study']):continue
                pair=tuple(sorted((b['id'],m['id'])))
                if pair in self.active or pair in self.near:continue
                reach=(bike['v']+motor['v'])*TTC_LIMIT_S+(math.hypot(motor['obj'].LENGTH,motor['obj'].WIDTH)+math.hypot(bike['obj'].LENGTH,bike['obj'].WIDTH))/2
                if np.linalg.norm(bike['pos']-motor['pos'])>reach:continue
                mp,bp=pose(motor),pose(bike)
                mi=(motor['obj'].LENGTH,motor['obj'].WIDTH);bi=(bike['obj'].LENGTH,bike['obj'].WIDTH)
                k=rectangle_ttc(mp,bp,mi,bi,self.times)
                if k is None or k==0:continue
                overlap=polygon(mp[0][k],mp[1][k],*mi).intersection(polygon(bp[0][k],bp[1][k],*bi))
                if overlap.is_empty:continue
                e=dict(pair=list(pair),time=float(t),ttc_s=float(self.times[k]),point=list(overlap.centroid.coords[0]),
                       motor_speed_mps=float(motor['v']),bicycle_speed_mps=float(bike['v']),
                       kind='motor_bicycle',occupancy={})
                self.active[pair]=e;self.events.append(e)
        for pair,e in list(self.active.items()):
            for name in pair:
                a=by_id.get(name);inside=a is not None and at_point(a,e['point'])
                visit=e['occupancy'].get(name)
                if inside:
                    if visit is None:e['occupancy'][name]={'enter':float(t),'exit':None}
                elif visit is not None and visit['exit'] is None:visit['exit']=float(t)
            visits=list(e['occupancy'].values())
            if len(visits)==2 and all(v['exit'] is not None for v in visits):
                pet=max(0.,max(v['enter'] for v in visits)-min(v['exit'] for v in visits))
                e['pet_s']=pet
                if pet<=PET_LIMIT_S:self.near[pair]=e
                del self.active[pair]
            elif t-e['time']>TTC_LIMIT_S+PET_LIMIT_S+5:
                # Expired/unvisited projections stay in diagnostics, never scored.
                del self.active[pair]

    def classify(self, contacts):
        return {pair:e for pair,e in self.near.items() if pair not in contacts}
