from pathlib import Path
import json,zipfile,hashlib,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/metadrive_school'
protocol=json.loads((OUT/'pilot_protocol.json').read_text())
files=[ROOT/'East_Avenue_MetaDrive.ipynb',ROOT/'MetaDrive_README.md',ROOT/'requirements-metadrive.txt']
files+=list((ROOT/'metadrive_school').glob('*.py'))
files+=list((ROOT/'data/metadrive_school').glob('*.csv'))+list((ROOT/'data/metadrive_school').glob('*.json'))
files+=[ROOT/'tests/test_metadrive_learning.py']
files+=[ROOT/'scripts/audit_historical_delay_gate.py']
files+=[ROOT/'scripts/audit_metadrive_curb_repair.py',ROOT/'scripts/audit_metadrive_crossing_repair.py']
files+=[ROOT/'scripts/diagnose_metadrive_crossing_grid.py']
files+=list((OUT/'crossing_repair'/'liveness'/protocol['snapshot']).glob('grid.json'))
files+=[p for p in (OUT/'crossing_repair').glob('*.json') if '_prefix_' not in p.name and p.name!='RESUME.json']
files+=list((OUT/'crossing_repair').glob('*.csv'))
files+=list((OUT/'crossing_repair'/'before').glob('*.json'))+list((OUT/'crossing_repair'/'before').glob('*.csv'))
files+=list(OUT.glob('historical_delay_gate_audit.*'))
files+=list((OUT/'curb_repair').glob('repair_summary.json'))
files+=list((OUT/'curb_repair').glob('matched_before_after.csv'))
files+=list((OUT/'curb_repair').glob('truck_gap_window_*.json'))
files+=list((OUT/'curb_repair'/'before').glob('pilot_runs.csv'))
files+=list((OUT/'curb_repair'/'before').glob('pilot_policy_freeze.json'))
for name in ['validation.json','runtime_manifest.json','pilot_runs.csv','pilot_contexts.csv','pilot_protocol.json','pilot_quality.json','pilot_policy_freeze.json','pilot_evaluation.json','pilot_learning_progress.csv','pilot_training_status.json','candidate_totals.csv','report.json','pilot_comparison.png','MetaDrive_Report.html','Development_Evidence.md']:
    p=OUT/name
    if p.exists():files.append(p)
files+=list((OUT/'runs'/protocol['snapshot']).glob('*.json'))
files+=list((OUT/'runs'/protocol['snapshot']/'cutoff_diagnostics').glob('*.json'))
files+=list((OUT/'runs'/protocol['snapshot']/'source').glob('*.py'))
files+=list((OUT/'pilot_learner_source').glob('*.py'))
bundle=OUT/'East_Avenue_MetaDrive_Colab.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:z.write(p,p.relative_to(ROOT))
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None
    assert not any('.venv' in name or '/.git/' in name or 'credential' in name for name in z.namelist())
    assert 'metadrive_school/engine.py' in z.namelist()
    assert 'data/metadrive_school/observations.csv' in z.namelist()
sha=hashlib.sha256(bundle.read_bytes()).hexdigest();(OUT/'bundle_sha256.txt').write_text(sha+'  '+bundle.name+'\n')
for src,name in [(ROOT/'East_Avenue_MetaDrive.ipynb','East_Avenue_MetaDrive.ipynb'),(ROOT/'data/metadrive_school/observations.csv','metadrive_observations.csv'),(OUT/'pilot_runs.csv','metadrive_pilot_runs.csv')]:
    shutil.copyfile(src,OUT/name)
print(json.dumps(dict(bundle=str(bundle),files=len(files),bytes=bundle.stat().st_size,sha256=sha)))
