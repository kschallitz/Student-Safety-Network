from pathlib import Path
import json,zipfile,hashlib,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/metadrive_school'
protocol=json.loads((OUT/'pilot_protocol.json').read_text())
files=[ROOT/'East_Avenue_MetaDrive.ipynb',ROOT/'MetaDrive_README.md',ROOT/'requirements-metadrive.txt']
files+=list((ROOT/'metadrive_school').glob('*.py'))
files+=list((ROOT/'data/metadrive_school').glob('*.csv'))+list((ROOT/'data/metadrive_school').glob('*.json'))
files+=[ROOT/'tests/test_metadrive_learning.py']
files+=[ROOT/'scripts/audit_historical_delay_gate.py']
files+=list(OUT.glob('historical_delay_gate_audit.*'))
for name in ['validation.json','runtime_manifest.json','pilot_runs.csv','pilot_contexts.csv','pilot_protocol.json','pilot_quality.json','pilot_policy_freeze.json','pilot_evaluation.json','pilot_learning_progress.csv','pilot_training_status.json','candidate_totals.csv','report.json','pilot_comparison.png','MetaDrive_Report.html','Development_Evidence.md']:
    p=OUT/name
    if p.exists():files.append(p)
files+=list((OUT/'runs'/protocol['snapshot']).glob('*.json'))
files+=list((OUT/'runs'/protocol['snapshot']/'cutoff_diagnostics').glob('*.json'))
files+=list((OUT/'runs'/protocol['snapshot']/'source').glob('*.py'))
files+=list((OUT/'pilot_learner_source').glob('*.py'))
bundle=OUT/'East_Avenue_MetaDrive_Colab.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:z.write(p,p.relative_to(ROOT))
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None
    assert not any('.venv' in name or '/.git/' in name or 'credential' in name for name in z.namelist())
    assert 'metadrive_school/engine.py' in z.namelist()
    assert 'data/metadrive_school/observations.csv' in z.namelist()
sha=hashlib.sha256(bundle.read_bytes()).hexdigest();(OUT/'bundle_sha256.txt').write_text(sha+'  '+bundle.name+'\n')
for src,name in [(ROOT/'East_Avenue_MetaDrive.ipynb','East_Avenue_MetaDrive.ipynb'),(ROOT/'data/metadrive_school/observations.csv','metadrive_observations.csv'),(OUT/'pilot_runs.csv','metadrive_pilot_runs.csv')]:
    shutil.copyfile(src,OUT/name)
print(json.dumps(dict(bundle=str(bundle),files=len(files),bytes=bundle.stat().st_size,sha256=sha)))
