"""Read saved results to test whether the old 30-second gate removed options.

This audit does not run SUMO or change its historical results. Re-execution
requires the legacy workspace CSVs; only the derived audit is in the Colab bundle.
"""
from pathlib import Path
import hashlib
import json
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/metadrive_school'
rows=[]
sources={}
policy_checks=[]
for release,baseline_id in [('mitigation_rl','A0'),('mitigation_batch','A0'),('mitigation_priority','C01')]:
    for split in ['train','validation','test']:
        path=ROOT/'outputs'/release/f'{split}_runs.csv'
        sources[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
        d=pd.read_csv(path)
        if 'profile' not in d:d['profile']='nominal'
        batches=d.groupby(['profile','context_id','action'],as_index=False).agg(delay=('mean_motor_delay','mean'),complete=('complete','all'),runs=('seed','size'))
        baseline=batches[batches.action.eq(baseline_id)][['profile','context_id','delay']].rename(columns={'delay':'base_delay'})
        batches=batches.merge(baseline,on=['profile','context_id'],validate='many_to_one')
        batches['extra_delay']=batches.delay-batches.base_delay
        for (profile,action),g in batches.groupby(['profile','action']):
            rows.append(dict(release=release,split=split,profile=profile,action=action,windows=len(g),episodes=int(g.runs.sum()),mean_added_delay_s=float(g.extra_delay.mean()),max_window_added_delay_s=float(g.extra_delay.max()),all_complete=bool(g.complete.all()),blocked_by_mean_delay=bool(g.extra_delay.mean()>30)))
    for filename in ['validation_agents.csv','test_policies.csv','test_policy_results.csv']:
        path=ROOT/'outputs'/release/filename
        if not path.exists():continue
        sources[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
        frame=pd.read_csv(path)
        column='validation_eligible' if 'validation_eligible' in frame else 'eligible'
        policy_checks.append(dict(file=str(path.relative_to(ROOT)),policies=len(frame),all_eligible=bool(frame[column].all())))
frame=pd.DataFrame(rows)
frame.to_csv(OUT/'historical_delay_gate_audit.csv',index=False)
result=dict(question='Did the 30-second added-mean-motor-delay gate exclude slower candidates?',
    sources=sources,threshold_seconds=30,candidates_blocked_by_delay=int(frame.blocked_by_mean_delay.sum()),
    largest_candidate_mean_added_delay_s=float(frame.mean_added_delay_s.max()),published_policy_checks=policy_checks,
    conclusion='The gate could bias a safety-only objective, but it did not bind in these saved nominal experiments. It cannot explain their observed contact-count reversal.',
    current_metadrive_rule='No travel-delay eligibility cutoff or delay term in the safety reward. Serve the whole cohort; report excess travel separately.',
    limit='Historical motor delay and the new all-traveler excess-travel measure are different metrics; their values are not a simulator calibration comparison.')
(OUT/'historical_delay_gate_audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='sources'},indent=2))
