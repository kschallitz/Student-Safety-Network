import os
os.environ.setdefault("MPLCONFIGDIR", "/tmp/school-metadrive-mpl")
from metadrive.envs.scenario_env import ScenarioEnv
from metadrive.engine.engine_utils import initialize_engine, close_engine
from metadrive.component.map.scenario_map import ScenarioMap
from metadrive.component.vehicle.vehicle_type import DefaultVehicle
from metadrive.component.traffic_participants.pedestrian import Pedestrian
from metadrive_school.geometry import build
from types import SimpleNamespace
import numpy as np

c=ScenarioEnv.default_config();c.update(dict(use_render=False,image_observation=False,show_terrain=False,show_skybox=False,show_interface=False,physics_world_step_size=.02,log_level=40))
c["vehicle_config"].update(dict(navigation_module=None,show_navi_mark=False,show_dest_mark=False,lidar=dict(num_lasers=0,distance=0),side_detector=dict(num_lasers=0,distance=0),lane_line_detector=dict(num_lasers=0,distance=0)))
engine=initialize_engine(c)
try:
    g=build("C01");m=ScenarioMap(0,g['features']);m.attach_to_world();engine.map_manager=SimpleNamespace(current_map=m)
    engine.terrain.reset([0,0])
    v=engine.spawn_object(DefaultVehicle,vehicle_config=dict(spawn_position_heading=([-50,-6],0),navigation_module=None),name='test_car',random_seed=1)
    p=engine.spawn_object(Pedestrian,position=[0,20],heading_theta=0,name='test_ped',random_seed=1)
    for i in range(500):
        v.before_step([0,.3]);p.set_velocity([1,0],1.4);engine.step_physics_world()
    print('car:',v.position.tolist(),'speed:',v.speed,'ped:',p.position.tolist())
    engine.clear_objects(['test_car','test_ped'],force_destroy=True)
    m.destroy();engine.map_manager.current_map=None
finally:close_engine()
