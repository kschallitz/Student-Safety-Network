from pathlib import Path
import nbformat as nbf
import json
ROOT=Path(__file__).resolve().parents[1]
nb=nbf.v4.new_notebook();cells=[]
def md(x):cells.append(nbf.v4.new_markdown_cell(x))
def code(x):cells.append(nbf.v4.new_code_cell(x))
md('''# East Avenue / Estates — MetaDrive and mitigation learning

**Version 0.22 · 8 October 2026**

This notebook reproduces an independent MetaDrive/Bullet experiment using observed 15-minute traffic counts. SUMO is not used. Its outputs are simulated contacts and pedestrian near-miss indicators, not annual real-world collision probabilities.

Version 0.22 repairs crossing behavior: walkers continuously check for vehicle obstructions, and vehicles clear an occupied crossing while walkers wait outside their footprint. Yielding anticipation uses stopping time and native brake response. All 96 episodes use the same observed demand, seeds and score as before. The matched audit is in `outputs/metadrive_school/crossing_repair`.

The runnable implementation, source inventory, simulator checks and candidate comparisons are included. The notebook displays the current recommendation-release status rather than assuming a fitted neural network is valid.

**Colab:** choose a CPU runtime, upload `East_Avenue_MetaDrive_Colab.zip` when prompted, then run the notebook. The saved notebook was executed on the local Mac; cloud execution has not been independently verified.''')
code('''import sys, os, subprocess, zipfile
from pathlib import Path
IN_COLAB = 'google.colab' in sys.modules
if IN_COLAB:
    from google.colab import files
    if not Path('/content/east_avenue_metadrive/metadrive_school').exists():
        uploaded = files.upload()
        bundle = next(name for name in uploaded if name.endswith('.zip'))
        with zipfile.ZipFile(bundle) as archive:
            archive.extractall('/content/east_avenue_metadrive')
    os.chdir('/content/east_avenue_metadrive')
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-q', '-r', 'requirements-metadrive.txt'])
ROOT = Path.cwd()
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
from metadrive_school.config import DATA, OUT, CANDIDATES
if IN_COLAB:
    import metadrive
    assets = Path(metadrive.__file__).parent/'assets'/'version.txt'
    if not assets.exists():
        subprocess.check_call([sys.executable,'-m','metadrive.pull_asset'])
print('Runtime:', 'Google Colab' if IN_COLAB else 'Local computer')
print('Workspace:', ROOT)
''')
md('''## 1. Observed evidence and assumptions
The [City of Livermore report](https://www.livermoreca.gov/home/showpublisheddocument/12943/638887914440930000) supplies movement counts and speed bins. These are aggregated observations, not measured individual trajectories. Geometry is a tracing from an April 2025 drawing, not a certified May 2023 as-built survey. Reaction times, individual arrival seconds and yielding rules remain modeling assumptions.

The 25 mph candidate scales desired operating speeds by 25/30. It does not establish compliance with a changed sign. All ages are represented in these school-period counts; individual pedestrians are not labeled as students.''')
code('''import json
import pandas as pd
from IPython.display import display, Markdown, Image
manifest = json.loads((DATA/'manifest.json').read_text())
observations = pd.read_csv(DATA/'observations.csv')
contexts = pd.read_csv(DATA/'contexts.csv')
assert observations.measurement_status.eq('observed').all()
assert observations.groupby('context_id')['count'].sum().sum() == contexts.total.sum()
display(pd.DataFrame([{'Observed quarter-hour windows':len(contexts), 'Observed movements':int(contexts.total.sum())}]))
display(observations.loc[observations['count'].gt(0), ['interval_start','mode','from_arm','to_arm','crossing_leg','count','source_page']].head(6).rename(columns={'interval_start':'15-minute start','from_arm':'From','to_arm':'To','crossing_leg':'Crossing','source_page':'PDF page'}))
display(pd.DataFrame(CANDIDATES)[['id','label','mph']])
print('Simulator revision:',manifest['metadrive_commit'])
''')
md('''## 2. Verify that the simulator actually runs
This cell starts MetaDrive and moves one vehicle with native steering/throttle/brake physics. It is a fresh run, separate from the saved batch results below. The full motion checks cover turns, U-turns, pedestrians, bicycles, detector controls, braking and repeatability.''')
code('''from metadrive_school.engine import World
from metadrive_school.checks import traveler
world = World()
try:
    world.reset('C01')
    smoke = world.run('notebook_live_smoke', custom=[traveler('notebook_car')], max_time=60)
finally:
    world.close()
assert smoke['complete'] and smoke['collision_pairs'] == 0
assert smoke['precontact_boundary_violations'] == 0
print({k:smoke[k] for k in ['complete','arrived','collision_pairs','max_route_deviation_m','wall_seconds']})
validation = json.loads((OUT/'validation.json').read_text())
display(pd.DataFrame(validation['checks'])[['name','passed']])
''')
md('''## 3. Matched traffic, disjoint demand periods and the release gate
Every candidate receives the same demand ledger and seed for a given context/realization. New random realizations must be explicitly requested; repeating identical inputs does not add independent evidence. Each 15-minute input cohort is followed through queue clearance, with a 2,400-second maximum; extending the tail does not validate field throughput. Earlier truncated attempts are retained. March training windows and separate March validation windows are distinct from the May test windows.

There is no added-delay cutoff and no delay term in the safety reward. Slower complete cohorts remain eligible; excess travel is reported separately.

An entire matched context is excluded from exploratory fitting if any candidate has incomplete accounting, a pre-contact curb incursion or excessive path deviation. The release gate withholds a recommendation if any predeclared run or motion check fails. This prevents a design from winning by leaving travelers unserved or exploiting a geometry error.''')
code('''from metadrive_school.quality import assess
quality, runs = assess(save=False)
print('Saved / planned episodes:',quality['completed_runs'],'/',quality['planned_runs'])
print('Recommendation released:',quality['recommendation_released'])
for reason in quality['release_blockers']: print('•',reason)
assert runs.groupby(['context_id','realization']).demand_sha256.nunique().eq(1).all()
display(runs.groupby(['split','action']).agg(episodes=('score','size'),contacts=('collision_pairs','sum'),near_pairs=('near_pairs','sum'),reward=('score','sum'),physics_pass=('physics_pass','sum')))
''')
md('''## 4. Candidate outcomes
These counts describe this simulation matrix. They are not injury-crash predictions or estimates of a real-world treatment effect. One matched realization per window is a pilot, not a statistically powered rare-event study. A high contact count is a reason to inspect behavior assumptions, not evidence of an unsafe real intersection.''')
code('''import matplotlib.pyplot as plt
summary = runs.groupby('action').agg(contacts=('collision_pairs','sum'),pedestrian_near_pairs=('near_pairs','sum'),episodes=('score','size'),reward=('score','sum'))
ax=summary[['contacts','pedestrian_near_pairs']].plot.bar(figsize=(10,4),color=['#B0573A','#39798B'])
ax.set(title='MetaDrive pilot: simulated event pairs',xlabel='Candidate',ylabel='Unique encounter pairs across episodes')
ax.tick_params(axis='x',rotation=0)
plt.tight_layout();plt.show()
display(summary)
''')
md('''## 5. Learning the intervention choice
An action selects one treatment before an episode. Reward is **−1,000 per distinct contact pair**, **−5 per distinct non-contact pedestrian pair with PET ≤1.5 s**, and **0 otherwise**. This is a terminal Q-learning/contextual-bandit problem (discount factor zero), not a neural driver for every vehicle.

Tabular, linear and neural learners replay the completed simulator outcomes. Neural updates are not additional traffic simulations. The consultant identity is revealed after policy selection; held-out May rewards do not train the learner. The current PET implementation covers pedestrian encounters, while native contacts include vehicles and bicycles.''')
code('''freeze_path=OUT/'pilot_policy_freeze.json'
if freeze_path.exists():
    policy=json.loads(freeze_path.read_text())
    assert policy['snapshot']==quality['snapshot']
    display(pd.DataFrame(policy['agents']).T[['fixed_action','updates','replayed_samples','fresh_simulations_during_learning','validation_score','training_rmse_points']])
    print('Validation-selected family:',policy['champion'])
    print('Recommendation released:',policy['recommendation_released'])
    print('Excluded matched contexts:',policy['excluded_contexts'])
    evaluation=json.loads((OUT/'pilot_evaluation.json').read_text())
    display(pd.DataFrame(evaluation['comparison']))
else:
    print('No fitted policy is released for this snapshot. See validation results above.')
''')
md('''## 6. Rerun or expand the experiment
The commands below are opt-in because fresh physics episodes take time. `pilot` runs the predeclared selected windows; `full` runs all 64 observed windows × eight designs = 512 episodes per realization. CPU is sufficient. Changing simulator code or data invalidates the previous run fingerprint.

If all rewards are indistinguishable, more neural replay updates cannot create information absent from the simulator. Additional observed behavior and matched traffic realizations are separate needs.''')
code('''RUN_NEW_BATCH = False
SUITE = 'pilot'  # change to 'full' to use all observed windows
if RUN_NEW_BATCH:
    for args in [
        ['-m','metadrive_school.validation'],
        ['scripts/diagnose_metadrive_crossing_grid.py'],
        ['-m','metadrive_school.run','--suite',SUITE,'--workers','2','--realizations','1'],
        ['-m','metadrive_school.learning','--suite',SUITE,'--updates','10000'],
    ]:
        subprocess.check_call([sys.executable,*args])
else:
    print('Fresh batch disabled. Set RUN_NEW_BATCH=True to run it.')
''')
summary_path=ROOT/'outputs/metadrive_school/report.json'
if summary_path.exists():
    summary=json.loads(summary_path.read_text())
    speed=summary['speed_comparisons'][0]
    md(f'''## Corrected v0.22 findings
{summary['evaluation_message']}

Across all 12 matched periods, the 25 mph candidate produced **{speed['reduced_speed_contacts']} contact pairs**, compared with **{speed['baseline_contacts']} at 30 mph**. Counts were lower in {speed['fewer']} periods, tied in {speed['unchanged']}, and higher in {speed['more']}. These totals include every declared period. The complete before/after audit is in `outputs/metadrive_school/crossing_repair/repair_summary.json`.

Walker obstruction checks and braking-response tests are included in the software validation suite.''')
md('''## 7. What can be stated in the paper
The project implements a source-driven traffic simulation and an intervention-learning pipeline with reproducibility checks, matched comparisons and a validation gate. Observed movement counts constrain exposure. Individual behavior remains assumed. The output is **not yet an independently validated estimate of real-world collision reduction**.

The software tests verify motion, braking and event detection. They do not calibrate yielding, near misses, annual crashes or transfer to Christensen/Altamont Creek. Those claims require additional field measurements and independent evaluation. The existing Intersection Explorer probabilities were not used as targets for this MetaDrive simulation.

**References and provenance:** [City report](https://www.livermoreca.gov/home/showpublisheddocument/12943/638887914440930000); [MetaDrive project](https://github.com/metadriverse/metadrive); [MetaDrive installation](https://metadrive-simulator.readthedocs.io/en/latest/install.html). Exact source identifiers and hashes are in `data/metadrive_school/manifest.json`. Full implementation notes are in `MetaDrive_README.md`.''')
from website_release import version
for cell in cells:
    if cell.cell_type=='markdown':cell.source=cell.source.replace('Version 0.22','Version '+version()).replace('v0.22','v'+version())
nb.cells=cells
nb.metadata={'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python','version':'3.13'}}
nbf.write(nb,ROOT/'East_Avenue_MetaDrive.ipynb')
print(ROOT/'East_Avenue_MetaDrive.ipynb')
