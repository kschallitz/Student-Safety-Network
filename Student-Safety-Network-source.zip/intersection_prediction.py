"""Reproducible intersection inventory, TIMS matching, and annual time-band experiment.

Snapshot roads are a retrospective spatial frame, not a reconstructed historical map.
Only matched, reported pedestrian/bicycle injury/fatal collisions are modeled.
"""
from pathlib import Path
import gzip
import json
import itertools
import re
import time
import warnings
from collections import defaultdict, Counter

import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point
from scipy.spatial import cKDTree
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPRegressor
from sklearn.linear_model import PoissonRegressor
from sklearn.metrics import log_loss, brier_score_loss, average_precision_score, roc_auc_score, mean_poisson_deviance
from threadpoolctl import threadpool_limits

OUT = Path('intersection_prediction_output')
RADIUS_M = 152.4  # 500 feet, shared by training labels, history, and the drawn map area.
CRS = 'EPSG:26910'
BANDS = ['Midnight–6 am', '6–9 am', '9 am–noon', 'Noon–3 pm', '3–6 pm', '6 pm–midnight']
BASE_FEATURES = ['speed_mean', 'speed_max', 'speed_unknown_share', 'arms', 'road_names',
                 'arterial_share', 'collector_share', 'school_distance_km', 'schools_within_1km',
                 'junctions_within_250m', 'prior3_total_per_year', 'prior3_band_per_year',
                 'prior3_known_share']
FEATURES = BASE_FEATURES + [f'time_band_{i}' for i in range(6)]
PROTOCOL = {
    'target': 'Count of geocoded reported pedestrian/bicycle injury or fatal collisions within 500 feet of a junction center in one calendar year and one time band',
    'geography': 'Current public-road junctions in Alameda County or Tracy, within 2 straight-line miles of an active school in the saved school inventory',
    'training_years': [2017, 2018, 2019, 2020, 2021], 'validation_year': 2022,
    'held_out_years': [2023, 2024, 2025], 'provisional_years': [2024, 2025],
    'history_years': 3, 'selection_metric': '2022 binary log loss after Poisson count-to-probability conversion',
    'road_history': 'Current road geometry is a fixed spatial frame. Historical speeds come from bounded source-corridor matches under explicit annual continuity assumptions; unavailable histories remain unknown. Adoption years are excluded; no June date is fabricated.',
    'match_rule': 'Coordinates within 152.4 metres of the junction center, regardless of the intersection flag or street-name spelling. Include once per containing area; areas overlap and must not be summed as distinct crashes.',
    'unknown_rule': 'Missing/invalid coordinates exclude the case city-year-band; unknown city excludes its source county. Unknown time excludes all bands in every containing area. Areas crossing current source-region boundaries are withheld from training and prediction display.',
    'zero_rule': 'No geocoded TIMS source case in the 500-ft area, conditional on reporting coverage; uncertainty exclusions remain unknown.',
    'speed_rule': 'Historical training uses the saved annual speed panel, not a current-speed backfill. Old limits extend at most three full years before adoption; new limits carry forward through 2025 unless contradicted. Unchanged Livermore survey values span 2017–2025; Pleasanton code snapshots carry forward from the next full year. These are continuity assumptions, not verified sign dates. Current city/county posted values are retained for 2026 map scenarios.',
    'probability': '1-exp(-expected count); annual all-hours probability uses the sum of six expected counts. Assumes a Poisson process; time bands are annual exposure windows, not single-day or per-traveller probabilities.',
    'map_horizon': 'Hypothetical next 12 months using history through 2025 and the current road snapshot; no 2026 observations or time-specific traffic exposure are included.',
    'speed_scenario': 'Recompute the fitted model after changing one named road among the selected junction approaches, holding history and other features fixed. Model sensitivity, not an estimated causal intervention effect.',
    'age_rule': '5–18 inclusive identifies recorded school-age pedestrian/bicyclist victims, not enrollment or a school trip; age is not a future predictor.',
    'radius_feet': 500, 'overlapping_areas': True,
    'test_reuse': '2023–2025 outcomes were already inspected under the prior target. These are reused temporal diagnostics, not a fresh untouched final test.',
    'uncertainty': 'Central 90% range of 40 spatial 2-km-block bootstrap fits, fixed preprocessing and hyperparameters. Conditional model stability only; not a calibrated confidence level for true local risk or causal speed effects.',
    'nn_candidates': [{'hidden': 8, 'alpha': 10}, {'hidden': 16, 'alpha': 100}],
    'glm_candidates': [0.001, 0.01], 'seed': 42, 'pca': False,
    'exposure': 'No continuous pedestrian, bicycle, or vehicle volumes. County spot counts are saved separately but not joined to this model.',
}


def road_key(value):
    if value is None or pd.isna(value):
        return ''
    s = re.sub(r'^\s*\d+\s+', '', str(value).upper())
    aliases = {'AVENUE':'AV','AVE':'AV','BOULEVARD':'BL','BLVD':'BL','ROAD':'RD','STREET':'ST',
               'DRIVE':'DR','COURT':'CT','CIRCLE':'CI','CIR':'CI','WAY':'WY','LANE':'LN',
               'PARKWAY':'PW','PKWY':'PW','PLACE':'PL','NORTH':'N','SOUTH':'S','EAST':'E','WEST':'W',
               'TERRACE':'TE','TER':'TE','1ST':'FIRST','2ND':'SECOND','3RD':'THIRD','4TH':'FOURTH',
               '5TH':'FIFTH','6TH':'SIXTH','7TH':'SEVENTH','8TH':'EIGHTH','9TH':'NINTH','10TH':'TENTH'}
    return ' '.join(aliases.get(t,t) for t in re.sub('[^A-Z0-9 ]', ' ', s).split())


def relaxed_key(s):
    a=s.split()
    return ' '.join(a[1:]) if len(a)>2 and a[0] in ['N','S','E','W'] else s


def hour_band(h):
    if pd.isna(h): return -1
    return int(np.searchsorted([6,9,12,15,18], float(h), side='right'))


def read_gz_geo(path):
    with gzip.open(path, 'rt') as f: return gpd.GeoDataFrame.from_features(json.load(f)['features'], crs=4326)


class Union:
    def __init__(self,n): self.p=list(range(n))
    def find(self,a):
        while a!=self.p[a]:
            self.p[a]=self.p[self.p[a]]; a=self.p[a]
        return a
    def join(self,a,b):
        a,b=self.find(a),self.find(b)
        if a!=b: self.p[b]=a


def prepare_roads():
    a=read_gz_geo('data/regional_roads/raw/alameda_county_streets.geojson.gz')
    a=a.loc[a.RoadType.eq('Road') & a.IsPrivate.eq('No') & ~a.FunctionalClass.isin(['Interstate','Freeway or Expressway','Ramp'])].copy()
    a['sid']='AC-'+a.OBJECTID.astype(str)
    a['name']=a.FullStreetName.map(road_key)
    a['city']=a.CitySitusLeftFull.fillna(a.CitySitusRightFull).fillna('Unincorporated').str.upper()
    a['road_class']=a.FunctionalClass.fillna('Local')
    # Preserve source attributes for geometry/SUMO integration. These current
    # fields are not silently added to historical model features.
    a['county_lanes']=pd.to_numeric(a.NumberOfLanes,errors='coerce')
    a['county_oneway']=a.Oneway
    a['e0']=pd.to_numeric(a.FrElevation,errors='coerce').fillna(0)
    a['e1']=pd.to_numeric(a.ToElevation,errors='coerce').fillna(0)
    speed=pd.to_numeric(a.PostedSpeedLimit,errors='coerce')
    a['speed']=speed.where(speed.between(15,65)&speed.ne(25))
    a['speed_source']=np.where(a.speed.notna(),'County reported posted limit','Unknown / default-looking county value')
    t=read_gz_geo('data/regional_roads/raw/tracy_streets.geojson.gz')
    t=t.loc[~t.FUNCTIONAL.isin(['Freeway','Ramp','Private']) & ~t.Private.fillna('').str.strip().str.upper().isin(['Y','YES'])].copy()
    t['sid']='TR-'+t.OBJECTID.astype(str);t['name']=t.FULL_STR_NAME.map(road_key)
    t['city']='TRACY';t['road_class']=t.FUNCTIONAL.fillna('Local')
    t['e0']=pd.to_numeric(t.F_ELEV,errors='coerce').fillna(0);t['e1']=pd.to_numeric(t.T_ELEV,errors='coerce').fillna(0)
    t['speed']=np.nan;t['speed_source']='Unknown / Tracy SPEED definition unverified'
    t['county_lanes']=np.nan;t['county_oneway']=None
    cols=['sid','name','city','road_class','e0','e1','speed','speed_source','county_lanes','county_oneway','geometry']
    roads=gpd.GeoDataFrame(pd.concat([a[cols],t[cols]],ignore_index=True),crs=4326).to_crs(CRS)
    roads=roads.loc[roads.name.ne('') & roads.geometry.geom_type.eq('LineString') & roads.length.gt(2)].reset_index(drop=True)
    # The city and county StreetIDs are different identifiers; use name plus geometry instead.
    city=gpd.read_file('school_forecast_output/livermore_road_speed_inventory.geojson').to_crs(CRS)
    city['name']=city.FullStreetName.map(road_key)
    city=city.loc[city.posted_speed_known & city.posted_speed_mph.between(15,65)]
    by={k:v for k,v in city.groupby('name')}
    replaced=0
    for i,r in roads.loc[roads.city.eq('LIVERMORE')].iterrows():
        candidates=by.get(r['name'])
        if candidates is None: continue
        midpoint=r.geometry.interpolate(.5,normalized=True)
        near=candidates.loc[candidates.distance(midpoint).le(12)].copy()
        if not len(near): continue
        # A buffered overlap is safer than a nearest endpoint on an adjacent segment.
        near['overlap']=near.geometry.buffer(8).intersection(r.geometry).length/r.geometry.length
        near=near.loc[near.overlap.ge(.6)].sort_values('overlap',ascending=False)
        if len(near) and (len(near)==1 or near.posted_speed_mph.nunique()==1 or near.overlap.iloc[0]-near.overlap.iloc[1]>.25):
            roads.loc[i,'speed']=float(near.posted_speed_mph.iloc[0]);roads.loc[i,'speed_source']='Livermore city posted limit';replaced+=1
    print('Public road segments',len(roads),'city speed matches',replaced,flush=True)
    return roads


def make_junctions(roads,schools,boundary):
    coords=[];edge=[];level=[]
    for i,r in roads.iterrows():
        coords.extend([r.geometry.coords[0][:2],r.geometry.coords[-1][:2]])
        edge.extend([i,i]);level.extend([r.e0,r.e1])
    xy=np.asarray(coords);u=Union(len(xy))
    for a,b in cKDTree(xy).query_pairs(4):
        if level[a]==level[b]: u.join(a,b)
    groups=defaultdict(list)
    for i in range(len(xy)): groups[u.find(i)].append(i)
    nodes=[]
    for ends in groups.values():
        ids=sorted(set(edge[e] for e in ends)); rr=roads.loc[ids]
        names=sorted(set(rr.name))
        if len(ends)<3 or len(names)<2: continue
        p=Point(np.mean(xy[ends],axis=0))
        city=Counter(rr.city).most_common(1)[0][0]
        if city!='TRACY' and not boundary.covers(p): continue
        nodes.append({'geometry':p,'ids':ids,'names':names,'city':city,'arms':len(ends)})
    # Collapse divided-road micro-junctions only when they represent the same road pair.
    xy=np.array([[n['geometry'].x,n['geometry'].y] for n in nodes]);u=Union(len(nodes))
    for a,b in cKDTree(xy).query_pairs(32):
        if nodes[a]['names']==nodes[b]['names']:u.join(a,b)
    merged=defaultdict(list)
    for i in range(len(nodes)):merged[u.find(i)].append(i)
    stree=cKDTree(np.c_[schools.geometry.x,schools.geometry.y]);records=[]
    for idxs in merged.values():
        p=Point(np.mean(xy[idxs],axis=0));d,nearest=stree.query([p.x,p.y])
        if d>3218.688:continue
        ids=sorted(set(itertools.chain.from_iterable(nodes[i]['ids'] for i in idxs)))
        rr=roads.loc[ids];approaches=[]
        for name,g in rr.groupby('name'):
            approaches.append({'name':name,'speeds':[None if pd.isna(x) else float(x) for x in g.speed],
                               'sources':sorted(set(g.speed_source)), 'segments':g.sid.tolist()})
        known=rr.speed.dropna()
        records.append({'junction_id':f'J{len(records):05d}','name':' / '.join(sorted(set(rr.name))),
            'city':Counter(rr.city).most_common(1)[0][0], 'geometry':p,
            'speed_mean':float(known.mean()) if len(known) else 30.,
            'speed_max':float(known.max()) if len(known) else 30.,
            'speed_unknown_share':float(rr.speed.isna().mean()),
            'arms':len(ids),'road_names':rr.name.nunique(),
            'arterial_share':float(rr.road_class.str.contains('Arterial',case=False).mean()),
            'collector_share':float(rr.road_class.str.contains('Collector',case=False).mean()),
            'school_distance_km':d/1000,'schools_within_1km':len(stree.query_ball_point([p.x,p.y],1000)),
            'approaches':approaches,'names':sorted(set(rr.name))})
    j=gpd.GeoDataFrame(records,crs=CRS)
    tree=cKDTree(np.c_[j.geometry.x,j.geometry.y])
    j['junctions_within_250m']=[len(z)-1 for z in tree.query_ball_point(np.c_[j.geometry.x,j.geometry.y],250)]
    return j


def match_cases(j,crashes):
    """All geocoded source cases in each 500-ft area; overlapping areas share cases.

    One case appears once per area, never once per victim. Neither the intersection
    flag nor street-name equality excludes a geographically nearby source record.
    Invalid coordinates leave affected city/year/bands unknown, not zero.
    """
    projected=j.to_crs(CRS)
    xy=np.c_[projected.geometry.x,projected.geometry.y];tree=cKDTree(xy)
    by_city={name:set(g.index) for name,g in j.groupby('city')}
    n=len(j);counts=np.zeros((n,12,6),dtype=np.int16);unknown=np.zeros_like(counts,dtype=bool)
    records=[];members=[]
    valid=crashes.coordinate_screen_pass.eq(True)
    pts=gpd.GeoSeries(gpd.points_from_xy(crashes.longitude.fillna(0),crashes.latitude.fillna(0)),crs=4326).to_crs(CRS)
    for idx,c in crashes.iterrows():
        band=hour_band(c.hour);year=int(c.year);chosen=None;distance=None
        indexes=[];blocked=set()
        if valid.iloc[idx]:
            p=pts.iloc[idx];indexes=sorted(tree.query_ball_point([p.x,p.y],RADIUS_M))
            method='within_500ft_area' if indexes else 'outside_all_500ft_areas'
            distances=sorted((float(np.linalg.norm(xy[i]-[p.x,p.y])),i) for i in indexes)
            if distances:distance,chosen=distances[0]
            for d,i in distances:
                members.append({'case_id':str(c.CASE_ID),'junction_index':i,'year':year,'band':band,'distance_ft':d/.3048})
                if band>=0:counts[i,year-2014,band]+=1
                else:blocked.add(i)
        else:
            method='missing_coordinate_city_exclusion'
            city=str(c.CITY).upper()
            blocked=set(by_city.get(city,[]))
            if not blocked:
                # Unincorporated/unknown city may be anywhere in the source county.
                blocked=set(j.index[j.city.ne('TRACY')]) if str(c.export_region).lower().find('tracy')<0 else set(by_city.get('TRACY',[]))
        for i in blocked:
            if band<0:unknown[i,year-2014,:]=True
            else:unknown[i,year-2014,band]=True
        records.append({'case_id':str(c.CASE_ID),'junction_index':chosen,'year':year,'band':band,
            'match_method':method,'distance_m':distance,'blocked_junctions':len(blocked),
            'area_memberships':len(indexes),'area_indices':json.dumps(indexes)})
    if 'coverage_complete' in j:
        unknown[~j.coverage_complete.to_numpy(dtype=bool),:,:]=True
    return pd.DataFrame(records),counts,unknown,pd.DataFrame(members)


def rematch_areas():
    """Reuse the reviewed network; change only the declared event geography."""
    j,old_counts,old_unknown=load_prepared()
    boundary=gpd.read_file('data/regional_roads/raw/alameda_boundary.geojson').to_crs(CRS).geometry.union_all()
    tracy=gpd.read_file('data/regional_roads/raw/tracy_boundary.geojson').to_crs(CRS).geometry.union_all()
    footprint=boundary.union(tracy)
    jp=j.to_crs(CRS)
    j['coverage_complete']=[footprint.covers(p.buffer(RADIUS_M)) for p in jp.geometry]
    crashes=pd.read_csv('tims_intake_output/regional_tims_crashes_2014_2025.csv',low_memory=False)
    audit,counts,unknown,members=match_cases(j,crashes)
    (OUT/'junctions.geojson').write_text(j.to_json())
    audit.to_csv(OUT/'case_assignment_audit.csv',index=False)
    members.to_csv(OUT/'case_area_membership.csv',index=False)
    np.savez_compressed(OUT/'counts_and_unknown.npz',counts=counts,unknown=unknown)
    summary=json.loads((OUT/'preparation_summary.json').read_text())
    summary.update(target_version='500ft-areas-v2',radius_feet=500,
        assigned_cases=int(audit.area_memberships.gt(0).sum()),assigned_known_time_cases=int(audit.loc[audit.band.ge(0),'area_memberships'].gt(0).sum()),
        area_case_memberships=len(members),known_time_area_case_memberships=int(counts.sum()),
        unknown_intersection_year_bands=int(unknown.sum()),complete_coverage_areas=int(j.coverage_complete.sum()),
        match_methods=audit.match_method.value_counts().to_dict(),
        overlap_note='Each distinct case appears once in each containing area. Never sum overlapping area counts as distinct regional crashes.')
    (OUT/'preparation_summary.json').write_text(json.dumps(summary,indent=2))
    (OUT/'protocol.json').write_text(json.dumps(PROTOCOL,indent=2))
    print(json.dumps(summary,indent=2),flush=True)
    return j,counts,unknown


def feature_year(j,counts,unknown,year):
    k=year-2014;past=counts[:,k-3:k,:];known=~unknown[:,k-3:k,:]
    # Retain available lower-bound history with an explicit coverage feature.
    static=j[BASE_FEATURES[:10]].to_numpy(dtype=float)
    if 'junction_id' in j:
        from historical_speed_features import year_features
        static[:,:3]=year_features(j,year)
    x=np.repeat(static,6,axis=0)
    hist=np.c_[np.repeat(past.sum(axis=(1,2))/3,6),past.sum(axis=1).reshape(-1)/3,
               known.mean(axis=1).reshape(-1)]
    x=np.c_[x,hist,np.tile(np.eye(6),(len(j),1))]
    return x


def prepare():
    OUT.mkdir(exist_ok=True)
    (OUT/'protocol.json').write_text(json.dumps(PROTOCOL,indent=2))
    roads=prepare_roads()
    schools=gpd.read_file('school_forecast_output/school_sites.geojson').to_crs(CRS)
    boundary=gpd.read_file('data/regional_roads/raw/alameda_boundary.geojson').to_crs(CRS).geometry.iloc[0]
    j=make_junctions(roads,schools,boundary)
    crashes=pd.read_csv('tims_intake_output/regional_tims_crashes_2014_2025.csv',low_memory=False)
    audit,counts,unknown,members=match_cases(j,crashes)
    # JSON handles nested approaches and preserves unknown speed as null.
    (OUT/'junctions.geojson').write_text(j.to_crs(4326).to_json())
    np.savez_compressed(OUT/'counts_and_unknown.npz',counts=counts,unknown=unknown)
    audit.to_csv(OUT/'case_assignment_audit.csv',index=False)
    members.to_csv(OUT/'case_area_membership.csv',index=False)
    roads[['sid','name','city','speed','speed_source','county_lanes','county_oneway','geometry']].to_crs(4326).to_file(OUT/'road_inventory.geojson',driver='GeoJSON')
    summary={'junctions':len(j),'road_segments':len(roads),'schools':len(schools),
        'distinct_source_cases':len(crashes),'assigned_cases':int(audit.junction_index.notna().sum()),
        'assigned_known_time_cases':int(counts.sum()),'unknown_intersection_year_bands':int(unknown.sum()),
        'match_methods':audit.match_method.value_counts().to_dict(),
        'cities':j.city.value_counts().to_dict(),'junctions_any_known_speed':int(j.speed_unknown_share.lt(1).sum()),
        'livermore_junctions':int(j.city.eq('LIVERMORE').sum())}
    (OUT/'preparation_summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2),flush=True)
    return j,counts,unknown


def load_prepared():
    j=gpd.read_file(OUT/'junctions.geojson')
    # GDAL may serialize list-valued attributes; read nested fields directly.
    raw=json.loads((OUT/'junctions.geojson').read_text())
    for col in ['names','approaches']:j[col]=[f['properties'][col] for f in raw['features']]
    data=np.load(OUT/'counts_and_unknown.npz')
    return j,data['counts'],data['unknown']


def probability(mu):return -np.expm1(-np.clip(mu,1e-12,1e6))


def predict_export(model,x):
    if model['kind']=='ten_year_pooled':
        from ten_year_model import calibrated_rates
        return calibrated_rates(model,np.asarray(x))
    v=(np.asarray(x)-model['mean'])/model['scale']
    if model['kind']=='poisson_glm':return np.exp(v@np.asarray(model['weights'])+model['intercept'])
    for i,(w,b) in enumerate(zip(model['weights'],model['biases'])):
        v=v@np.asarray(w)+b
        v=np.exp(v) if i==len(model['weights'])-1 else np.tanh(v)
    return v.ravel()


def scenario_rows(x,approaches,selected,override):
    result=np.array(x,copy=True)
    speeds=[override if i==selected and override is not None else s
            for i,a in enumerate(approaches) for s in a['speeds']]
    speeds=[s for s in speeds if s is not None]
    if speeds:result[:,0]=np.mean(speeds);result[:,1]=max(speeds)
    return result


def metrics(y,mu):
    p=np.clip(probability(mu),1e-10,1-1e-10);positive=y>0
    return {'rows':len(y),'events':int(y.sum()),'positive_rows':int(positive.sum()),
        'log_loss':float(log_loss(positive,p,labels=[False,True])),
        'brier':float(brier_score_loss(positive,p)),
        'average_precision':float(average_precision_score(positive,p)),
        'roc_auc':float(roc_auc_score(positive,p)),
        'poisson_deviance':float(mean_poisson_deviance(y,np.maximum(mu,1e-10))),
        'predicted_events':float(np.sum(mu))}


def export_model(model,scaler,name):
    base={'name':name,'mean':scaler.mean_.tolist(),'scale':scaler.scale_.tolist(),'features':FEATURES}
    if isinstance(model,MLPRegressor):
        base.update(kind='mlp',weights=[a.tolist() for a in model.coefs_],biases=[a.tolist() for a in model.intercepts_],activation='tanh')
    else:base.update(kind='poisson_glm',weights=model.coef_.tolist(),intercept=float(model.intercept_))
    return base


def train_three_year_legacy():
    j,counts,unknown=load_prepared();start=time.monotonic()
    from historical_speed_features import eligible
    (OUT/'protocol.json').write_text(json.dumps(PROTOCOL,indent=2))
    datasets={}
    for year in range(2017,2026):
        x=feature_year(j,counts,unknown,year);y=counts[:,year-2014,:].reshape(-1).astype(float)
        mask=eligible(j,unknown,year)
        datasets[year]=(x[mask],y[mask],mask)
    x=np.concatenate([datasets[y][0] for y in PROTOCOL['training_years']]);y=np.concatenate([datasets[z][1] for z in PROTOCOL['training_years']])
    scaler=StandardScaler().fit(x);sx=scaler.transform(x)
    vx,vy,_=datasets[2022];sv=scaler.transform(vx)
    # Fold identical feature rows; weighted mean targets give the same Poisson objective.
    unique,inverse,weights=np.unique(sx,axis=0,return_inverse=True,return_counts=True)
    target=np.bincount(inverse,weights=y)/weights
    print('Training rows',len(y),'unique feature rows',len(unique),'events',int(y.sum()),flush=True)
    candidates=[];models={};logs=[]
    for hidden,alpha in [(8,10),(16,100)]:
        name=f'Neural network {hidden} units, penalty {alpha}'
        m=MLPRegressor(loss='poisson',hidden_layer_sizes=(hidden,),activation='tanh',solver='lbfgs',
            alpha=alpha,max_iter=1000,max_fun=5000,tol=1e-5,random_state=42)
        tick=time.monotonic()
        with warnings.catch_warnings(record=True) as caught,threadpool_limits(limits=2):
            warnings.simplefilter('always');m.fit(unique,target,sample_weight=weights)
        mu=m.predict(sv);row={'model':name,'family':'nn',**metrics(vy,mu),'fit_seconds':time.monotonic()-tick,
                             'iterations':int(m.n_iter_),'warnings':[str(w.message) for w in caught]}
        candidates.append(row);models[name]=m;print(row,flush=True)
    for alpha in PROTOCOL['glm_candidates']:
        name=f'Poisson regression, penalty {alpha}';m=PoissonRegressor(alpha=alpha,max_iter=400,tol=1e-7)
        with threadpool_limits(limits=2):m.fit(unique,target,sample_weight=weights)
        candidates.append({'model':name,'family':'glm',**metrics(vy,m.predict(sv))});models[name]=m
    best_nn=min((r for r in candidates if r['family']=='nn'),key=lambda r:r['log_loss'])['model']
    best_glm=min((r for r in candidates if r['family']=='glm'),key=lambda r:r['log_loss'])['model']
    # A common per-band baseline is estimated only on training rows, with no held-out calibration.
    band=np.argmax(x[:,-6:],axis=1);rates=np.array([y[band==b].mean() for b in range(6)])
    calibration=[];predictions=[]
    for year in [2022,2023,2024,2025]:
        tx,ty,mask=datasets[year];st=scaler.transform(tx)
        for label,name in [('Neural network',best_nn),('Poisson regression',best_glm),('Time-band baseline',None)]:
            mu=models[name].predict(st) if name else rates[np.argmax(tx[:,-6:],axis=1)]
            logs.append({'year':year,'model':label,**metrics(ty,mu)})
            if year>=2023:
                p=probability(mu);order=np.argsort(p);chunks=np.array_split(order,10)
                for decile,ix in enumerate(chunks):
                    calibration.append({'year':year,'model':label,'decile':decile+1,'rows':len(ix),'mean_probability':float(p[ix].mean()),'observed_fraction':float((ty[ix]>0).mean())})
            if label=='Neural network':
                predictions.append(pd.DataFrame({'year':year,'junction_index':np.repeat(np.arange(len(j)),6)[mask],
                    'band':np.tile(np.arange(6),len(j))[mask],'observed_count':ty,'predicted_count':mu}))
    pd.DataFrame(candidates).to_csv(OUT/'validation_candidates.csv',index=False)
    pd.DataFrame(logs).to_csv(OUT/'evaluation.csv',index=False)
    pd.DataFrame(calibration).to_csv(OUT/'calibration.csv',index=False)
    pd.concat(predictions).to_csv(OUT/'held_out_predictions.csv.gz',index=False)
    bundle={'nn':export_model(models[best_nn],scaler,best_nn),'glm':export_model(models[best_glm],scaler,best_glm),
        'baseline_rates':rates.tolist(),'bands':BANDS,'protocol':PROTOCOL}
    (OUT/'model.json').write_text(json.dumps(bundle))
    # The map uses the last three complete source years. History is held fixed for speed edits.
    forecast_x=feature_year(j,counts,unknown,2026)
    np.savez_compressed(OUT/'map_features.npz',x=forecast_x)
    forecast_mu=models[best_nn].predict(scaler.transform(forecast_x)).reshape(-1,6)
    pred=j[['junction_id','name','city','speed_unknown_share']].copy()
    pred['annual_probability']=probability(forecast_mu.sum(axis=1));pred['expected_annual_count']=forecast_mu.sum(axis=1)
    pred['recorded_cases_2014_2025']=counts.sum(axis=(1,2));pred.to_csv(OUT/'map_predictions.csv',index=False)
    summary={'train_rows':len(y),'train_events':int(y.sum()),'unique_training_feature_rows':len(unique),
             'features':FEATURES,'selected_nn':best_nn,'selected_glm':best_glm,'elapsed_seconds':time.monotonic()-start,
             'held_out_years':[2023,2024,2025],'all_training_on':'Local Mac CPU','test_used_for_selection':False}
    (OUT/'training_summary.json').write_text(json.dumps(summary,indent=2))
    print(pd.DataFrame(logs).to_string(index=False),flush=True)
    return bundle


def train():
    """Current default; the prior three-year implementation is retained for audit."""
    from ten_year_model import train as train_ten_year
    return train_ten_year()


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['prepare','rematch','train','all']);args=p.parse_args()
    if args.stage in ['prepare','all']:prepare();rematch_areas()
    if args.stage=='rematch':rematch_areas()
    if args.stage in ['train','all']:train()
