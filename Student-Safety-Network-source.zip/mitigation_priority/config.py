from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data/mitigation_priority';OUT=ROOT/'outputs/mitigation_priority'
ACTIONS=[f'C{i:02}' for i in range(1,9)]
VALIDATION=['20230302T080000','20230302T084500','20230302T144500','20230302T154500']
VALIDATION_SEEDS=list(range(1100000,1100030))
TEST_SEEDS=list(range(1400000,1400030))
CHECKPOINTS=[6000,30000,100000,300000]
REWARD_SCALE=1000.
COLLISION_PENALTY=1000
NEAR_MISS_PENALTY=5
PREVIOUS_ACTION='C08'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def reward(c,n):return -COLLISION_PENALTY*int(c)-NEAR_MISS_PENALTY*int(n)
