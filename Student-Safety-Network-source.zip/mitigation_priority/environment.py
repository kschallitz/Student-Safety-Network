"""One permanent candidate, with feedback summed over 30 real SUMO repeats."""
import numpy as np
import pandas as pd
import gymnasium as gym
from gymnasium import spaces
from mitigation_rl.learn import features
from .config import DATA,OUT,ACTIONS,reward
from .runs import run

class DesignBatchEnv(gym.Env):
    def __init__(self,split='train'):
        if split=='test' and not (OUT/'policy_freeze.json').exists():
            raise ValueError('Freeze before test access')
        c=pd.read_csv(DATA/'contexts.csv')
        self.contexts=c[c.split.eq(split)].reset_index(drop=True)
        self.action_space=spaces.Discrete(len(ACTIONS))
        self.observation_space=spaces.Box(-np.inf,np.inf,(7,),dtype=np.float32)
        self.done=True

    def reset(self,*,seed=None,options=None):
        super().reset(seed=seed);options=options or {};c=self.contexts
        if 'context_id' in options:c=c[c.context_id.eq(options['context_id'])]
        if c.empty:raise ValueError('Unknown context')
        self.context=c.iloc[int(self.np_random.integers(len(c)))].to_dict()
        start=int(options.get('simulation_seed_start',self.np_random.integers(1500000,1600000)))
        self.seeds=list(range(start,start+30));self.done=False
        return features(pd.DataFrame([self.context]))[0].astype(np.float32),{'context_id':self.context['context_id'],'repeats':30,'seeds':self.seeds}

    def step(self,action):
        if self.done:raise RuntimeError('Reset after a terminal batch')
        if not self.action_space.contains(action):raise ValueError('Invalid candidate index')
        rows=[run((self.context['context_id'],ACTIONS[int(action)],s,'nominal')) for s in self.seeds]
        self.done=True
        if not all(r['complete'] for r in rows):raise RuntimeError('Incomplete batch: reward invalid')
        scores=[reward(r['collision_pairs'],r['near_pairs']) for r in rows]
        return features(pd.DataFrame([self.context]))[0].astype(np.float32),float(sum(scores)),True,False,{
            'action':ACTIONS[int(action)],'episode_scores':scores,'collisions':sum(r['collision_pairs'] for r in rows),
            'near_misses':sum(r['near_pairs'] for r in rows),'results':rows}
