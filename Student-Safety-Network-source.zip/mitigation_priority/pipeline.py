import json,time
import pandas as pd
from .config import ROOT,DATA,OUT,sha,PREVIOUS_ACTION
from .runs import batch,sensitivity

def normalize_split(split):
    path=OUT/f'{split}_runs.csv';d=pd.read_csv(path)
    if 'source_split' not in d:d['source_split']=d['split']
    d['split']=split;d.to_csv(path,index=False)

def main():
    start=time.time();manifest={'started_unix':start,'protocol_sha256':sha(ROOT/'mitigation_priority/protocol.md')}
    (OUT/'run_manifest.json').write_text(json.dumps(manifest,indent=2))
    for split in ['train','validation']:
        if not (OUT/f'{split}_runs.csv').exists():batch(split)
        normalize_split(split)
    if not (OUT/'policy_freeze.json').exists():
        from .learn import main as train
        train()
    f=json.loads((OUT/'policy_freeze.json').read_text())
    # Benchmark identity is revealed only after learning and policy selection.
    key=json.loads((DATA/'benchmark_key.json').read_text())
    actions=sorted(set([x['action'] for x in f['agents'].values()]+[key['baseline'],key['consultant_candidate'],PREVIOUS_ACTION]))
    if not (OUT/'test_runs.csv').exists():batch('test',actions)
    profile_actions=sorted(set([f['agents'][f['champion']]['action'],key['baseline'],key['consultant_candidate'],PREVIOUS_ACTION]))
    if not (OUT/'sensitivity_runs.csv').exists():sensitivity(profile_actions)
    from .evaluate import main as evaluate
    evaluate();manifest.update(completed_unix=time.time(),seconds=time.time()-start);(OUT/'run_manifest.json').write_text(json.dumps(manifest,indent=2))

if __name__=='__main__':
    import sys
    if '--wait-for-input-batches' in sys.argv:
        print('Waiting for active pre-period batches.',flush=True)
        while not all((OUT/f'{x}_runs.csv').exists() for x in ['train','validation']):time.sleep(5)
    main()
