"""Portable experiment, results UI data, and assignment evidence."""
import base64,html,io,json,zipfile
from pathlib import Path
import numpy as np,pandas as pd,nbformat
from mitigation_rl.learn import values
from mitigation_batch.config import SENSITIVITY_CONTEXTS
from .config import ROOT,DATA,OUT,ACTIONS
from .learn import scored,batches,fixed_performance

PROFILE_LABELS={'nominal':'Nominal','nominal_subset':'Nominal (same eight windows)','cautious':'Cautious drivers','tighter_gaps':'Tighter gaps','half_speed_response':'Half speed response'}

DISPLAY_LABELS={'C01':'Unchanged layout at 30 mph','C02':'Speed reduced from 30 to 25 mph','C03':'Small generic curb extensions at 30 mph','C04':'Small curbs with speed reduced to 25 mph','C05':'Protected curb extensions and shortened crossings at 30 mph','C06':'Painted medians and marked crossings at 30 mph','C07':'Full protected-curb, median and crossing package at 30 mph','C08':'Full package with speed reduced from 30 to 25 mph'}

def display_candidates():
    return [{**c,'label':DISPLAY_LABELS[c['id']]} for c in json.loads((DATA/'candidates.json').read_text())]

def finding(r):
    f=r['freeze'];d=pd.DataFrame(r['policies']).set_index('policy');a=d.loc[f['champion']];h=d.loc['consultant'];base=d.loc['unchanged']
    text=f"With the collision penalty increased to −1,000, validation selected {f['champion']}: {a.action}, {DISPLAY_LABELS[a.action].lower()}. "
    text+=('The selected design is unchanged from v0.17. ' if a.action==r['previous_candidate'] else 'The selected design differs from v0.17. ')
    text+=f'On 960 fresh repeats it scored {a.total_score:,.0f}, versus {h.total_score:,.0f} for the consultant and {base.total_score:,.0f} for unchanged. '
    if a.action==r['benchmark_candidate']:text+='It chose the same modeled design as the consultants, giving identical matched outcomes.'
    elif a.consultant_gain_low>0:text+='Its paired 95% interval supports a better weighted score under nominal simulation assumptions.'
    else:text+='Its paired 95% interval does not establish a better weighted score than the consultant design.'
    winners=r['descriptive_best_test_agents'];best=d.loc[winners[0]]
    text+=f' Highest observed agent test score: {best.action}, selected by {len(winners)} {'agent' if len(winners)==1 else 'agents'}, with {best.total_score:,.0f} points.'
    if best.action!=r['benchmark_candidate'] and best.consultant_gain_low<=0:text+=' Its 95% interval still includes no improvement over the consultant.'
    return text

def evidence(r):
    f=r['freeze'];d=pd.DataFrame(r['policies']).set_index('policy');a=d.loc[f['champion']];h=d.loc['consultant'];b=d.loc['unchanged']
    p=OUT/'paper_materials';p.mkdir(exist_ok=True)
    source=json.loads((DATA/'source_coverage.json').read_text());best=d.loc[r['descriptive_best_test_agents'][0]]
    text=f'''# COSC 645 evidence update · v0.18

## Application
The application supports school-area traffic planning by comparing proposed intersection designs under the same observed demand. East Avenue at Estates Avenue is the working demonstration. The intersection explorer provides a separate historical collision model; its probabilities are not training targets for this SUMO experiment. The project target is Wednesday October 7, with the paper due the following Sunday. This is evidence for the 8–10-page paper, not the completed paper.

## Collision penalty revision
This release changes the collision penalty from -100 to -1,000 while keeping near misses at -5 and event-free repeats at zero. All nine agents are retrained for 300,000 updates each using rewards recomputed from the same pre-period simulation counts. This preserves the traffic, geometry, features and learning budget; it does not merely rescore the old trained policy. One collision now costs 200 near misses. The weight expresses the user's priority and was fixed before new tests; it was not tuned to force agreement with the consultants.

The new test uses seeds 1400000–1400029, disjoint from v0.17 and from training/validation. The previous selected C08 is included as a frozen reference on these exact same traveler draws. The new champion's mean score gain over that previous selection is {a.mean_gain_vs_previous:.2f} points per 30-repeat batch, with paired 95% interval [{a.previous_gain_low:.2f}, {a.previous_gain_high:.2f}]. Comparing released totals across versions would confound changed weights and changed random draws.

## Earlier corrections retained
Under the old -100 collision penalty, the earlier four-action menu excluded the complete consultant design. Even the hindsight best selection among those four actions on the old test batches scored -15,490, versus -12,890 for the consultant design. More training alone could not erase that saved-data action-menu gap. The old Saturday validation also had only two pedestrians and two bicycles. A separate audit extending the original learners from 6,000 to 300,000 updates substantially improved the neural learners' training choices, supporting the user's concern about too little learning. That audit reused existing simulator data; it was not 2.7 million new simulations.

As in v0.17, this revision offers eight anonymous candidates, including the complete modeled consultant package, its curb and median components, and combinations with speed reduced from 30 to 25 mph. The learner receives no consultant-choice label or imitation target. It chooses a single permanent layout using mean predicted value over training contexts. The physical layout no longer changes with the quarter-hour traffic window. All nine agents use their final 300,000-update checkpoint.

## Source data and interventions
Native 15-minute observed vehicle turning movements, bicycle movements and pedestrian crossing counts come from the City's tactical bikeway report. Training uses 28 pre-installation windows (20 on March 2 and eight on February 11). Four separate weekday validation windows, chosen by traffic exposure and time rather than reward, contain 68 pedestrians and four bicycles. Testing uses the 32 May 18/20 windows with fresh simulation seeds. These are repeated draws from only four observed source dates, not many newly observed days.

Here, a 25 mph option means lowering the modeled 30 mph limit to 25 mph, not adding 25 mph. Comparing unchanged at 30 mph with the full package at 25 mph changes both geometry and speed. Compare C07 with C08 to isolate the modeled speed-response increment while retaining the same package.

The report lists protected painted curb extensions, painted medians, high-visibility crossings, K71 bollards and in-street pedestrian-yield signs. Speed humps are not identified as an installed Estates treatment. All modeled parts of the documented package are offered. Curbs/medians constrain turning geometry; crossings retain the modeled yielding controls. Bollard boundaries are idealized. Independent benefits of paint visibility and sign compliance are not calibrated, and no invented reduction factor is assigned. Median refuge waiting is not independently calibrated. The reconstructed pilot geometry comes from an April 2025 memorandum and is not certified May 2023 as-built geometry.

## Development and learning
Python, SUMO/libsumo 1.27.1, PyTorch, Gymnasium, pandas/NumPy, Matplotlib and JavaScript comprise the implementation. It runs on CPU with no paid AI API. The three agent families are tabular, linear and a neural network with two 32-unit tanh layers. Seeds 41, 73 and 109 give nine agents. Seven context features describe motor demand, pedestrian demand, bicycle demand, cyclic time, weekend status and heavy-vehicle share.

This is one-step reinforcement learning (a contextual bandit). The agent explores anonymous actions and updates its selected action value from simulation feedback. Each reward target sums 30 matched SUMO repeats. It replays a finite table of batch rewards for 300,000 learning updates per agent, 2,700,000 total. Exploration remains at least 10 percent; neural learning rates decrease as training continues. Rewards are divided by 1,000 for numerical optimization and restored to score units on export. The checkpoint chart distinguishes value approximation error from the quality of the final permanent design.

Training contains 6,720 simulation records: 28 windows × eight candidates × 30 repeats. Weekday validation contains 960 records. Pre-period matching-physics records are reused and rescored; the planned test seeds are new to this release. Final testing contains {r['simulation_records']['test']:,} records across the distinct selected designs, unchanged, consultant and previous selection; all 30 test seeds are new relative to training/validation. Sensitivity adds {r['simulation_records']['sensitivity']:,} profile records, with identical non-speed cases reused under the half-speed-response profile. Agents selecting the same action share its matched outcomes. Do not multiply this record count by the number of agents or call learning updates fresh simulations.

The score is -1,000 per collision encounter and -5 per non-collision near-miss encounter. A distinct motor/VRU pair counts once, irrespective of detector frames; a colliding pair does not also earn a near-miss penalty. Three near misses score -15. One collision and three other near misses score -1,015. Event-free repeats score zero. The existing projected body-contact within 1.5 seconds rule defines a near miss. Every scheduled traveler must finish on the correct crossing without teleportation. More than 30 seconds of added mean motor delay makes a candidate ineligible.

## Frozen evaluation results
{finding(r)}

The highest observed test score among trained agents belongs to {', '.join(r['descriptive_best_test_agents'])}, choosing {best.action} with {int(best.collisions)} collision encounters and {int(best.near_misses)} near misses. Its mean paired score gain over the consultant is {best.mean_gain_vs_consultant:.2f} per batch, with 95% interval [{best.consultant_gain_low:.2f}, {best.consultant_gain_high:.2f}]. This descriptive comparison does not replace the preselected champion or turn test selection into independent validation.

The paired mean collision-count difference from the consultant is {a.mean_collision_diff_vs_consultant:.4f} encounters per 30-repeat batch, with 95% interval [{a.collision_diff_consultant_low:.4f}, {a.collision_diff_consultant_high:.4f}]. Negative means fewer simulated collisions. These intervals describe variation across observed traffic windows and seeded simulator draws, not field uncertainty.

The champion produced {int(a.collisions)} collision encounters and {int(a.near_misses)} near-miss encounters across 960 test repeats. The consultant design produced {int(h.collisions)} and {int(h.near_misses)}, respectively. Unchanged produced {int(b.collisions)} and {int(b.near_misses)}. The mean paired score gain over the consultant design was {a.mean_gain_vs_consultant:.2f} points per 30-repeat batch, with 95% interval [{a.consultant_gain_low:.2f}, {a.consultant_gain_high:.2f}]. The gain over unchanged was {a.mean_gain_vs_unchanged:.2f}, interval [{a.baseline_gain_low:.2f}, {a.baseline_gain_high:.2f}].

Under this reward, one collision has the same penalty as 200 near misses. A lower total penalty can therefore coexist with a higher collision count. Report collision counts separately; do not describe a score improvement alone as reduced collision probability.

The champion was selected among the final agents using only weekday validation scores. Agents choosing the same design tie on this criterion; the prespecified agent-ID tie break does not establish that one model family is superior. The model file, training data, validation data and protocol hashes were frozen before new May simulations. Earlier versions used these same source dates, so this remains retrospective development. Fresh seeds test conditional simulation generalization, not an untouched field study.

## Uncertainty and implementation roadblocks
Intervals resample the 32 observed traffic-window clusters, pairing each candidate with the comparison on the same travelers. They describe variation across these windows, not independent variability across seasons or schools. Only two post source dates exist. The separate cautious, tighter-gap and half-speed-response profiles stress behavior assumptions on the same eight windows. Those profiles are not measured local behavior frequencies.

Selecting the identical consultant candidate demonstrates agreement within the offered menu and yields identical matched runs; it is not independent validation of real-world injury reduction. A different design whose interval crosses zero has not been shown equivalent. More learning can reduce value-approximation error; more simulation draws can reduce Monte Carlo noise. Neither fixes incorrect geometry, missing driver behavior or absent field conflict labels. The current collision counts are simulator events rather than calibrated injury probabilities.

Transfer to Christensen or Altamont Creek requires local intersection geometry, school-period turning/crossing counts and observed speeds, followed by validation. Field conflict trajectories, dated as-built geometry and measured driver response are the main remaining evidence needs. The interface runs actual exported policy inference and displays saved simulations. The portable notebook retrains all nine agents, rebuilds figures, recomputes tests and runs a fresh 30-repeat Gymnasium step. It has been designed for Colab CPU; local execution is recorded separately from any hosted Colab claim.

## Source and appendix pointers
City of Livermore, East Avenue Tactical Bikeway final report: https://www.livermoreca.gov/home/showpublisheddocument/12943/638887914440930000

HMH memorandum, April 3, 2025: https://library.livermoreca.gov/home/showpublisheddocument/12945/638887914731000000

SUMO safety documentation: https://sumo.dlr.de/docs/Simulation/Safety.html

Appendix code: mitigation_priority/learn.py (selected-action learning and fixed design), environment.py (30 actual SUMO repeats), config.py (reward), verify.py (checks), protocol.md (frozen methodology). Validate publication metadata on the source title pages when preparing the final APA references.
'''
    (p/'Evidence_Update.md').write_text(text)
    body=[]
    for para in text.split('\n\n'):
        if para.startswith('# '):body.append('<h1>'+html.escape(para[2:])+'</h1>')
        elif para.startswith('## '):body.append('<h2>'+html.escape(para[3:])+'</h2>')
        else:body.append('<p>'+html.escape(para).replace('\n','<br>')+'</p>')
    (p/'Evidence_Update.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>v0.18 project evidence</title><style>body{max-width:900px;margin:30px auto;padding:0 20px;font:17px/1.6 Georgia;color:#153b50}h1,h2{font-family:system-ui}</style><a href="/mitigation-lab">Return to lab</a>'+''.join(body)+'</html>')

def bundle():
    paths=list((ROOT/'mitigation_priority').glob('*.py'))+[ROOT/'mitigation_priority/protocol.md']
    paths += [ROOT/'mitigation_rl'/f for f in ['__init__.py','prepare.py','simulator.py','events.py','learn.py']]
    paths += [ROOT/'mitigation_batch'/f for f in ['__init__.py','config.py','evaluate.py','learn.py']]
    paths += [ROOT/'sumo_v06/demand.py',ROOT/'sumo_v06/network.py',ROOT/'data/sumo_v06/traces.json',ROOT/'outputs/sumo_v02/calibration.json',ROOT/'outputs/sumo_v07/calibration.json',ROOT/'outputs/mitigation_rl/policy_freeze.json']
    for base in [DATA,ROOT/'data/mitigation_rl']:
        paths+=list(base.glob('*.csv'))+list(base.glob('*.json'))
        paths+=list((base/'networks').rglob('*.xml'))+list((base/'networks').rglob('*.json'))
    paths+=list((ROOT/'outputs/sumo_v06/networks/Estates/pilot').rglob('*.xml'))+list((ROOT/'outputs/sumo_v06/networks/Estates/pilot').rglob('*.json'))
    paths+=[p for p in OUT.glob('*.csv') if '.partial.' not in p.name]
    paths+=[p for p in OUT.glob('*.json') if not any(x in p.name for x in ['web_data','expected_inference','progress','checkpoints','notebook_validation'])]
    paths+=list(OUT.glob('*.png'))+list((OUT/'paper_materials').glob('*'))
    paths += [ROOT/'outputs/mitigation_training_audit/results.json',ROOT/'outputs/mitigation_training_audit/learning_checkpoints.csv']
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(set(paths)):z.write(p,p.relative_to(ROOT))
    (ROOT/'Estates_Collision_Priority.zip').write_bytes(buf.getvalue());return buf.getvalue()

def notebook(payload):
    nb=nbformat.v4.new_notebook();cells=[]
    md=lambda s:cells.append(nbformat.v4.new_markdown_cell(s));code=lambda s:cells.append(nbformat.v4.new_code_cell(s))
    md('''# Estates design learning · v0.18

## tl;dr
Nine agents train for **300,000 selected-action updates each**, then recommend one permanent design from eight available choices. The modeled consultant package is available anonymously. Each reward is the sum of **30 SUMO repeats: −1,000 per collision encounter and −5 per near miss**. This notebook retrains from saved simulation batches, rebuilds plots and runs a fresh batch on CPU. Learning updates are not fresh simulator runs.

## Context & methods
This is a fresh training experiment with collision penalty raised from −100 to −1,000. The original v0.17 code, models, notebook and results are preserved. Training and validation reuse raw pre-period events; test seeds 1400000–1400029 are new. The old selected design is evaluated alongside the new selection on identical fresh draws.

28 pre-installation traffic windows train; four separate weekday windows select the agent; 32 May windows test frozen choices on new seeds. These are observed 15-minute counts, with reconstructed geometry and frozen pre-period speed behavior. This is a retrospective simulation experiment, not calibrated real-world collision probability.

## Key assumptions
Bollards are idealized turn boundaries; additional paint/sign conspicuity effects are uncalibrated. The pilot drawing's date is uncertain relative to May counts. Encounter pairs count once, regardless of detector frames. Incomplete traveler accounting invalidates a batch. No post outcomes or consultant-choice label enter learning.''')
    md('**Released result:** '+finding(json.loads((OUT/'results.json').read_text())))
    code('''import sys,os,subprocess,importlib.util,importlib.metadata,pathlib,zipfile,base64,io,json,contextlib
packages={'nbformat':'nbformat','numpy':'numpy','pandas':'pandas','torch':'torch','gymnasium':'gymnasium','shapely':'shapely','matplotlib':'matplotlib','sumolib':'sumolib==1.27.1','libsumo':'libsumo==1.27.1','sumo':'eclipse-sumo==1.27.1'}
missing=[p for m,p in packages.items() if importlib.util.find_spec(m) is None]
for p in ['sumolib','libsumo','eclipse-sumo']:
    try:
        if importlib.metadata.version(p)!='1.27.1':missing.append(p+'==1.27.1')
    except importlib.metadata.PackageNotFoundError:pass
if missing:subprocess.check_call([sys.executable,'-m','pip','install','-q',*sorted(set(missing))])
workspace=pathlib.Path.cwd()/'estates_priority_run';workspace.mkdir(exist_ok=True)
payload="'''+base64.b64encode(payload).decode()+'''"
with zipfile.ZipFile(io.BytesIO(base64.b64decode(payload))) as z:z.extractall(workspace)
os.chdir(workspace);sys.path.insert(0,str(workspace));os.environ['MPLCONFIGDIR']=str(workspace/'.mplconfig')
import numpy as np,pandas as pd
pd.set_option('display.max_colwidth', None)
from IPython.display import display,Markdown,Image
OUT=workspace/'outputs/mitigation_priority';DATA=workspace/'data/mitigation_priority'
''')
    md('''## Inspect data and available designs
The learner sees anonymous IDs, not the consultant-selection key. The full design and component alternatives are available. The four validation windows include school-period pedestrian traffic.''')
    code('''from mitigation_priority.config import reward,ACTIONS
assert reward(0,3)==-15 and reward(1,3)==-1015
c=pd.read_csv(DATA/'contexts.csv');display(c.groupby('split')[['passenger','heavy','pedestrian','bicycle']].sum())
from mitigation_priority.deliver import display_candidates
display(pd.DataFrame(display_candidates())[['id','label','speed_limit_mph']])
from mitigation_priority.learn import scored
for split in ['train','validation','test']:
    d=scored(split);assert d.complete.all();print(split,len(d),'simulation records, all complete')
''')
    md('''## Retrain all nine agents
This cell makes **2.7 million learning updates**, replaying 6,720 saved SUMO training records grouped into 224 batch targets. Each update receives only its selected action's batch score. It does not run 2.7 million fresh simulations. The final 300,000-update checkpoints choose one design using average predicted training-context value. Weekday validation selects the champion; post data and benchmark identity remain withheld.''')
    code('''# A subprocess keeps multiprocessing portable in Colab/Jupyter.
subprocess.run([sys.executable,'-m','mitigation_priority.learn'],check=True,stdout=subprocess.PIPE,text=True)
freeze=json.loads((OUT/'policy_freeze.json').read_text())
assert freeze['total_updates']==2700000 and not freeze['consultant_identity_supplied_to_learner']
display(pd.read_csv(OUT/'validation_agents.csv')[['agent','updates','action','training_regret_to_best_fixed','validation_total_score']])
print('Validation-selected champion:',freeze['champion'])
assert freeze['reward']['collision']==-1000
''')
    md('''## Recompute held-out scores
Policies selecting the same physical design share the same matched simulation outcomes. A paired 95% interval above zero supports an improvement under this simulator. Identical design selection gives exactly zero difference, not an independent field validation.''')
    code('''from mitigation_priority.evaluate import main as evaluate
# If a different software platform yields a different final choice, simulate it.
required={r['action'] for r in freeze['agents'].values()}|{'C01','C07','C08'}
if not required.issubset(set(pd.read_csv(OUT/'test_runs.csv').action)):
    from mitigation_priority.runs import batch
    batch('test',sorted(required))
profile_required={freeze['agents'][freeze['champion']]['action'],'C01','C07','C08'}
if not profile_required.issubset(set(pd.read_csv(OUT/'sensitivity_runs.csv').action)):
    from mitigation_priority.runs import sensitivity
    sensitivity(sorted(profile_required))
with contextlib.redirect_stdout(io.StringIO()):evaluate()
display(pd.read_csv(OUT/'agent_choice_comparison.csv'))
display(pd.read_csv(OUT/'test_policies.csv')[['policy','action','total_score','collisions','near_misses','consultant_gain_low','consultant_gain_high']].round(2))
from mitigation_priority.plots import main as rebuild_figures
rebuild_figures()  # Editable source is bundled in mitigation_priority/plots.py.
display(Image(filename=str(OUT/'comparison.png')))
display(Image(filename=str(OUT/'collisions.png')))
''')
    md('''## Learning curves and behavior sensitivity
These figures are rebuilt from this run's checkpoints and recalculated results. Check whether the learner reduces value error and reaches the best fixed training design. Sensitivity profiles change illustrative behavior assumptions; they are not observed local probabilities.''')
    code('''display(Image(filename=str(OUT/'learning.png')))
display(Image(filename=str(OUT/'sensitivity.png')))
display(pd.read_csv(OUT/'sensitivity_policies.csv')[['profile','policy','action','total_score','collisions','near_misses']])
''')
    md('''## Execute a fresh 30-repeat SUMO batch
The agent's permanent design stays fixed. This cell uses fresh seeds for the May 18 07:30 traffic window and runs SUMO 30 times. The website performs policy inference but displays saved batches; this cell actually executes the simulator.''')
    code('''from mitigation_priority.environment import DesignBatchEnv
models=json.loads((OUT/'models.json').read_text());chosen=models[freeze['champion']]['fixed_action']
env=DesignBatchEnv('test');obs,info=env.reset(seed=413,options={'context_id':'20230518T073000','simulation_seed_start':1500400})
obs,total,terminated,truncated,detail=env.step(ACTIONS.index(chosen))
assert terminated and not truncated and len(detail['episode_scores'])==30
assert total==-1000*detail['collisions']-5*detail['near_misses']
display(pd.DataFrame([{'action':chosen,'repeats':30,'collisions':detail['collisions'],'near_misses':detail['near_misses'],'score':total}]))
print('Individual scores:',detail['episode_scores'])
''')
    md('''## Verification and documentation
The checks cover separate context/seed sets, matched travelers, all nine final 300k models, actual exported-value inference, unchanged benchmark geometry and cumulative rewards. They do not establish field safety effectiveness.''')
    code('''from mitigation_priority.verify import main as verify
verify()
from mitigation_priority.deliver import evidence
results=json.loads((OUT/'results.json').read_text());evidence(results)
display(Markdown((OUT/'paper_materials/Evidence_Update.md').read_text()))
''')
    md('''## Optional regeneration of every simulation
The default already retrains, recomputes evaluation and runs 30 fresh simulations. Enable below to rebuild all simulation tables on CPU. This can take much longer. Existing outputs and caches are moved to a backup within this notebook workspace.''')
    code('''RERUN_ALL=False
if RERUN_ALL:
    import shutil,time
    backup=workspace/f'prior_design_outputs_{time.time_ns()}';backup.mkdir()
    for name in ['train_runs.csv','validation_runs.csv','test_runs.csv','sensitivity_runs.csv','policy_freeze.json']:
        p=OUT/name
        if p.exists():shutil.move(str(p),str(backup/name))
    for p in [workspace/'outputs/mitigation_rl/episodes',OUT/'episodes']:
        if p.exists():shutil.move(str(p),str(backup/(p.parent.name+'_episodes')))
    subprocess.check_call([sys.executable,'-m','mitigation_priority.pipeline'])
else:print('Full regeneration disabled; the fresh 30-repeat batch above has run.')
''')
    nb.cells=cells;nb.metadata={'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python'}}
    nbformat.validate(nb);nbformat.write(nb,ROOT/'Estates_Collision_Priority.ipynb')

def main():
    r=json.loads((OUT/'results.json').read_text());models=json.loads((OUT/'models.json').read_text())
    from .plots import main as plots
    plots();evidence(r)
    pre=[]
    for split in ['train','validation']:
        tb=batches(scored(split))
        pre += [{'split':split,'action':a,**fixed_performance(a,tb)} for a in ACTIONS]
    pd.DataFrame(pre).to_csv(OUT/'available_design_scores.csv',index=False)
    c=pd.read_csv(DATA/'contexts.csv');train=c[c.split.eq('train')];test=c[c.split.eq('test')]
    b=pd.concat([pd.read_csv(OUT/'test_batches.csv'),batches(pd.read_csv(OUT/'scored_sensitivity_runs.csv'))],ignore_index=True)
    episodes=pd.concat([pd.read_csv(OUT/'scored_test_runs.csv'),pd.read_csv(OUT/'scored_sensitivity_runs.csv')])
    allowed=[a for a in ACTIONS if fixed_performance(a,batches(scored('train')))['eligible']]
    web={'results':r,'models':models,'finding':finding(r),'candidates':display_candidates(),
         'source_coverage':json.loads((DATA/'source_coverage.json').read_text()),'profile_labels':PROFILE_LABELS,'available_design_scores':pre,
         'training_contexts':train.to_dict('records'),'allowed_actions':allowed,'contexts':test.to_dict('records'),
         'sensitivity_contexts':SENSITIVITY_CONTEXTS,'batches':json.loads(b.to_json(orient='records')),
         'learning':json.loads(pd.read_csv(OUT/'learning_checkpoints.csv').to_json(orient='records')),
         'episodes':json.loads(episodes[['context_id','profile','action','seed','collision_pairs','near_pairs','score','complete']].to_json(orient='records'))}
    (OUT/'web_data.json').write_text(json.dumps(web,allow_nan=False))
    expected={n:{'q':values(m,train).tolist(),'mean_q':values(m,train).mean(0).tolist(),'action':m['fixed_action']} for n,m in models.items()}
    (OUT/'expected_inference.json').write_text(json.dumps(expected))
    payload=bundle();notebook(payload);print(finding(r));print('Bundle bytes',len(payload))
if __name__=='__main__':main()
