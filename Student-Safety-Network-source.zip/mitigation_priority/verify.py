"""Scientific invariants, preserved geometry, reward and portable inference."""
import json
import numpy as np,pandas as pd
from mitigation_rl.learn import values
from mitigation_batch.config import SENSITIVITY_CONTEXTS,PROFILES
from .config import ROOT,DATA,OUT,ACTIONS,TEST_SEEDS,VALIDATION_SEEDS,PREVIOUS_ACTION,sha,reward
from .learn import scored,batches,fixed_performance

def main():
    f=json.loads((OUT/'policy_freeze.json').read_text());models=json.loads((OUT/'models.json').read_text())
    c=pd.read_csv(DATA/'contexts.csv');tr=c[c.split.eq('train')]
    assert c.context_id.is_unique
    assert c.groupby('split').size().to_dict()=={'test':32,'train':28,'validation':4}
    assert reward(0,3)==-15 and reward(1,3)==-1015 and reward(0,0)==0
    assert sha(ROOT/'mitigation_priority/config.py')==f['config_sha256']
    assert f['reward']['collision']==-1000 and f['reward']['near_miss']==-5
    for filename,field in [('models.json','models_sha256'),('train_runs.csv','train_sha256'),('validation_runs.csv','validation_sha256')]:
        assert sha(OUT/filename)==f[field],filename+' changed after freeze'
    assert sha(ROOT/'mitigation_priority/protocol.md')==f['protocol_sha256']
    assert sha(ROOT/'mitigation_priority/learn.py')==f['trainer_sha256']
    for name,field in [('contexts.csv','contexts_sha256'),('observations.csv','observations_sha256'),('candidates.json','candidate_catalog_sha256')]:
        assert sha(DATA/name)==f[field]
    for a in json.loads((DATA/'candidates.json').read_text()):
        assert sha(DATA/'networks'/a['id']/'network.net.xml')==a['network_sha256']
    assert sha(DATA/'networks/C07/network.net.xml')==sha(ROOT/'outputs/sumo_v06/networks/Estates/pilot/network.net.xml')
    sets={};counts={}
    for split in ['train','validation','test']:
        d=scored(split);assert d.complete.all();assert set(d.split)=={split}
        sets[split]=set(d.seed);counts[split]=len(d)
        expected=len(c[c.split.eq(split)])*30*(8 if split!='test' else len(set(x['action'] for x in f['agents'].values())|{'C01','C07',PREVIOUS_ACTION}))
        assert len(d)==expected
        assert set(d.action)==(set(ACTIONS) if split!='test' else set(x['action'] for x in f['agents'].values())|{'C01','C07',PREVIOUS_ACTION})
    assert sets['validation']==set(VALIDATION_SEEDS) and sets['test']==set(TEST_SEEDS)
    assert not sets['test']&set(range(1200000,1200030)), 'v0.17 test seeds reused'
    assert all(not sets[a]&sets[b] for a,b in [('train','validation'),('train','test'),('validation','test')])
    tb=batches(scored('train'));allowed=np.array([fixed_performance(a,tb)['eligible'] for a in ACTIONS])
    assert len(models)==9 and f['total_updates']==2700000 and f['fixed_design']
    assert not f['consultant_identity_supplied_to_learner'] and not f['test_outcomes_in_training']
    for name,m in models.items():
        assert m['steps']==300000
        q=values(m,tr).mean(0);assert np.allclose(q,m['training_context_mean_q'])
        chosen=ACTIONS[int(np.argmax(np.where(allowed,q,-np.inf)))]
        assert chosen==m['fixed_action']==f['agents'][name]['action']
    hist=pd.read_csv(OUT/'learning_checkpoints.csv')
    assert len(hist)==36 and hist.groupby('agent').updates.max().eq(300000).all()
    assert all(sum(json.loads(x))==u for x,u in zip(hist.action_update_counts,hist.updates))
    s=pd.read_csv(OUT/'sensitivity_runs.csv')
    assert set(s.context_id)==set(SENSITIVITY_CONTEXTS) and set(s.profile)==set(PROFILES)
    assert s.complete.all() and s.groupby(['profile','context_id','action']).size().eq(30).all()
    assert s.groupby(['profile','context_id','seed']).traveler_sha256.nunique().eq(1).all()
    assert not s.duplicated(['profile','context_id','action','seed']).any()
    policies=pd.read_csv(OUT/'test_policies.csv')
    assert policies[policies.policy.eq('previous_selection')].action.tolist()==[PREVIOUS_ACTION]
    assert policies.episodes.eq(960).all()
    for r in policies.itertuples():assert r.total_score==reward(r.collisions,r.near_misses)
    test=scored('test');half=s[s.profile.eq('half_speed_response') & ~s.action.isin(['C02','C04','C08'])]
    paired=half.merge(test,on=['context_id','action','seed'],suffixes=('_half','_nominal'))
    for col in ['collision_pairs','near_pairs','mean_motor_delay']:
        assert np.allclose(paired[col+'_half'],paired[col+'_nominal'])
    prior=json.loads((OUT/'preparation.json').read_text())['preserved_files']
    prior_available=all((ROOT/p).exists() for p in prior)
    if prior_available:
        for p,digest in prior.items():assert sha(ROOT/p)==digest,'Prior release changed: '+p
    receipt={'passed':True,'agents_at_300000_updates':9,'learning_updates':2700000,'records':counts,
             'reward':f['reward'],'new_test_seeds_vs_v017':True,'prior_release_hashes_verified':True if prior_available else None,'prior_release_check_scope':'original workspace' if prior_available else 'original release files not included in portable bundle',
             'sensitivity_records':len(s),'fixed_design_inference_verified':True,'all_travelers_completed':True,
             'disjoint_seed_ranges':True,'matched_travelers':True,'benchmark_geometry_preserved':True,
             'reward_is_cumulative':True,'frozen_hashes_verified':True}
    (OUT/'verification.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
if __name__=='__main__':main()
