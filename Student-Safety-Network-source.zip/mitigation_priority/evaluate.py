import json
import numpy as np,pandas as pd
from mitigation_batch.evaluate import ci
from .config import ROOT,DATA,OUT,sha,reward,PREVIOUS_ACTION
from .learn import scored,batches

def summarize(b,policies,benchmark,profile):
    reference=b[b.action.eq(benchmark)].set_index('context_id');rows=[]
    previous=b[b.action.eq(PREVIOUS_ACTION)].set_index('context_id')
    baseline=b[b.action.eq('C01')].set_index('context_id')
    for name,action in policies.items():
        p=b[b.action.eq(action)].set_index('context_id').sort_index()
        if set(p.index)!=set(reference.index):raise ValueError(f'Missing complete test batches for {name}: {action}')
        h=reference.loc[p.index]
        valid=bool(p.complete.all() and p.base_complete.all() and h.complete.all())
        gain=p.score-h.score;basegain=p.score-p.base_score
        low,high=ci(gain);bl,bh=ci(basegain)
        previous_gain=p.score-previous.loc[p.index].score
        pl,ph=ci(previous_gain)
        collision_deltas={}
        for suffix,other in [('consultant',h),('unchanged',baseline.loc[p.index]),('previous',previous.loc[p.index])]:
            delta=p.collisions-other.collisions;cl,ch=ci(delta)
            collision_deltas.update({f'mean_collision_diff_vs_{suffix}':float(delta.mean()),f'collision_diff_{suffix}_low':cl,f'collision_diff_{suffix}_high':ch})
        rows.append({'profile':profile,'policy':name,'action':action,'contexts':len(p),'episodes':len(p)*30,
                     'total_score':float(p.score.sum()) if valid else None,'collisions':int(p.collisions.sum()),'near_misses':int(p.near_misses.sum()),
                     'mean_gain_vs_consultant':float(gain.mean()) if valid else None,'consultant_gain_low':low,'consultant_gain_high':high,
                     'mean_gain_vs_unchanged':float(basegain.mean()) if valid else None,'baseline_gain_low':bl,'baseline_gain_high':bh,
                     'mean_gain_vs_previous':float(previous_gain.mean()),'previous_gain_low':pl,'previous_gain_high':ph,
                     **collision_deltas,
                     'eligible':bool(valid and (p.delay-p.base_delay).mean()<=30),'delay_increase_s':float((p.delay-p.base_delay).mean()),'same_physical_design_as_consultant':action==benchmark})
    return rows

def main():
    f=json.loads((OUT/'policy_freeze.json').read_text());assert sha(OUT/'models.json')==f['models_sha256']
    key=json.loads((DATA/'benchmark_key.json').read_text());benchmark=key['consultant_candidate'];baseline=key['baseline']
    policies={n:r['action'] for n,r in f['agents'].items()};policies.update(unchanged=baseline,consultant=benchmark,previous_selection=PREVIOUS_ACTION)
    d=scored('test');b=batches(d);rows=summarize(b,policies,benchmark,'nominal')
    d.to_csv(OUT/'scored_test_runs.csv',index=False);b.to_csv(OUT/'test_batches.csv',index=False);pd.DataFrame(rows).to_csv(OUT/'test_policies.csv',index=False)
    sensitivity=[]
    if (OUT/'sensitivity_runs.csv').exists():
        s=pd.read_csv(OUT/'sensitivity_runs.csv');s['score']=[reward(r.collision_pairs,r.near_pairs) if r.complete else np.nan for r in s.itertuples()]
        chosen={f['champion']:f['agents'][f['champion']]['action'],'unchanged':baseline,'consultant':benchmark,'previous_selection':PREVIOUS_ACTION}
        for profile,z in [('nominal_subset',d[d.context_id.isin(s.context_id.unique())])]+list(s.groupby('profile')):
            sensitivity+=summarize(batches(z),chosen,benchmark,profile)
        s.to_csv(OUT/'scored_sensitivity_runs.csv',index=False);pd.DataFrame(sensitivity).to_csv(OUT/'sensitivity_policies.csv',index=False)
    agent_rows=[z for z in rows if z['policy'] in f['agents'] and z['eligible']]
    best_score=max(z['total_score'] for z in agent_rows)
    best_agents=sorted(z['policy'] for z in agent_rows if z['total_score']==best_score)
    old=json.loads((OUT/'previous_selection.json').read_text())
    choices=[{'agent':n,'previous_action':old['agents'][n],'new_action':v['action'],'changed':old['agents'][n]!=v['action']} for n,v in sorted(f['agents'].items())]
    pd.DataFrame(choices).to_csv(OUT/'agent_choice_comparison.csv',index=False)
    r={'agent_choices':choices,'descriptive_best_test_agents':best_agents,'release':'0.18','freeze':f,'reward':f['reward'],'previous_candidate':PREVIOUS_ACTION,'benchmark_candidate':benchmark,'baseline_candidate':baseline,'policies':rows,'sensitivity':sensitivity,
       'simulation_records':{p:len(pd.read_csv(OUT/f'{p}_runs.csv')) for p in ['train','validation','test','sensitivity']},
       'scope':'Anonymous candidate selection; complete modeled consultant design was available. Conditional simulation comparison, not real-world safety validation.'}
    (OUT/'results.json').write_text(json.dumps(r,indent=2,allow_nan=False));print(pd.DataFrame(rows)[['policy','action','total_score','collisions','near_misses','same_physical_design_as_consultant']].to_string(index=False))

if __name__=='__main__':main()
