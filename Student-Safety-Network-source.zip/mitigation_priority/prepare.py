import copy,json,shutil
import pandas as pd
from .config import ROOT,DATA,OUT,ACTIONS,VALIDATION,sha

LABELS=['Unchanged','25 mph operating response','Small generic curb extensions','Small curbs + 25 mph',
        'Protected curb extensions + shortened marked crossings','Painted medians + marked crossings',
        'Protected curbs + medians + marked crossings','Protected curbs + medians + marked crossings + 25 mph']

def main():
    DATA.mkdir(exist_ok=True);OUT.mkdir(exist_ok=True)
    obs=pd.read_csv(ROOT/'data/mitigation_rl/observations.csv');c=pd.read_csv(ROOT/'data/mitigation_rl/contexts.csv')
    for frame in [obs,c]:
        frame['original_split']=frame['split'];frame['split']=frame.context_id.map(lambda s:'test' if s.startswith('202305') else 'validation' if s in VALIDATION else 'train')
    obs.to_csv(DATA/'observations.csv',index=False);c.to_csv(DATA/'contexts.csv',index=False)
    import sumo_v06.network as builder
    trace=json.loads((ROOT/'data/sumo_v06/traces.json').read_text())
    nets=DATA/'networks';nets.mkdir(exist_ok=True)
    for i,old in enumerate(['A0','A1','A2','A3']):shutil.copytree(ROOT/'data/mitigation_rl/networks'/old,nets/ACTIONS[i],dirs_exist_ok=True)
    # Independently offer the implemented curb and median components. Their
    # dimensions are available choices; their selection by consultants is not a label.
    for candidate,curbs,medians in [('C05',True,False),('C06',False,True)]:
        spec=copy.deepcopy(trace);e=spec['Estates']
        if not curbs:
            for v in e['corners'].values():v['pilot']=copy.deepcopy(v['before'])
            for v in e['crossings'].values():v['pilot']=copy.deepcopy(v['before'])
        if not medians:e['medians']=[]
        builder.TRACE=spec;builder.OUT=OUT/'build'/candidate
        src=builder.build('Estates','pilot');shutil.copytree(src,nets/candidate,dirs_exist_ok=True)
    shutil.copytree(ROOT/'outputs/sumo_v06/networks/Estates/pilot',nets/'C07',dirs_exist_ok=True)
    from mitigation_rl.prepare import speed_network
    speed_network(nets/'C07',nets/'C08')
    catalog=[]
    for a,label in zip(ACTIONS,LABELS):
        catalog.append({'id':a,'label':label,'network_sha256':sha(nets/a/'network.net.xml'),
                        'protected_curbs':a in ['C05','C07','C08'],'painted_medians':a in ['C06','C07','C08'],
                        'marked_crossings_and_yield_signs':a in ['C05','C06','C07','C08'],
                        'bollard_boundaries':a in ['C05','C06','C07','C08'],'speed_limit_mph':25 if a in ['C02','C04','C08'] else 30})
    (DATA/'candidates.json').write_text(json.dumps(catalog,indent=2))
    (DATA/'benchmark_key.json').write_text(json.dumps({'consultant_candidate':'C07','baseline':'C01','not_a_training_label':True},indent=2))
    (DATA/'source_coverage.json').write_text(json.dumps({'sources':['data/traffic_exposure/raw/east_avenue_tactical_final_2024.layout.txt','data/sumo_v06/raw/permanent_treatments_april_2025.txt'],
       'implemented_components':['protected painted curb extensions','painted medians','high-visibility crosswalks','K71 bollards','in-street pedestrian yield signs'],
       'speed_humps':'Not identified as an installed Estates treatment; mentions elsewhere concern other cities or future proposals.',
       'representation':{'curbs':'Source-traced boundaries and shorter crossing paths','medians':'Source-traced channelization boundaries','bollards':'Idealized boundary-constrained turning paths, not impact/deformation physics','markings_and_signs':'Crossing geometry and yielding controls; additional perception/compliance benefit uncalibrated'},
       'geometry_date':'April 2025 existing-pilot drawing; not certified May 2023 as-built'},indent=2))
    (OUT/'preparation.json').write_text(json.dumps({'protocol_sha256':sha(ROOT/'mitigation_priority/protocol.md'),'context_counts':c.split.value_counts().to_dict(),'all_eight_candidates_built':True,'benchmark_matches_previous_network':sha(nets/'C07/network.net.xml')==sha(ROOT/'outputs/sumo_v06/networks/Estates/pilot/network.net.xml')},indent=2))
    print(c.groupby('split')[['pedestrian','bicycle']].agg(['sum','count']).to_string())

if __name__=='__main__':main()
