"""Descriptive rankings using the city's published intersection classification."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point
from shapely.ops import unary_union
from road_month_experiment import road_key,undirected_key

def street_label(key):
    words={'AV':'Avenue','BL':'Boulevard','RD':'Road','ST':'Street','DR':'Drive','WY':'Way','LN':'Lane','CT':'Court','CI':'Circle','LP':'Loop','PW':'Parkway','CYN':'Canyon','I580':'I-580'}
    if key=='E AV':return 'East Avenue'
    return ' '.join(words.get(w,w.title() if len(w)>1 else w) for w in key.split())

def point_parts(geometry):
    if geometry.is_empty:return []
    if geometry.geom_type=='Point':return [geometry]
    if hasattr(geometry,'geoms'):
        return [point for part in geometry.geoms for point in point_parts(part)]
    return []

def rank_intersections(city_cases,schools,roads,output):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    c=city_cases.copy()
    assert not c.CASE_ID.duplicated().any()
    c=c.loc[c.PEDESTRIAN_ACCIDENT.eq('Y')|c.BICYCLE_ACCIDENT.eq('Y')].copy()
    assert c.ACCIDENT_YEAR.between(2020,2024).all()
    total=len(c)
    c=c.loc[c.Intersection_TJKM.eq('Y')].copy()
    c['road_a']=c.PRIMARY_RD.map(road_key).map(undirected_key)
    c['road_b']=c.SECONDARY_RD.map(road_key).map(undirected_key)
    c['junction_key']=c.apply(lambda r:' | '.join(sorted([r.road_a,r.road_b])),axis=1)
    c=c.to_crs(26910)
    school=schools.loc[schools.school_id.eq('01612006085773')].to_crs(26910)
    assert len(school)==1
    school_point=school.geometry.iloc[0]
    road=roads.to_crs(26910).copy()
    road['key']=road.FullStreetName.map(road_key).map(undirected_key)
    lines={key:unary_union(group.geometry.tolist()) for key,group in road.groupby('key')}
    rows=[]
    for key,group in c.groupby('junction_key'):
        a,b=key.split(' | ')
        centre=Point(float(group.geometry.x.median()),float(group.geometry.y.median()))
        span=max(group.geometry.distance(centre))
        if span>160:raise ValueError('Road-pair groups need spatial review: '+key)
        candidates=point_parts(lines[a].intersection(lines[b])) if a in lines and b in lines else []
        closest=min(candidates,key=lambda p:p.distance(centre)) if candidates else None
        if closest is not None and closest.distance(centre)<=125:
            point=closest;method='Crossing of current named road geometries';error_m=30.
        else:
            point=centre;method='Median source collision position; junction approximate';error_m=100.+span
        miles=point.distance(school_point)/1609.344
        # Approximate positions close to the cutoff are not silently admitted.
        membership='within' if miles+error_m/1609.344<=2 else ('outside' if miles-error_m/1609.344>2 else 'boundary_uncertain')
        lonlat=gpd.GeoSeries([point],crs=26910).to_crs(4326).iloc[0]
        rows.append({'junction_key':key,'intersection':street_label(a)+' & '+street_label(b),
            'pedbike_collisions':len(group),'fatal_collisions':int(group.COLLISION_SEVERITY.eq(1).sum()),
            'serious_collisions':int(group.COLLISION_SEVERITY.eq(2).sum()),
            'fatal_or_serious':int(group.COLLISION_SEVERITY.isin([1,2]).sum()),
            'pedestrian_collisions':int(group.PEDESTRIAN_ACCIDENT.eq('Y').sum()),
            'bicycle_collisions':int(group.BICYCLE_ACCIDENT.eq('Y').sum()),
            'strict_at_intersection_collisions':int(group.INTERSECTION.eq('Y').sum()),
            'miles_from_christensen':miles,'within_two_miles':membership,'location_method':method,
            'source_point_spread_metres':span,'longitude':lonlat.x,'latitude':lonlat.y,
            'case_ids':';'.join(sorted(group.CASE_ID.astype(str))),
            'period':'2020-2024 city injury/fatal collision layer'})
    all_rows=pd.DataFrame(rows)
    def ordered(frame):
        frame=frame.sort_values(['pedbike_collisions','fatal_or_serious','fatal_collisions','intersection'],ascending=[False,False,False,True]).reset_index(drop=True)
        scores=list(zip(frame.pedbike_collisions,frame.fatal_or_serious,frame.fatal_collisions))
        frame['rank']=[scores.index(s)+1 for s in scores]
        frame['same_score_intersections']=[scores.count(s) for s in scores]
        return frame
    city=ordered(all_rows);nearby=ordered(all_rows.loc[all_rows.within_two_miles.eq('within')])
    city.to_csv(output/'livermore_all_intersection_rankings.csv',index=False)
    nearby.to_csv(output/'christensen_two_mile_rankings.csv',index=False)
    city.head(5).to_csv(output/'livermore_top_five.csv',index=False)
    nearby.head(5).to_csv(output/'christensen_top_five.csv',index=False)
    c.drop(columns='geometry').to_csv(output/'intersection_case_audit.csv',index=False)
    protocol={'period':'2020-2024','source':'City of Livermore published collision layer',
        'mode':'Pedestrian or bicycle involvement; unique crash counted once even if both',
        'intersection_definition':'Published Intersection_TJKM=Y, including nearby approaches; also retain stricter INTERSECTION=Y counts',
        'order':'Collision count descending, fatal/serious count descending, fatal count descending, alphabetical display within ties',
        'city_pedbike_cases':total,'intersection_associated_cases':len(c),'ranked_intersections':len(city),
        'within_two_miles_intersections':len(nearby),'boundary_uncertain':int(all_rows.within_two_miles.eq('boundary_uncertain').sum()),
        'school_name':school.school_name.iloc[0],'school_id':school.school_id.iloc[0],
        'radius':'2 statute miles straight line; UTM 26910; approximate boundary locations flagged',
        'interpretation':'Recorded collision burden, not exposure-adjusted danger or a model prediction. Top-five cutoff can split ties.',
        'excluded':'Other modes; property-damage-only events absent from city layer; mid-block cases; unreported cases. Not merged with CCRS.'}
    (output/'ranking_protocol.json').write_text(json.dumps(protocol,indent=2))
    return city,nearby,protocol
