"""Exploratory Livermore road-month occurrence model; frozen public snapshot."""
# %% imports
from pathlib import Path
import json
import re
import time
import warnings
import numpy as np
import pandas as pd
import geopandas as gpd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import average_precision_score, roc_auc_score, brier_score_loss, log_loss
from sklearn.exceptions import ConvergenceWarning

NUMERIC = ['posted_speed_mph', 'posted_speed_missing', 'lanes', 'log_length_m',
           'season_sin', 'season_cos', 'prior12_positive_months', 'prior12_known_share']
CATEGORICAL = ['road_class']
MODELS = ['Constant prevalence', 'Logistic without speed', 'Logistic with speed', 'Neural network with speed']
PROTOCOL = {
    'target': 'At least one source pedestrian/bicycle collision assigned to a Livermore segment in a calendar month',
    'source_years': list(range(2016,2026)),
    'training_target_years': list(range(2017,2024)), 'validation_year': 2024, 'test_year': 2025,
    'selection_metric': 'validation binary log loss', 'seed': 42, 'pca': False,
    'match_distance_metres': 30, 'ambiguity_margin_metres': 5,
    'match_rule': 'Existing coordinate within 30 m of matching normalized primary-road name; nearest candidate must lead runner-up by more than 5 m',
    'zero_rule': 'No assigned crash and no unresolved crash that could belong to that segment/month; source reporting coverage assumed, not certified',
    'road_history_assumption': 'Current active road geometry, class, lanes and posted values treated as fixed historical context; historical correctness unverified',
    'backtest': 'Retrospective conditional experiment, not historical as-of validation; 2025 city totals have already been inspected in another experiment',
    'neural_network': {'hidden_layer_sizes': [8], 'activation': 'tanh', 'solver': 'lbfgs', 'alpha': 10, 'max_iter': 500, 'max_fun': 10000},
    'no_oversampling': True, 'no_class_weighting': True,
    'model_output': 'Experimental monthly probability conditional on snapshot assumptions; not calibrated school/year risk or a causal effect'}

# %% preparation
def road_key(value):
    if pd.isna(value):
        return ''
    text = re.sub(r'^\s*\d+\s+', '', str(value).upper())  # House numbers, not numbered street ordinals.
    text = re.sub(r'\b(?:INTERSTATE\s*-?\s*|I\s*-?\s*)580\b', 'I580', text)
    tokens = re.sub(r'[^A-Z0-9 ]', ' ', text).split()
    aliases = {'AVENUE':'AV', 'AVE':'AV', 'BOULEVARD':'BL', 'BLVD':'BL', 'ROAD':'RD',
               'STREET':'ST', 'DRIVE':'DR', 'COURT':'CT', 'CIRCLE':'CI', 'CIR':'CI',
               'WAY':'WY', 'LANE':'LN', 'PARKWAY':'PW', 'PKWY':'PW', 'PLACE':'PL',
               'NORTH':'N', 'SOUTH':'S', 'EAST':'E', 'WEST':'W', 'TERRACE':'TE', 'TER':'TE',
               'EASTBOUND':'EB','WESTBOUND':'WB','NORTHBOUND':'NB','SOUTHBOUND':'SB',
               '1ST':'FIRST','2ND':'SECOND','3RD':'THIRD','4TH':'FOURTH','5TH':'FIFTH',
               '6TH':'SIXTH','7TH':'SEVENTH','8TH':'EIGHTH','9TH':'NINTH','10TH':'TENTH'}
    return ' '.join(aliases.get(t, t) for t in tokens)


def undirected_key(key):
    words = key.split()
    return ' '.join(words[1:]) if len(words)>2 and words[0] in ['N','S','E','W'] else key


def assign_crashes(roads, crashes):
    """Never manufacture a point for missing coordinates. Keep every match decision."""
    roads = roads.loc[roads.Status.eq('Active')].copy().reset_index(drop=True)
    if roads.segment_id.duplicated().any() or roads.segment_id.isna().any():
        raise ValueError('Invalid segment IDs.')
    crashes = crashes.copy()
    if crashes.case_id.isna().any() or crashes.case_id.duplicated().any():
        raise ValueError('Invalid collision IDs.')
    crashes['date'] = pd.to_datetime(crashes.date, errors='raise')
    if crashes.date.isna().any() or not crashes.date.dt.year.between(min(PROTOCOL['source_years']), max(PROTOCOL['source_years'])).all():
        raise ValueError('Review dates before extending this protocol.')
    roads['road_key'] = roads.FullStreetName.map(road_key)
    projected = roads.to_crs('EPSG:26910')
    by_name = {name: group.index.to_numpy() for name, group in roads.groupby('road_key') if name}
    roads['undirected_key'] = roads.road_key.map(undirected_key)
    by_undirected = {name: group.index.to_numpy() for name, group in roads.groupby('undirected_key') if name}
    decisions = []
    for _, crash in crashes.iterrows():
        key = road_key(crash.PrimaryRoad)
        indexes = by_name.get(key, np.array([], dtype=int))
        match_name_rule = 'exact_normalized'
        # If the source omits N/S/E/W, coordinate matching can resolve the candidates.
        # Never drop a supplied direction merely to force a match.
        if not len(indexes) and key == undirected_key(key):
            indexes = by_undirected.get(key, np.array([], dtype=int))
            match_name_rule = 'source_direction_omitted'
        chosen = None
        distance = np.nan
        status = 'primary_road_unmatched'
        # Candidate zero exclusions use the entire primary road, including ambiguous intersections.
        possible = roads.loc[indexes, 'segment_id'].tolist()
        latitude, longitude = pd.to_numeric(crash.Latitude, errors='coerce'), pd.to_numeric(crash.Longitude, errors='coerce')
        valid = np.isfinite(latitude) and np.isfinite(longitude) and 37 < latitude < 38.3 and -123 < longitude < -120.8
        if len(indexes):
            status = 'missing_or_invalid_coordinate'
            if valid:
                point = gpd.GeoSeries(gpd.points_from_xy([longitude], [latitude]), crs=4326).to_crs(projected.crs).iloc[0]
                distances = projected.loc[indexes].distance(point).sort_values(kind='stable')
                distance = float(distances.iloc[0])
                if distance > PROTOCOL['match_distance_metres']:
                    status = 'coordinate_road_disagreement'
                elif len(distances) > 1 and distances.iloc[1] - distance <= PROTOCOL['ambiguity_margin_metres']:
                    status = 'ambiguous_adjacent_segments'
                else:
                    chosen = roads.loc[distances.index[0], 'segment_id']
                    status = 'coordinate_and_primary_road_match'
        decisions.append({'case_id': str(crash.case_id), 'month': crash.date.to_period('M').to_timestamp(),
            'PrimaryRoad': crash.PrimaryRoad, 'SecondaryRoad': crash.SecondaryRoad,
            'segment_id': chosen, 'match_status': status, 'road_name_rule':match_name_rule, 'nearest_named_road_distance_m': distance,
            'possible_segment_ids': possible, 'block_all_segments': not len(possible) and chosen is None})
    decisions = pd.DataFrame(decisions)
    return roads, decisions


def make_monthly_panel(roads, decisions, start_year=2016, end_year=2025):
    """Complete Cartesian grid; uncertain labels remain nullable rather than false."""
    months = pd.date_range(f'{start_year}-01-01', f'{end_year}-12-01', freq='MS')
    if not decisions.month.isin(months).all():
        raise ValueError('Source case lies outside the requested grid.')
    grid = pd.MultiIndex.from_product([roads.segment_id, months], names=['segment_id', 'month'])
    counts = decisions.loc[decisions.segment_id.notna()].groupby(['segment_id', 'month']).size()
    panel = counts.reindex(grid, fill_value=0).rename('assigned_collision_count').reset_index()
    panel['uncertain_location'] = False
    unknown_pairs, unknown_months = set(), set()
    for row in decisions.loc[decisions.segment_id.isna()].itertuples():
        if row.block_all_segments:
            unknown_months.add(row.month)
        else:
            unknown_pairs.update((sid, row.month) for sid in row.possible_segment_ids)
    uncertain = grid.isin(list(unknown_pairs)) | panel.month.isin(unknown_months).to_numpy()
    panel['uncertain_location'] = uncertain
    panel['collision_occurred'] = panel.assigned_collision_count.gt(0).astype('Int64')
    panel.loc[panel.uncertain_location & panel.assigned_collision_count.eq(0), 'collision_occurred'] = pd.NA
    panel['label_status'] = np.select([panel.collision_occurred.eq(1).fillna(False).to_numpy(dtype=bool),
        panel.collision_occurred.eq(0).fillna(False).to_numpy(dtype=bool)],
        ['positive_assigned_record', 'zero_under_coverage_assumption'], default='unknown_location')
    panel['posted_speed_history_verified'] = False
    return panel


def feature_rows(panel, roads):
    frame = panel.sort_values(['segment_id', 'month']).copy()
    if frame.duplicated(['segment_id','month']).any():
        raise ValueError('Duplicate segment-month rows.')
    # Shift before rolling: the target month never enters its own history features.
    frame['_positive'] = frame.collision_occurred.fillna(0).astype(float)
    frame['_known'] = frame.collision_occurred.notna().astype(float)
    frame['prior12_positive_months'] = frame.groupby('segment_id')._positive.transform(lambda s: s.shift(1).rolling(12,min_periods=12).sum())
    frame['prior12_known_share'] = frame.groupby('segment_id')._known.transform(lambda s: s.shift(1).rolling(12,min_periods=12).mean())
    context = roads[['segment_id', 'FullStreetName', 'posted_speed_mph', 'NumberOfLanes', 'FunctionalClass', 'length_m']].copy()
    context = context.rename(columns={'NumberOfLanes':'lanes','FunctionalClass':'road_class'})
    context['posted_speed_missing'] = context.posted_speed_mph.isna().astype(int)
    context['lanes'] = pd.to_numeric(context.lanes, errors='coerce').where(lambda x: x.gt(0))
    context['road_class'] = context.road_class.fillna('Unknown').astype(str)
    context['log_length_m'] = np.log1p(context.length_m)
    frame = frame.merge(context, on='segment_id', how='left', validate='many_to_one')
    frame['season_sin'] = np.sin(2*np.pi*frame.month.dt.month/12)
    frame['season_cos'] = np.cos(2*np.pi*frame.month.dt.month/12)
    frame['feature_cutoff'] = frame.month - pd.Timedelta(days=1)
    history_year = int(frame.month.dt.year.min())
    frame['split'] = np.select([frame.month.dt.year.le(history_year), frame.month.dt.year.le(2023), frame.month.dt.year.eq(2024)],
                              ['history','train','validation'], default='test')
    return frame.drop(columns=['_positive','_known'])

# %% training
def make_model(name):
    numeric = NUMERIC if name != 'Logistic without speed' else [n for n in NUMERIC if n not in ['posted_speed_mph', 'posted_speed_missing']]
    preprocessing = ColumnTransformer([
        ('numeric', Pipeline([('impute', SimpleImputer(strategy='median', keep_empty_features=True)),
                             ('scale', StandardScaler())]), numeric),
        ('categorical', OneHotEncoder(handle_unknown='ignore', sparse_output=False), CATEGORICAL)])
    if name == 'Neural network with speed':
        estimator = MLPClassifier(hidden_layer_sizes=(8,), activation='tanh', solver='lbfgs',
            alpha=10., random_state=42, max_iter=500, max_fun=10000, tol=1e-6)
    else:
        estimator = LogisticRegression(C=1., solver='lbfgs', max_iter=1000)
    return Pipeline([('preprocess',preprocessing), ('model',estimator)])


def probability_scores(y, p):
    y = np.asarray(y, dtype=int)
    p = np.clip(np.asarray(p, dtype=float), 1e-12, 1-1e-12)
    if not np.isfinite(p).all():
        raise ValueError('Nonfinite probability.')
    # Capacity-based ranking is a diagnostic; it does not tune a test threshold.
    k = max(1, int(np.ceil(len(y)*.01)))
    top = np.argsort(-p, kind='stable')[:k]
    return {'rows': len(y), 'positive_months': int(y.sum()), 'prevalence': float(y.mean()),
        'log_loss': float(log_loss(y,p,labels=[0,1])), 'brier_score': float(brier_score_loss(y,p)),
        'average_precision': float(average_precision_score(y,p)),
        'roc_auc': float(roc_auc_score(y,p)) if len(set(y)) == 2 else None,
        'mean_predicted_probability': float(p.mean()),
        'accuracy_at_0_5': float(np.mean((p>=.5)==y)),
        'recall_at_0_5': float(((p>=.5)&(y==1)).sum()/y.sum()) if y.sum() else None,
        'top_1pct_recall': float(y[top].sum()/y.sum()) if y.sum() and np.ptp(p)>0 else None,
        'top_1pct_precision': float(y[top].mean()) if np.ptp(p)>0 else None}


def run_experiment(frame):
    eligible = frame.loc[frame.collision_occurred.notna() & frame.split.ne('history')].copy()
    partitions = {split:eligible.loc[eligible.split.eq(split)].copy() for split in ['train','validation','test']}
    if any(part.collision_occurred.nunique()!=2 for part in partitions.values()):
        raise ValueError('Each time partition needs both target classes.')
    train, valid, test = (partitions[k] for k in ['train','validation','test'])
    assert train.month.max() < valid.month.min() < test.month.min()
    metrics, timing, fitted, predictions = [], [], {}, {}
    for name in MODELS:
        started = time.perf_counter()
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always', ConvergenceWarning)
            if name == 'Constant prevalence':
                model = float(train.collision_occurred.mean())
            else:
                model = make_model(name)
                model.fit(train[NUMERIC+CATEGORICAL], train.collision_occurred.astype(int))
        elapsed = time.perf_counter()-started
        fitted[name] = model
        warning_text = [str(w.message) for w in caught]
        timing.append({'model': name, 'fit_seconds': elapsed, 'warnings':warning_text,
                       'converged': not any(issubclass(w.category,ConvergenceWarning) for w in caught)})
        p = np.full(len(valid),model) if isinstance(model,float) else model.predict_proba(valid[NUMERIC+CATEGORICAL])[:,1]
        metrics.append({'split':'validation','model':name,**probability_scores(valid.collision_occurred,p)})
        predictions[('validation',name)] = p
    validation = pd.DataFrame(metrics)
    converged = {row['model'] for row in timing if row['converged']}
    selected = validation.loc[validation.model.isin(converged)].sort_values(['log_loss','model']).iloc[0].model
    # No refitting or hyperparameter changes after validation; same models assess 2025.
    for name, model in fitted.items():
        p = np.full(len(test),model) if isinstance(model,float) else model.predict_proba(test[NUMERIC+CATEGORICAL])[:,1]
        predictions[('test',name)] = p
        metrics.append({'split':'test','model':name,**probability_scores(test.collision_occurred,p)})
    return {'metrics':pd.DataFrame(metrics),'timing':timing,'models':fitted,'selected':selected,
            'predictions':predictions,'partitions':partitions}

# %% outputs
def speed_sensitivity(result, frame):
    """Change posted speed only, using 2025 rows as fixed comparison contexts."""
    context = frame.loc[frame.split.eq('test') & frame.posted_speed_mph.gt(25)].copy()
    proposed = context.copy()
    proposed['posted_speed_mph'] = 25.
    rows = []
    for name in MODELS:
        model = result['models'][name]
        before = np.full(len(context), model) if isinstance(model,float) else model.predict_proba(context[NUMERIC+CATEGORICAL])[:,1]
        after = np.full(len(context), model) if isinstance(model,float) else model.predict_proba(proposed[NUMERIC+CATEGORICAL])[:,1]
        estimates = context[['segment_id','FullStreetName','posted_speed_mph','road_class']].copy()
        estimates['baseline_monthly_probability'] = before
        estimates['proposed25_monthly_probability'] = after
        group = estimates.groupby(['segment_id','FullStreetName','posted_speed_mph','road_class'],as_index=False).mean(numeric_only=True)
        group['probability_change_pp'] = 100*(group.proposed25_monthly_probability-group.baseline_monthly_probability)
        group['relative_reduction_percent'] = 100*(1-group.proposed25_monthly_probability/group.baseline_monthly_probability)
        group['model'] = name
        group['selected_model'] = name == result['selected']
        group['interpretation'] = 'Input sensitivity averaged over 2025 month contexts; not observed before/after or an annual collision probability'
        rows.append(group)
    return pd.concat(rows,ignore_index=True)


def compare_speed_for_segment(result, frame, segment_id, proposed_mph=25):
    """Recompute fixed-context monthly sensitivity for a reviewed segment."""
    if not np.isfinite(proposed_mph) or not 5<=proposed_mph<=75:
        raise ValueError('Proposed posted speed must be between 5 and 75 mph.')
    context=frame.loc[frame.segment_id.eq(segment_id)&frame.split.eq('test')].copy()
    if len(context)!=12:
        raise ValueError('Select a segment with twelve comparison months.')
    if context.posted_speed_mph.isna().any():
        raise ValueError('Verify the observed posted speed before comparing this segment.')
    proposed=context.copy();proposed['posted_speed_mph']=float(proposed_mph)
    result_rows=[]
    for name,model in result['models'].items():
        before=float(model) if isinstance(model,float) else float(model.predict_proba(context[NUMERIC+CATEGORICAL])[:,1].mean())
        after=float(model) if isinstance(model,float) else float(model.predict_proba(proposed[NUMERIC+CATEGORICAL])[:,1].mean())
        result_rows.append({'model':name,'selected_on_validation':name==result['selected'],
            'segment_id':segment_id,'road':context.FullStreetName.iloc[0],
            'observed_snapshot_mph':float(context.posted_speed_mph.iloc[0]),'proposed_mph':float(proposed_mph),
            'baseline_monthly_percent':100*before,'scenario_monthly_percent':100*after,
            'change_percentage_points':100*(after-before),'relative_reduction_percent':100*(1-after/before)})
    return pd.DataFrame(result_rows)


def compare_history_results(recent_result, extended_result, output):
    """Verify identical later-year labels/features before comparing history lengths."""
    for split in ['validation','test']:
        cols=['segment_id','month','collision_occurred']+NUMERIC+CATEGORICAL
        a=recent_result['partitions'][split][cols].reset_index(drop=True)
        b=extended_result['partitions'][split][cols].reset_index(drop=True)
        pd.testing.assert_frame_equal(a,b)
    comparison=pd.concat([recent_result['metrics'].assign(history='2020-2025'),
                          extended_result['metrics'].assign(history='2016-2025')],ignore_index=True)
    comparison.to_csv(Path(output)/'history_length_comparison.csv',index=False)
    return comparison


def export_run(result, frame, panel, roads, decisions, output):
    import joblib
    output = Path(output); output.mkdir(parents=True,exist_ok=True)
    result['metrics'].to_csv(output/'model_metrics.csv',index=False)
    pd.DataFrame(result['timing']).to_json(output/'fit_timing.json',orient='records',indent=2)
    frame.to_csv(output/'road_month_training_table.csv.gz',index=False,compression='gzip')
    decisions.assign(possible_segment_ids=decisions.possible_segment_ids.map(json.dumps)).to_csv(output/'crash_segment_assignments.csv',index=False)
    summaries = panel.assign(year=panel.month.dt.year).groupby('year').agg(
        potential_rows=('month','size'),usable_labels=('collision_occurred','count'),positive_months=('collision_occurred','sum'),assigned_crashes=('assigned_collision_count','sum'))
    summaries['unknown_months'] = summaries.potential_rows-summaries.usable_labels
    summaries['negative_months'] = summaries.usable_labels-summaries.positive_months
    summaries.to_csv(output/'annual_label_audit.csv')
    for split in ['validation','test']:
        predictions = result['partitions'][split][['segment_id','FullStreetName','month','collision_occurred']].copy()
        for name in MODELS:
            predictions[name] = result['predictions'][(split,name)]
        predictions.to_csv(output/f'{split}_predictions.csv.gz',index=False,compression='gzip')
    scenario = speed_sensitivity(result,frame)
    scenario.to_csv(output/'speed25_model_sensitivity.csv',index=False)
    protocol = {**PROTOCOL, 'source_years':sorted(frame.month.dt.year.unique().tolist()),
                'training_target_years':sorted(frame.loc[frame.split.eq('train'),'month'].dt.year.unique().tolist())}
    for name, model in result['models'].items():
        joblib.dump({'model':model,'protocol':protocol,'numeric':NUMERIC,'categorical':CATEGORICAL},output/(name.lower().replace(' ','_')+'.joblib'))
    encoded = result['models']['Neural network with speed'].named_steps['preprocess'].get_feature_names_out().tolist()
    summary = {'segments':len(roads),'potential_segment_months':len(panel),'source_crashes':len(decisions),
        'assigned_crashes':int(decisions.segment_id.notna().sum()),'unresolved_crashes':int(decisions.segment_id.isna().sum()),
        'match_status_counts':decisions.match_status.value_counts().to_dict(),
        'selected_model':result['selected'],'raw_feature_columns':len(NUMERIC+CATEGORICAL),'encoded_feature_columns':len(encoded),
        'encoded_feature_names':encoded,'pca_used':False,
        'split_rows':{s:len(p) for s,p in result['partitions'].items()},
        'split_positive_months':{s:int(p.collision_occurred.sum()) for s,p in result['partitions'].items()},
        'total_fitting_seconds':sum(t['fit_seconds'] for t in result['timing']),
        'speed_change_history_available':False,'causal_effect_estimated':False,
        'school_area_forecast_trained':False,'monthly_road_model_trained':True}
    (output/'summary.json').write_text(json.dumps(summary,indent=2))
    (output/'protocol.json').write_text(json.dumps(protocol,indent=2))
    return summary,scenario


def diagnostic_figures(result, annual_audit, output):
    import matplotlib.pyplot as plt
    from sklearn.metrics import precision_recall_curve
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    labels = ['Constant','Logistic\nwithout speed','Logistic\nwith speed','Neural network\nwith speed']
    fig, axes = plt.subplots(1,2,figsize=(12,5.2),layout='constrained')
    x=np.arange(4); colors=['#777777','#397c91','#ae7625','#7462a3']
    valid=result['metrics'].query("split == 'validation'").set_index('model').loc[MODELS]
    test=result['metrics'].query("split == 'test'").set_index('model').loc[MODELS]
    axes[0].bar(x-.19,valid.log_loss,.36,label='2024 validation',color='#397c91')
    axes[0].bar(x+.19,test.log_loss,.36,label='2025 evaluation',color='#ae7625')
    axes[0].set(xticks=x,xticklabels=labels,ylabel='Binary log loss · lower is better',title='Probability error')
    axes[0].legend(frameon=False,fontsize=9,loc='upper center',bbox_to_anchor=(.5,-.20),ncol=2)
    axes[1].bar(x,test.average_precision,color=colors)
    axes[1].axhline(test.prevalence.iloc[0],linestyle='--',color='#555555',label='Positive-month prevalence')
    axes[1].set(xticks=x,xticklabels=labels,ylabel='Average precision · higher is better',title='2025 collision-month ranking')
    axes[1].legend(frameon=False,fontsize=9)
    fig.suptitle(f'Exploratory road-month model · {int(test.positive_months.iloc[0])} positive months in 2025\nZeros assume reporting coverage; historical road attributes unverified',fontsize=12)
    fig.savefig(Path(output)/'model_comparison.png',dpi=160,bbox_inches='tight')
    coverage,ax=plt.subplots(figsize=(9,4.5),layout='constrained')
    years=annual_audit.index.astype(str)
    ax.bar(years,annual_audit.negative_months,label='Zero under coverage assumption',color='#9fbcc6')
    ax.bar(years,annual_audit.unknown_months,bottom=annual_audit.negative_months,label='Unknown; excluded from fitting',color='#c9a46c')
    ax.bar(years,annual_audit.positive_months,bottom=annual_audit.negative_months+annual_audit.unknown_months,label='Assigned positive',color='#705c99')
    for i,(_,row) in enumerate(annual_audit.iterrows()):
        ax.text(i,row.potential_rows+450,f'{int(row.positive_months)} positive',ha='center',fontsize=9)
    ax.set(ylabel='Segment-month rows',title='Monthly grid includes negative and unknown labels',ylim=(0,float(annual_audit.potential_rows.max())*1.12))
    ax.legend(frameon=False,loc='upper center',bbox_to_anchor=(.5,-.10),ncol=1,fontsize=9)
    coverage.savefig(Path(output)/'monthly_label_coverage.png',dpi=160,bbox_inches='tight')
    return fig,coverage
