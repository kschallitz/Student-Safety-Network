"""A simulator recommendation requires more than a fitted neural network."""
import json
import pandas as pd
from .config import OUT,ACTION_IDS
from .run import signature

def assess(suite='pilot',save=True):
    protocol=json.loads((OUT/f'{suite}_protocol.json').read_text())
    frame=pd.read_csv(OUT/f'{suite}_runs.csv')
    checks=json.loads((OUT/'validation.json').read_text()) if (OUT/'validation.json').exists() else {}
    reward_valid=frame.score.eq(-1000*frame.collision_pairs-5*frame.near_pairs)
    accounting=frame.complete & frame.arrived.eq(frame.requested) & frame.pending.eq(0)
    physics=accounting & reward_valid & frame.precontact_boundary_violations.eq(0) & frame.precontact_max_route_deviation_m.le(1.5)
    frame=frame.assign(physics_pass=physics)
    reasons=[]
    if len(frame)!=protocol['runs']:reasons.append('The predeclared simulation matrix is incomplete.')
    if frame.duplicated(['context_id','action','realization']).any():reasons.append('Duplicate simulation records were found.')
    if not reward_valid.all():reasons.append('Saved rewards do not reconcile to their event counts.')
    if 'earlier_contact_prefix_matches' in frame and frame.earlier_contact_prefix_matches.dropna().eq(False).any():reasons.append('A repeated cohort did not reproduce its earlier contact prefix.')
    expected_signature=signature(protocol['physics_dt'])
    if not frame.snapshot.eq(protocol['snapshot']).all() or protocol['snapshot']!=expected_signature:reasons.append('Simulation source or input fingerprint changed.')
    if checks.get('snapshot')!=expected_signature or not checks.get('passed'):reasons.append('One or more motion/detector/repeatability checks have not passed for this source version and time step.')
    if not accounting.all():reasons.append(f'{int((~accounting).sum())} episodes have incomplete traveler accounting.')
    if frame.precontact_boundary_violations.gt(0).any():reasons.append(f'{int(frame.precontact_boundary_violations.gt(0).sum())} episodes have vehicle-footprint incursions into modeled curbs before contact.')
    if frame.precontact_max_route_deviation_m.gt(1.5).any():reasons.append(f'{int(frame.precontact_max_route_deviation_m.gt(1.5).sum())} episodes have route deviation over 1.5 m before contact.')
    paired=frame.groupby(['context_id','realization']).agg(actions=('action','nunique'),ledgers=('demand_sha256','nunique'))
    if not (paired.actions.eq(len(ACTION_IDS))&paired.ledgers.eq(1)).all():reasons.append('A demand block is missing a candidate or uses unmatched travelers.')
    result=dict(snapshot=protocol['snapshot'],completed_runs=len(frame),planned_runs=protocol['runs'],
                software_checks_passed=checks.get('passed',False),software_checks_total=len(checks.get('checks',[])),
                physics_pass_runs=int(physics.sum()),physics_fail_runs=int((~physics).sum()),
                recommendation_released=not reasons,release_blockers=reasons,
                field_safety_validated=False,annual_collision_probability_available=False,
                failed_episodes=frame.loc[~physics,['context_id','action','complete','precontact_boundary_violations','precontact_max_route_deviation_m']].to_dict('records'))
    if save:(OUT/f'{suite}_quality.json').write_text(json.dumps(result,indent=2))
    return result,frame

if __name__=='__main__':print(json.dumps(assess()[0],indent=2))
