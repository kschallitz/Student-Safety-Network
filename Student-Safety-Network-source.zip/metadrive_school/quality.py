"""A simulator recommendation requires more than a fitted neural network."""
import json,hashlib
from pathlib import Path
import pandas as pd
from .config import OUT,ACTION_IDS
from .run import signature
from .conflicts import METRIC_VERSION
from .rewards import SCORING_VERSION, REWARD_DEFINITION, source_hash

def inherited_checks(expected_signature):
    """Resolve immutable evidence without pretending it ran on the new metric."""
    folder=OUT/'validation_lineage'/expected_signature
    path=folder/'manifest.json'
    if not path.exists():return None
    m=json.loads(path.read_text())
    if m.get('applies_to_snapshot')!=expected_signature:return None
    if not all(m.get(k) for k in ['motion_ast_identical','geometry_demand_config_identical','input_fingerprint_identical']):return None
    for name,sha in m['source_hashes'].items():
        if hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()!=sha:return None
    for name,sha in m['evidence_hashes'].items():
        p=OUT/name
        if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=sha:return None
    if m.get('exact_physical_replays')!=24 or not m.get('detector_checks',{}).get('passed'):return None
    return m,json.loads((folder/'original_validation.json').read_text()),json.loads((folder/'original_grid.json').read_text())

def assess(suite='pilot',save=True):
    protocol=json.loads((OUT/f'{suite}_protocol.json').read_text())
    frame=pd.read_csv(OUT/f'{suite}_runs.csv')
    checks=json.loads((OUT/'validation.json').read_text()) if (OUT/'validation.json').exists() else {}
    reward_valid=frame.score.eq(-1000*frame.collision_pairs-5*frame.near_pairs)
    accounting=frame.complete & frame.arrived.eq(frame.requested) & frame.pending.eq(0)
    physics=accounting & reward_valid & frame.precontact_boundary_violations.eq(0) & frame.precontact_max_route_deviation_m.le(1.5)
    frame=frame.assign(physics_pass=physics)
    reasons=[]
    if (protocol.get('scoring_version')!=SCORING_VERSION or protocol.get('scoring_source_sha256')!=source_hash()
        or 'scoring_version' not in frame or not frame.scoring_version.eq(SCORING_VERSION).all()
        or 'scoring_source_sha256' not in frame or not frame.scoring_source_sha256.eq(source_hash()).all()):
        reasons.append('Rewards must be rescored for the current motor-vehicle/pedestrian/bicycle objective.')
    elif not (frame.collision_pairs.eq(frame.motor_pedestrian_collision_pairs+frame.motor_bicycle_collision_pairs).all()
              and frame.all_contact_pairs.eq(frame.collision_pairs+frame.motor_vehicle_collision_pairs_diagnostic+frame.other_contact_pairs_diagnostic).all()
              and frame.near_pairs.eq(frame.motor_pedestrian_near_pairs).all()
              and frame.motor_bicycle_near_pairs.isna().all()):
        reasons.append('Contact types or near-miss coverage do not reconcile to the reward scope.')
    # Motion checks do not validate a safety reward. The speed investigation
    # found that PET-only counts were being presented as collision courses.
    speed_review_path=OUT/'speed_issue_audit/release_review.json'
    speed_review=json.loads(speed_review_path.read_text()) if speed_review_path.exists() else {}
    if speed_review.get('snapshot')!=signature(protocol['physics_dt']) or not speed_review.get('approved'):
        reasons.append('The reduced-speed safety-metric investigation has not been reviewed for this version; do not train or release a mitigation recommendation from these counts.')
    if len(frame)!=protocol['runs']:reasons.append('The predeclared simulation matrix is incomplete.')
    if frame.duplicated(['context_id','action','realization']).any():reasons.append('Duplicate simulation records were found.')
    if not reward_valid.all():reasons.append('Saved rewards do not reconcile to their event counts.')
    if 'earlier_contact_prefix_matches' in frame and frame.earlier_contact_prefix_matches.dropna().eq(False).any():reasons.append('A repeated cohort did not reproduce its earlier contact prefix.')
    expected_signature=signature(protocol['physics_dt'])
    if protocol.get('safety_metric_version')!=METRIC_VERSION or 'safety_metric_version' not in frame or not frame.safety_metric_version.eq(METRIC_VERSION).all():
        reasons.append('Episode safety metric is missing or inconsistent with the corrected protocol.')
    grid_path=OUT/'crossing_repair/liveness'/expected_signature/'grid.json'
    grid=json.loads(grid_path.read_text()) if grid_path.exists() else {}
    lineage=inherited_checks(expected_signature)
    checks_signature=expected_signature
    if lineage is not None:
        manifest,checks,grid=lineage
        checks_signature=manifest['executed_snapshot']
    grid_rows=grid.get('rows',[])
    grid_pass=(grid.get('snapshot')==checks_signature and len(grid_rows)==384
               and all(r['complete'] and r['contacts']==0 for r in grid_rows))
    if not grid_pass:reasons.append('The 384 crossing/turn clearance checks have not all completed without contact for this source version.')
    if not frame.snapshot.eq(protocol['snapshot']).all() or protocol['snapshot']!=expected_signature:reasons.append('Simulation source or input fingerprint changed.')
    if checks.get('snapshot')!=checks_signature or not checks.get('passed'):reasons.append('One or more motion/detector/repeatability checks have not passed for this source version and time step.')
    if not accounting.all():reasons.append(f'{int((~accounting).sum())} episodes have incomplete traveler accounting.')
    if frame.precontact_boundary_violations.gt(0).any():reasons.append(f'{int(frame.precontact_boundary_violations.gt(0).sum())} episodes have vehicle-footprint incursions into modeled curbs before contact.')
    if frame.precontact_max_route_deviation_m.gt(1.5).any():reasons.append(f'{int(frame.precontact_max_route_deviation_m.gt(1.5).sum())} episodes have route deviation over 1.5 m before contact.')
    paired=frame.groupby(['context_id','realization']).agg(actions=('action','nunique'),ledgers=('demand_sha256','nunique'))
    if not (paired.actions.eq(len(ACTION_IDS))&paired.ledgers.eq(1)).all():reasons.append('A demand block is missing a candidate or uses unmatched travelers.')
    result=dict(snapshot=protocol['snapshot'],completed_runs=len(frame),planned_runs=protocol['runs'],
                software_checks_passed=checks.get('passed',False),software_checks_total=len(checks.get('checks',[])),
                crossing_grid_passed=grid_pass,crossing_grid_tests=len(grid_rows),
                physical_checks_executed_snapshot=checks_signature,physical_checks_reused=lineage is not None,
                metric_version=METRIC_VERSION,
                scoring_version=SCORING_VERSION,scoring_source_sha256=source_hash(),reward_definition=REWARD_DEFINITION,
                bicycle_collision_coverage=True,bicycle_near_misses_measured=False,
                physics_pass_runs=int(physics.sum()),physics_fail_runs=int((~physics).sum()),
                recommendation_released=not reasons,release_blockers=reasons,
                field_safety_validated=False,annual_collision_probability_available=False,
                failed_episodes=frame.loc[~physics,['context_id','action','complete','precontact_boundary_violations','precontact_max_route_deviation_m']].to_dict('records'))
    if save:(OUT/f'{suite}_quality.json').write_text(json.dumps(result,indent=2))
    return result,frame

if __name__=='__main__':print(json.dumps(assess()[0],indent=2))
