"""Execute explicit demand realizations, matched across eight designs."""
import argparse,hashlib,json,sys,time,shutil
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import pandas as pd
from .config import DATA,OUT,ACTION_IDS,SEED,BEHAVIOR

_WORLD=None
MAX_COHORT_SECONDS=2400
def signature(dt=.05):
    h=hashlib.sha256()
    for p in sorted(Path(__file__).parent.glob('*.py')):
        if p.name not in ('engine.py','geometry.py','demand.py','config.py'):continue
        h.update(p.name.encode());h.update(p.read_bytes())
    for p in sorted(DATA.iterdir()):
        if p.suffix in ('.csv','.json'):h.update(p.read_bytes())
    # The original recorded batch uses .05 s. Other resolutions must never
    # silently reuse that batch's cached physics results.
    if dt!=.05:h.update(f'physics_dt={dt!r}'.encode())
    return h.hexdigest()[:16]

def task(args):
    global _WORLD
    from .engine import World
    context,action,realization,dt,sig=args
    folder=OUT/'runs'/sig;folder.mkdir(parents=True,exist_ok=True)
    dest=folder/f'{context}_{action}_{realization}.json'
    prior=json.loads(dest.read_text()) if dest.exists() else None
    # An already cleared cohort is unaffected by a longer permitted tail.
    if prior is not None and prior['complete']:return prior
    if prior is not None:
        archive=folder/'cutoff_diagnostics';archive.mkdir(exist_ok=True)
        copy=archive/dest.name
        if not copy.exists():shutil.copyfile(dest,copy)
    if _WORLD is None:_WORLD=World(dt)
    _WORLD.reset(action)
    keep=context=='20230302T074500' and action in ('C01','C07','C08')
    r=_WORLD.run(context,realization=realization,record=keep,max_time=MAX_COHORT_SECONDS)
    r['time_limit_seconds']=MAX_COHORT_SECONDS
    if prior is not None:
        r['earlier_cutoff_arrived']=prior['arrived']
        old={(tuple(c['pair']),round(c['time'],2)) for c in prior['contacts']}
        prefix={(tuple(c['pair']),round(c['time'],2)) for c in r['contacts'] if c['time']<=prior['simulated_seconds']}
        r['earlier_contact_prefix_matches']=old==prefix
    if keep:
        (folder/f'{context}_{action}_{realization}_trajectory.json').write_text(json.dumps(r.pop('frames')))
    else:r.pop('frames')
    r['snapshot']=sig
    dest.write_text(json.dumps(r,indent=2))
    return r

def suite(name):
    c=pd.read_csv(DATA/'contexts.csv')
    if name=='full':return c
    preferred={
        'train':['20230302T073000','20230302T074500','20230302T081500','20230302T143000'],
        'validation':['20230302T080000','20230302T084500','20230302T144500','20230302T154500'],
        'test':['20230518T073000','20230518T081500','20230518T141500','20230518T143000']}
    ids=sum(preferred.values(),[])
    assert set(ids).issubset(set(c.context_id)), set(ids)-set(c.context_id)
    return c[c.context_id.isin(ids)].copy()

def main():
    p=argparse.ArgumentParser();p.add_argument('--suite',choices=['pilot','full'],default='pilot')
    p.add_argument('--workers',type=int,default=3);p.add_argument('--realizations',type=int,default=1)
    p.add_argument('--dt',type=float,default=.05);a=p.parse_args()
    c=suite(a.suite);sig=signature(a.dt);tasks=[(s,act,r,a.dt,sig) for s in c.context_id for act in ACTION_IDS for r in range(a.realizations)]
    protocol=dict(version='0.20.0',suite=a.suite,seed=SEED,physics_dt=a.dt,snapshot=sig,
        contexts=c[['context_id','split']].to_dict('records'),actions=ACTION_IDS,
        runs=len(tasks),realizations=a.realizations,behavior=BEHAVIOR,
        reward=dict(collision=-1000,pedestrian_pet_near_miss=-5,event_free=0),
        new_simulation_engine='MetaDrive / Panda3D Bullet',sumo_used=False,
        maximum_cohort_seconds=MAX_COHORT_SECONDS,
        clearance_policy='900 s observed-count arrival period plus 60 s estimated warmup; follow the entire cohort until clear, up to 2400 s. Earlier complete cohorts can be reused; truncated attempts are preserved.',
        statistical_scope='pilot software evaluation; no independent field crash validation',
        candidate_effects='continuous route constraints, crossing lengths, operating speed; no extra sign-compliance multiplier',
        before_run_unix=time.time())
    OUT.mkdir(exist_ok=True,parents=True)
    snapshot=OUT/'runs'/sig;snapshot.mkdir(parents=True,exist_ok=True)
    for source in Path(__file__).parent.glob('*.py'):
        (snapshot/'source').mkdir(exist_ok=True);shutil.copyfile(source,snapshot/'source'/source.name)
    (snapshot/'protocol.json').write_text(json.dumps(protocol,indent=2))
    (OUT/f'{a.suite}_protocol.json').write_text(json.dumps(protocol,indent=2))
    c.to_csv(OUT/f'{a.suite}_contexts.csv',index=False)
    rows=[]
    with ProcessPoolExecutor(max_workers=a.workers) as pool:
        for f in as_completed([pool.submit(task,t) for t in tasks]):
            r=f.result();row={k:v for k,v in r.items() if k not in ('frames','contacts','near_misses','pet_events','finished','remaining_actors')};rows.append(row)
            frame=pd.DataFrame(rows).merge(c[['context_id','split']],on='context_id',validate='many_to_one')
            frame.to_csv(OUT/f'{a.suite}_runs.csv',index=False)
            print(f"{len(rows)}/{len(tasks)} {r['context_id']} {r['action']} complete={r['complete']} contacts={r['collision_pairs']} near={r['near_pairs']}",flush=True)
    assert len(rows)==len(tasks)

if __name__=='__main__':main()
