"""Continuous source-traced routes, built directly as MetaDrive map features."""
import json
from functools import lru_cache
import numpy as np
from shapely.geometry import Polygon, LineString
from shapely.ops import unary_union
from .config import DATA, candidate

D = {"E": np.array([1.,0.]), "W": np.array([-1.,0.]), "N": np.array([0.,1.]), "S": np.array([0.,-1.])}
OPP = dict(E="W", W="E", N="S", S="N")
RIGHT = dict(E="N", N="W", W="S", S="E")

class Route:
    def __init__(self, points, key):
        q = np.asarray(points, dtype=float)
        q = q[np.r_[True, np.linalg.norm(np.diff(q,axis=0),axis=1)>1e-7]]
        self.points = q; self.key = key
        self.s = np.r_[0.,np.cumsum(np.linalg.norm(np.diff(q,axis=0),axis=1))]
        self.length = self.s[-1]; self.line = LineString(q)
        self.headings = np.unwrap(np.arctan2(np.diff(q,axis=0)[:,1],np.diff(q,axis=0)[:,0]))
        self.curvature = np.r_[0.,np.abs(np.diff(self.headings))/np.maximum(np.diff(self.s)[1:],1e-4),0.]

    def position(self, s):
        return np.array([np.interp(s,self.s,self.points[:,i]) for i in (0,1)])

    def heading(self,s):
        return float(self.headings[min(np.searchsorted(self.s,s,side="right")-1,len(self.headings)-1)])

    def project(self,pos):
        # Projection measures actual physics motion; never moves an actor onto a lane.
        from shapely.geometry import Point
        return float(self.line.project(Point(pos)))

    def curve_limit(self,s,lateral_accel):
        # Anticipate braking and reaction distance, not a fixed 18 m lookahead.
        # Otherwise a fast car reaches a tight turn before it can slow down.
        ix=(self.s>=s-2)&(self.s<=s+80)&(self.curvature>1e-4)
        if not ix.any():return 30.
        curve=np.sqrt(lateral_accel/self.curvature[ix]);distance=np.maximum(0,self.s[ix]-s)
        from .config import BEHAVIOR
        br=BEHAVIOR['comfortable_decel'];rt=BEHAVIOR['reaction_s']
        envelope=np.maximum(curve,np.sqrt((br*rt)**2+curve**2+2*br*distance)-br*rt)
        return min(30.,float(envelope.min()))

def cubic(a,b,di,do,reach1,reach2):
    t=np.linspace(0,1,81)[:,None]
    c=a+di*reach1; d=b-do*reach2
    return (1-t)**3*a+3*(1-t)**2*t*c+3*(1-t)*t*t*d+t**3*b

@lru_cache(maxsize=8)
def build(action):
    trace=json.loads((DATA/"geometry.json").read_text());spec=trace["Estates"]; c=candidate(action)
    scale=trace["metres_per_pixel"];origin=np.array(spec["origin"])
    def xy(q): return (np.asarray(q,dtype=float)-origin)*[scale,-scale]
    def phase_points(v):
        if c["curbs"]=="small":
            # Generic 0.75 m shortening from each end, without invented as-built tracing.
            return xy(v["before"])
        return xy(v[c["curbs"]])
    polygons=[Polygon(phase_points(v)) for v in spec["corners"].values()]
    curb_blocks=unary_union(polygons)
    if c["medians"]: polygons += [Polygon(xy(z)) for z in spec["medians"]]
    blocks=unary_union(polygons)
    routes={}; audit=[]
    for arm in ("E","W","N"):
        for target in ("E","W","N"):
            if arm==target and arm=="N": continue
            inbound=xy(spec["arms"][arm]["in"]);outbound=xy(spec["arms"][target]["out"])
            mappings=[(len(inbound)-1,0)] if arm==target else [(i,min(i,len(outbound)-1)) for i in range(min(len(inbound),len(outbound)))] if target==OPP[arm] else [(0,0)] if target==RIGHT[arm] else [(len(inbound)-1,len(outbound)-1)]
            for i,j in mappings:
                a,b=inbound[i],outbound[j];di=-D[arm];do=D[target]
                options=[]
                if arm==target:
                    # Observations do not specify the receiving lane. Use the
                    # outer lane and a feasible semicircle, not a tight cubic
                    # cusp. Painted median is traversable; curb is not.
                    radius=abs(b[1]-a[1])/2;cy=(a[1]+b[1])/2
                    theta=np.linspace(np.pi/2,3*np.pi/2,81) if arm=='E' else np.linspace(-np.pi/2,np.pi/2,81)
                    arc=np.column_stack([radius*np.cos(theta),cy+radius*np.sin(theta)])
                    q=np.vstack([a,arc,b]);clear=LineString(q).distance(curb_blocks)
                    if clear<1.3:raise ValueError(f'No feasible U-turn clearance {action} {arm}')
                    options=[(float(Route(q,'candidate').curvature.max()),q,clear)];lengths=[]
                elif target==OPP[arm]:
                    lengths=[(np.linalg.norm(b-a)*k,np.linalg.norm(b-a)*k) for k in np.linspace(.15,.65,25)]
                else:
                    ts=np.linalg.solve(np.column_stack([di,do]),b-a)
                    lengths=[(ts[0]*k,ts[1]*k) for k in np.linspace(.25,1.15,91)]
                for r1,r2 in lengths:
                    q=cubic(a,b,di,do,r1,r2);line=LineString(q);clear=line.distance(blocks)
                    if clear<(1.05 if arm==target else 1.3): continue
                    rr=Route(q,"candidate")
                    options.append((float(rr.curvature.max()),q,clear))
                if not options: raise ValueError(f"No clear continuous route: {action} {arm}->{target} {i}")
                _,q,clear=min(options,key=lambda z:z[0])
                start=a+D[arm]*100;end=b+D[target]*100
                p=np.vstack([start,q,end]);key=f"{arm}_{target}_{i}"
                routes[key]=Route(p,key)
                audit.append(dict(route=key,clearance_m=float(clear),source_in_lane=i,source_out_lane=j))
    crossings={}
    for arm,v in spec["crossings"].items():
        q=xy(v["pilot"] if c["curbs"]=="pilot" else v["before"])
        if c["curbs"]=="small" and arm in ("E","N"):
            direction=(q[1]-q[0])/np.linalg.norm(q[1]-q[0]);q[0]+=direction*.75;q[1]-=direction*.75
        crossings[arm]=q
    features={}
    for key,r in routes.items():
        features[key]=dict(type="LANE_SURFACE_STREET",polyline=r.points.tolist(),
            polygon=list(r.line.buffer(1.55,cap_style=2).exterior.coords),speed_limit_mph=c["mph"])
    for arm,q in crossings.items():
        features[f"crosswalk_{arm}"]=dict(type="CROSSWALK",polygon=list(LineString(q).buffer(.8,cap_style=2).exterior.coords))
    # Boundaries are rendered and checked, not made invisible collision-free territory.
    return dict(routes=routes,crossings=crossings,blocks=blocks,curb_blocks=curb_blocks,polygons=polygons,features=features,audit=audit)
