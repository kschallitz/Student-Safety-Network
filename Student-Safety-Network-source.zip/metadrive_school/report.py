"""Render evidence, never promote a diagnostic score to an annual probability."""
import json,html
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .config import OUT,DATA,CANDIDATES
from .quality import assess

COLORS={'passenger':'#2C7193','heavy':'#AF663C','bicycle':'#568A48','pedestrian':'#8C5896'}
def main():
    q,r=assess();contexts=pd.read_csv(OUT/'pilot_contexts.csv');manifest=json.loads((DATA/'manifest.json').read_text())
    validation=json.loads((OUT/'validation.json').read_text())
    state_path=OUT/'pilot_policy_freeze.json';policy=json.loads(state_path.read_text()) if state_path.exists() else None
    if policy and policy.get('snapshot')!=q['snapshot']:policy=None
    evaluation=json.loads((OUT/'pilot_evaluation.json').read_text()) if policy is not None and (OUT/'pilot_evaluation.json').exists() else None
    totals=r.groupby('action').agg(runs=('score','size'),contacts=('collision_pairs','sum'),near_pairs=('near_pairs','sum'),reward=('score','sum'),arrived=('arrived','sum'),requested=('requested','sum'),physics_pass=('physics_pass','sum')).reindex([c['id'] for c in CANDIDATES])
    totals['mean_excess_travel_s']=(r.assign(total_excess=r.mean_delay_s*r.arrived).groupby('action').total_excess.sum()/totals.arrived).round(1)
    # Actual time from scheduled arrival to exit includes entry queuing and does
    # not change its reference speed when a slower design is selected.
    journey_seconds={c['id']:0. for c in CANDIDATES}
    for episode in r.itertuples():
        path=OUT/'runs'/q['snapshot']/f'{episode.context_id}_{episode.action}_{episode.realization}.json'
        raw=json.loads(path.read_text())
        served=[a for a in raw['finished'] if a['study']]
        assert len(served)==episode.arrived
        journey_seconds[episode.action]+=sum(a['duration'] for a in served)
    totals['mean_journey_s']=(pd.Series(journey_seconds)/totals.arrived).round(1)
    totals['longest_clearance_s']=(r.groupby('action').simulated_seconds.max()-960).clip(lower=0).round(1)
    totals.to_csv(OUT/'candidate_totals.csv')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
    totals[['contacts','near_pairs']].rename(columns={'contacts':'Native contact pairs','near_pairs':'Pedestrian near-miss pairs'}).plot.bar(ax=axes[0],color=['#B0573A','#39798B'])
    axes[0].set(title='Simulation events by candidate',xlabel='Anonymous design',ylabel='Unique pairs across selected episodes');axes[0].tick_params(axis='x',rotation=0);axes[0].legend(fontsize=8)
    totals.physics_pass.plot.bar(ax=axes[1],color='#39798B');axes[1].axhline(contexts.shape[0],color='#888',linestyle='--',linewidth=1)
    axes[1].set(title='Episodes passing accounting and path checks',xlabel='Anonymous design',ylabel='Episodes');axes[1].tick_params(axis='x',rotation=0);axes[1].set_ylim(0,contexts.shape[0]+1)
    fig.suptitle('East Avenue / Estates · MetaDrive pilot',fontweight='bold');fig.savefig(OUT/'pilot_comparison.png',dpi=160);plt.close(fig)
    status='Simulation recommendation eligible for review' if q['recommendation_released'] else 'Recommendation withheld: validation is incomplete'
    summary=dict(version='0.20',status=status,quality=q,candidates=CANDIDATES,totals=totals.reset_index().to_dict('records'),policy=policy,evaluation=evaluation,
                 observed_contexts=manifest['observed_contexts'],observed_travelers=manifest['observed_travelers'],
                 pilot_contexts=len(contexts),pilot_observed_travelers=int(contexts.total.sum()),checks=validation,
                 notes=['These are simulated contact/PET events, not injury collisions or annual probabilities.',
                        'The 25 mph scenario assumes desired operating speeds scale by 25/30.',
                        'Observed counts constrain demand; reaction, individual arrival seconds and yielding are assumptions.',
                        'Curbs are route constraints with footprint checks, not physical Bullet barriers.',
                        'No independent field near-miss calibration or transfer validation has been completed.'])
    (OUT/'report.json').write_text(json.dumps(summary,indent=2))
    rows=''.join(f"<tr><td>{html.escape(c['id']+' — '+c['label'])}</td>"+''.join(f'<td>{totals.loc[c["id"],k]:.0f}</td>' for k in ['runs','contacts','near_pairs','reward','physics_pass'])+'</tr>' for c in CANDIDATES)
    checks=''.join(f'<li>{"Pass" if x["passed"] else "FAIL"} — {html.escape(x["name"])}</li>' for x in validation['checks'])
    blockers=''.join('<li>'+html.escape(x)+'</li>' for x in q['release_blockers'])
    chosen='No trained policy artifact for this snapshot.' if policy is None else f"Exploratory learner: {policy['champion']}; selected anonymous candidate: {policy['agents'][policy['champion']]['fixed_action']}." 
    report=f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MetaDrive experiment · v0.20</title><style>body{{font:17px/1.6 system-ui;margin:32px auto;padding:0 22px;max-width:1050px;color:#17394a}}h1{{line-height:1.2}}table{{border-collapse:collapse;width:100%;font-size:14px}}td,th{{padding:8px;border-bottom:1px solid #ddd;text-align:left}}img{{max-width:100%}}.status{{background:#fff2d9;padding:18px;border-left:4px solid #bd792e}}a{{color:#146b86}}</style><h1>East Avenue / Estates<br>MetaDrive experiment · v0.20</h1><p>Independent MetaDrive/Bullet implementation. SUMO is not used by this experiment.</p><div class="status"><strong>{status}</strong><ul>{blockers}</ul><p>{chosen}</p></div><p>{q['completed_runs']} of {q['planned_runs']} pilot episodes saved. {sum(x['passed'] for x in validation['checks'])}/{len(validation['checks'])} software checks pass. Source inventory: {manifest['observed_travelers']:,} observed movements across {manifest['observed_contexts']} quarter-hour windows.</p><img src="pilot_comparison.png" alt="Simulated event counts and episode quality by anonymous candidate"><h2>Simulator outcomes</h2><p>Counts below are diagnostic simulation events, not recorded real-world collisions. No annual probability or treatment-effect percentage is established.</p><table><thead><tr><th>Candidate</th><th>Episodes</th><th>Contacts</th><th>Pedestrian near misses</th><th>Reward</th><th>Physics pass</th></tr></thead><tbody>{rows}</tbody></table><h2>How the agent learns</h2><p>A candidate is selected before an episode. Its reward is −1,000 per distinct contact pair and −5 per non-contact pedestrian pair with PET ≤1.5 s; event-free episodes score zero. Tabular, linear and neural terminal Q learners use simulation replay. March validation selects the learner; May demand is held out. The consultant identity is revealed after policy selection. Replay updates are not new simulation episodes.</p><h2>Evidence boundaries</h2><ul>{''.join('<li>'+html.escape(x)+'</li>' for x in summary['notes'])}</ul><p>Geometry is traced from an April 2025 drawing, not certified as the May 2023 installation. Source: <a href="{manifest['source_url']}">City of Livermore report</a>. See the input manifest for provenance and assumptions.</p><details><summary>Software checks</summary><ul>{checks}</ul></details><p>Saved fingerprint: <code>{q['snapshot']}</code></p></html>'''
    (OUT/'MetaDrive_Report.html').write_text(report)
    print(status);print(totals.to_string())

if __name__=='__main__':main()
