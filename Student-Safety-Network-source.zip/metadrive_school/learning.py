"""One intervention then one episode: terminal contextual Q learning (gamma=0).

The expensive environment returns a completed MetaDrive episode reward. Saved
episodes can be replayed for learning. Updates are never called new simulations.
"""
import argparse,json,time,hashlib,shutil
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
import gymnasium as gym
from .config import DATA,OUT,ACTION_IDS,SEED

FEATURES=['passenger','heavy','bicycle','pedestrian','hour','weekend']

def features(c):
    a=c[FEATURES].to_numpy(dtype=np.float32).copy();a[:,:4]=np.log1p(a[:,:4]);return a

class MitigationEnv(gym.Env):
    """Gymnasium adapter; 'live' calls MetaDrive, 'replay' uses measured episodes."""
    def __init__(self,contexts,runs=None,mode='replay'):
        if mode not in ('live','replay'):raise ValueError('mode must be live or replay')
        self.contexts=contexts.reset_index(drop=True);self.runs=runs;self.mode=mode;self.world=None
        self.action_space=gym.spaces.Discrete(len(ACTION_IDS))
        self.observation_space=gym.spaces.Box(-np.inf,np.inf,shape=(6,),dtype=np.float32)
        self.terminal=True

    def reset(self,seed=SEED,options=None):
        super().reset(seed=seed)
        self.index=(options or {}).get('context_index',int(self.np_random.integers(len(self.contexts))))
        self.terminal=False
        return features(self.contexts.iloc[[self.index]])[0],{'context_id':self.contexts.iloc[self.index].context_id}

    def step(self,action):
        if self.terminal:raise RuntimeError('Call reset before choosing another intervention')
        action=ACTION_IDS[int(action)];context=self.contexts.iloc[self.index].context_id
        if self.mode=='live':
            from .engine import World
            if self.world is None:self.world=World()
            from .run import MAX_COHORT_SECONDS
            self.world.reset(action);r=self.world.run(context,max_time=MAX_COHORT_SECONDS)
        else:
            rows=self.runs[self.runs.context_id.eq(context)&self.runs.action.eq(action)]
            if rows.empty:raise ValueError('No completed simulation for this context and action')
            r=rows.iloc[int(self.np_random.integers(len(rows)))].to_dict()
        self.terminal=True
        if not r['complete']:raise ValueError('Incomplete traveler accounting cannot supply a training reward')
        if r.get('precontact_boundary_violations',1)>0 or r.get('precontact_max_route_deviation_m',float('inf'))>1.5:
            raise ValueError('Physical validation failed; this episode cannot supply a training reward')
        expected=-1000*r['collision_pairs']-5*r['near_pairs']
        if not np.isclose(r['score'],expected):raise ValueError('Saved reward does not reconcile to its event counts')
        return features(self.contexts.iloc[[self.index]])[0],float(r['score']),True,False,r

    def close(self):
        if self.world is not None:self.world.close();self.world=None

def fit(suite='pilot',updates=10000):
    torch.manual_seed(SEED);torch.set_num_threads(1);rng=np.random.default_rng(SEED)
    contexts=pd.read_csv(OUT/f'{suite}_contexts.csv');runs=pd.read_csv(OUT/f'{suite}_runs.csv')
    from .quality import assess
    quality,checked=assess(suite)
    # Exclude the entire matched block if any design fails physics/accounting,
    # rather than letting a design benefit from suppressing or trapping traffic.
    fair=checked.groupby('context_id').agg(ok=('physics_pass','all'),actions=('action','nunique'))
    eligible=fair.index[fair.ok & fair.actions.eq(8)]
    contexts=contexts[contexts.context_id.isin(eligible)]
    runs=runs[runs.context_id.isin(eligible)]
    train_c=contexts[contexts.split.eq('train')];valid_c=contexts[contexts.split.eq('validation')]
    if len(train_c)<2 or len(valid_c)<1:raise RuntimeError('Too few fully matched, physically eligible windows to train and validate. See the quality report.')
    # Test outcomes and benchmark identities are absent from learning matrices.
    tr=runs[runs.split.eq('train')];va=runs[runs.split.eq('validation')]
    assert not tr.duplicated(['context_id','action','realization']).any()
    assert tr.groupby(['context_id','realization']).demand_sha256.nunique().eq(1).all()
    usable=ACTION_IDS
    if not usable:raise RuntimeError('No action has complete train/validation accounting; retain diagnostics, do not train.')
    matrix=tr.groupby(['context_id','action']).score.mean().unstack().reindex(index=train_c.context_id,columns=ACTION_IDS)
    assert matrix.notna().all().all()
    X=features(train_c);mu=X.mean(0);sd=X.std(0);sd[sd<1e-6]=1
    X=(X-mu)/sd;Y=matrix.to_numpy(dtype=np.float32)/1000
    valid=features(valid_c);valid=(valid-mu)/sd
    agents={};progress=[];start=time.monotonic()
    for family in ['tabular','linear','neural']:
        torch.manual_seed(SEED);rng=np.random.default_rng(SEED)
        net=nn.Linear(6,8) if family=='linear' else nn.Sequential(nn.Linear(6,32),nn.Tanh(),nn.Linear(32,32),nn.Tanh(),nn.Linear(32,8))
        optimizer=torch.optim.Adam(net.parameters(),lr=.001)
        table=np.zeros_like(Y);visits=np.zeros_like(Y)
        if family=='tabular':
            for n in range(updates*64):
                i=int(rng.integers(len(X)));a=int(rng.integers(8));visits[i,a]+=1
                table[i,a]+=(Y[i,a]-table[i,a])/visits[i,a]
            predicted=table.mean(0);learned_values=table
        else:
            xx=torch.tensor(X);yy=torch.tensor(Y)
            for n in range(updates):
                i=torch.tensor(rng.integers(len(X),size=64));epsilon=max(.1,1-n/max(1,updates*.8))
                q=net(xx[i]);actions=q.detach().argmax(1)
                explore=rng.random(64)<epsilon;actions[torch.tensor(explore)]=torch.tensor(rng.integers(8,size=int(explore.sum())))
                prediction=q[torch.arange(64),actions];target=yy[i,actions]
                loss=(prediction-target).square().mean();optimizer.zero_grad();loss.backward()
                torch.nn.utils.clip_grad_norm_(net.parameters(),10);optimizer.step()
                if n in [99,999,updates-1]:
                    with torch.no_grad():rmse=float((net(xx)-yy).square().mean().sqrt())*1000
                    progress.append(dict(family=family,update=n+1,training_rmse_points=rmse))
            with torch.no_grad():learned_values=net(xx).numpy();predicted=learned_values.mean(0)
        scores={a:float(predicted[j]*1000) for j,a in enumerate(ACTION_IDS)}
        selected=max(usable,key=lambda a:(scores[a],-ACTION_IDS.index(a)))
        state=dict(family=family,seed=SEED,fixed_action=selected,mean=mu.tolist(),std=sd.tolist(),
                   mean_training_q=scores,updates=updates if family!='tabular' else updates*64,
                   replayed_samples=updates*64,fresh_simulations_during_learning=0,
                   validation_score=float(va[va.action.eq(selected)].score.sum()),
                   training_rmse_points=float(np.sqrt(np.mean((learned_values-Y)**2)))*1000)
        if family=='tabular':state['q_table']=(table*1000).tolist()
        else:
            layers=[net] if family=='linear' else [m for m in net if isinstance(m,nn.Linear)]
            state['layers']=[dict(weight=l.weight.detach().numpy().tolist(),bias=l.bias.detach().numpy().tolist(),activation='linear' if j==len(layers)-1 else 'tanh') for j,l in enumerate(layers)]
        agents[family]=state
    champion=max(agents,key=lambda k:(agents[k]['validation_score'],-['tabular','linear','neural'].index(k)))
    frozen=dict(snapshot=quality['snapshot'],agents=agents,champion=champion,consultant_identity_used=False,test_outcomes_used=False,
        train_contexts=train_c.context_id.tolist(),validation_contexts=valid_c.context_id.tolist(),
        frozen_at_unix=time.time(),duration_s=time.monotonic()-start,device='cpu',
        recommendation_released=quality['recommendation_released'],release_blockers=quality['release_blockers'],
        excluded_contexts=sorted(set(checked.context_id)-set(eligible)),
        note='Small feature network; CPU selected. These are replay updates, not additional simulator episodes.')
    source=OUT/f'{suite}_learner_source';source.mkdir(exist_ok=True)
    for name in ['learning.py','quality.py']:
        shutil.copyfile(Path(__file__).with_name(name),source/name)
    frozen['learning_source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (OUT/f'{suite}_policy_freeze.json').write_text(json.dumps(frozen,indent=2))
    pd.DataFrame(progress).to_csv(OUT/f'{suite}_learning_progress.csv',index=False)
    return frozen

def evaluate(suite='pilot'):
    f=OUT/f'{suite}_policy_freeze.json';frozen=json.loads(f.read_text())
    # This is the first benchmark-key lookup in the learner/evaluator path.
    benchmark=json.loads((DATA/'benchmark_key.json').read_text())['consultant_candidate']
    test=pd.read_csv(OUT/f'{suite}_runs.csv').query("split == 'test'")
    test=test[~test.context_id.isin(frozen['excluded_contexts'])]
    rows=[]
    for name,action in [('unchanged','C01'),('consultant_geometry',benchmark)]+[(k,v['fixed_action']) for k,v in frozen['agents'].items()]:
        z=test[test.action.eq(action)]
        rows.append(dict(policy=name,action=action,runs=len(z),contacts=int(z.collision_pairs.sum()),
            pedestrian_near_pairs=int(z.near_pairs.sum()),score=float(z.score.sum()),
            complete=bool(len(z)>0 and z.complete.all()),arrived=int(z.arrived.sum()),requested=int(z.requested.sum())))
    result=dict(comparison=rows,policy_freeze_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),
        benchmark_revealed_after_freeze=True,real_world_safety_validated=False,
        recommendation_released=frozen['recommendation_released'] and len(test)>0,
        held_out_definition='May 2023 observed demand, with unchanged and alternative geometry simulated using identical travelers',
        limits='One matched demand realization per window in the pilot; no observed near-miss/contact calibration. Geometry is a 2025 tracing.')
    (OUT/f'{suite}_evaluation.json').write_text(json.dumps(result,indent=2));return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--suite',default='pilot');p.add_argument('--updates',type=int,default=10000)
    a=p.parse_args();fit(a.suite,a.updates);print(json.dumps(evaluate(a.suite),indent=2))

if __name__=='__main__':main()
