"""Executable software checks, independent of observed safety-outcome validation."""
import json, math, hashlib
import numpy as np
from .engine import World, contact_pairs
from .checks import traveler
from .config import OUT, MPH, SEED
from .demand import ledger
from .run import signature
from metadrive.base_class.base_object import BaseObject

def main():
    OUT.mkdir(parents=True,exist_ok=True);checks=[];w=World()
    def check(name,passed,**evidence):
        checks.append(dict(name=name,passed=bool(passed),**evidence));print(name,bool(passed),flush=True)
    try:
        for action in ['C01','C07']:
            for arm,target in [('W','E'),('E','W'),('E','N'),('W','N'),('N','W'),('N','E'),('E','E'),('W','W')]:
                w.reset(action);r=w.run('isolated_turn',custom=[traveler('car',arm=arm,target=target)],max_time=90)
                check(f'{action} isolated {arm}->{target}',r['complete'] and r['collision_pairs']==0 and r['boundary_violations']==0 and r['max_route_deviation_m']<.6,
                      complete=r['complete'],curb_intrusions=r['boundary_violations'],max_path_error_m=r['max_route_deviation_m'])
        for mode,arm,target,leg,speed in [('pedestrian','W','E','E',1.4),('pedestrian','W','E','N',1.4),('bicycle','N','E',None,5.)]:
            w.reset('C07');r=w.run('vru_continuity',custom=[traveler('traveler',mode,arm,target,leg,desired=speed)],max_time=120)
            check(f'{mode} continuity {leg or arm}',r['complete'] and r['max_step_displacement_m']<.4 and r['max_route_deviation_m']<.6,
                  largest_step_m=r['max_step_displacement_m'],completed=r['complete'])
        # Detector positive and negative controls deliberately set test fixture poses.
        w.reset('C01');car=traveler('car');ped=traveler('ped','pedestrian',leg='E',desired=1.4)
        a=w.spawn(car,w.route(car));b=w.spawn(ped,w.route(ped));b['obj'].set_position(a['obj'].position)
        for _ in range(3):w.engine.step_physics_world()
        check('Native contact positive control',('car','ped') in contact_pairs(w.engine.physics_world.dynamic_world,{'car':a,'ped':b}))
        b['obj'].set_position([50,50])
        for _ in range(3):w.engine.step_physics_world()
        check('Native contact negative control',not contact_pairs(w.engine.physics_world.dynamic_world,{'car':a,'ped':b}))
        braking=[]
        for mph in [25,30]:
            w.reset('C01');r=traveler('car');a=w.spawn(r,w.route(r));obj=a['obj']
            for _ in range(30):obj.before_step([0,0]);w.engine.step_physics_world()
            direction=np.array([math.cos(obj.heading_theta),math.sin(obj.heading_theta)])
            BaseObject.set_velocity(obj,direction,mph*MPH);start=np.array(obj.position)
            initial=float(obj.speed)
            for _ in range(400):
                obj.before_step([0,-1]);w.engine.step_physics_world()
                if obj.speed<.1:break
            braking.append(dict(mph=mph,initial_speed_mps=initial,stopped=bool(obj.speed<.1),distance_m=float(np.linalg.norm(np.array(obj.position)-start))))
        check('25 mph braking distance shorter than 30 mph',all(r['stopped'] for r in braking) and braking[0]['distance_m']<braking[1]['distance_m'],results=braking)
        for adjacent in [True,False]:
            w.reset('C01');a=traveler('lane_a');b=traveler('lane_b');b['lane_draw']=.99 if adjacent else 0.
            result=w.run('entry_capacity_regression',custom=[a,b],record=True,max_time=70)
            first=min(f['t'] for f in result['frames']);first_ids={f['id'] for f in result['frames'] if f['t']==first}
            check('Adjacent lanes insert independently' if adjacent else 'Same lane insertion preserves separation',
                  result['complete'] and result['collision_pairs']==0 and len(first_ids)==(2 if adjacent else 1),
                  first_frame_actors=len(first_ids),completed=result['arrived'],contacts=result['collision_pairs'])
        pair,_=ledger('20230302T073000');pair=[r.copy() for r in pair if r['id'] in ['s00014','s00112']]
        for r in pair:r['depart']-=180
        for action in ['C01','C02','C07','C08']:
            traces=[]
            for repeat in range(2 if action=='C08' else 1):
                w.reset(action);r=w.run('turn_visibility_regression',custom=pair,record=True,max_time=120)
                traces.append([[f[k] for k in ['t','x','y','speed']] for f in r['frames']])
            check(f'{action} turn clearance regression',r['complete'] and r['collision_pairs']==0 and r['precontact_boundary_violations']==0,contacts=r['collision_pairs'],complete=r['complete'])
            if len(traces)==2:
                identical=np.shape(traces[0])==np.shape(traces[1]) and np.allclose(traces[0],traces[1],atol=1e-6,rtol=0)
                check('Fixed seed trajectory repeatability',identical,frames=len(traces[0]))
    finally:w.close()
    output=dict(snapshot=signature(),seed=SEED,checks=checks,passed=all(c['passed'] for c in checks),
                scope='Software and motion tests only; not calibration to field collisions or near misses.')
    (OUT/'validation.json').write_text(json.dumps(output,indent=2));print(json.dumps(output,indent=2))
    if not output['passed']:raise SystemExit(1)

if __name__=='__main__':main()
