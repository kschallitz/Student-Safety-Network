"""Executable software checks, independent of observed safety-outcome validation."""
import json, math, hashlib
import numpy as np
from .engine import World, contact_pairs, braking_limits
from .checks import traveler
from .config import OUT, MPH, SEED
from .demand import ledger
from .run import signature
from metadrive.base_class.base_object import BaseObject

def main():
    OUT.mkdir(parents=True,exist_ok=True);checks=[];w=World()
    def check(name,passed,**evidence):
        checks.append(dict(name=name,passed=bool(passed),**evidence));print(name,bool(passed),flush=True)
    try:
        for action in ['C01','C07']:
            for arm,target in [('W','E'),('E','W'),('E','N'),('W','N'),('N','W'),('N','E'),('E','E'),('W','W')]:
                w.reset(action);r=w.run('isolated_turn',custom=[traveler('car',arm=arm,target=target)],max_time=90)
                check(f'{action} isolated {arm}->{target}',r['complete'] and r['collision_pairs']==0 and r['boundary_violations']==0 and r['max_route_deviation_m']<.6,
                      complete=r['complete'],curb_intrusions=r['boundary_violations'],max_path_error_m=r['max_route_deviation_m'])
        # The original isolated-route coverage contained passenger cars only.
        # Exercise the truck's weaker native brakes on every observed heavy
        # movement. The source contains no heavy U-turns; the passenger U-turn
        # radius is not a certified truck swept path and is rejected explicitly.
        for action in ['C01','C07']:
            for arm,target in [('W','E'),('E','W'),('W','N'),('N','W'),('N','E')]:
                w.reset(action);r=w.run('isolated_heavy_turn',custom=[traveler('truck','heavy',arm=arm,target=target,desired=15.302167668016418)],max_time=120)
                check(f'{action} isolated truck {arm}->{target}',r['complete'] and r['collision_pairs']==0 and r['boundary_violations']==0 and r['max_route_deviation_m']<.6,
                      complete=r['complete'],curb_intrusions=r['boundary_violations'],max_path_error_m=r['max_route_deviation_m'])
        w.reset('C07')
        try:w.route(traveler('unsupported','heavy',arm='E',target='E'))
        except ValueError:rejected=True
        else:rejected=False
        check('Unsupported truck U-turn rejected before simulation',rejected)
        truck_records,_=ledger('20230518T081500')
        truck=[dict(r,depart=0.) for r in truck_records if r['id']=='s00037']
        w.reset('C08');r=w.run('truck_braking_regression',custom=truck,max_time=120)
        check('Observed truck turn braking regression',r['complete'] and r['boundary_violations']==0 and r['max_route_deviation_m']<.6,
              complete=r['complete'],curb_intrusions=r['boundary_violations'],max_path_error_m=r['max_route_deviation_m'])
        # A queued truck slightly overruns the nominal decision line. The old
        # s<98 cutoff released it into oncoming traffic while still on the
        # 100 m approach. Preserve the complete observed local arrival window.
        gap_records,_=ledger('20230302T154500')
        gap_records=[dict(r,depart=r['depart']-580) for r in gap_records if 580<=r['depart']<=680]
        for action in ['C06','C07']:
            w.reset(action);r=w.run('truck_yield_boundary_regression',custom=gap_records,max_time=180)
            check(f'{action} truck keeps yielding after decision-line overrun',r['complete'] and r['collision_pairs']==0 and r['precontact_boundary_violations']==0,
                  complete=r['complete'],contacts=r['collision_pairs'],requested=r['requested'],arrived=r['arrived'])
        warmup,_=ledger('20230302T144500');warmup=[r for r in warmup if r['depart']<100]
        w.reset('C07');r=w.run('warmup_contact_accounting',custom=warmup,max_time=110)
        event=next((e for e in r['boundary_events'] if e['id']=='w00010'),{})
        check('Former warmup crossing contact and curb deflection avoided',r['warmup_contact_pairs']==0 and r['collision_pairs']==0 and r['precontact_boundary_violations']==0 and not event,
              warmup_contacts=r['warmup_contact_pairs'],scored_contacts=r['collision_pairs'],precontact_curb_intrusions=r['precontact_boundary_violations'],curb_event=event)
        # Preserve the stopping failure as a two-actor regression. These exact
        # properties previously led a walker into a car stopped in the crossing.
        records,_=ledger('20230302T143000')
        car=next(r.copy() for r in records if r['id']=='s00142')
        ped=next(r.copy() for r in records if r['id']=='s00308')
        for action in ['C01','C02','C07','C08']:
            for release in [0.,2.40740183801984,4.,6.]:
                car['depart']=0.;ped['depart']=release
                w.reset(action);r=w.run('crossing_stop_regression',custom=[car.copy(),ped.copy()],max_time=90)
                check(f'{action} reactive crossing release {release:.2f}s',r['complete'] and r['collision_pairs']==0 and r['precontact_boundary_violations']==0,
                      complete=r['complete'],contacts=r['collision_pairs'],arrived=r['arrived'])
        for mode,arm,target,leg,speed in [('pedestrian','W','E','E',1.4),('pedestrian','W','E','N',1.4),('bicycle','N','E',None,5.)]:
            w.reset('C07');r=w.run('vru_continuity',custom=[traveler('traveler',mode,arm,target,leg,desired=speed)],max_time=120)
            check(f'{mode} continuity {leg or arm}',r['complete'] and r['max_step_displacement_m']<.4 and r['max_route_deviation_m']<.6,
                  largest_step_m=r['max_step_displacement_m'],completed=r['complete'])
        for action,arm,target,leg,forward,release in [
            ('C01','E','N','E',False,0.),
            ('C02','E','N','E',False,4.),
            ('C01','W','E','E',False,0.),
            ('C07','N','E','E',True,0.),
        ]:
            car=traveler('car',arm=arm,target=target,desired=13.4)
            ped=traveler('ped','pedestrian',leg=leg,depart=release,desired=1.4);ped['forward']=forward
            w.reset(action);r=w.run('crossing_footprint_liveness',custom=[car,ped],max_time=90)
            check(f'{action} footprint clearance {arm}->{target}/{leg}/{forward}/{release}',
                  r['complete'] and r['collision_pairs']==0,
                  complete=r['complete'],contacts=r['collision_pairs'],remaining=r['remaining_actors'])
        # Single-car tests missed the circular wait between opposing walkers
        # and several stopped lanes. Preserve the actual congested arrival
        # prefix, with both walking directions and every source traveler.
        entry_records,_=ledger('20230302T143000')
        entry_records=[r for r in entry_records if r['depart']<=150]
        for action in ['C01','C02','C07','C08']:
            w.reset(action);r=w.run('opposing_crosswalk_entry',custom=entry_records,max_time=300)
            check(f'{action} opposing walkers and multiple lanes clear',
                  r['complete'] and r['collision_pairs']==0 and r['precontact_boundary_violations']==0,
                  complete=r['complete'],contacts=r['collision_pairs'],requested=r['requested'],arrived=r['arrived'])
        # Detector positive and negative controls deliberately set test fixture poses.
        w.reset('C01');car=traveler('car');ped=traveler('ped','pedestrian',leg='E',desired=1.4)
        a=w.spawn(car,w.route(car));b=w.spawn(ped,w.route(ped));b['obj'].set_position(a['obj'].position)
        for _ in range(3):w.engine.step_physics_world()
        check('Native contact positive control',('car','ped') in contact_pairs(w.engine.physics_world.dynamic_world,{'car':a,'ped':b}))
        b['obj'].set_position([50,50])
        for _ in range(3):w.engine.step_physics_world()
        check('Native contact negative control',not contact_pairs(w.engine.physics_world.dynamic_world,{'car':a,'ped':b}))
        braking=[]
        for mph in [25,30]:
            w.reset('C01');r=traveler('car');a=w.spawn(r,w.route(r));obj=a['obj']
            for _ in range(30):obj.before_step([0,0]);w.engine.step_physics_world()
            direction=np.array([math.cos(obj.heading_theta),math.sin(obj.heading_theta)])
            BaseObject.set_velocity(obj,direction,mph*MPH);start=np.array(obj.position)
            initial=float(obj.speed)
            for _ in range(400):
                obj.before_step([0,-1]);w.engine.step_physics_world()
                if obj.speed<.1:break
            braking.append(dict(mph=mph,initial_speed_mps=initial,stopped=bool(obj.speed<.1),distance_m=float(np.linalg.norm(np.array(obj.position)-start))))
        check('25 mph braking distance shorter than 30 mph',all(r['stopped'] for r in braking) and braking[0]['distance_m']<braking[1]['distance_m'],results=braking)
        from .config import BEHAVIOR
        w.reset('C01');record=traveler('brake_truck','heavy');a=w.spawn(record,w.route(record));obj=a['obj']
        for _ in range(30):obj.before_step([0,0]);w.engine.step_physics_world()
        unit=np.array([math.cos(obj.heading_theta),math.sin(obj.heading_theta)])
        BaseObject.set_velocity(obj,unit,25*MPH);initial=float(obj.speed)
        for step in range(400):
            obj.before_step([0,-1]);w.engine.step_physics_world()
            if obj.speed<.1:break
        observed_decel=(initial-float(obj.speed))/((step+1)*w.dt)
        comfortable,emergency,anticipation=braking_limits(obj,w.dt,BEHAVIOR)
        check('Truck stopping envelope respects measured brake capacity',obj.speed<.1 and abs(emergency-observed_decel)<.1 and comfortable<=emergency and anticipation>BEHAVIOR['reaction_s'],
              observed_decel_mps2=observed_decel,emergency_decel_mps2=emergency,comfortable_decel_mps2=comfortable,anticipation_s=anticipation)
        for adjacent in [True,False]:
            w.reset('C01');a=traveler('lane_a');b=traveler('lane_b');b['lane_draw']=.99 if adjacent else 0.
            result=w.run('entry_capacity_regression',custom=[a,b],record=True,max_time=70)
            first=min(f['t'] for f in result['frames']);first_ids={f['id'] for f in result['frames'] if f['t']==first}
            check('Adjacent lanes insert independently' if adjacent else 'Same lane insertion preserves separation',
                  result['complete'] and result['collision_pairs']==0 and len(first_ids)==(2 if adjacent else 1),
                  first_frame_actors=len(first_ids),completed=result['arrived'],contacts=result['collision_pairs'])
        pair,_=ledger('20230302T073000');pair=[r.copy() for r in pair if r['id'] in ['s00014','s00112']]
        for r in pair:r['depart']-=180
        for action in ['C01','C02','C07','C08']:
            traces=[]
            for repeat in range(2 if action=='C08' else 1):
                w.reset(action);r=w.run('turn_visibility_regression',custom=pair,record=True,max_time=120)
                traces.append([[f[k] for k in ['t','x','y','speed']] for f in r['frames']])
            check(f'{action} turn clearance regression',r['complete'] and r['collision_pairs']==0 and r['precontact_boundary_violations']==0,contacts=r['collision_pairs'],complete=r['complete'])
            if len(traces)==2:
                identical=np.shape(traces[0])==np.shape(traces[1]) and np.allclose(traces[0],traces[1],atol=1e-6,rtol=0)
                check('Fixed seed trajectory repeatability',identical,frames=len(traces[0]))
    finally:w.close()
    output=dict(snapshot=signature(),seed=SEED,checks=checks,passed=all(c['passed'] for c in checks),
                scope='Software and motion tests only; not calibration to field collisions or near misses.')
    (OUT/'validation.json').write_text(json.dumps(output,indent=2));print(json.dumps(output,indent=2))
    if not output['passed']:raise SystemExit(1)

if __name__=='__main__':main()
