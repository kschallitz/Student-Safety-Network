"""Snapshot observed counts and source geometry, never previous simulator outputs."""
import hashlib, json, shutil, subprocess
import numpy as np
import pandas as pd
from .config import ROOT, DATA, OUT, CANDIDATES

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

from pathlib import Path

def main():
    DATA.mkdir(parents=True, exist_ok=True); OUT.mkdir(parents=True, exist_ok=True)
    sources = {
        "observations.csv": ROOT / "data/mitigation_priority/observations.csv",
        "contexts.csv": ROOT / "data/mitigation_priority/contexts.csv",
        "geometry.json": ROOT / "data/sumo_v06/traces.json",
        "speed_distributions.csv": ROOT / "data/traffic_exposure/normalized/speed_distributions.csv",
        "speed_observations.csv": ROOT / "data/traffic_exposure/normalized/speed_observations.csv",
    }
    provenance = []
    for dst, src in sources.items():
        shutil.copyfile(src, DATA / dst)
        provenance.append(dict(file=dst, original=str(src.relative_to(ROOT)), sha256=sha(src)))
    obs = pd.read_csv(DATA / "observations.csv")
    contexts = pd.read_csv(DATA / "contexts.csv")
    assert obs.site.eq("Estates").all() and obs.measurement_status.eq("observed").all()
    assert obs["count"].ge(0).all() and not contexts.context_id.duplicated().any()
    sums = obs.groupby("context_id")["count"].sum()
    assert (contexts.set_index("context_id").total == sums.reindex(contexts.context_id)).all()
    # Use a pre-installation empirical distribution as an approach-speed prior.
    # This is NOT the old SUMO-fitted desired-speed parameter.
    speeds = pd.read_csv(DATA / "speed_distributions.csv")
    pre = speeds[speeds.observation_date.isin(["2023-02-01", "2023-02-02", "2023-02-03"])]
    prior = {}
    for direction, g in pre.groupby("travel_direction"):
        bins = g.groupby(["speed_bin_lower_mph", "speed_bin_upper_mph"], dropna=False)["count"].sum().reset_index()
        bins = bins[bins["count"].gt(0)]
        prior[direction] = bins.to_dict("records")
    assert {"eastbound", "westbound"}.issubset(prior)
    (DATA / "speed_prior.json").write_text(json.dumps(prior, indent=2))
    (DATA / "candidates.json").write_text(json.dumps(CANDIDATES, indent=2))
    # Only evaluation code reads this identity, after learned choices are frozen.
    (DATA / "benchmark_key.json").write_text(json.dumps({"consultant_candidate": "C07"}))
    manifest = dict(sources=provenance, observed_contexts=len(contexts),
        observed_travelers=int(obs["count"].sum()), source_url="https://www.livermoreca.gov/home/showpublisheddocument/12943/638887914440930000",
        geometry_status="April 2025 source tracing; not certified May 2023 as-built geometry",
        speed_prior_status="Observed pre-installation corridor speed bins; uniform within each bin is assumed",
        generated_fields=["individual departure seconds", "pedestrian crossing direction", "individual speeds", "driver reaction and yielding behavior"],
        modeled_components="curb boundaries, crossing lengths, median-constrained routes, approach operating-speed response",
        uncalibrated_components="additional visibility/compliance effects of paint, signs and bollards; measured individual paths and reaction times",
        sumo_runtime_used=False, sumo_calibration_used=False,
        metadrive_commit=subprocess.check_output(["git", "-C", str(ROOT / "vendor/metadrive"), "rev-parse", "HEAD"], text=True).strip())
    (DATA / "manifest.json").write_text(json.dumps(manifest, indent=2))
    print(json.dumps({k:manifest[k] for k in ["observed_contexts", "observed_travelers", "metadrive_commit"]}))

if __name__ == "__main__": main()
