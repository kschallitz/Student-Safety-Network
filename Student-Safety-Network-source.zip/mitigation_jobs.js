/* Live controls use the private job API; no worker credentials enter the browser. */
const MitigationJobs=(()=>{
 let timer=null,generation=0;
 const supported=id=>['J01145','J02019'].includes(id);
 function stop(){generation++;clearTimeout(timer);timer=null;}
 async function api(path,body){
  const response=await fetch('/api/simulation/'+path,{method:body?'POST':'GET',headers:body?{'content-type':'application/json'}:{},...(body?{body:JSON.stringify(body)}:{}),cache:'no-store'});
  if(!response.headers.get('content-type')?.includes('application/json'))throw new Error('Open the hosted website to use its simulation worker.');
  const value=await response.json();if(!response.ok)throw new Error(value.error||'Could not reach the simulation worker.');return value;
 }
 function markup(id){
  if(!supported(id))return '';
  return `<section class="mit-box" id="mit-live"><span class="mit-tag">Run MetaDrive + train the agents</span><h3>Compare mitigations for this intersection</h3><p>Each batch runs the same traffic through every design, then trains three agents and checks their choices on the reserved May periods.</p><label for="mit-traffic-mode">Traffic arrivals</label><select id="mit-traffic-mode"><option value="fresh">New matched arrival realizations</option><option value="saved">Reproduce saved arrivals (reuse checked episodes)</option></select><label for="mit-repeats">Realizations per traffic period</label><select id="mit-repeats"><option value="1">1 · ${id==='J02019'?72:96} episodes</option><option value="3">3 · ${id==='J02019'?216:288} episodes</option><option value="10">10 · ${id==='J02019'?720:960} episodes</option><option value="30">30 · ${id==='J02019'?2160:2880} episodes</option></select><div class="mit-actions"><button type="button" id="mit-run" class="mit-primary" disabled>Run mitigation comparison</button></div><p class="small" id="mit-worker-status" aria-live="polite">Checking simulation worker…</p><div id="mit-job-progress" aria-live="polite"></div><p class="small">New simulations run on your Mac; keep it awake and connected. Saved results remain available on your phone when the Mac is off. One batch can take an hour or more. Larger batches repeat the traffic arrival sampling, not the original count survey.</p></section>`;
 }
 function mount(id,onResult){
  stop();if(!supported(id))return;const g=generation,el=id=>document.getElementById(id);
  const button=el('mit-run');if(!button)return;
  let seen=null;
  el('mit-traffic-mode').onchange=()=>{const saved=el('mit-traffic-mode').value==='saved';el('mit-repeats').disabled=saved;if(saved)el('mit-repeats').value='1';};
  const display=job=>{
   const node=el('mit-job-progress');node.replaceChildren();if(!job)return;
   const title=document.createElement('p');title.textContent=`${job.status[0].toUpperCase()+job.status.slice(1)} · ${job.completed}/${job.total} episodes · ${job.trafficMode==='saved'?'saved arrivals':'new arrivals'}`;node.append(title);
   const progress=document.createElement('progress');progress.max=job.total;progress.value=job.completed;progress.style.width='100%';progress.setAttribute('aria-label','Completed simulation episodes');node.append(progress);
   const message=document.createElement('p');message.className='small';message.textContent=job.message||'';node.append(message);
  };
  async function poll(){
   try{
    const [status,list]=await Promise.all([api('status'),api('jobs?junction='+encodeURIComponent(id))]);if(g!==generation)return;
    const active=list.jobs.find(j=>['queued','running'].includes(j.status)),latest=list.jobs[0];
    el('mit-worker-status').textContent=status.online?'Mac worker online'+(status.jobId?' · processing a comparison.':'.'):'Mac worker offline. Reconnect the Mac and start its worker to run a new comparison.';
    button.disabled=!status.online||!!active;button.textContent=active?'Comparison in progress':'Run mitigation comparison';display(active||latest);
    const saved=list.jobs.find(j=>j.status==='completed'&&j.result?.releaseChecked);
    if(saved&&seen!==saved.id){seen=saved.id;onResult(saved.result,saved);}
   }catch(e){if(g===generation){el('mit-worker-status').textContent=e.message;button.disabled=true;}}
   if(g===generation)timer=setTimeout(poll,15000);
  }
  button.onclick=async()=>{
   button.disabled=true;
   try{const data=await api('jobs',{junctionId:id,realizations:Number(el('mit-repeats').value),trafficMode:el('mit-traffic-mode').value});if(g!==generation)return;display(data.job);button.textContent='Comparison queued';clearTimeout(timer);poll();}
   catch(e){if(g===generation){el('mit-worker-status').textContent=e.message;button.disabled=false;}}
  };
  poll();
 }
 return {markup,mount,stop,supported};
})();
