"""Keep user-facing claims tied to the current target and saved model results."""
from pathlib import Path
import json
import pandas as pd


def write_report(evaluation,summary,prep):
    out=Path('intersection_prediction_output')
    ev=evaluation.loc[evaluation.year.ge(2023)]
    gains={int(y):100*(1-float(ev.loc[ev.year.eq(y)&ev.model.eq('Neural network'),'log_loss'].iloc[0])/float(ev.loc[ev.year.eq(y)&ev.model.eq('Time-band baseline'),'log_loss'].iloc[0])) for y in [2023,2024,2025]}
    uncertainty=json.loads((out/'uncertainty_method.json').read_text()) if (out/'uncertainty_method.json').exists() else {}
    r=(pd.read_csv(out/'probability_ranges.csv').query("junction_id == 'J00699' and model == 'nn'").iloc[0]
       if (out/'probability_ranges.csv').exists() else None)
    example=(f"The neural-network estimate for the Garaventa Ranch / North Vasco / Overlake 500-foot area is {r.point_probability*100:.2f}%, with a central 90% bootstrap model range of {r.model_range_low*100:.2f}%–{r.model_range_high*100:.2f}%. " if r is not None else '')
    lines=['# Intersection-area model: accuracy, uncertainty and corrected case coverage','',
      '**Assessment: exploratory forecasts with caveats; not validated engineering intervention advice.** The percentages are outputs of real fitted models. Their individual-location accuracy is not established, and a nominal bootstrap range does not provide a verified confidence level for the true probability.','',
      '## Corrected target and screenshot finding','',
      'Case **81874171**, September 22, 2022 at 08:06, is recorded on Vasco Road **20 feet north of Garaventa Ranch Road**, with `INTERSECTION=N`. Its mapped point is **23.3 feet** from our junction center. The previous model excluded it because it required `INTERSECTION=Y`, not because the coordinates were too far away. That definition was narrower than the intended safety area.','',
      'The revised target is **at least one geocoded, reported pedestrian/bicycle injury or fatal collision within a 500-foot radius of the selected junction, over 12 months**. Training labels, map history and the highlighted circle use that same area. Intersection flags and road-name spelling do not exclude a nearby coordinate. The Garaventa/Vasco/Overlake area now includes **two source cases, in 2015 and 2022**, including the screenshot case.','',
      f"The {prep['junctions']:,} candidate areas contain {prep['assigned_cases']:,} distinct source cases. Their overlapping circles create {prep['area_case_memberships']:,} area-case memberships. A crash is counted once within each containing circle; these are not {prep['area_case_memberships']:,} independent crashes. Do not sum area probabilities or counts as regional totals. There are {prep['complete_coverage_areas']:,} areas entirely inside the current source-region boundary; edge areas show history but withhold model percentages.",'',
      '## Degree of certainty','',example,
      f"Annual ranges, time-band error bars and paired speed-change ranges use the 5th–95th percentiles of {uncertainty.get('replicates','not yet completed')} spatial-block bootstrap fits for each model. Training locations are resampled in 2-km blocks, keeping all their years and time bands together. This is intended to retain much of the dependence from nearby/overlapping circles. Preprocessing, lagged histories, model family and selected hyperparameters are held fixed.",'',
      '**These are conditional model-stability ranges, not calibrated 90% confidence intervals for real-world risk.** They exclude unknown reporting, coordinate errors, historical road/speed errors, missing travel exposure, omitted variables, future shifts, and model-selection uncertainty. They are not uncertainty intervals for a causal speed-limit intervention. A narrow range can still be wrong. There is no verified number such as “we are 95% certain this intersection’s true risk lies here.”','',
      'Speed-change ranges use paired fits: each resampled model predicts both settings, then their difference is calculated. If the displayed range crosses zero, the direction is unstable across those fits. Even a range entirely above/below zero establishes only the model response, not a causal effect.','',
      '## Temporal diagnostics','',
      f"Training targets are 2017–2021 with three years of preceding history, and 2022 selects the model. There are {summary['train_rows']:,} eligible training rows and {summary['train_events']:,} area-event memberships. The selected network is {summary['selected_nn']}. Inputs are scaled using training data only. The earlier 2023–2025 outcomes have already been inspected; the revised results are reused temporal diagnostics, not a fresh untouched final test. 2024–2025 source records remain provisional.",'',
      f"Relative to the time-band baseline, neural-network log-loss improvements are {gains[2023]:.1f}% (2023), {gains[2024]:.1f}% (2024) and {gains[2025]:.1f}% (2025). These compare errors for the revised 500-foot target, not changes in collisions and not comparisons with the old target's numeric loss.",'',
      ev[['year','model','rows','events','log_loss','brier','average_precision','roc_auc','predicted_events']].rename(columns={'events':'observed area-events','predicted_events':'predicted area-events'}).to_markdown(index=False,floatfmt='.6f'),'',
      'The calibration chart compares mean predictions with observed frequencies. Good ranking or improvement over a baseline does not establish precise individual percentages. Historic road geometry/speeds and continuous exposure remain missing; a future independent time period and local outcome/coverage checks are needed before stronger accuracy claims.','',
      '## Use and reproduce','',
      'Open `intersection_prediction_output/school_intersection_predictions.html`. Select a school, then an intersection. The smaller highlighted circle is the 500-foot modeled area; the larger school circle is the two-mile selection area. History stays tied to all source pedestrian/bicycle cases in the small circle. Map-only age/mode filters do not redefine the prediction target. Complete case lists show the source intersection flag and distances.','',
      '`School_Intersection_Neural_Network.ipynb` embeds the prepared data, saved point models and bootstrap ensembles, plus runnable training and map code. Its default displays/rebuilds saved results; set RETRAIN=True to repeat point-model selection and all bootstrap fits on CPU. Run `intersection_prediction.py rematch`, `intersection_prediction.py train`, `intersection_uncertainty.py`, then `scripts/build_intersection_deliverables.py` locally to repeat the full revision from the saved network.','',
      'Sources: [TIMS codebook](https://tims.berkeley.edu/help/crashdata/switrs-codebook.php), [TIMS query](https://tims.berkeley.edu/tools/query/), [county streets](https://gis.dublin.ca.gov/arcgis/rest/services/EnerGov/EnerGov_DisplayMap/MapServer/6), [Livermore speed inventory](https://services7.arcgis.com/acUiOt0qxC8BlCCx/arcgis/rest/services/Livermore_Vision_zero/FeatureServer/7), [Tracy boundary](https://maps.cityoftracy.org/server/rest/services/SharedServices/Open_Data/MapServer/2).','']
    Path('Intersection_Prediction_Results.md').write_text('\n'.join(lines))
    history=json.loads((out/'historical_speed_summary.json').read_text())
    comparison=pd.read_csv(out/'historical_speed_paired_evaluation.csv')
    ablation=pd.read_csv(out/'speed_ablation_evaluation.csv')
    before_after=pd.read_csv(out/'speed_change_before_after.csv')
    scenario_group=json.loads((out/'speed_sensitivity_audit.json').read_text())['groups']['Livermore']['-5']
    sensitivity=scenario_group['nn']
    annual=['# Annual historical-speed experiment · September 26, 2026','',
      '**Assessment: share with caveats.** The neural network has been retrained with historical speed inputs and transition-year exclusions. Historical speed adds little predictive benefit in the temporal checks. The speed slider remains exploratory, and its direction is not a reliable intervention recommendation.','',
      '## What changed','',
      f"Matched {history['matched_changes']} adopted changes ({history['matched_changes_with_old_and_new']} with numeric old and new limits) and {history['matched_records']-history['matched_changes']} survey/code entries to {history['matched_segments']} current inventory segments. {history['junctions_with_any_historical_speed']} of {prep['junctions']:,} candidate junctions have historical speed coverage in at least one source year. Repeated code snapshots are separate entries, not distinct roads. Unmatched offsets, revised boundaries and ambiguous street endpoints remain deferred.",'',
      history['rule'],'',
      'This is an **annual continuity assumption**, not an assertion that signs changed on January 1 or in June. The exact installation dates remain unknown. Adoption-year targets are withheld for all 500-foot areas touching a matched change corridor, while their source crash records remain visible and can supply later crash-history features. Static current speeds are no longer copied into every historical training year. Current map speeds still describe current road conditions. Historical road geometry and traffic volumes remain unavailable.','',
      '## Did the historical inputs improve prediction?','',
      comparison[['year','model','log_loss','brier']].to_markdown(index=False,floatfmt='.6f'),'',
      'The same eligible diagnostic rows were used for each model in this comparison. The new model slightly improves 2023 and 2024 error, and slightly worsens 2025 error. These differences are small and are not evidence of a reliable intervention effect. The earlier model also used more training rows because it did not exclude transition years.','',
      'A separately selected neural network without any speed inputs uses exactly the same training/validation rows and candidate architectures:', '',
      pd.concat([evaluation.loc[evaluation.model.eq('Neural network')],ablation])[['year','model','log_loss','brier']].sort_values(['year','model']).to_markdown(index=False,floatfmt='.6f'),'',
      'The speed-free network has slightly lower 2022 selection error; differences in later years are mixed or very small. The historical-speed network is retained as an explicitly labeled experiment for inspection, not promoted as the best intervention model.','',
      f"For {scenario_group['road_scenarios']} fully known, uniform-speed Livermore road-at-junction scenarios, lowering one road by 5 mph decreases the network estimate in {sensitivity['probability_down']} scenarios and increases it in {sensitivity['probability_up']}. These scenarios overlap and are not independent roads. Garaventa still shows the counterintuitive direction. Model weights and the browser calculation have been checked; adding limited histories has not resolved the statistical problem.",'',
      '## What happened around actual changes?','',
      f"{len(before_after)} matched changes have a documented old limit and equal full-year windows available on both sides. The table counts distinct geocoded reported pedestrian/bicycle injury/fatal cases within 500 feet of each road stretch, including nearby cross-street incidents. It does not sum overlapping intersection labels. It is not a traffic-adjusted or controlled causal comparison. Reporting/geocoding gaps, pandemic-era travel changes, other road changes and provisional 2024–2025 records can affect these counts.",'',
      before_after[['city','road','limits','old_mph','new_mph','adoption_year_excluded','before_years','after_years','before_cases','after_cases']].to_markdown(index=False),'',
      'Zero before-cases means a relative percent change is undefined; zero on both sides does not establish a safety benefit. Corridors can overlap, so these counts must not be summed as unique regional crashes.','',
      '## Reproduce and inspect','',
      'The updated School_Intersection_Neural_Network notebook embeds the annual panel, matching audit, model weights and runnable training/bootstrap code. It defaults to saved results; RETRAIN=True repeats fitting. The matching audit and source catalog preserve document links and deferred corridors. Historical-speed matching can be rebuilt locally with historical_speed_features.py using the saved road inventory and source tables.','',
      'Sources: the saved [Livermore, Pleasanton and Dublin source catalog](../outputs/speed_history/Historical_Speed_Data_Report.html), [TIMS](https://tims.berkeley.edu/tools/query/), and the source links in the matching audit. The speed slider and bootstrap intervals describe fitted model behavior, not the effect of installing a sign.','']
    Path('Annual_Speed_History_Results.md').write_text('\n'.join(annual))
    # Keep the prior results document current for readers following its existing link.
    text=Path('Intersection_Prediction_Results.md').read_text()
    text=text.replace('Historic road geometry/speeds and continuous exposure remain missing;',
                      'Historical speed coverage is now partial and assumed between source observations; historic road geometry and continuous exposure remain missing;')
    text += '\n\n'+ '\n'.join(annual[2:])
    Path('Intersection_Prediction_Results.md').write_text(text)
