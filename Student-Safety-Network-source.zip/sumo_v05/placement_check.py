"""Bound the effect of unknown sensor position within the reported road block."""
import json
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np,pandas as pd
from .speed_check import ROOT,OUT,run,setup

def main():
 d=pd.read_csv(ROOT/'data/traffic_exposure/normalized/speed_observations.csv');d=d[d.observation_date.eq('2023-05-25')&d.eligible_for_automatic_aggregation];tasks=[(r.observation_date,r.travel_direction,int(r.interval_start[11:13]),int(r.sample_count),851003+int(r.interval_start[11:13])*17,piece) for piece in [4,10] for r in d.itertuples()];rows=[]
 with ProcessPoolExecutor(max_workers=2) as pool:
  jobs={pool.submit(run,t):t for t in tasks}
  for job in as_completed(jobs):
   rows.append({**job.result(),'detector_piece':jobs[job][-1]})
   if len(rows)%24==0:print('Placement checks',len(rows),'/',len(tasks),flush=True)
 pd.DataFrame(rows).to_csv(OUT/'placement_hours.csv',index=False);summary=[]
 for (dr,piece),g in pd.DataFrame(rows).groupby(['direction','detector_piece']):
  speeds=np.concatenate([pd.read_csv(ROOT/r.path/'speeds.csv').mph.to_numpy() for r in g.itertuples()]);loc=setup(piece)[1][dr];summary.append({'direction':dr,'detector_piece':piece,'lon':loc['lon'],'lat':loc['lat'],'requested':int(g.requested.sum()),'detected':len(speeds),'pending':int(g.pending.sum()),'sim_mean_mph':float(speeds.mean()),'sim_p85_mph':float(np.quantile(speeds,.85))})
 pd.DataFrame(summary).to_csv(OUT/'placement_summary.csv',index=False);print(pd.DataFrame(summary).to_string(index=False))
if __name__=='__main__':main()
