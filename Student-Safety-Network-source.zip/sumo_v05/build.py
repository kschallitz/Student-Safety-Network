"""Build the static lab and its source-backed report from saved results."""
import argparse,hashlib,json,shutil
import pandas as pd
from .replay import ROOT,OUT

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--preview',action='store_true');args=ap.parse_args();dest=OUT/'preview' if args.preview else ROOT/'hosted_map/out';dest.mkdir(exist_ok=True,parents=True)
 if not args.preview:
  gate=json.loads((OUT/'verification.json').read_text());assert gate['total_junction_runs']==480 and gate['positive_event_followup_complete']
  nbcheck=json.loads((OUT/'notebook_validation.json').read_text());assert nbcheck['executed_top_to_bottom'] and nbcheck['errors']==0
  assert nbcheck['notebook_sha256']==hashlib.sha256((ROOT/'East_Avenue_Scenario_Lab.ipynb').read_bytes()).hexdigest(),'Notebook changed after validation'
 def records(name):return json.loads(pd.read_csv(OUT/name).to_json(orient='records'))
 summary=json.loads((OUT/'summary.json').read_text());data={'summary':summary,'validation':records('speed_validation.csv'),'scenarios':records('scenario_summary.csv'),'paired':records('paired_changes.csv'),'counts':records('observed_session_counts.csv'),'field':records('explorer_field_check.csv'),'ledger':records('evidence_ledger.csv'),'placement':records('placement_summary.csv')}
 s=(ROOT/'sumo_v05/lab.html').read_text();s=s.replace('__LAB_DATA__',json.dumps(data,separators=(',',':'),allow_nan=False).replace('</','<\\/'))
 if args.preview:s=s.replace('<div class="badge">','<p class="notice caution">Local preview: the full simulation batch is still running. These are interim results.</p><div class="badge">')
 (dest/'east-avenue-lab.html').write_text(s)
 copies={'speed_validation.png':'east-lab-speed-validation.png','speed_distribution.png':'east-lab-speed-distribution.png','east_avenue_observations.csv':'east_avenue_observations.csv','runs.csv':'east-lab-runs.csv','paired_changes.csv':'east-lab-paired-changes.csv','evidence_ledger.csv':'east-lab-evidence-ledger.csv','speed_validation.csv':'east-lab-speed-validation.csv','hourly_binned_speed_check.csv':'east-lab-hourly-speeds.csv','explorer_field_check.csv':'east-lab-field-check.csv','fine.csv':'east-lab-numerical-runs.csv','visibility.csv':'east-lab-visibility-runs.csv'}
 if args.preview:copies={a:b for a,b in copies.items() if (OUT/a).exists()}
 for a,b in copies.items():shutil.copyfile(OUT/a,dest/b)
 if (OUT/'positive_contact_checks.csv').exists():shutil.copyfile(OUT/'positive_contact_checks.csv',dest/'east-lab-contact-checks.csv')
 for p in OUT.glob('animation_*.json'):shutil.copyfile(p,dest/('east-lab-'+p.name))
 shutil.copyfile(ROOT/'sumo_v05/protocol.md',dest/'east-lab-protocol.md')
 if (ROOT/'East_Avenue_Scenario_Lab.ipynb').exists():shutil.copyfile(ROOT/'East_Avenue_Scenario_Lab.ipynb',dest/'East_Avenue_Scenario_Lab.ipynb')
 if not args.preview:
  assert summary['primary_runs']==384 and summary['fine_runs']==48 and summary['visibility_runs']==48,'Do not publish an unfinished ensemble'
  assert len(list(dest.glob('east-lab-animation_*.json')))==6
  assert summary['speed_holdout_pass']
 print(json.dumps({'page':str(dest/'east-avenue-lab.html'),'runs':summary['primary_runs'],'preview':args.preview}))
if __name__=='__main__':main()
