"""East Avenue observed-demand scenario lab; independent of Explorer fitting."""
