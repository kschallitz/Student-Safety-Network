"""Release gates: complete schedules, real outputs, matched inputs and speed propagation."""
import hashlib,json,xml.etree.ElementTree as E
import numpy as np,pandas as pd
from .replay import ROOT,OUT,SEEDS

def main():
 checks={};allruns=[]
 for name,n,step in [('runs',384,.2),('fine',48,.1),('visibility',48,.2)]:
  d=pd.read_csv(OUT/(name+'.csv'));schedule=pd.read_csv(OUT/(name+'_schedule.csv'));keys=['session_id','seed','posted_mph','step','visibility_m'];assert len(d)==n and len(schedule)==n;assert not d.duplicated(keys).any();assert set(map(tuple,d[keys].to_numpy()))==set(map(tuple,schedule[keys].to_numpy()));assert d.step.eq(step).all();assert d.action_step.eq(.2).all();assert d.integration.eq('ballistic').all();assert json.loads((OUT/(name+'_failures.json')).read_text())==[];checks[name+'_schedule_complete']=True;allruns.append(d)
 d=pd.concat(allruns,ignore_index=True);audited_limits=0;reused=0
 for r in d.itertuples():
  p=ROOT/r.path;saved=json.loads((p/'result.json').read_text());assert saved['contact_pairs']==r.contact_pairs and saved['study_arrived']==r.study_arrived
  assert hashlib.sha256((p/'demand.rou.xml').read_bytes()).hexdigest()==r.demand_sha256
  cfg=E.parse(p/'run.sumocfg').getroot();proc=cfg.find('processing')
  assert proc.find('pedestrian.striping.jamtime.narrow').get('value')=='-1'
  assert proc.find('step-method.ballistic').get('value')=='true'
  assert proc.find('time-to-teleport').get('value')=='-1'
  if r.posted_mph!=30:
   audit=json.loads((p/'runtime_speed_limit_audit.json').read_text());assert len(audit)>0;assert all(abs(x['required_mps']-x['runtime_mps'])<1e-8 for x in audit);audited_limits+=len(audit)
  elif getattr(r,'reused_unchanged_baseline',False) is True:reused+=1
  trips=E.parse(p/'trips.xml').getroot();arrived=sum(z.get('id','').startswith('s') for z in trips);assert arrived==r.study_arrived
  assert bool(r.complete)==(r.study_requested==arrived and r.pending==0)
 for (sid,seed,step,vis),g in d.groupby(['session_id','seed','step','visibility_m']):
  assert set(g.posted_mph)=={25,30,35};assert g.demand_sha256.nunique()==1
 speed=pd.read_csv(OUT/'speed_validation.csv');assert len(speed)==4 and speed['pass'].all() and speed.complete.all()
 placement=pd.read_csv(OUT/'placement_summary.csv');assert placement.requested.eq(placement.detected).all() and placement.pending.eq(0).all()
 reuse=json.loads((OUT/'baseline_reuse_verification.json').read_text());assert reuse['all_metrics_identical'] and reuse['scenario.add.xml_identical'] and reuse['demand.rou.xml_identical'] and reuse['run.sumocfg_identical']
 field=pd.read_csv(OUT/'explorer_field_check.csv');assert len(field)==12 and field.known_label_all_bands.all()
 positive=pd.concat(allruns[::2],ignore_index=True);positive=positive[positive.contact_pairs.gt(0)].sort_values(['visibility_m','session_id','seed','posted_mph']).head(24)
 follow=pd.read_csv(OUT/'positive_contact_checks.csv');assert set(follow.coarse_path)==set(positive.path)
 for r in follow.itertuples():
  a=json.loads((ROOT/r.coarse_path/'result.json').read_text());b=json.loads((ROOT/r.fine_path/'result.json').read_text());assert a['demand_sha256']==b['demand_sha256']==r.demand_sha256;assert a['contact_pairs']==r.coarse_contact_pairs and b['contact_pairs']==r.fine_contact_pairs;assert b['step']==.1 and b['action_step']==.2;assert a['complete']==bool(r.coarse_complete) and b['complete']==bool(r.fine_complete)
 checks['positive_event_followup_complete']=True
 animations=[]
 for site in ['Estates','Hillcrest']:
  for mph in [25,30,35]:
   a=json.loads((OUT/f'animation_{site}_{mph}.json').read_text());row=d[d.site.eq(site)&d.posted_mph.eq(mph)&d.start_hour.eq(14)&d.seed.eq(SEEDS[0])&d.step.eq(.2)&d.visibility_m.eq(4.5)].iloc[0];assert a['source_run']==row.path and len(a['frames'])==181;assert [x['t'] for x in a['frames']]==list(range(181));assert any(x['points'] for x in a['frames']);animations.append({'site':site,'mph':mph,'frames':181})
 modelhash=hashlib.sha256((ROOT/'intersection_prediction_output/model.json').read_bytes()).hexdigest();assert modelhash=='12d19ef2f8bd7ab047e50f3fa435c29c8a8bada6ff5d26fdd85c8ebf1f4c3818'
 sources=['data/traffic_exposure/raw/east_avenue_tactical_final_2024.pdf','data/sumo_v02/junction_demand_15min.csv','data/traffic_exposure/normalized/speed_observations.csv','data/traffic_exposure/normalized/speed_distributions.csv','data/traffic_exposure/normalized/speed_daily_summaries.csv','outputs/sumo_v03/east_joined.net.xml','data/sumo_v03/fixed_signal.add.xml','outputs/sumo_v05/calibration.json','sumo_v05/replay.py','sumo_v05/speed_check.py','sumo_v05/calibrate.py']
 manifest={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources};(OUT/'source_manifest.json').write_text(json.dumps(manifest,indent=2))
 result={**checks,'total_junction_runs':len(d),'complete_primary_runs':int(allruns[0].complete.sum()),'incomplete_primary_runs':int((~allruns[0].complete).sum()),'all_demand_pairs_identical':True,'runtime_internal_lane_limit_checks':audited_limits,'baseline_reuse_control_pass':True,'animations':animations,'speed_holdout_pass':True,'detector_placement_completed':True,'model_sha256_unchanged':modelhash,'collision_probability_validation_claimed':False};(OUT/'verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
