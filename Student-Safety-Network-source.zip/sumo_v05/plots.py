"""Editable publication figures from the reviewed tables."""
import os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR',str(Path(__file__).resolve().parents[1]/'outputs/.mplconfig'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np,pandas as pd
from .replay import OUT

def main():
 plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white','axes.titleweight':'bold'})
 d=pd.read_csv(OUT/'speed_validation.csv');d=d[d.date.eq('2023-05-25')];fig,ax=plt.subplots(1,2,figsize=(10,4),layout='constrained')
 for a,stat,label in zip(ax,['mean','p85'],['Average speed','85th percentile speed']):
  x=np.arange(2);a.bar(x-.18,d['observed_'+stat+'_mph'],.36,label='Observed May 25',color='#153c52');a.bar(x+.18,d['sim_'+stat+'_mph'],.36,label='SUMO, fit May 24',color='#168a8c');a.set_xticks(x,['Eastbound','Westbound']);a.set_ylim(0,45);a.set_ylabel('mph');a.set_title(label)
  for i,(_,r) in enumerate(d.iterrows()):a.text(i,40,f"Error {r[stat+'_error_mph']:+.2f} mph",ha='center',fontsize=10)
 handles,labels=ax[0].get_legend_handles_labels();fig.legend(handles,labels,fontsize=9,loc='outside lower center',ncol=2,frameon=False);fig.suptitle('Independent next-day speed check · Jensen–Estates midblock');fig.savefig(OUT/'speed_validation.png',dpi=160);plt.close(fig)
 c=pd.read_csv(OUT/'speed_cdf.csv');c=c[c.date.eq('2023-05-25')];fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
 for a,(dr,g) in zip(axes,c.groupby('direction')):
  a.plot(g.upper_bound_mph,g.observed_fraction*100,'s--',color='#153c52',markersize=4,label='Observed bin limits');a.plot(g.upper_bound_mph,g.simulated_fraction*100,'o-',color='#168a8c',markersize=3,label='SUMO at same limits');a.set(xlim=(10,60),ylim=(0,102),xlabel='Speed bin upper limit (mph)',ylabel='Vehicles at or below limit (%)',title=dr.title());a.legend(fontsize=9)
 fig.suptitle('May 25 distribution check · compared at published bin limits');fig.savefig(OUT/'speed_distribution.png',dpi=160);plt.close(fig)
 s=pd.read_csv(OUT/'scenario_summary.csv');s=s[s.start_hour.eq(14)&s.visibility_m.eq(4.5)];fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
 for a,(site,g) in zip(axes,s.groupby('site')):
  g=g.sort_values('posted_mph');y=g.east_approach_mean_mph;err=np.vstack([y-g.east_approach_mean_mph_low,g.east_approach_mean_mph_high-y]);a.errorbar(g.posted_mph,y,yerr=err,fmt='o-',capsize=4,color='#168a8c');a.set(xticks=[25,30,35],ylim=(0,40),xlabel='Assumed posted limit (mph)',ylabel='Simulated approach speed (mph)',title=site);a.grid(axis='y',alpha=.2)
 fig.suptitle('Dismissal traffic · approach speed response\n95% seed-mean intervals; default 4.5 m visibility');fig.savefig(OUT/'speed_scenarios.png',dpi=160);plt.close(fig)
 raw=pd.read_csv(OUT/'runs.csv');vis=pd.read_csv(OUT/'visibility.csv') if (OUT/'visibility.csv').exists() else raw.iloc[:0];matched=raw[raw.seed.isin(vis.seed)] if len(vis) else raw;s=pd.concat([matched,vis]);s=s[s.start_hour.eq(14)].groupby(['site','posted_mph','visibility_m']).east_approach_mean_mph.mean().reset_index();fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
 for a,(site,g) in zip(axes,s.groupby('site')):
  for vis,z in g.groupby('visibility_m'):
   z=z.sort_values('posted_mph');a.plot(z.posted_mph,z.east_approach_mean_mph,'o-',label=f'{vis:g} m assumed visibility')
  a.set(xticks=[25,30,35],ylim=(0,40),xlabel='Posted limit (mph)',ylabel='Approach speed (mph)',title=site);a.legend(fontsize=9)
 fig.suptitle('Visibility is an unmeasured input, not a fitted fact\nMatched two-seed sensitivity accompanies the primary ensemble');fig.savefig(OUT/'visibility_sensitivity.png',dpi=160);plt.close(fig)
if __name__=='__main__':main()
