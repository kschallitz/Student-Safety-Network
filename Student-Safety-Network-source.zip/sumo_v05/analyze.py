"""Recompute summaries from completed runs, preserving failure and uncertainty."""
import hashlib,json
from pathlib import Path
import numpy as np,pandas as pd
from scipy.stats import beta
from .replay import ROOT,OUT

METRICS=['east_approach_mean_mph','east_approach_p85_mph','turn_mean_mph','motor_duration_s','motor_time_loss_s','pedestrian_duration_s','pedestrian_time_loss_s']
def interval(k,n):return (float(beta.ppf(.025,k,n-k+1)) if k else 0.,float(beta.ppf(.975,k+1,n-k)) if k<n else 1.)

def main():
 d=pd.read_csv(OUT/'runs.csv');fine=pd.read_csv(OUT/'fine.csv') if (OUT/'fine.csv').exists() else pd.DataFrame();vis=pd.read_csv(OUT/'visibility.csv') if (OUT/'visibility.csv').exists() else pd.DataFrame();all_scenarios=pd.concat([d,vis],ignore_index=True);rows=[];paired=[];rng=np.random.default_rng(9123)
 for (site,h,mph,visibility),g in all_scenarios.groupby(['site','start_hour','posted_mph','visibility_m']):
  good=g[g.complete];k=int(good.any_contact.sum());n=len(good);missing=len(g)-n;lo=interval(k,len(g))[0];hi=interval(k+missing,len(g))[1]
  r={'site':site,'start_hour':int(h),'posted_mph':int(mph),'visibility_m':visibility,'runs':len(g),'complete_runs':n,'incomplete_runs':missing,'contact_runs':k,'contact_pairs':int(good.contact_pairs.sum()),'contact_probability':k/n if n else None,'contact95_low':lo,'contact95_high':hi,'vru_requested_per_run':int(g.iloc[0].vru_requested),'total_requested_per_run':int(g.iloc[0].study_requested)}
  for metric in METRICS:
   a=good[metric].to_numpy();boot=np.mean(a[rng.integers(0,len(a),(2000,len(a)))],axis=1) if len(a) else [np.nan];r[metric]=float(np.mean(a));r[metric+'_low'],r[metric+'_high']=map(float,np.quantile(boot,[.025,.975]))
  r['continuous_interval_method']='observed range across two runs' if n==2 else '2000-resample percentile bootstrap 95% interval over seeds'
  rows.append(r)
 for (site,h,visibility),g in all_scenarios.groupby(['site','start_hour','visibility_m']):
  base=g[g.posted_mph.eq(30)]
  for mph in [25,35]:
   p=base.merge(g[g.posted_mph.eq(mph)],on=['session_id','seed'],suffixes=('_base','_scenario'));assert p.demand_sha256_base.eq(p.demand_sha256_scenario).all();good=p[p.complete_base&p.complete_scenario]
   r={'site':site,'start_hour':int(h),'posted_mph':mph,'visibility_m':visibility,'paired_runs':len(p),'complete_pairs':len(good),'demand_hashes_identical':True,'contact_run_difference':float((good.any_contact_scenario-good.any_contact_base).mean()),'fewer_contact_runs':int((good.any_contact_scenario<good.any_contact_base).sum()),'more_contact_runs':int((good.any_contact_scenario>good.any_contact_base).sum())}
   for metric in METRICS:
    a=(good[metric+'_scenario']-good[metric+'_base']).to_numpy();boot=np.mean(a[rng.integers(0,len(a),(2000,len(a)))],axis=1);r[metric+'_difference']=float(np.mean(a));r[metric+'_difference_low'],r[metric+'_difference_high']=map(float,np.quantile(boot,[.025,.975]))
   r['continuous_interval_method']='observed range of two paired changes' if len(good)==2 else '2000-resample paired percentile bootstrap 95% interval over seeds'
   paired.append(r)
 pd.DataFrame(rows).to_csv(OUT/'scenario_summary.csv',index=False);pd.DataFrame(paired).to_csv(OUT/'paired_changes.csv',index=False)
 if len(fine):
  p=d.merge(fine,on=['site','session_id','seed','posted_mph'],suffixes=('_coarse','_fine'));assert p.demand_sha256_coarse.eq(p.demand_sha256_fine).all();p['contacts_changed']=p.contact_pairs_coarse.ne(p.contact_pairs_fine);p['approach_speed_difference']=p.east_approach_mean_mph_fine-p.east_approach_mean_mph_coarse;p['turn_speed_difference']=p.turn_mean_mph_fine-p.turn_mean_mph_coarse;p['complete_pair']=p.complete_coarse&p.complete_fine;p.to_csv(OUT/'numerical_pairs.csv',index=False)
  control={'paired_runs':len(p),'complete_pairs':int(p.complete_pair.sum()),'contact_count_disagreements':int(p.contacts_changed.sum()),'coarse_contacts':int(p.contact_pairs_coarse.sum()),'fine_contacts':int(p.contact_pairs_fine.sum()),'approach_speed_mean_abs_difference_mph':float(p.approach_speed_difference.abs().mean()),'turn_speed_mean_abs_difference_mph':float(p.turn_speed_difference.abs().mean())}
 else:control={'status':'not yet run'}
 # Independent field-speed distribution comparison, after fitting two moments.
 bins=pd.read_csv(ROOT/'data/traffic_exposure/normalized/speed_distributions.csv');hours=pd.read_csv(OUT/'speed_hours.csv');cdf=[]
 for (date,dr),g in hours.groupby(['date','direction']):
  speeds=np.concatenate([pd.read_csv(ROOT/r.path/'speeds.csv').mph.to_numpy() for r in g.itertuples()]);b=bins[bins.observation_date.eq(date)&bins.travel_direction.eq(dr)].groupby('speed_bin_upper_mph',dropna=False)['count'].sum().sort_index();total=b.sum();cumulative=0
  for bound,count in b.items():
   cumulative+=count
   if pd.notna(bound):cdf.append({'date':date,'direction':dr,'upper_bound_mph':float(bound),'observed_fraction':cumulative/total,'simulated_fraction':float(np.mean(speeds<=bound))})
 pd.DataFrame(cdf).to_csv(OUT/'speed_cdf.csv',index=False)
 source=pd.read_csv(ROOT/'data/sumo_v02/junction_demand_15min.csv');source=source[source.phase.eq('post_installation')];source.to_csv(OUT/'east_avenue_observations.csv',index=False)
 source.groupby(['site','date','session_id','mode'])['count'].sum().unstack(fill_value=0).reset_index().to_csv(OUT/'observed_session_counts.csv',index=False)
 speed=pd.read_csv(OUT/'speed_validation.csv');modelhash=hashlib.sha256((ROOT/'intersection_prediction_output/model.json').read_bytes()).hexdigest()
 result={'experiment':'v0.5','website_version':'0.12','primary_runs':len(d),'fine_runs':len(fine),'visibility_runs':len(vis),'complete_primary_runs':int(d.complete.sum()),'primary_raw_contact_pairs':int(d.contact_pairs.sum()),'primary_contact_pairs_complete_runs':int(d.loc[d.complete,'contact_pairs'].sum()),'primary_contact_pairs_incomplete_runs':int(d.loc[~d.complete,'contact_pairs'].sum()),'calibration_date':'2023-05-24','validation_date':'2023-05-25','speed_fit_pass':bool(speed[speed.date.eq('2023-05-24')]['pass'].all()),'speed_holdout_pass':bool(speed[speed.date.eq('2023-05-25')]['pass'].all()),'speed_validation':speed.to_dict('records'),'numerical_check':control,'model_sha256':modelhash,'explorer_refitted':False,'simulation_endpoint':'physical pedestrian/bicycle contact during a repeated observed two-hour pattern','field_endpoint':'reported pedestrian/bicycle injury or fatal collision within 500 feet','collision_probability_validated':False,'transfer_status':'workflow and code transferable; school-specific demand, speeds, control and geometry must be measured before applying numbers'}
 if (OUT/'positive_contact_checks.json').exists():result['positive_contact_checks']=json.loads((OUT/'positive_contact_checks.json').read_text())
 (OUT/'summary.json').write_text(json.dumps(result,indent=2,allow_nan=False));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
