"""Same-endpoint historical Explorer check; no conversion from SUMO contacts."""
import json
import numpy as np,pandas as pd
from scipy.stats import poisson
from intersection_prediction import load_prepared,predict_export
from ten_year_model import feature_year
from sumo_comparison.run import SITES
from .replay import ROOT,OUT

def main():
 j,c,u=load_prepared();bundle=json.loads((ROOT/'intersection_prediction_output/model.json').read_text());indices={site:int(np.flatnonzero(j.junction_id.eq(v['junction_id']))[0]) for site,v in SITES.items()};rows=[];frozen=[];members=pd.read_csv(ROOT/'intersection_prediction_output/case_area_membership.csv')
 for year in [2023,2024,2025]:
  x=feature_year(j,c,u,year,bundle['cities']).reshape(len(j),6,-1)
  for site,idx in indices.items():
   cases=members[members.junction_index.eq(idx)&members.year.eq(year)].drop_duplicates('case_id');known=not bool(u[idx,year-2014].any())
   for kind in ['nn','glm']:
    rates=predict_export(bundle[kind],x[idx]);mu=float(rates.sum());p=float(-np.expm1(-mu));count=len(cases);frozen.append({'site':site,'year':year,'kind':kind,'features':x[idx].tolist(),'rates':rates.tolist(),'expected_count':mu,'recorded_cases':count,'case_ids':cases.case_id.tolist(),'known_label':known})
    rows.append({'site':site,'junction_id':SITES[site]['junction_id'],'year':year,'model':kind,'expected_count':mu,'probability_at_least_one':p,'recorded_cases':count,'recorded_any':int(count>0),'brier_component':(p-int(count>0))**2 if known else None,'known_label_all_bands':known,'provisional_export_year':year>=2024,'poisson_95_count_low':int(poisson.ppf(.025,mu)),'poisson_95_count_high':int(poisson.ppf(.975,mu)),'case_ids':' '.join(str(z) for z in cases.case_id),'status':'reused retrospective diagnostic; all dates within year, not intervention effect'})
 pd.DataFrame(rows).to_csv(OUT/'explorer_field_check.csv',index=False)
 (OUT/'frozen_field_inference.json').write_text(json.dumps({'models':bundle,'rows':frozen},indent=2))
 pd.DataFrame([{'site':site,**SITES[site],'junction_index':idx} for site,idx in indices.items()]).to_csv(OUT/'field_check_locations.csv',index=False)
 print(pd.DataFrame(rows).to_string(index=False))
if __name__=='__main__':main()
