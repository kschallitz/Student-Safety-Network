"""Check finer-grained speed evidence and record what was actually observed."""
import json
import numpy as np,pandas as pd
from .replay import ROOT,OUT

def main():
 bins=pd.read_csv(ROOT/'data/traffic_exposure/normalized/speed_distributions.csv');hours=pd.read_csv(OUT/'speed_hours.csv');rows=[]
 for r in hours.itertuples():
  b=bins[bins.observation_date.eq(r.date)&bins.travel_direction.eq(r.direction)&bins.interval_start.str[11:13].astype(int).eq(r.hour)].sort_values('speed_bin_lower_mph');positive=b[b['count'].gt(0)];total=int(positive['count'].sum());assert total==r.requested
  lower=float(np.average(positive.speed_bin_lower_mph,weights=positive['count']));upper=float(np.average(positive.speed_bin_upper_mph,weights=positive['count'])) if positive.speed_bin_upper_mph.notna().all() else None
  q=positive.loc[positive['count'].cumsum().ge(.85*total)].iloc[0];qlo=float(q.speed_bin_lower_mph);qhi=float(q.speed_bin_upper_mph) if pd.notna(q.speed_bin_upper_mph) else None
  rows.append({'date':r.date,'direction':r.direction,'hour':r.hour,'n':total,'source_page':int(b.iloc[0].source_page),'mean_lower_mph':lower,'mean_upper_mph':upper,'sim_mean_mph':r.mean_mph,'p85_lower_mph':qlo,'p85_upper_mph':qhi,'sim_p85_mph':r.p85_mph,'school_or_evening_window':r.hour in [7,8,14,15,16,17],'mean_inside_source_bin_bounds':bool(r.mean_mph>=lower and (upper is None or r.mean_mph<=upper)),'p85_inside_source_bin_bounds':bool(r.p85_mph>=qlo and (qhi is None or r.p85_mph<=qhi))})
 pd.DataFrame(rows).to_csv(OUT/'hourly_binned_speed_check.csv',index=False)
 ledger=[
  ('motor movements','Observed','May 18/20 2023','15-minute passenger count derived as total minus observed heavy subset'),
  ('pedestrian and bicycle movements','Observed','May 18/20 2023','Separate modes and crossing legs; not all are verified students'),
  ('midblock speeds','Observed','May 24/25 2023','Named Jensen–Estates block; exact detector position unknown'),
  ('arrival instants','Modeled','Within each observed 15-minute interval','Uniform random arrival time; warmup repeats first interval'),
  ('30 mph East Avenue reference','Documented corridor prior','City Phase I report p22 and posted-limit inventory','School-specific conditional restrictions not scheduled; 25 mph tested as a scenario'),
  ('side-street speed','Assumed','25 mph','No measured side-street speed distribution'),
  ('road and crossing geometry','Mapped approximation','OSM September 2026','Not a surveyed 2023 as-built; lane/sidewalk widths include SUMO defaults'),
  ('signal control','Modeled prior','2020 HCM worksheets','Not observed controller log; same timing retained across speed cases'),
  ('driver conflict visibility','Assumed sensitivity','4.5 m and 30 m','Neither value measured by the report; affects approach speeds substantially'),
  ('curb extensions and median treatment','Observed project description','April installation, June adjustments 2023','Site-specific curb geometry not measured; 22% corridor average not applied sitewide'),
  ('physical contacts','Simulated','Repeated two-hour patterns','Not injury/fatal events and not an RL reward calibrated to field risk'),
  ('recorded injury/fatal crashes','Observed reported records','TIMS 2014–2025 export','2024/2025 provisional; all ages; overlapping 500-foot areas share cases')]
 pd.DataFrame(ledger,columns=['input_or_outcome','measurement_status','period_or_value','qualification']).to_csv(OUT/'evidence_ledger.csv',index=False)
 d=pd.DataFrame(rows);hold=d[d.date.eq('2023-05-25')&d.school_or_evening_window];print(hold[['direction','hour','mean_lower_mph','sim_mean_mph','mean_upper_mph','p85_lower_mph','sim_p85_mph','p85_upper_mph']].to_string(index=False));print('Mean inside bin bounds',int(hold.mean_inside_source_bin_bounds.sum()),'/',len(hold))
if __name__=='__main__':main()
