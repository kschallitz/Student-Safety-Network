"""Small actual SUMO trajectory replays for the interactive scenario lab."""
import json,math,os,xml.etree.ElementTree as E
from concurrent.futures import ProcessPoolExecutor
import pandas as pd,sumolib
from .replay import ROOT,OUT,SEEDS,context,xml

def record(row):
 import libsumo as sim
 site,mph=row['site'],int(row['posted_mph']);p=OUT/'animation_runs'/f'{site}_{mph}';p.mkdir(parents=True,exist_ok=True);original=ROOT/row['path'];n,_=context();center=n.getNode(site).getCoord();add=E.parse(original/'scenario.add.xml')
 for z in list(add.getroot()):
  if z.tag=='instantInductionLoop':add.getroot().remove(z)
 xml(add.getroot(),p/'scenario.add.xml');cfg=E.parse(original/'run.sumocfg')
 inp=cfg.getroot().find('input');inp.find('net-file').set('value',str(ROOT/'outputs/sumo_v03/east_joined.net.xml'));inp.find('route-files').set('value',str(original/'demand.rou.xml'));inp.find('additional-files').set('value','scenario.add.xml');cfg.getroot().remove(cfg.getroot().find('output'));xml(cfg.getroot(),p/'run.sumocfg')
 lanes=[]
 for e in n.getEdges(withInternal=True):
  if min(math.dist(center,pt) for pt in e.getShape())>125:continue
  for l in e.getLanes():
   if l.allows('passenger') or l.allows('pedestrian'):
    lanes.append({'id':l.getID(),'shape':[[round(x-center[0],2),round(y-center[1],2)] for x,y in l.getShape()],'width':l.getWidth(),'kind':'crossing' if e.getFunction()=='crossing' else 'sidewalk' if not l.allows('passenger') else 'motor'})
 frames=[];sim.start([sumolib.checkBinary('sumo'),'-c',str(p/'run.sumocfg'),'--no-step-log','true','--duration-log.disable','true','--no-warnings','true'])
 try:
  sim.simulationStep(2700)
  for t in range(2700,2881):
   if t>2700:sim.simulationStep(t)
   points=[]
   for domain,kind in [(sim.vehicle,'motor'),(sim.person,'pedestrian')]:
    for vid in domain.getIDList():
     x,y=domain.getPosition(vid)
     if math.dist((x,y),center)>125:continue
     typ='pedestrian' if kind=='pedestrian' else 'bicycle' if vid.endswith('_bicycle') else 'heavy' if vid.endswith('_heavy') else 'motor'
     points.append([vid,round(x-center[0],2),round(y-center[1],2),round(domain.getAngle(vid),1),typ,round(domain.getSpeed(vid)/.44704,1)])
   frames.append({'t':t-2700,'points':points})
 finally:sim.close()
 out={'site':site,'posted_mph':mph,'seed':int(row['seed']),'date':'2023-05-18','clock_start':'14:30','duration_seconds':180,'frame_interval_seconds':1,'lanes':lanes,'frames':frames,'source_run':row['path'],'interpretation':'actual SUMO trajectories from the same recorded demand and fixed seed, not field video; current mapped geometry approximation'}
 (OUT/f'animation_{site}_{mph}.json').write_text(json.dumps(out,separators=(',',':')));return {'site':site,'mph':mph,'frames':len(frames)}

def main():
 d=pd.read_csv(OUT/'runs.csv');d=d[d.start_hour.eq(14)&d.seed.eq(SEEDS[0])]
 assert len(d)==6
 with ProcessPoolExecutor(max_workers=2) as p:
  for r in p.map(record,d.to_dict('records')):print(r,flush=True)
if __name__=='__main__':main()
