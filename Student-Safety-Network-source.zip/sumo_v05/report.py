"""Plain-language analytical handoff with actual outcomes, not promised tests."""
import json
import pandas as pd
from .replay import ROOT,OUT

def main():
 result=json.loads((OUT/'summary.json').read_text());v=pd.read_csv(OUT/'speed_validation.csv');s=pd.read_csv(OUT/'scenario_summary.csv');p=pd.read_csv(OUT/'paired_changes.csv');field=pd.read_csv(OUT/'explorer_field_check.csv');nc=result['numerical_check'];pc=result['positive_contact_checks'];selected=s[s.start_hour.eq(14)&s.visibility_m.eq(4.5)].copy()
 selected['contact interval']=selected.apply(lambda r:f"{100*r.contact_probability:.1f}% [{100*r.contact95_low:.1f}, {100*r.contact95_high:.1f}]",axis=1)
 text=f'''# East Avenue scenario lab — website v0.12

The East Avenue simulation now has a measured operating-speed calibration,
an independent next-day speed check, and {result['primary_runs']} matched speed
experiments on the actual 15-minute traffic counts. Another {result['fine_runs']}
fine-step and {result['visibility_runs']} visibility runs test important assumptions.
The interactive page includes actual SUMO trajectory replays and downloadable inputs.

## What is now calibrated

The earlier February fit was transferred to the mapped road without checking its
output there. The new detector audit found average speeds about 1.5 mph too low.
Two desired-speed parameters per direction were refitted using **May 24 only**.
Optimization compresses the hourly flows into six ranges; final verification replays
every original hour. May 25 was excluded from fitting, though it had been inspected
in earlier diagnostics. This is an out-of-fit check, not a newly blinded experiment.

{v[['date','direction','observed_mean_mph','sim_mean_mph','observed_p85_mph','sim_p85_mph','simulated_n']].to_markdown(index=False,floatfmt='.3f')}

The speed station is somewhere between Jensen and Estates; its exact position is
not reported. The simulation uses an approximate middle-of-block position on the
mapped road. Every requested speed-check vehicle passes the detector. Good agreement
in these two speed statistics does not establish field collision-risk calibration.

Moving the detector to two alternative positions keeps next-day daily mean errors
below 0.2 mph. All twelve school/evening direction-hour checks fall inside the bounds
implied by the reported speed bins, mostly 5 mph wide. This hourly check is coarse;
it does not establish 0.1 mph accuracy at each hour. A constant previous-day speed
also performs well because the measured days are very similar.

## The intervention experiments

Traffic comes from the May 18 and May 20 post-installation counts at Estates and
Hillcrest. Native 15-minute motor turns, heavy vehicles, bikes and pedestrians remain
separate. Each fixed seed is replayed at 25, 30 and 35 mph with identical demand and
driver speed ranks. Sixteen seeds cover each of eight two-hour patterns. This is
384 repetitions of measured traffic patterns, not 384 different observed days.

A runtime audit also found and repaired an inherited implementation error: proposed
limits had stopped at the external road lanes, leaving straight internal connectors
at 30 mph. Limits now propagate through those connectors, while lower turning caps
remain. Every affected 25/35 mph run was repeated. Unchanged 30 mph references were
reused only with matching source hashes and a fresh byte-identical control replay.

The driver speed-to-limit ratio stays fixed: this assumes a compliance response.
Changing only a sign in the real world need not produce that response. The baseline
geometry is current mapped OSM, with approximated widths and crossings. Hillcrest
uses a historical signal-program prior, not observed 2023 controller logs.

Dismissal results under the default visibility assumption:

{selected[['site','posted_mph','east_approach_mean_mph','turn_mean_mph','motor_duration_s','contact_runs','complete_runs','contact interval']].to_markdown(index=False,floatfmt='.2f')}

Contact intervals are exact 95% binomial bounds, expanded to allow incomplete runs
either outcome. Zero contacts does not establish zero risk. Paired speed/delay
intervals resample random seeds; input uncertainty is not included.

## An assumption that materially changes the answer

SUMO's default minor-link visibility is 4.5 m. It forces vehicles to slow before
assessing a crossing conflict and produces a roughly 18 mph approach ceiling at
Estates. This is not a field measurement. The lab exposes a separate 30 m sensitivity
using the first two matched seeds in all eight patterns and all three speed cases.
Neither value is selected because it gives a preferred contact result. This is one
reason a speed change can have little effect under one traffic-control assumption.

The numerical check holds driver action interval and ballistic integration fixed:
{nc['paired_runs']} coarse/fine pairs, {nc['contact_count_disagreements']} contact-count
disagreements, and {nc['approach_speed_mean_abs_difference_mph']:.3f} mph mean absolute
approach-speed difference. The main ensemble completed all traffic in
{result['complete_primary_runs']} of {result['primary_runs']} runs. Failures remain visible.

The prespecified numerical subset had {nc['coarse_contacts']} coarse-step contacts.
An additional targeted check therefore selected {pc['checked_positive_runs']} of
{pc['eligible_positive_runs']} positive main/visibility runs (cap 24). Contact counts
changed in {pc['contact_count_disagreements']} of those pairs, from
{pc['coarse_contacts']} total coarse contacts to {pc['fine_contacts']} fine contacts.
These selected cases diagnose numerical sensitivity; their frequency cannot be
used as an unbiased risk estimate. {pc['coarse_incomplete_runs']} coarse runs in
this selected set failed to finish traffic; {pc['recovered_runs']} of those completed
at the smaller step. Failed-run contact counts are not included as valid frequency
observations. The result does not support treating the
reported contact percentages as stable estimates of field collision probability.

## Comparison with the actual field record

The Explorer was not retrained. Its weights remain `{result['model_sha256']}`.
The following uses the same 500-foot areas and the correct target years, with each
year's inputs built only from preceding local history. These are injury/fatal
pedestrian/bicycle records, all ages, not just students.

{field[field.model.eq('nn')][['site','year','probability_at_least_one','expected_count','recorded_cases']].to_markdown(index=False,floatfmt='.3f')}

These six area-years are too few to validate calibration. The circles overlap and
share a 2025 case, so their counts cannot be summed as distinct collisions. The
2024–2025 export years are provisional. A rare-event probability does not predict
the binary outcome of each individual year. Some observed counts are well above the
model's expected counts, so this is not evidence that the Explorer is now accurate.

SUMO contacts are not equivalent to reported injury crashes. The page therefore
does not convert repeated contacts into an annual injury probability or tune the
simulator to reproduce the Explorer. No RL policy is called validated on that basis.

## Does it reproduce the actual 2023 project?

It reproduces observed post-project demand and the measured midblock speed pattern.
The study found no substantial midblock slowdown. The intervention was painted
curb extensions, medians, crossings and delineators, not a simple sign change.
The reported 22% crossing-distance reduction was a corridor average after June
adjustments; it is not an Estates/Hillcrest measurement and has not been fabricated
as one. Exact before/after curb radii, turning speeds, yielding and controller logs
are absent. The current work does not establish the project's causal crash effect.

## Applying this to Christensen or Altamont Creek

The CSV schema, calibration procedure, simulator, paired experiments and interface
are reusable. East Avenue numerical effects are not automatically transferable.
Each target needs arrival/dismissal turning and pedestrian/bicycle counts, observed
speed distributions, control settings and a check of crossing geometry/visibility.
Existing ADT and short speed surveys can support that work but do not replace those
observations. Do not train an RL collision-probability reward from these assumptions.

## Files and sources

- `East_Avenue_Scenario_Lab.ipynb`: portable Colab-compatible inputs, editable figures,
  saved results and a fresh paired SUMO replay; full reruns are optional CPU work.
- `outputs/sumo_v05/east_avenue_observations.csv`: observed native movement counts with
  source pages, dates, status and heavy-vehicle accounting.
- `outputs/sumo_v05/speed_validation.csv`, `scenario_summary.csv`, `paired_changes.csv`,
  `numerical_pairs.csv`, `explorer_field_check.csv`: inspectable evidence.
- [City final report](https://www.livermoreca.gov/home/showpublisheddocument/12943/638887914440930000),
  raw counts pp. 80–404; speed summaries pp. 439–442.
- [SUMO intersection behavior](https://sumo.dlr.de/docs/Simulation/Intersections.html)
  and [connection visibility](https://sumo.dlr.de/docs/Networks/PlainXML.html#lane-to-lane-connectivity).
- [TIMS](https://tims.berkeley.edu/), reviewed local regional export, 2014–2025.
'''
 (ROOT/'East_Avenue_Scenario_Lab.md').write_text(text)
if __name__=='__main__':main()
