"""Paired observed-demand experiments with speed sensors and completion gates."""
import argparse,hashlib,json,math,os,time,xml.etree.ElementTree as E
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np,pandas as pd,sumolib
from sumo_v03.replay import context,make_demand
from sumo_v02.calibrate import xml
from sumo_comparison.run import SITES
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/sumo_v05';MPH=.44704
SEEDS=[920009+1013*i for i in range(16)]

def execute(task,reuse_baseline=True):
 import libsumo as sim
 sid,seed,mph,step=task[:4];visibility=float(task[4]) if len(task)>4 else 4.5
 d=pd.read_csv(ROOT/'data/sumo_v02/junction_demand_15min.csv');rows=d[d.session_id.eq(sid)].copy();site=rows.iloc[0].site
 assert rows.phase.eq('post_installation').all() and rows.interval_start.nunique()==8
 net=ROOT/'outputs/sumo_v03/east_joined.net.xml' if visibility==4.5 else OUT/f'visibility_{visibility:g}.net.xml';signal=ROOT/'data/sumo_v03/fixed_signal.add.xml'
 # The internal-speed repair is a no-op at the 30 mph reference. Reuse only
 # completed baseline runs whose original physics inputs remain identical.
 if reuse_baseline and mph==30 and (OUT/'baseline_reuse.csv').exists():
  reuse=pd.read_csv(OUT/'baseline_reuse.csv');match=reuse[reuse.session_id.eq(sid)&reuse.seed.eq(seed)&reuse.step.eq(step)&reuse.visibility_m.eq(visibility)]
  hashes=json.loads((OUT/'baseline_reuse_inputs.json').read_text())
  if len(match)==1 and all(hashlib.sha256((ROOT/k).read_bytes()).hexdigest()==v for k,v in hashes.items()):
   oldpath=ROOT/match.iloc[0].path/'result.json'
   if oldpath.exists():
    saved=json.loads(oldpath.read_text());saved['reused_unchanged_baseline']=True;return saved
 files=[net,signal,ROOT/'outputs/sumo_v02/calibration.json',OUT/'calibration.json',ROOT/'data/sumo_v02/junction_demand_15min.csv',ROOT/'sumo_v03/replay.py',Path(__file__)]
 digest=hashlib.sha256(b''.join(p.read_bytes() for p in files)).hexdigest();key=hashlib.sha256(json.dumps([digest,task]).encode()).hexdigest()[:20];p=OUT/'junction_runs'/key;p.mkdir(parents=True,exist_ok=True)
 if (p/'result.json').exists():return json.loads((p/'result.json').read_text())
 n,ports=context();study,total=make_demand(rows,seed,p,n,ports);routes=E.parse(p/'demand.rou.xml')
 # Transform the fixed pre-fit normal draws into the mapped-road calibrated
 # distribution. Arrival draws and each driver's rank stay matched across speeds.
 old=json.loads((ROOT/'outputs/sumo_v02/calibration.json').read_text());new=json.loads((OUT/'calibration.json').read_text())
 for vehicle in routes.getroot().findall('vehicle'):
  if vehicle.get('type')=='bicycle':continue
  path=vehicle.find('route').get('edges').split();dr=None
  if ports[site]['W']['in'] in path:dr='eastbound'
  elif ports[site]['E']['in'] in path:dr='westbound'
  if dr:
   z=(float(vehicle.get('speedFactor'))*30-old[dr]['desired_mean_mph'])/old[dr]['desired_sd_mph']
   vehicle.set('speedFactor',str(max(.2,(new[dr]['desired_mean_mph']+z*new[dr]['desired_sd_mph'])/30)))
 for v in routes.getroot().findall('vType'):
  if v.get('vClass')!='pedestrian':v.set('actionStepLength','.2')
 xml(routes.getroot(),p/'demand.rou.xml');add=E.parse(signal).getroot();changed=[];center=n.getNode(site).getCoord()
 # The identical corridor scope is used in all three scenarios, including 30.
 for edge in n.getEdges():
  if edge.getFunction() or edge.getName()!='East Avenue' or min(math.dist(center,pt) for pt in edge.getShape())>200:continue
  lanes=[l.getID() for l in edge.getLanes() if l.allows('passenger')]
  if lanes:
   sign=E.SubElement(add,'variableSpeedSign',id='speed_'+edge.getID(),lanes=' '.join(lanes));E.SubElement(sign,'step',time='0',speed=str(mph*MPH));changed.append(edge.getID())
 # A road's limit also applies while traversing its short internal connectors.
 # Preserve geometric turn caps; do not multiply curvature-limited turns upward.
 network_tree=E.parse(net).getroot();internal_limits={};links=network_tree.findall('connection')
 if mph!=30:
  for c in links:
   if not c.get('via') or (c.get('from') not in changed and c.get('to') not in changed):continue
   if c.get('from','').startswith(':'):continue
   straight=c.get('dir')=='s' and n.getEdge(c.get('from')).getName()=='East Avenue' and n.getEdge(c.get('to')).getName()=='East Avenue'
   queue=[c.get('via')];seen=set()
   while queue:
    lane_id=queue.pop()
    if lane_id in seen:continue
    seen.add(lane_id);lane=n.getLane(lane_id);original=lane.getSpeed()
    limit=original*mph/30 if straight and abs(original-30*MPH)<.02 else min(original,mph*MPH)
    internal_limits[lane_id]=min(limit,internal_limits.get(lane_id,float('inf')))
    edge,index=lane_id.rsplit('_',1)
    queue.extend(z.get('via') for z in links if z.get('from')==edge and z.get('fromLane')==index and z.get('via'))
  for i,(lane_id,limit) in enumerate(sorted(internal_limits.items())):
   sign=E.SubElement(add,'variableSpeedSign',id='internal_speed_'+str(i),lanes=lane_id);E.SubElement(sign,'step',time='0',speed=str(limit))
 detectors={}
 for arm,port in ports[site].items():
  edge=n.getEdge(port['in'])
  for lane in edge.getLanes():
   if lane.allows('passenger'):
    ident='approach_'+arm+'_'+str(lane.getIndex());pos=max(.1,lane.getLength()-8)
    E.SubElement(add,'instantInductionLoop',id=ident,lane=lane.getID(),pos=str(pos),file='sensors.xml');detectors[ident]={'kind':'approach','arm':arm,'lane':lane.getID(),'pos':pos}
 # Curvature governs these speeds; no fabricated turning-speed targets.
 root=E.parse(net).getroot();vias={}
 for c in root.findall('connection'):
  if c.get('from') in {x['in'] for x in ports[site].values()} and c.get('dir') in ['l','r'] and c.get('via'):
   vias[c.get('via')]=c.get('dir')
 for lane_id,turn in sorted(vias.items()):
  lane=n.getLane(lane_id);ident='turn_'+lane_id
  E.SubElement(add,'instantInductionLoop',id=ident,lane=lane_id,pos=str(lane.getLength()/2),file='sensors.xml');detectors[ident]={'kind':'turn','arm':turn,'lane':lane_id,'pos':lane.getLength()/2}
 xml(add,p/'scenario.add.xml');(p/'sensor_locations.json').write_text(json.dumps(detectors,indent=2));(p/'scenario.json').write_text(json.dumps({'posted_mph':mph,'changed_edges':changed,'compliance':'same desired-speed-to-limit ratio for each driver; not a measured sign response','geometry':'current OSM approximation of post-installation layout','control':'2020 worksheet prior, not observed 2023 controller'},indent=2))
 cfg=E.Element('configuration');inp=E.SubElement(cfg,'input')
 for k,v in [('net-file',os.path.relpath(net,p)),('route-files','demand.rou.xml'),('additional-files','scenario.add.xml')]:E.SubElement(inp,k,value=v)
 tm=E.SubElement(cfg,'time');E.SubElement(tm,'step-length',value=str(step));E.SubElement(tm,'end',value='9900');ran=E.SubElement(cfg,'random_number');E.SubElement(ran,'seed',value=str(seed));proc=E.SubElement(cfg,'processing')
 for k,v in [('step-method.ballistic','true'),('pedestrian.striping.jamtime','-1'),('pedestrian.striping.jamtime.crossing','-1'),('pedestrian.striping.jamtime.narrow','-1'),('time-to-teleport','-1'),('collision.action','warn'),('intermodal-collision.action','warn'),('collision.check-junctions','true'),('collision.mingap-factor','0')]:E.SubElement(proc,k,value=v)
 output=E.SubElement(cfg,'output')
 for k,v in [('collision-output','collisions.xml'),('tripinfo-output','trips.xml')]:E.SubElement(output,k,value=v)
 xml(cfg,p/'run.sumocfg');tick=time.monotonic();sim.start([sumolib.checkBinary('sumo'),'-c',str(p/'run.sumocfg'),'--no-step-log','true','--duration-log.disable','true','--no-warnings','true','--error-log',str(p/'warnings.log')])
 try:
  sim.simulationStep(.2)
  runtime=[{'lane':lane,'required_mps':value,'runtime_mps':sim.lane.getMaxSpeed(lane)} for lane,value in sorted(internal_limits.items())]
  assert all(abs(z['required_mps']-z['runtime_mps'])<1e-8 for z in runtime),'Posted limit failed to propagate to an internal connector'
  (p/'runtime_speed_limit_audit.json').write_text(json.dumps(runtime,indent=2))
  sim.simulationStep(9900);pending=sim.simulation.getMinExpectedNumber();version=sim.getVersion()[1]
 finally:sim.close()
 audit=[];seen=set();xycenter=n.convertLonLat2XY(SITES[site]['lon'],SITES[site]['lat'])
 for z in E.parse(p/'collisions.xml').getroot():
  a=dict(z.attrib);ids=[a.get('collider',''),a.get('victim','')];vru=any('_ped_' in s or s.endswith('_bicycle') for s in ids);xy=sumolib.geomhelper.positionAtShapeOffset(n.getLane(a['lane']).getShape(),float(a['pos']));distance=math.dist(xy,xycenter);t=float(a['time']);pair=tuple(sorted(ids));reason='eligible'
  if not vru:reason='no_vru'
  elif not 900<=t<8100:reason='outside_two_hours'
  elif not any(s.startswith('s') for s in ids):reason='warmup_only'
  elif distance>152.4:reason='outside_500_feet'
  elif pair in seen:reason='duplicate_pair'
  if reason=='eligible':seen.add(pair)
  a.update(reason=reason,distance_m=distance);audit.append(a)
 (p/'event_audit.json').write_text(json.dumps(audit,indent=2))
 sensor=[];seen_sensors=set()
 for _,z in E.iterparse(p/'sensors.xml',events=('end',)):
  a=z.attrib
  if a.get('state')=='enter' and a.get('vehID','').startswith('s') and 900<=float(a['time'])<8100:
   key=(a['id'],a['vehID'])
   if key not in seen_sensors:
    seen_sensors.add(key);sensor.append({**a,**detectors[a['id']],'mph':float(a['speed'])/MPH})
  z.clear()
 sensor=pd.DataFrame(sensor);sensor.to_csv(p/'sensor_passages.csv.gz',index=False)
 # Compact every entered-vehicle observation; stay/leave rows add no used data.
 (p/'sensors.xml').unlink()
 trips=E.parse(p/'trips.xml').getroot();study_trips=[z for z in trips if z.get('id','').startswith('s')];motor=[z for z in study_trips if z.tag=='tripinfo' and z.get('vType') in ['passenger','heavy']];people=[z.find('walk') for z in study_trips if z.tag=='personinfo'];people=[z for z in people if z is not None]
 motor_sensor=sensor[sensor['type'].isin(['passenger','heavy'])];approach=motor_sensor[motor_sensor.kind.eq('approach')];through=approach[approach.arm.isin(['E','W'])];turn=motor_sensor[motor_sensor.kind.eq('turn')]
 def avg(vals):return float(np.mean(vals)) if len(vals) else None
 result={'site':site,'session_id':sid,'date':rows.iloc[0].date,'start_hour':int(rows.interval_start.min()[11:13]),'seed':seed,'posted_mph':mph,'visibility_m':visibility,'step':step,'action_step':.2,'integration':'ballistic','simulation_version':version,'study_requested':study,'study_arrived':len(study_trips),'pending':pending,'complete':len(study_trips)==study and pending==0,'vru_requested':int(rows[rows['mode'].isin(['pedestrian','bicycle'])]['count'].sum()),'pedestrians_requested':int(rows[rows['mode'].eq('pedestrian')]['count'].sum()),'pedestrians_arrived':len(people),'contact_pairs':len(seen),'any_contact':int(bool(seen)),'east_approach_mean_mph':avg(through.mph),'east_approach_p85_mph':float(through.mph.quantile(.85)),'turn_mean_mph':avg(turn.mph),'motor_duration_s':avg([float(z.get('duration')) for z in motor]),'motor_time_loss_s':avg([float(z.get('timeLoss')) for z in motor]),'motor_depart_delay_s':avg([float(z.get('departDelay')) for z in motor]),'pedestrian_duration_s':avg([float(z.get('duration')) for z in people]),'pedestrian_time_loss_s':avg([float(z.get('timeLoss','0')) for z in people]),'sensor_passages':len(sensor),'seconds':time.monotonic()-tick,'input_digest':digest,'demand_sha256':hashlib.sha256((p/'demand.rou.xml').read_bytes()).hexdigest(),'path':str(p.relative_to(ROOT))}
 (p/'result.json').write_text(json.dumps(result,indent=2));return result

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');ap.add_argument('--workers',type=int,default=2);ap.add_argument('--fine',action='store_true');ap.add_argument('--visibility',type=float,default=4.5);args=ap.parse_args();OUT.mkdir(exist_ok=True,parents=True)
 validation=pd.read_csv(OUT/'speed_validation.csv')
 if not validation['pass'].all():raise RuntimeError('Mapped-road speed validation has not passed. Do not run unsupported baseline.')
 if args.visibility!=4.5:
  tree=E.parse(ROOT/'outputs/sumo_v03/east_joined.net.xml');ports=json.loads((ROOT/'data/sumo_v03/ports.json').read_text());incoming={p['in'] for site in ports.values() for p in site.values()}
  for z in tree.getroot().findall('connection'):
   if z.get('from') in incoming:z.set('visibility',str(args.visibility))
  xml(tree.getroot(),OUT/f'visibility_{args.visibility:g}.net.xml')
 d=pd.read_csv(ROOT/'data/sumo_v02/junction_demand_15min.csv');sessions=sorted(d[d.phase.eq('post_installation')].session_id.unique());seeds=SEEDS[:1] if args.pilot else SEEDS[:2] if args.fine or args.visibility!=4.5 else SEEDS;step=.1 if args.fine else .2
 if args.pilot:sessions=[sid for sid in sessions if '14:00' in sid]
 tasks=[(sid,seed,mph,step,args.visibility) for seed in seeds for sid in sessions for mph in [25,30,35]];name='pilot' if args.pilot else 'visibility' if args.visibility!=4.5 else 'fine' if args.fine else 'runs';pd.DataFrame(tasks,columns=['session_id','seed','posted_mph','step','visibility_m']).to_csv(OUT/(name+'_schedule.csv'),index=False);out=[];failures=[];start=time.monotonic()
 with ProcessPoolExecutor(max_workers=args.workers) as pool:
  jobs={pool.submit(execute,t):t for t in tasks}
  for job in as_completed(jobs):
   try:out.append(job.result())
   except Exception as ex:failures.append({'task':jobs[job],'error':repr(ex)})
   if len(out)%12==0 or len(out)+len(failures)==len(tasks):
    pd.DataFrame(out).to_csv(OUT/(name+'.csv'),index=False);print(json.dumps({'complete_tasks':len(out),'total':len(tasks),'errors':len(failures),'incomplete_traffic':sum(not x['complete'] for x in out),'contacts':sum(x['contact_pairs'] for x in out),'seconds':round(time.monotonic()-start)}),flush=True)
 (OUT/(name+'_failures.json')).write_text(json.dumps(failures,indent=2))
 if failures:raise RuntimeError(f'{len(failures)} failed tasks')
if __name__=='__main__':main()
