"""Independent detector check on the mapped Jensen–Estates block."""
import argparse,hashlib,json,os,time,xml.etree.ElementTree as E
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np,pandas as pd,sumolib
from sumo_v03.replay import context
from sumo_v02.calibrate import xml
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'outputs/sumo_v05'; MPH=.44704

def setup(detector_piece=8):
 n,_=context(); routes={}; sensors={}
 # Stay within the named Jensen–Estates block; no signalized Hillcrest crossing.
 for dr,ends,det in [('eastbound',('1046369274#0','1046369274#13'),f'1046369274#{detector_piece}'),('westbound',('-1046369274#13','-1046369274#0'),f'-1046369274#{detector_piece}')]:
  path,_=n.getShortestPath(n.getEdge(ends[0]),n.getEdge(ends[1]),vClass='passenger')
  routes[dr]=' '.join(e.getID() for e in path)
  sensors[dr]={'edge':det,'lanes':[l.getID() for l in n.getEdge(det).getLanes() if l.allows('passenger')], 'pos':n.getEdge(det).getLength()/2}
  xy=sumolib.geomhelper.positionAtShapeOffset(n.getEdge(det).getShape(),sensors[dr]['pos']);sensors[dr]['lon'],sensors[dr]['lat']=n.convertXY2LonLat(*xy)
 return routes,sensors

def run(task,parameters=None):
 import libsumo as sim
 date,dr,hour,count,seed=task[:5];routes,sensors=setup(task[5] if len(task)>5 else 8);cal=OUT/'calibration.json' if (OUT/'calibration.json').exists() else ROOT/'outputs/sumo_v02/calibration.json';model=parameters or json.loads(cal.read_text())[dr]
 net=ROOT/'outputs/sumo_v03/east_joined.net.xml';digest=hashlib.sha256(net.read_bytes()+Path(__file__).read_bytes()+(ROOT/'outputs/sumo_v02/calibration.json').read_bytes()).hexdigest()
 key=hashlib.sha256(json.dumps([digest,task,model]).encode()).hexdigest()[:20];p=OUT/'speed_runs'/key;p.mkdir(parents=True,exist_ok=True)
 if (p/'result.json').exists():return json.loads((p/'result.json').read_text())
 rng=np.random.default_rng(seed);r=E.Element('routes');E.SubElement(r,'vType',id='car',vClass='passenger',accel='2.6',decel='4.5',sigma='.5',tau='1.2',minGap='2.5',length='5',maxSpeed='60',speedDev='0',actionStepLength='.2');E.SubElement(r,'route',id='r',edges=routes[dr])
 warm=int(round(count/12));deps=[(float(t),'w'+str(i)) for i,t in enumerate(rng.uniform(0,300,warm))]+[(float(t),'s'+str(i)) for i,t in enumerate(rng.uniform(300,3900,count))]
 for t,vid in sorted(deps):
  factor=max(.2,rng.normal(model['desired_mean_mph'],model['desired_sd_mph'])/30)
  E.SubElement(r,'vehicle',id=vid,type='car',route='r',depart=f'{t:.3f}',departLane='free',departSpeed='max',speedFactor=str(factor))
 xml(r,p/'demand.rou.xml');a=E.Element('additional')
 for i,lane in enumerate(sensors[dr]['lanes']):E.SubElement(a,'inductionLoop',id='d'+str(i),lane=lane,pos=str(sensors[dr]['pos']),file='detector.xml',period='3600')
 xml(a,p/'detector.add.xml');cfg=E.Element('configuration');inp=E.SubElement(cfg,'input')
 for k,v in [('net-file',os.path.relpath(net,p)),('route-files','demand.rou.xml'),('additional-files','detector.add.xml')]:E.SubElement(inp,k,value=v)
 tm=E.SubElement(cfg,'time');E.SubElement(tm,'step-length',value='.2');E.SubElement(tm,'end',value='4800');pr=E.SubElement(cfg,'processing');E.SubElement(pr,'time-to-teleport',value='-1');E.SubElement(pr,'step-method.ballistic',value='true');ran=E.SubElement(cfg,'random_number');E.SubElement(ran,'seed',value=str(seed));xml(cfg,p/'run.sumocfg')
 tick=time.monotonic();speeds={};sim.start([sumolib.checkBinary('sumo'),'-c',str(p/'run.sumocfg'),'--no-step-log','true','--duration-log.disable','true','--no-warnings','true'])
 try:
  while sim.simulation.getTime()<4800:
   sim.simulationStep()
   for i in range(len(sensors[dr]['lanes'])):
    for vid,length,entry,leave,_ in sim.inductionloop.getVehicleData('d'+str(i)):
     if vid.startswith('s') and leave>entry and vid not in speeds:speeds[vid]=length/(leave-entry)/MPH
   if sim.simulation.getMinExpectedNumber()==0:break
  pending=sim.simulation.getMinExpectedNumber()
 finally:sim.close()
 pd.DataFrame({'vehicle_id':speeds.keys(),'mph':speeds.values()}).to_csv(p/'speeds.csv',index=False)
 result={'date':date,'direction':dr,'hour':hour,'requested':count,'detected':len(speeds),'pending':pending,'seed':seed,'mean_mph':float(np.mean(list(speeds.values()))),'p85_mph':float(np.quantile(list(speeds.values()),.85)),'path':str(p.relative_to(ROOT)),'input_digest':digest,'seconds':time.monotonic()-tick}
 (p/'result.json').write_text(json.dumps(result,indent=2));return result

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');ap.add_argument('--workers',type=int,default=2);args=ap.parse_args();OUT.mkdir(parents=True,exist_ok=True)
 _,sensors=setup();(OUT/'detector_locations.json').write_text(json.dumps(sensors,indent=2))
 d=pd.read_csv(ROOT/'data/traffic_exposure/normalized/speed_observations.csv');d=d[d.observation_date.str.startswith('2023-05') & d.eligible_for_automatic_aggregation];d['hour']=d.interval_start.str[11:13].astype(int)
 if args.pilot:d=d[d.hour.eq(8)&d.observation_date.eq('2023-05-24')]
 tasks=[(r.observation_date,r.travel_direction,int(r.hour),int(r.sample_count),851003+int(r.hour)*17) for r in d.itertuples()];out=[]
 with ProcessPoolExecutor(max_workers=args.workers) as pool:
  for job in as_completed([pool.submit(run,t) for t in tasks]):
   out.append(job.result())
   if len(out)%12==0:print('Speed checks',len(out),'/',len(tasks),flush=True)
 pd.DataFrame(out).to_csv(OUT/('speed_pilot.csv' if args.pilot else 'speed_hours.csv'),index=False)
 if args.pilot:print(pd.DataFrame(out).to_string(index=False));return
 obs=pd.read_csv(ROOT/'data/traffic_exposure/normalized/speed_daily_summaries.csv');summ=[]
 for (date,dr),g in pd.DataFrame(out).groupby(['date','direction']):
  measured=obs[obs.observation_date.eq(date)&obs.travel_direction.eq(dr)].iloc[0];ss=np.concatenate([pd.read_csv(ROOT/r.path/'speeds.csv').mph.to_numpy() for r in g.itertuples()]);mean=float(ss.mean());p85=float(np.quantile(ss,.85));complete=bool(g.requested.sum()==len(ss) and g.pending.sum()==0)
  summ.append({'date':date,'direction':dr,'source_page':int(measured.source_page),'observed_n':int(measured.sample_count),'simulated_n':len(ss),'observed_mean_mph':measured.mean_mph,'sim_mean_mph':mean,'mean_error_mph':mean-measured.mean_mph,'observed_p85_mph':measured.p85_mph,'sim_p85_mph':p85,'p85_error_mph':p85-measured.p85_mph,'complete':complete,'pass':complete and abs(mean-measured.mean_mph)<=2 and abs(p85-measured.p85_mph)<=3})
 pd.DataFrame(summ).to_csv(OUT/'speed_validation.csv',index=False);print(pd.DataFrame(summ).to_string(index=False))
if __name__=='__main__':main()
