"""Fit May 24 only; mapped-road speed response rather than Explorer targets."""
import json
from concurrent.futures import ProcessPoolExecutor
import numpy as np,pandas as pd
from scipy.optimize import minimize
from .speed_check import ROOT,OUT,run

def fit_direction(dr):
 d=pd.read_csv(ROOT/'data/traffic_exposure/normalized/speed_observations.csv');d=d[d.observation_date.eq('2023-05-24')&d.travel_direction.eq(dr)];daily=pd.read_csv(ROOT/'data/traffic_exposure/normalized/speed_daily_summaries.csv');target=daily[daily.observation_date.eq('2023-05-24')&daily.travel_direction.eq(dr)].iloc[0]
 # Compress the 24 observed flows into six count ranges for optimization only.
 # The final validation runs every original hourly flow without interpolation.
 d=d.sort_values('sample_count');groups=np.array_split(np.arange(len(d)),6);levels=[]
 for ix in groups:
  g=d.iloc[ix];levels.append((int(round(np.average(g.sample_count,weights=g.sample_count))),int(g.sample_count.sum())))
 trace=[]
 def objective(x):
  speeds=[];weights=[]
  for i,(n,w) in enumerate(levels):
   r=run(('fit_2023-05-24',dr,i,n,701003+i*37),{'desired_mean_mph':float(x[0]),'desired_sd_mph':float(x[1])});ss=pd.read_csv(ROOT/r['path']/'speeds.csv').mph.to_numpy();speeds.extend(ss);weights.extend(np.full(len(ss),w/len(ss)))
  ss=np.array(speeds);ww=np.array(weights);order=np.argsort(ss);mean=float(np.average(ss,weights=ww));p85=float(np.interp(.85,np.cumsum(ww[order])/ww.sum(),ss[order]));loss=(mean-target.mean_mph)**2+(p85-target.p85_mph)**2;trace.append({'direction':dr,'desired_mean':float(x[0]),'desired_sd':float(x[1]),'sim_mean':mean,'sim_p85':p85,'loss':loss});return loss
 res=minimize(objective,[36.1,3.8],method='Nelder-Mead',bounds=[(30,43),(1,8)],options={'maxiter':45,'xatol':.04,'fatol':.003})
 model={'desired_mean_mph':float(res.x[0]),'desired_sd_mph':float(res.x[1]),'fit_date':'2023-05-24','source_page':int(target.source_page),'target_mean_mph':float(target.mean_mph),'target_p85_mph':float(target.p85_mph),'fit_loss':float(res.fun),'optimizer_success':bool(res.success),'flow_levels':levels,'interpretation':'conditional desired speeds fitted to mapped Jensen–Estates detector; no injury-crash or Explorer target'}
 pd.DataFrame(trace).to_csv(OUT/('calibration_trace_'+dr+'.csv'),index=False);print('Fitted',dr,model,flush=True);return dr,model

def main():
 with ProcessPoolExecutor(max_workers=2) as p:models=dict(p.map(fit_direction,['eastbound','westbound']))
 (OUT/'calibration.json').write_text(json.dumps(models,indent=2))
if __name__=='__main__':main()
