"""Targeted time-step diagnosis of positive runs, not another risk estimate."""
import argparse,json
from concurrent.futures import ProcessPoolExecutor,as_completed
import pandas as pd
from .replay import OUT,execute

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=2);args=ap.parse_args()
 d=pd.concat([pd.read_csv(OUT/'runs.csv'),pd.read_csv(OUT/'visibility.csv')],ignore_index=True)
 positive=d[d.contact_pairs.gt(0)].sort_values(['visibility_m','session_id','seed','posted_mph'])
 # A bounded diagnostic deliberately selects positive runs. It cannot supply
 # an unbiased fine-step contact probability or replace the prespecified subset.
 selected=positive.head(24);out=[]
 with ProcessPoolExecutor(max_workers=args.workers) as pool:
  jobs={pool.submit(execute,(r.session_id,int(r.seed),int(r.posted_mph),.1,float(r.visibility_m))):r for r in selected.itertuples()}
  for job in as_completed(jobs):
   coarse=jobs[job];fine=job.result();assert fine['demand_sha256']==coarse.demand_sha256
   out.append({'site':coarse.site,'session_id':coarse.session_id,'seed':coarse.seed,'posted_mph':coarse.posted_mph,'visibility_m':coarse.visibility_m,'coarse_contact_pairs':coarse.contact_pairs,'fine_contact_pairs':fine['contact_pairs'],'coarse_complete':coarse.complete,'fine_complete':fine['complete'],'coarse_path':coarse.path,'fine_path':fine['path'],'demand_sha256':fine['demand_sha256'],'selection':'post-result positive-run diagnostic; not unbiased frequency'})
   print(len(out),'/',len(selected),'checked',flush=True)
 result=pd.DataFrame(out);result.to_csv(OUT/'positive_contact_checks.csv',index=False)
 receipt={'eligible_positive_runs':len(positive),'checked_positive_runs':len(result),'cap':24,'coarse_contacts':int(result.coarse_contact_pairs.sum()) if len(result) else 0,'fine_contacts':int(result.fine_contact_pairs.sum()) if len(result) else 0,'contact_count_disagreements':int(result.coarse_contact_pairs.ne(result.fine_contact_pairs).sum()) if len(result) else 0,'coarse_incomplete_runs':int((~result.coarse_complete).sum()) if len(result) else 0,'fine_incomplete_runs':int((~result.fine_complete).sum()) if len(result) else 0,'recovered_runs':int((~result.coarse_complete & result.fine_complete).sum()) if len(result) else 0,'selection':'post-result positives; no prevalence inference'}
 (OUT/'positive_contact_checks.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
if __name__=='__main__':main()
