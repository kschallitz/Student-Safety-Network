"""Build the cumulative-score lab, paper evidence, and portable notebook."""
import base64,html,io,json,zipfile
from pathlib import Path
import numpy as np,pandas as pd,nbformat
from mitigation_rl.learn import values
from mitigation_rl.prepare import LABELS
from .config import ROOT,DATA,OUT,ACTIONS,SENSITIVITY_CONTEXTS,PROFILES
from .learn import batches

PROFILE_LABELS={'nominal':'Nominal','nominal_subset':'Nominal (same 8 windows)','cautious':'Cautious drivers','tighter_gaps':'Tighter gaps','half_speed_response':'Half speed response'}

def figures(result):
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
 f=result['frozen_selection'];names=list(f['representatives'].values())+['A0','best_fixed','random','H'];d=pd.DataFrame(result['policies']).set_index('policy').loc[names]
 labels=[n.split('_')[0].title()+' Q' if n in f['representatives'].values() else {'A0':'Unchanged','best_fixed':'Best fixed from training','random':'Uniform random','H':'Held-out pilot'}[n] for n in names]
 fig,ax=plt.subplots(figsize=(9,4.6),layout='constrained');y=np.arange(len(d));valid=d.mean_batch_score.notna();v=d[valid]
 ax.errorbar(v.mean_batch_score,y[valid],xerr=[v.mean_batch_score-v.score_low,v.score_high-v.mean_batch_score],fmt='o',color='#147787',capsize=4);ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlabel('Mean cumulative score per 30-repeat batch (higher is better)');ax.set_title('32 traffic windows · 960 episodes per policy · 95% context-bootstrap intervals',loc='left',fontsize=11);ax.grid(axis='x',alpha=.15);fig.savefig(OUT/'policy_results.png',dpi=150);plt.close(fig)
 s=pd.DataFrame(result['sensitivity']);profiles=['nominal_subset',*PROFILES];fig,ax=plt.subplots(figsize=(9,4.8),layout='constrained')
 for a in ACTIONS+['H']:
  z=s[s.policy.eq(a)].set_index('profile').reindex(profiles);ax.plot(range(4),z.mean_batch_score,'o-',label={'A0':'Unchanged','A1':'25 mph response','A2':'Generic curbs','A3':'Curbs + speed','H':'Pilot'}[a])
 ax.set_xticks(range(4),['Nominal','Cautious','Tighter gaps','Half speed response']);ax.set_ylabel('Mean 30-repeat batch score');ax.set_title('Same eight windows and 30 seeds · fixed layouts under behavior assumptions',loc='left',fontsize=11);ax.grid(alpha=.15);ax.legend(ncol=3,fontsize=9);fig.savefig(OUT/'sensitivity.png',dpi=150);plt.close(fig)
 h=pd.read_csv(OUT/'training_history.csv');fig,ax=plt.subplots(figsize=(9,4),layout='constrained')
 for family,g in h.groupby(h.agent.str.split('_').str[0]):
  z=g.groupby('episode').mean_training_reward.mean();ax.plot(z.index,z,label=family)
 ax.set_xlabel('Selected-action updates per agent');ax.set_ylabel('Batch score (200-update training average)');ax.legend();ax.grid(alpha=.15);fig.savefig(OUT/'learning.png',dpi=150);plt.close(fig)

def evidence(result,finding):
 f=result['frozen_selection'];d=pd.DataFrame(result['policies']).set_index('policy');a=d.loc[f['champion']];base=d.loc['A0'];pilot=d.loc['H'];out=OUT/'paper_materials';out.mkdir(exist_ok=True)
 text=f'''# COSC 645 evidence update: cumulative penalties and 30-repeat batches

Working project target: Wednesday October 7; paper due Sunday. This evidence pack supports the 8–10-page APA paper and code appendix. It supplements the original v0.15 pack; it is not the completed paper.

## Implemented change requested by the user
The user replaced worst-event-only rewards with cumulative penalties: -100 for each collision encounter and -5 for each non-collision near-miss encounter. Sum the scores over 30 simulation repeats. Thus three near misses produce -15; one collision plus three separate near misses produces -115; 30 event-free simulations produce 0. Higher is better. There is no +1 avoidance bonus.

A distinct motor/VRU pair passes through this local junction once and counts as one encounter. Repeated detector frames are not additional near misses. A pair that collides receives only its collision penalty; other near-miss pairs in the same episode still count. The existing 1.5-second projected-footprint-contact definition remains unchanged. SUMO overlaps are simulator events, not calibrated injury labels.

## Application and development evidence
The application area remains school-area traffic planning. Estates is the demonstrated site. The interface performs actual exported-policy inference, then looks up the matching simulated batch. The Python/Gymnasium environment can run a fresh 30-repeat batch. The site does not run a hidden live SUMO server.

The stack remains Python, SUMO/libsumo 1.27.1, PyTorch, Gymnasium, NumPy/pandas, Matplotlib and a JavaScript interface. Computation is CPU-only, with no paid AI API. Seven pre-defined context features drive three one-step Q-learning families: tabular, linear and a two-layer neural network. Each family has three learner seeds and 6,000 selected-action updates per seed. The selected-action target is a complete 30-run score, divided by 100 only during optimization and restored to point units for exported predictions.

The experiment contains 2,880 training simulations (24 pre-installation windows × 30 × 4 actions), 960 validation simulations (8 pre windows × 30 × 4) and 4,800 test simulations (32 post windows × 30 × 5 layouts): 8,640 nominal runs. The earlier 832 identical nominal records can be reused. Repeated seeds are simulation draws, not new measured traffic days.

The four generic actions are unchanged, an assumed 25 mph operating response, generic curb extensions, and the combined scenario. The actual pilot H remains excluded from the training action set. New policies are frozen before v0.16 test aggregation. The developer and user already saw v0.15 May outcomes; describe this as a retrospective follow-up, not a fully untouched confirmatory experiment.

## Results
{finding}

The validation-selected agent is {f['champion']}. Its total nominal held-out score is {a.total_score}, compared with {base.total_score} for unchanged and {pilot.total_score} for the implemented pilot. These totals cover 32 batches of 30, or 960 episodes per policy. The mean score improvement over unchanged is {a.mean_gain_vs_baseline:.2f} points per 30-run batch, with a 95% paired context-bootstrap interval of {a.gain_low:.2f} to {a.gain_high:.2f}. The pilot produced {int(pilot.collisions)} collision encounters and {int(pilot.near_misses)} near-miss encounters, versus {int(base.collisions)} and {int(base.near_misses)} for unchanged.

The highest-scoring test agent, selected descriptively after testing, was {result['descriptive_best_test_agent']}. The best generic fixed action on the test was {result['descriptive_best_generic_test_action']}. These descriptive winners do not replace the validation-selected champion or prove superiority in future conditions.

## Driver behavior sensitivity
Three profiles were fixed before scoring: cautious drivers (1.6-second headway, 0.8-second decision interval, 15-metre pedestrian clearance), tighter gaps (1.0 second, 0.8 second, 5 metres), and half of the assumed desired-speed response to a 30-to-25 mph change. Nominal headway is 1.2 seconds, decision interval 0.2 seconds, and default pedestrian clearance 10 metres. These are illustrative assumptions, not measured local distributions. No deliberate ignoring of right of way or forced unsafe speeds was added.

The implemented pilot had the highest score among the five fixed layouts under all four tested profiles, including the nominal eight-window subset. The best generic fixed action changed: the combined scenario led under nominal assumptions, the speed scenario led under cautious and half-response assumptions, and curb extensions led under tighter gaps. The validation-selected agent did not establish a score improvement over unchanged in any profile. These comparisons are conditional simulation findings.

The same eight specified post traffic windows and 30 seeds are used for every sensitivity profile. All nine policies stay frozen. Each profile has 1,200 scenario records (8 × 30 × 5); the three profiles total 3,600 records. Under half response, the 720 unchanged/non-speed-action records can be reused from nominal because their physics are identical. Compare profile results against the nominal eight-window subset, not the entire 32-window population. Inspect sensitivity_policy_results.csv and the accompanying plot for rank reversals and invalid runs.

## Uncertainty and roadblocks
The main intervals bootstrap observed traffic-window clusters. Per-window intervals resample the 30 simulation seeds and show uncertainty in the expected 30-run total; they are not prediction intervals for an individual future batch. They do not cover inaccurate geometry, driver behavior, field reporting, seasonality or injuries. More runs improve conditional precision; they do not create new field dates or validate the reward against real conflicts.

Every scheduled traveler must finish; any incomplete episode invalidates its batch. A selected incomplete batch makes a policy ineligible. More than 30 seconds of added mean motor delay also fails eligibility. These checks prevent an intervention from appearing safe by suppressing traffic or stranding road users.

Persistent limitations include only two post-installation source dates, a Saturday validation set, reconstructed geometry whose exact date is uncertain, assumed speed compliance, rare physical overlaps and no observed field conflict-reduction target. Transfer to Christensen and Altamont Creek still requires local data and validation. The principal demonstration can explain a working learning/evaluation pipeline without claiming certified safety benefits.

## Sources and appendix pointers
- City of Livermore, East Avenue tactical bikeway final report: https://www.livermoreca.gov/home/showpublisheddocument/12943/638887914440930000
- HMH memorandum, April 3, 2025, used for geometry evidence: https://library.livermoreca.gov/home/showpublisheddocument/12945/638887914731000000
- SUMO vehicle/junction parameters: https://sumo.dlr.de/docs/Definition_of_Vehicles,_Vehicle_Types,_and_Routes.html
- SUMO safety definitions: https://sumo.dlr.de/docs/Simulation/Safety.html

Appendix candidates: mitigation_batch/config.py (exact reward); environment.py (30-repeat Gymnasium step); learn.py (batch targets and frozen policy selection); protocol.md (predeclared follow-up). The notebook embeds the code, data, networks and scored tables. The original v0.15 results are archived separately. Confirm source title-page metadata when preparing the final APA reference list.
'''
 (out/'Evidence_Update.md').write_text(text);body=[]
 for p in text.split('\n\n'):
  if p.startswith('# '):body.append('<h1>'+html.escape(p[2:])+'</h1>')
  elif p.startswith('## '):body.append('<h2>'+html.escape(p[3:])+'</h2>')
  else:body.append('<p>'+html.escape(p).replace('\n','<br>')+'</p>')
 (out/'Evidence_Update.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>COSC 645 cumulative-score evidence</title><style>body{max-width:920px;margin:32px auto;padding:0 20px;font:17px/1.6 Georgia,serif;color:#193b4d}h1,h2{font-family:system-ui}h2{margin-top:36px}</style><a href="/mitigation-lab">Return to lab</a>'+''.join(body)+'</html>')

def bundle():
 paths=[ROOT/'mitigation_batch'/f for f in ['__init__.py','config.py','runs.py','sensitivity.py','learn.py','evaluate.py','environment.py','pipeline.py','protocol.md']]
 paths += [ROOT/'mitigation_rl'/f for f in ['__init__.py','prepare.py','simulator.py','events.py','learn.py']]
 paths += [ROOT/'sumo_v06/demand.py',ROOT/'outputs/sumo_v02/calibration.json',ROOT/'outputs/sumo_v07/calibration.json',ROOT/'outputs/mitigation_rl/policy_freeze.json']
 paths += list(DATA.glob('*.csv'))+list(DATA.glob('*.json'))+list((DATA/'networks').rglob('*.xml'))+list((DATA/'networks').rglob('*.json'))
 paths += list((ROOT/'outputs/sumo_v06/networks/Estates/pilot').rglob('*.xml'))+list((ROOT/'outputs/sumo_v06/networks/Estates/pilot').rglob('*.json'))
 paths += [p for p in OUT.glob('*.csv') if '.partial.' not in p.name]+[p for p in OUT.glob('*.json') if p.name not in ['web_data.json','expected_inference.json','CHECKPOINT.json']]+list(OUT.glob('*.png'))+list((OUT/'paper_materials').glob('*'))
 buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(set(paths)):z.write(p,p.relative_to(ROOT))
 (ROOT/'Estates_Mitigation_Batches.zip').write_bytes(buf.getvalue());return buf.getvalue()

def notebook(payload,result):
 nb=nbformat.v4.new_notebook();cells=[];md=lambda s:cells.append(nbformat.v4.new_markdown_cell(s));code=lambda s:cells.append(nbformat.v4.new_code_cell(s))
 md('''# Estates cumulative mitigation scores · v0.16

## tl;dr
Nine trained one-step RL policies choose interventions. A batch contains **30 matched repeats**; its score is **−100 per collision encounter −5 per non-collision near-miss encounter**, summed across all repeats. This notebook retrains the agents from saved batches, recomputes evaluation and runs a fresh 30-repeat SUMO environment step. CPU is sufficient.

## Context & Methods
There are 8,640 nominal simulation records and 3,600 sensitivity records, with identical-physics records reused where possible. The actual pilot is excluded from training. The user requested this revision after seeing v0.15; the source dates are not a new untouched field holdout.

### Key Assumptions
Counts are observed 15-minute demand inputs. Geometry is reconstructed and speeds use a frozen pre-period fit. Encounters count once per distinct motor/VRU pair, not per detector frame. A colliding pair is not also a near miss. Event-free batches score zero. Incomplete batches are invalid. Scores are not real-world collision probabilities.
''')
 code('''import sys,os,subprocess,importlib.util,importlib.metadata,pathlib,zipfile,base64,io,json,contextlib,hashlib
packages={'numpy':'numpy','pandas':'pandas','torch':'torch','gymnasium':'gymnasium','shapely':'shapely','matplotlib':'matplotlib','sumolib':'sumolib==1.27.1','libsumo':'libsumo==1.27.1','sumo':'eclipse-sumo==1.27.1'}
missing=[p for m,p in packages.items() if importlib.util.find_spec(m) is None]
for p in ['sumolib','libsumo','eclipse-sumo']:
    try:
        if importlib.metadata.version(p)!='1.27.1':missing.append(p+'==1.27.1')
    except importlib.metadata.PackageNotFoundError:pass
if missing:subprocess.check_call([sys.executable,'-m','pip','install','-q',*sorted(set(missing))])
workspace=pathlib.Path.cwd()/'estates_batch_run';workspace.mkdir(exist_ok=True)
payload="'''+base64.b64encode(payload).decode()+'''"
with zipfile.ZipFile(io.BytesIO(base64.b64decode(payload))) as z:z.extractall(workspace)
os.chdir(workspace);sys.path.insert(0,str(workspace));os.environ['MPLCONFIGDIR']=str(workspace/'.mplconfig')
import numpy as np,pandas as pd
from IPython.display import display,Markdown,Image
OUT=workspace/'outputs/mitigation_batch';DATA=workspace/'data/mitigation_rl'
''')
 md('''## Data and reward checks
The batch size is the same in training, validation and testing. March 2 trains, February 11 selects, and May 18/20 tests. Additional seeds measure simulation variability and do not create additional observed days.''')
 code('''from mitigation_batch.config import reward,score_tests
assert score_tests()['passed'];assert reward(1,3)==-115
from mitigation_batch.learn import scored,batches
for split in ['train','validation','test']:
    d=scored(split);print(split,len(d),'simulations;',int(d.complete.sum()),'complete; 30 repeats per action/context')
display(Markdown((workspace/'mitigation_batch/protocol.md').read_text()))
''')
 md('''## Train selected-action batch values
Each update receives one selected intervention's total over 30 repeats. All three families have three learner seeds. Targets are divided by 100 only for stable numerical optimization; exported values return to total-point units. Only pre-installation batches select the policies.''')
 code('''from mitigation_batch.learn import main as train_agents
with contextlib.redirect_stdout(io.StringIO()):train_agents()
freeze=json.loads((OUT/'policy_freeze.json').read_text());assert not freeze['pilot_in_training'] and not freeze['post_outcomes_in_training']
display(pd.read_csv(OUT/'validation_agents.csv'))
print('Validation-selected champion:',freeze['champion'])
''')
 md('''## Held-out scores and uncertainty
A policy has 32 test batches × 30 repeats = 960 episodes. Sum scores to compare at equal exposure. The chart shows mean batch score with 95% intervals over traffic-window clusters. Separate per-window intervals concern repeat randomness only.''')
 code('''from mitigation_batch.evaluate import main as evaluate_agents
with contextlib.redirect_stdout(io.StringIO()):evaluate_agents()
display(pd.read_csv(OUT/'test_policy_results.csv')[['policy','total_score','mean_batch_score','gain_low','gain_high','collisions','near_misses','eligible']].round(2))
display(Image(filename=str(OUT/'policy_results.png')))
print('Charts describe released policies; the table is recalculated from this notebook’s retraining.')
''')
 md('''## Behavior sensitivity
Cautious, tighter-gap and half-speed-response profiles are evaluated on the same eight windows and 30 seeds. They are illustrative assumptions, not local field measurements. Frozen policies are evaluated without tuning them to a profile or the consultant’s result.''')
 code('''s=pd.read_csv(OUT/'sensitivity_policy_results.csv')
display(s[s.policy.isin([freeze['champion'],'A0','A1','A2','A3','H'])][['profile','policy','total_score','collisions','near_misses','eligible']])
display(Image(filename=str(OUT/'sensitivity.png')))
''')
 md('''## Run a fresh 30-repeat batch
This step runs SUMO 30 times with new seeds and returns the actual cumulative reward. The browser uses the same policy inference but displays saved simulation batches.''')
 code('''from mitigation_batch.environment import BatchMitigationEnv
from mitigation_rl.learn import values
models=json.loads((OUT/'models.json').read_text());env=BatchMitigationEnv('test')
obs,info=env.reset(seed=413,options={'context_id':'20230518T073000','simulation_seed_start':995400})
action=int(values(models[freeze['champion']],pd.DataFrame([env.context]))[0].argmax())
obs,total,terminated,truncated,detail=env.step(action)
assert terminated and not truncated and len(detail['episode_scores'])==30
assert total==-100*detail['collisions']-5*detail['near_misses']
display(pd.DataFrame([{'action':detail['action'],'repeats':30,'collisions':detail['collisions'],'near_misses':detail['near_misses'],'batch_score':total}]))
print('Episode scores:',detail['episode_scores'])
''')
 md('''## Takeaways and documentation
A more negative score means more or more heavily penalized simulated encounters. Rankings can change under behavior assumptions. No empirical crash-to-score calibration has been established. The evidence update captures the assignment’s application, development and roadblock sections.''')
 code('''display(Image(filename=str(OUT/'learning.png')))
display(Markdown((OUT/'paper_materials/Evidence_Update.md').read_text()))
''')
 md('''## Optional full simulation rerun
The default retrains all nine agents, recalculates scores, and executes a fresh batch. Enable the flag to regenerate all nominal and sensitivity runs. This takes substantially longer on CPU. Only generated output tables and caches are moved into a backup inside this notebook workspace.''')
 code('''RERUN_ALL=False
if RERUN_ALL:
    import shutil,time
    backup=workspace/f'previous_batch_outputs_{time.time_ns()}';backup.mkdir()
    for name in ['train_runs.csv','validation_runs.csv','test_runs.csv','sensitivity_runs.csv','policy_freeze.json']:
        p=OUT/name
        if p.exists():shutil.move(str(p),str(backup/name))
    for p in [workspace/'outputs/mitigation_rl/episodes',OUT/'episodes']:
        if p.exists():shutil.move(str(p),str(backup/(p.parent.name+'_episodes')))
    subprocess.check_call([sys.executable,'-m','mitigation_batch.pipeline'])
else:print('Fresh 30-repeat batch completed above; full regeneration disabled.')
''')
 nb.cells=cells;nb.metadata={'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python'}};nbformat.validate(nb);nbformat.write(nb,ROOT/'Estates_Mitigation_Batches.ipynb')

def main():
 result=json.loads((OUT/'results.json').read_text());f=result['frozen_selection'];models=json.loads((OUT/'models.json').read_text());d=pd.DataFrame(result['policies']).set_index('policy');champ=d.loc[f['champion']];base=d.loc['A0']
 finding=f"The validation-selected {f['champion']} scored {champ.total_score:,.0f} across 32 test batches, versus {base.total_score:,.0f} for unchanged. "
 finding+=('Its paired 95% interval supports a higher score under nominal simulator assumptions.' if champ.gain_low>0 else 'Its paired 95% interval does not establish a higher score than unchanged.')
 figures(result);evidence(result,finding)
 c=pd.read_csv(DATA/'contexts.csv');c=c[c.split.eq('test')];b=pd.read_csv(OUT/'test_batch_scores.csv');s=pd.read_csv(OUT/'scored_sensitivity_runs.csv');sb=batches(s);b=pd.concat([b,sb],ignore_index=True)
 labels={**LABELS,**{n:n.split('_')[0].title()+' Q ('+n.split('_')[1]+')' for n in models},'best_fixed':'Best fixed from training ('+f['best_fixed_training_action']+')','random':'Uniform random expectation'}
 web={'results':result,'models':models,'finding':finding,'labels':labels,'profile_labels':PROFILE_LABELS,'contexts':c.to_dict('records'),'sensitivity_contexts':SENSITIVITY_CONTEXTS,'batches':json.loads(b.to_json(orient='records')),'episodes':json.loads(pd.concat([pd.read_csv(OUT/'scored_test_runs.csv'),s])[['context_id','profile','action','seed','collision_pairs','near_pairs','score','complete']].to_json(orient='records'))}
 (OUT/'web_data.json').write_text(json.dumps(web,allow_nan=False));expected={name:[{'context_id':r.context_id,'q':values(m,pd.DataFrame([r._asdict()]))[0].tolist()} for r in c.itertuples(index=False)] for name,m in models.items()};(OUT/'expected_inference.json').write_text(json.dumps(expected))
 data=bundle();notebook(data,result);print(finding);print('Bundle bytes',len(data))
if __name__=='__main__':main()
