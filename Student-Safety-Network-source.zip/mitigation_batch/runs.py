"""Versioned batch tables; reuse nominal SUMO physics and verified cache."""
import argparse,json,time
from concurrent.futures import ProcessPoolExecutor,as_completed
import pandas as pd
from mitigation_rl.simulator import run as nominal_run
from .config import ROOT,DATA,OUT,ACTIONS,SEEDS,PROFILES,SENSITIVITY_CONTEXTS,sha

def run(task):
 context,action,seed,profile=task
 if action=='H' or profile!='nominal':assert (OUT/'policy_freeze.json').exists(),'Freeze v0.16 policies before pilot/sensitivity access'
 if profile=='nominal' or (profile=='half_speed_response' and action not in ['A1','A3']):
  result=nominal_run((context,action,seed,.1));result={**result,'profile':profile,'traveler_sha256':result['demand_sha256'],'nominal_physics':True}
 else:
  from .sensitivity import run as changed_run
  result=changed_run((context,action,seed,.1,profile));result['nominal_physics']=False
 return result

def batch(split,workers=4):
 c=pd.read_csv(DATA/'contexts.csv');c=c[c.split.eq(split)]
 if split=='test':assert (OUT/'policy_freeze.json').exists()
 tasks=[(r.context_id,a,s,'nominal') for r in c.itertuples() for s in SEEDS[split] for a in ACTIONS+(['H'] if split=='test' else [])]
 execute(tasks,OUT/f'{split}_runs.csv',workers)

def execute(tasks,dest,workers):
 rows=[];start=time.monotonic()
 with ProcessPoolExecutor(max_workers=workers) as pool:
  fs=[pool.submit(run,t) for t in tasks]
  for f in as_completed(fs):
   rows.append(f.result())
   if len(rows)%100==0 or len(rows)==len(tasks):
    print(f'{dest.stem}: {len(rows)}/{len(tasks)}, incomplete={sum(not r["complete"] for r in rows)}, elapsed={time.monotonic()-start:.0f}s',flush=True)
    pd.DataFrame(rows).to_csv(dest.with_suffix('.partial.csv'),index=False)
 pd.DataFrame(rows).sort_values(['profile','context_id','seed','action']).to_csv(dest,index=False)

def sensitivity(workers=4):
 tasks=[(c,a,s,p) for p in PROFILES for c in SENSITIVITY_CONTEXTS for s in SEEDS['test'] for a in ACTIONS+['H']]
 execute(tasks,OUT/'sensitivity_runs.csv',workers)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('split',choices=['train','validation','test','sensitivity']);p.add_argument('--workers',type=int,default=4);a=p.parse_args()
 sensitivity(a.workers) if a.split=='sensitivity' else batch(a.split,a.workers)
