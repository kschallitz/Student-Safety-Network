"""Validate scoring, pairing, batch sizes and frozen inputs after the run."""
import json
import numpy as np,pandas as pd
from .config import ROOT,OUT,SEEDS,sha,score_tests
from .learn import scored,batches

def main():
 f=json.loads((OUT/'policy_freeze.json').read_text());assert sha(OUT/'models.json')==f['models_sha256'];assert sha(ROOT/'mitigation_batch/protocol.md')==f['protocol_sha256']
 for split in ['train','validation']:assert sha(OUT/f'{split}_runs.csv')==f[f'{split}_sha256']
 assert sha(ROOT/'mitigation_batch/learn.py')==f['trainer_sha256']
 assert sha(ROOT/'mitigation_rl/learn.py')==f['reused_learner_sha256']
 manifest=json.loads((OUT/'run_manifest.json').read_text())
 assert sha(ROOT/'mitigation_rl/simulator.py')==manifest['nominal_engine_sha256']
 assert sha(ROOT/'mitigation_batch/sensitivity.py')==manifest['sensitivity_engine_sha256']
 sizes={};complete={}
 for split,n in [('train',2880),('validation',960),('test',4800)]:
  d=scored(split);assert len(d)==n;assert set(d.seed)==set(SEEDS[split]);assert (d.score.dropna()<=0).all()
  b=batches(d);ok=b[b.complete];assert np.allclose(ok.score,-100*ok.collisions-5*ok.near_misses)
  sizes[split]=len(d);complete[split]=int(d.complete.sum())
 s=pd.read_csv(OUT/'sensitivity_runs.csv');assert len(s)==3600
 assert s.groupby(['profile','context_id','action']).size().eq(30).all();assert s.groupby(['profile','context_id','seed']).traveler_sha256.nunique().eq(1).all()
 # Nominal records reused in half-response must be identical event-for-event.
 test=pd.read_csv(OUT/'test_runs.csv');reuse=s[s.profile.eq('half_speed_response')&s.action.isin(['A0','A2','H'])].merge(test,on=['context_id','action','seed'],suffixes=('_s','_n'))
 assert len(reuse)==720
 for col in ['collision_pairs','near_pairs','mean_motor_delay','complete']:assert reuse[col+'_s'].equals(reuse[col+'_n'])
 # Invalid batch score must remain missing rather than silently dropping a repeat.
 test_scored=scored('test');tiny=test_scored[test_scored.context_id.eq(test_scored.iloc[0].context_id)].copy();i=tiny[tiny.action.eq('A0')].index[0]
 tiny.loc[i,'complete']=False;tiny.loc[i,'score']=np.nan;invalid=batches(tiny)
 assert pd.isna(invalid[invalid.action.eq('A0')].iloc[0].score)
 assert not invalid.base_complete.any()
 # Direct score arithmetic checks cover collision plus non-collision near misses.
 result={**score_tests(),'primary_sizes':sizes,'primary_completed':complete,'sensitivity_records':len(s),'sensitivity_completed':int(s.complete.sum()),'all_batches_have_30':True,'matched_exogenous_travelers':True,'unchanged_sensitivity_records_reused':720,'models_and_protocol_unchanged':True,'nominal_engine_identical_to_v015':True}
 (OUT/'verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
if __name__=='__main__':main()
