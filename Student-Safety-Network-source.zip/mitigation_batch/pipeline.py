"""Resume caches; maintain the pre/test freeze order without interactive waits."""
import json,time
from .config import ROOT,OUT,sha
from .runs import batch,sensitivity
def main():
 start=time.time();manifest={'protocol_sha256':sha(ROOT/'mitigation_batch/protocol.md'),'started_unix':start,'nominal_engine_sha256':sha(ROOT/'mitigation_rl/simulator.py'),'sensitivity_engine_sha256':sha(ROOT/'mitigation_batch/sensitivity.py')}
 (OUT/'run_manifest.json').write_text(json.dumps(manifest,indent=2))
 # The first train batch may have been started separately while coding.
 for split in ['train','validation']:
  if not (OUT/f'{split}_runs.csv').exists():batch(split,6)
 if not (OUT/'policy_freeze.json').exists():
  from .learn import main as learn
  learn()
 if not (OUT/'test_runs.csv').exists():batch('test',6)
 if not (OUT/'sensitivity_runs.csv').exists():sensitivity(6)
 from .evaluate import main as evaluate
 evaluate();manifest.update(completed_unix=time.time(),wall_seconds=time.time()-start);(OUT/'run_manifest.json').write_text(json.dumps(manifest,indent=2));print('Complete: all declared batches and sensitivity profiles evaluated.',flush=True)
if __name__=='__main__':
 import sys
 if '--wait-for-input-batches' in sys.argv:
  print('Waiting for the active training and validation batches, then continuing the frozen experiment.',flush=True)
  while not all((OUT/f'{s}_runs.csv').exists() for s in ['train','validation']):time.sleep(5)
 main()
