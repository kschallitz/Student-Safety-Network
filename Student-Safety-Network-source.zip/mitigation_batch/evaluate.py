"""Frozen-policy evaluation using summed 30-repeat penalties."""
import json
import numpy as np,pandas as pd
from mitigation_rl.learn import values
from .config import ROOT,DATA,OUT,ACTIONS,sha,reward,score_tests
from .learn import scored,batches

def ci(x,seed=5471):
 x=np.asarray(x,float)
 if not np.isfinite(x).all() or not len(x):return [None,None]
 rng=np.random.default_rng(seed);return np.quantile(rng.choice(x,(4000,len(x)),replace=True).mean(1),[.025,.975]).tolist()

def policy_map(models,contexts,freeze):
 policies={name:dict(zip(contexts.context_id,[ACTIONS[i] for i in values(model,contexts).argmax(1)])) for name,model in models.items()}
 policies.update({a:dict.fromkeys(contexts.context_id,a) for a in ACTIONS+['H']});policies['best_fixed']=dict.fromkeys(contexts.context_id,freeze['best_fixed_training_action']);return policies

def summaries(b,policies,profile):
 out=[];picked=[]
 for name,mapping in policies.items():
  p=b[b.action.eq(b.context_id.map(mapping))].copy();p['policy']=name;picked.append(p)
  valid=bool(p.complete.all() and p.base_complete.all());delay=float((p.delay-p.base_delay).mean());eligible=valid and delay<=30
  total=float(p.score.sum()) if valid else None;mean=total/len(p) if valid else None
  gain=p.score-p.base_score;lo,hi=ci(p.score);gl,gh=ci(gain)
  out.append({'profile':profile,'policy':name,'batches':len(p),'repeats_per_batch':30,'episodes':len(p)*30,'total_score':total,'mean_batch_score':mean,'score_low':lo,'score_high':hi,'mean_gain_vs_baseline':float(gain.mean()) if valid else None,'gain_low':gl,'gain_high':gh,'collisions':int(p.collisions.sum()) if valid else None,'near_misses':int(p.near_misses.sum()) if valid else None,'delay_increase_s':delay,'invalid_batches':int((~p.complete|~p.base_complete).sum()),'eligible':eligible,'curb_component_fraction':float(np.mean([a in ['A2','A3'] for a in mapping.values()]))})
 # Exact uniform-random action expectation for each context, at same exposure.
 r=b[b.action.isin(ACTIONS)].groupby('context_id').agg(score=('score','mean'),complete=('complete','all'),collisions=('collisions','mean'),near_misses=('near_misses','mean'),delay=('delay','mean'),base_score=('base_score','first'),base_delay=('base_delay','first'),base_complete=('base_complete','all')).reset_index()
 valid=bool(r.complete.all() and r.base_complete.all());lo,hi=ci(r.score);gl,gh=ci(r.score-r.base_score);delay=float((r.delay-r.base_delay).mean())
 out.append({'profile':profile,'policy':'random','batches':len(r),'repeats_per_batch':30,'episodes':len(r)*30,'total_score':float(r.score.sum()) if valid else None,'mean_batch_score':float(r.score.mean()) if valid else None,'score_low':lo,'score_high':hi,'mean_gain_vs_baseline':float((r.score-r.base_score).mean()) if valid else None,'gain_low':gl,'gain_high':gh,'collisions':float(r.collisions.sum()) if valid else None,'near_misses':float(r.near_misses.sum()) if valid else None,'delay_increase_s':delay,'invalid_batches':int((~r.complete|~r.base_complete).sum()),'eligible':valid and delay<=30,'curb_component_fraction':None})
 return out,pd.concat(picked)

def main():
 f=json.loads((OUT/'policy_freeze.json').read_text());assert sha(OUT/'models.json')==f['models_sha256'];assert sha(ROOT/'mitigation_batch/protocol.md')==f['protocol_sha256'];models=json.loads((OUT/'models.json').read_text())
 c=pd.read_csv(DATA/'contexts.csv');c=c[c.split.eq('test')];d=scored('test');b=batches(d);policies=policy_map(models,c,f);summary,picked=summaries(b,policies,'nominal')
 # Within-window uncertainty concerns simulator randomness, separately from
 # across-window intervals. Pair each repeat with unchanged before resampling.
 base=d[d.action.eq('A0')][['context_id','seed','score']].rename(columns={'score':'base_score'})
 dd=d.merge(base,on=['context_id','seed']);mc=[]
 for (ctx,a),z in dd.groupby(['context_id','action']):
  lo,hi=ci(z.score);gl,gh=ci(z.score-z.base_score)
  mc.append({'context_id':ctx,'action':a,'score_low':None if lo is None else 30*lo,'score_high':None if hi is None else 30*hi,'gain_low':None if gl is None else 30*gl,'gain_high':None if gh is None else 30*gh})
 b=b.merge(pd.DataFrame(mc),on=['context_id','action']);b.to_csv(OUT/'test_batch_scores.csv',index=False);d.to_csv(OUT/'scored_test_runs.csv',index=False);picked.to_csv(OUT/'policy_test_batches.csv',index=False);pd.DataFrame(summary).to_csv(OUT/'test_policy_results.csv',index=False)
 sensitivity_rows=[]
 if (OUT/'sensitivity_runs.csv').exists():
  s=pd.read_csv(OUT/'sensitivity_runs.csv');s['score']=[reward(r.collision_pairs,r.near_pairs) if r.complete else np.nan for r in s.itertuples()]
  assert s.groupby(['profile','context_id','action']).size().eq(30).all();assert s.groupby(['profile','context_id','seed']).traveler_sha256.nunique().eq(1).all()
  subset=c[c.context_id.isin(s.context_id.unique())];pol=policy_map(models,subset,f)
  for profile,z in [('nominal_subset',d[d.context_id.isin(subset.context_id)])]+list(s.groupby('profile')):
   sb=batches(z);rows,_=summaries(sb,pol,profile);sensitivity_rows+=rows
  s.to_csv(OUT/'scored_sensitivity_runs.csv',index=False);pd.DataFrame(sensitivity_rows).to_csv(OUT/'sensitivity_policy_results.csv',index=False)
 candidates=[x for x in summary if x['policy'] in models and x['eligible']];best=sorted(candidates,key=lambda x:(-x['total_score'],x['policy']))[0]['policy'] if candidates else None
 fixed=[x for x in summary if x['policy'] in ACTIONS and x['eligible']];bestfixed=sorted(fixed,key=lambda x:(-x['total_score'],x['policy']))[0]['policy'] if fixed else None
 result={'release':'0.16','reward':'-100 per collision encounter -5 per non-collision near-miss encounter','batch_repeats':30,'primary_simulations':8640,'test_simulations':len(d),'test_completed':int(d.complete.sum()),'frozen_selection':f,'policies':summary,'sensitivity':sensitivity_rows,'descriptive_best_test_agent':best,'descriptive_best_generic_test_action':bestfixed,'scope':'Simulator scores, not real-world injury probabilities. Retrospective follow-up with prior May results already seen.','score_checks':score_tests()}
 (OUT/'results.json').write_text(json.dumps(result,indent=2,allow_nan=False));print(pd.DataFrame(summary)[['policy','total_score','mean_batch_score','collisions','near_misses','eligible']].to_string(index=False))
if __name__=='__main__':main()
