"""Actually execute matched SUMO episodes. No Explorer probability enters reward."""
import argparse,hashlib,json,math,os,time,xml.etree.ElementTree as E
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np,pandas as pd,sumolib
from .config import ROOT,DATA,OUT,ACTIONS,SEEDS,PROFILES,sha
from mitigation_rl.events import body,ttc
from sumo_v06.demand import make_demand,xml

def run(task):
 context_id,action,seed,step,profile=task
 settings=PROFILES[profile]
 if action=='H':
  assert (OUT/'policy_freeze.json').exists(),'Pilot cannot run before policy freeze'
  src=ROOT/'outputs/sumo_v06/networks/Estates/pilot'
 else:src=DATA/'networks'/action
 net=src/'network.net.xml';d=pd.read_csv(DATA/'observations.csv');rows=d[d.context_id.eq(context_id)]
 sig=hashlib.sha256((str(task)+sha(net)+sha(__file__)+sha(ROOT/'mitigation_batch/config.py')+sha(ROOT/'mitigation_rl/events.py')+sha(DATA/'observations.csv')+sha(ROOT/'outputs/sumo_v07/calibration.json')).encode()).hexdigest()[:20]
 p=OUT/'episodes'/sig;p.mkdir(parents=True,exist_ok=True)
 if (p/'result.json').exists():return json.loads((p/'result.json').read_text())
 n=sumolib.net.readNet(str(net),withInternal=True,withPedestrianConnections=True)
 ports=json.loads((src/'ports.json').read_text());requested,total=make_demand(rows,seed,p,n,ports)
 routes=E.parse(p/'demand.rou.xml').getroot();old=json.loads((ROOT/'outputs/sumo_v02/calibration.json').read_text());new=json.loads((ROOT/'outputs/sumo_v07/calibration.json').read_text())
 for v in routes.findall('vType'):
  if v.get('vClass')!='pedestrian':v.set('actionStepLength','.2')
 for v in routes.findall('vehicle'):
  dr={'W_in':'eastbound','E_in':'westbound'}.get(v.find('route').get('edges').split()[0])
  if dr and v.get('type')!='bicycle':
   z=(float(v.get('speedFactor'))*30-old[dr]['desired_mean_mph'])/old[dr]['desired_sd_mph'];v.set('speedFactor',str(max(.2,(new[dr]['desired_mean_mph']+z*new[dr]['desired_sd_mph'])/30)))
 xml(routes,p/'demand.rou.xml');traveler_hash=sha(p/'demand.rou.xml')
 for v in routes.findall('vType'):
  if v.get('vClass') in ['passenger','truck']:
   v.set('tau',str(settings['tau']));v.set('actionStepLength',str(settings['action_step']));v.set('jmCrossingGap',str(settings['crossing_gap']))
 if profile=='half_speed_response' and action in ['A1','A3']:
  for v in routes.findall('vehicle'):
   if v.get('type') in ['passenger','heavy'] and v.find('route').get('edges').split()[0] in ['W_in','E_in']:
    v.set('speedFactor',str(float(v.get('speedFactor'))*1.1))
 xml(routes,p/'demand.rou.xml');demand_hash=sha(p/'demand.rou.xml')
 cfg=E.Element('configuration');inp=E.SubElement(cfg,'input')
 for k,v in [('net-file',os.path.relpath(net,p)),('route-files','demand.rou.xml')]:E.SubElement(inp,k,value=v)
 tm=E.SubElement(cfg,'time');E.SubElement(tm,'step-length',value=str(step));proc=E.SubElement(cfg,'processing')
 for k,v in [('step-method.ballistic','true'),('pedestrian.striping.reserve-oncoming','.5'),('pedestrian.striping.reserve-oncoming.junctions','.5'),('pedestrian.striping.reserve-oncoming.max','2'),('pedestrian.striping.jamtime','-1'),('pedestrian.striping.jamtime.crossing','-1'),('pedestrian.striping.jamtime.narrow','-1'),('time-to-teleport','-1'),('collision.action','warn'),('intermodal-collision.action','warn'),('collision.check-junctions','true'),('collision.mingap-factor','0')]:E.SubElement(proc,k,value=v)
 xml(cfg,p/'run.sumocfg')
 import libsumo as sim
 tick=time.monotonic();sim.start([sumolib.checkBinary('sumo'),'-c',str(p/'run.sumocfg'),'--seed',str(seed),'--no-step-log','true','--duration-log.disable','true','--no-warnings','true','--error-log',str(p/'warnings.log'),'--tripinfo-output',str(p/'trips.xml'),'--collision-output',str(p/'contacts.xml')])
 cross={e.get('id'):e.get('crossingEdges').split()[0][0] for e in E.parse(net).findall('edge') if e.get('function')=='crossing'}
 near={};wrong=set();teleports=0;pending=None
 try:
  for t in np.arange(.2,3000.01,.2):
   sim.simulationStep(float(t));teleports+=sim.simulation.getStartingTeleportNumber()
   if t>=900:
    motors=[];vru=[]
    for vid in sim.vehicle.getIDList():
     x,y=sim.vehicle.getPosition(vid)
     if math.hypot(x-250,y-250)>40:continue
     sp=sim.vehicle.getSpeed(vid);typ=sim.vehicle.getTypeID(vid)
     v=(vid,body(x,y,sim.vehicle.getAngle(vid),sp,sim.vehicle.getLength(vid),sim.vehicle.getWidth(vid)))
     if typ=='bicycle':vru.append(v)
     elif sp>=1:motors.append(v)
    for pid in sim.person.getIDList():
     road=sim.person.getRoadID(pid)
     if road not in cross:continue
     if pid.startswith('s') and cross[road]!=pid.rsplit('_',1)[1]:wrong.add(pid)
     x,y=sim.person.getPosition(pid);vru.append((pid,body(x,y,sim.person.getAngle(pid),sim.person.getSpeed(pid),.6,.6,False)))
    for mid,m in motors:
     for vid,v in vru:
      if not(mid.startswith('s') or vid.startswith('s')):continue
      if np.linalg.norm(m[0]-v[0])>35:continue
      q=ttc(m,v)
      if q is not None and q>1e-6:
       pair=tuple(sorted([mid,vid]));prior=near.get(pair)
       if prior is None or q<prior['min_ttc']:near[pair]={'min_ttc':q,'time':round(float(t),1)}
   if t>=1800 and sim.simulation.getMinExpectedNumber()==0:break
  pending=sim.simulation.getMinExpectedNumber()
 finally:sim.close()
 trips=E.parse(p/'trips.xml').getroot();study=[z for z in trips if z.get('id','').startswith('s')];motor=[z for z in study if z.tag=='tripinfo' and z.get('vType') in ['passenger','heavy']]
 collisions=set()
 def is_motor(s):return s.endswith(('_passenger','_heavy'))
 def is_vru(s):return '_ped_' in s or s.endswith('_bicycle')
 for z in E.parse(p/'contacts.xml').getroot():
  a,b=z.get('collider',''),z.get('victim','')
  if float(z.get('time','0'))>=900 and (a.startswith('s') or b.startswith('s')) and ((is_motor(a) and is_vru(b)) or (is_motor(b) and is_vru(a))):collisions.add(tuple(sorted([a,b])))
 near={p:q for p,q in near.items() if p not in collisions}
 counts={str(h):int(sum(q['min_ttc']<=h for q in near.values())) for h in [1.,1.5,2.]}
 result={'profile':profile,'profile_settings':settings,'traveler_sha256':traveler_hash,'context_id':context_id,'action':action,'seed':seed,'step':step,'split':rows.iloc[0]['split'],'requested':requested,'arrived':len(study),'pending':pending,'teleports':teleports,'wrong_crossings':len(wrong),'complete':len(study)==requested and pending==0 and teleports==0 and not wrong,'collision_pairs':len(collisions),'near_pairs':counts['1.5'],'near_pairs_1s':counts['1.0'],'near_pairs_2s':counts['2.0'],'collision':int(bool(collisions)),'near':int(counts['1.5']>0),'mean_motor_delay':float(np.mean([float(z.get('timeLoss')) for z in motor])) if motor else 0.,'wall_seconds':time.monotonic()-tick,'demand_sha256':demand_hash,'path':str(p.relative_to(ROOT))}
 (p/'event_pairs.json').write_text(json.dumps({'collisions':[list(z) for z in sorted(collisions)],'near':[{'pair':list(k),**v} for k,v in near.items()]},indent=2));(p/'result.json').write_text(json.dumps(result,indent=2));return result

