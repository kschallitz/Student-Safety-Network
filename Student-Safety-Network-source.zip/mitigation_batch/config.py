from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data/mitigation_rl';OUT=ROOT/'outputs/mitigation_batch'
ACTIONS=['A0','A1','A2','A3']
SEEDS={'train':[81011,81023,81041]+list(range(910000,910027)),
       'validation':[82009,82021]+list(range(920000,920028)),
       'test':[83003,83017,83029]+list(range(930000,930027))}
PROFILES={'cautious':{'tau':1.6,'action_step':.8,'crossing_gap':15},
          'tighter_gaps':{'tau':1.,'action_step':.8,'crossing_gap':5},
          'half_speed_response':{'tau':1.2,'action_step':.2,'crossing_gap':10}}
SENSITIVITY_CONTEXTS=['20230518T070000','20230518T073000','20230518T080000','20230518T083000','20230518T140000','20230518T143000','20230520T110000','20230520T120000']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def reward(collisions,near_misses):
 assert collisions>=0 and near_misses>=0
 return -100*int(collisions)-5*int(near_misses)
def score_tests():
 assert reward(0,0)==0 and reward(0,3)==-15
 assert reward(1,0)==-100 and reward(1,3)==-115 and reward(2,3)==-215
 assert sum(reward(0,3) for _ in range(30))==-450
 return {'cumulative_reward_checks':6,'passed':True}
