"""Learn cumulative 30-repeat action values from pre-installation batches only."""
import json
import numpy as np,pandas as pd
from mitigation_rl.learn import features,key,values,train
from .config import ROOT,DATA,OUT,ACTIONS,SEEDS,sha,reward,score_tests

def scored(split):
 d=pd.read_csv(OUT/f'{split}_runs.csv');d['score']=[reward(c,n) if ok else np.nan for c,n,ok in zip(d.collision_pairs,d.near_pairs,d.complete)]
 assert d.groupby(['profile','context_id','action']).size().eq(30).all()
 assert not d.duplicated(['profile','context_id','action','seed']).any()
 assert d.groupby(['profile','context_id','seed']).traveler_sha256.nunique().eq(1).all()
 return d

def batches(d):
 b=d.groupby(['profile','context_id','action']).agg(score=('score',lambda s:s.sum(min_count=30)),complete=('complete','all'),delay=('mean_motor_delay','mean'),collisions=('collision_pairs','sum'),near_misses=('near_pairs','sum'),repeats=('seed','size')).reset_index()
 base=b[b.action.eq('A0')][['profile','context_id','score','delay','complete']].rename(columns={'score':'base_score','delay':'base_delay','complete':'base_complete'})
 return b.merge(base,on=['profile','context_id'],validate='many_to_one')

def main():
 score_tests();c=pd.read_csv(DATA/'contexts.csv');tr=batches(scored('train'));va=batches(scored('validation'))
 valid=tr.groupby('context_id').complete.all();bad=valid[~valid].index.tolist();tr=tr[~tr.context_id.isin(bad)].copy()
 pd.DataFrame({'context_id':bad}).to_csv(OUT/'excluded_training_contexts.csv',index=False)
 train_c=c[c.split.eq('train')&~c.context_id.isin(bad)].reset_index(drop=True);val_c=c[c.split.eq('validation')].reset_index(drop=True)
 # The reused learner consumes one selected-action target. Here that target is
 # a whole 30-run batch in units of 100 points; no individual-repeat feedback.
 feedback=tr.assign(seed=0,reward=tr.score/100)[['context_id','action','seed','reward']]
 logs=[];records=[];models={}
 for family in ['tabular','linear','neural']:
  for seed in [41,73,109]:
   model,history=train(family,seed,train_c,feedback);name=f'{family}_{seed}'
   if family=='tabular':model['table']={k:(np.array(v)*100).tolist() for k,v in model['table'].items()};model['fallback']=(np.array(model['fallback'])*100).tolist()
   elif family=='linear':model['weights']=(np.array(model['weights'])*100).tolist()
   else:
    model['layers'][-1]['weight']=(np.array(model['layers'][-1]['weight'])*100).tolist();model['layers'][-1]['bias']=(np.array(model['layers'][-1]['bias'])*100).tolist()
   model.update(reward_definition='-100*collision_pairs - 5*near_pairs',decision_repeats=30,q_units='total points per 30-repeat batch')
   models[name]=model
   for row in history:row['mean_training_reward']*=100
   logs+=history
   mapping=dict(zip(val_c.context_id,[ACTIONS[i] for i in values(model,val_c).argmax(1)]));pick=va[va.action.eq(va.context_id.map(mapping))]
   eligible=bool(pick.complete.all() and pick.base_complete.all() and (pick.delay-pick.base_delay).mean()<=30)
   records.append({'agent':name,'family':family,'mean_batch_score':float(pick.score.mean()),'validation_total_score':float(pick.score.sum(min_count=len(val_c))),'eligible':eligible,'mean_delay_increase_s':float((pick.delay-pick.base_delay).mean())})
 ranking=sorted(records,key=lambda r:(not r['eligible'],-r['mean_batch_score'],r['agent']));representatives={f:next(r['agent'] for r in ranking if r['family']==f) for f in ['tabular','linear','neural']}
 bestfixed=tr.groupby('action').score.mean().sort_index().idxmax()
 (OUT/'models.json').write_text(json.dumps(models,indent=2));pd.DataFrame(records).to_csv(OUT/'validation_agents.csv',index=False);pd.DataFrame(logs).to_csv(OUT/'training_history.csv',index=False)
 freeze={'champion':ranking[0]['agent'],'representatives':representatives,'best_fixed_training_action':bestfixed,'selection':'eligible first; validation mean 30-repeat batch score; lexical ties','training_actions':ACTIONS,'pilot_in_training':False,'post_outcomes_in_training':False,'repeats':30,'excluded_train_contexts':bad,'protocol_sha256':sha(ROOT/'mitigation_batch/protocol.md'),'models_sha256':sha(OUT/'models.json'),'train_sha256':sha(OUT/'train_runs.csv'),'validation_sha256':sha(OUT/'validation_runs.csv'),'trainer_sha256':sha(__file__),'reused_learner_sha256':sha(ROOT/'mitigation_rl/learn.py')}
 (OUT/'policy_freeze.json').write_text(json.dumps(freeze,indent=2));print(json.dumps(freeze,indent=2))
if __name__=='__main__':main()
