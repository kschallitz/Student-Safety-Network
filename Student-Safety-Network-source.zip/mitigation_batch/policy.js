/* Portable inference for the exact exported one-step Q policies. */
(function(root){
 const actions=['A0','A1','A2','A3'];
 function features(c){let motor=c.passenger+c.heavy;return [Math.log1p(motor),Math.log1p(c.pedestrian),Math.log1p(c.bicycle),Math.sin(c.hour/24*2*Math.PI),Math.cos(c.hour/24*2*Math.PI),c.weekend,c.heavy/Math.max(motor,1)];}
 function key(c){const bin=(x,edges)=>edges.filter(v=>x>=v).length;return `${Math.floor(c.hour/3)}_${bin(c.pedestrian,[1,5,15,40])}_${bin(c.passenger+c.heavy,[150,250,400])}`;}
 function values(model,c){
  let x=features(c).map((v,i)=>(v-model.mean[i])/model.std[i]);
  if(model.family==='tabular')return model.table[key(c)]||model.fallback;
  if(model.family==='linear'){x.push(1);return actions.map((_,a)=>x.reduce((s,v,i)=>s+v*model.weights[i][a],0));}
  for(const layer of model.layers)x=layer.weight.map((w,j)=>{const z=w.reduce((s,v,i)=>s+v*x[i],layer.bias[j]);return layer.activation==='tanh'?Math.tanh(z):z;});
  return x;
 }
 function predict(model,c){const q=values(model,c);return {action:actions[q.indexOf(Math.max(...q))],q};}
 const api={features,key,values,predict};root.MitigationPolicy=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
