# MetaDrive intersection comparisons

**Public source release v0.31 — October 11, 2026.** Estates has checked results. Hillcrest has run controls, but its first 72-episode batch includes eight incomplete episodes; training is blocked and no Hillcrest recommendation is released. The public archive excludes study inputs, saved raw episodes and worker credentials. Follow the setup commands only after acquiring and preparing authorized inputs.

The current runner supports East Avenue / Estates Street (J01145) and East Avenue / Hillcrest Avenue (J02019). The website keeps the annual map estimate separate from the simulator's scored contacts and near misses.

## Website

Select either intersection and open **Find best mitigation**. The saved results include the agents' choices and comparisons on the four reserved May periods. **Run mitigation comparison** sends a job to the Mac worker. Its status and completed episode count update on the page. Completed results are saved on the website, so the Mac can be off when viewing them later.

New arrival realizations use new explicit realization numbers, with every candidate receiving the same travelers and arrival times within each comparison. The fixed master seed remains 1400000. Reproducing saved arrivals reuses already completed, fingerprint-matched episodes and retrains from them; it does not create independent traffic evidence.

The worker processes one job at a time. The Mac must remain awake and connected while it runs. To start or restart it from this project:

```sh
.venv-metadrive/bin/python -m metadrive_intersections.worker
```

Credentials are in `.private/simulation_worker.json` with owner-only file permissions. They are not in the website or reproduction download. Do not share that directory. Only two whitelisted sites and bounded numeric settings are accepted; uploaded CSVs do not execute code or automatically replace the checked counts.

## Local reproduction

```sh
PYTHONPATH=vendor/metadrive SCHOOL_SIM_SITE=Hillcrest .venv-metadrive/bin/python -m metadrive_intersections.validate
PYTHONPATH=vendor/metadrive SCHOOL_SIM_SITE=Hillcrest .venv-metadrive/bin/python -m metadrive_intersections.run --workers 2
PYTHONPATH=vendor/metadrive SCHOOL_SIM_SITE=Hillcrest .venv-metadrive/bin/python -m metadrive_intersections.learning
PYTHONPATH=vendor/metadrive SCHOOL_SIM_SITE=Hillcrest .venv-metadrive/bin/python -m metadrive_intersections.export
```

Replace Hillcrest with Estates for the other site. Initial batches use 12 demand periods, 6 Hillcrest or 8 Estates candidates, and one arrival realization per period. Increase `--realizations` (1–30) and use a new `--suite` name to retain the original matrix. All periods continue until every requested traveler finishes, up to a declared 3600-second cohort limit. A failed or incomplete episode blocks release of the whole comparison; delayed episodes are not discarded as unsuccessful mitigations.

## Counts, controls, and scoring

Hillcrest has its own observed count data, not transferred Estates counts. The available export has 56 complete-session 15-minute periods. The pilot uses 12 March/May periods for training, validation, and evaluation. Missing original cells remain missing; the incomplete March 2 afternoon session is not filled with zeros. The site manifest records this and the grouped bicycle left/U-turn ambiguity.

Hillcrest has four signal-controlled approaches. Its phase structure follows the available historical documentation. Base green durations and pedestrian clearance settings are explicit assumptions shared by all candidates. An occupied-junction guard extends all-red until committed vehicles/bicycles and started pedestrians clear; actual extensions depend on traffic and are saved with each episode. Geometry is traced from the 2025 drawing; traffic counts are from 2023. Corridor speed distributions transfer to Hillcrest as a stated assumption.

Reward is −1000 per distinct motor vehicle–pedestrian/bicycle contact pair and −5 per distinct measured near-miss pair. Vehicle–vehicle events and delay are diagnostics only. A contact pair cannot also incur a near-miss penalty in that episode.

A dense Hillcrest check exposed a phase-clearance defect: through traffic could be released while a turning vehicle was still waiting at an exit crossing. The Hillcrest-specific controller now holds conflicting greens until the junction clears, stops queues behind the junction entrance and crosswalk, and respects red pedestrian permissions. Pedestrians stage 2 m along the source-traced sidewalk direction, with separate right-side paths, so a waiting group does not block an adjacent crossing’s exit. These waiting offsets and stop margins are modeling assumptions. Estates retains its separate priority controller.

The app corrects the native Cyclist contact box so its long axis matches its travel heading. A native-corner comparison verifies alignment against the observer footprint before traffic runs are accepted.

Hillcrest's following controller also checks the full oriented body of a turning vehicle. A stopped right turn can leave its rear corner in the through lane after its center has moved out. The former fixed center-distance cutoff missed that obstruction; the revised check uses projected body dimensions and forward speed along the following vehicle's direction.

Bicycle near misses use route-projected oriented footprints, a projected overlap within 1.5 seconds, and confirmed actual passage through the fixed conflict point with post-encroachment time no greater than 5 seconds. Unvisited projections expire without reward. The observer does not change driving behavior. Tests cover crossing/following conflicts, separated and diverging paths, expiration, contact exclusion, and reward deduplication.

Three terminal-action learners (tabular, linear, and neural) learn candidate rewards from March training episodes. March validation chooses among their fixed recommendations. May data are reserved for evaluation; consultant identity is revealed after fitting. Training updates replay measured simulator outcomes; they are not additional simulator runs. Ties and worse-than-baseline outcomes are shown rather than hidden.

Speed humps and crossing guards remain planning candidates; their behavior is not in these scored candidate sets.

## Audit files

`data/metadrive_intersections/<site>/` contains observations, context periods, geometry, candidate definitions and source metadata. `outputs/metadrive_intersections/<site>/` contains raw episodes by source fingerprint, scalar results, motion checks, batch protocol, quality report, policy freeze, evaluation and site evidence. Job-specific outputs begin `job_<id>`. The original `metadrive_school` study remains intact.
