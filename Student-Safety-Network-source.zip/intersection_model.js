/* Pure inference and scenario functions; verified against the Python estimators. */
(function(root) {
  function rate(model, row) {
    if(model.kind==='ten_year_pooled') {
      const regionalRow=[...row.slice(0,10),...row.slice(12,18)];
      const regional=rate(model.regional,regionalRow)*(model.city_factors[row[18]]??1);
      return (row[10]+model.prior_years*regional)/(row[11]+model.prior_years);
    }
    let v = row.map((x,i)=>(x-model.mean[i])/model.scale[i]);
    if(model.kind==='poisson_glm') return Math.exp(model.intercept+v.reduce((s,x,i)=>s+x*model.weights[i],0));
    model.weights.forEach((w,k)=>{
      let out=model.biases[k].map((b,j)=>b+v.reduce((s,x,i)=>s+x*w[i][j],0));
      v=out.map(x=>k===model.weights.length-1 ? Math.exp(x) : Math.tanh(x));
    });
    return v[0];
  }
  function probability(mu) {return -Math.expm1(-Math.max(0,mu));}
  function predict(model, rows) {
    let rates=rows.map(row=>rate(model,row));
    if(model.kind==='ten_year_pooled') {
      if(rows.length!==6)throw new Error('Annual calibration requires six ordered time bands');
      const total=Math.max(rates.reduce((a,b)=>a+b,0),1e-12),[a,b]=model.calibration;
      const scale=Math.exp(a)*Math.pow(total,b)/total;
      rates=rates.map(r=>r*scale);
    }
    return {rates,bands:rates.map(probability),annual:probability(rates.reduce((a,b)=>a+b,0))};
  }
  function speedRows(rows,approaches,selected,override) {
    const speeds=approaches.flatMap((r,i)=>r.speeds.map(s=>i===selected&&override!==null ? override : s)).filter(x=>x!==null);
    if(!speeds.length) return rows.map(r=>r.slice());
    const mean=speeds.reduce((a,b)=>a+b,0)/speeds.length,max=Math.max(...speeds);
    return rows.map(row=>{const r=row.slice();r[0]=mean;r[1]=max;return r;});
  }
  function compare(bundle,junction,road,baselineSpeed,proposedSpeed,kind='nn') {
    const baselineRows=speedRows(junction.x,junction.approaches,road,baselineSpeed);
    const scenarioRows=speedRows(junction.x,junction.approaches,road,proposedSpeed);
    const baseline=predict(bundle[kind],baselineRows),scenario=predict(bundle[kind],scenarioRows);
    return {baseline,scenario,percentagePoints:100*(scenario.annual-baseline.annual),
      relativePercent:baseline.annual>0?100*(scenario.annual/baseline.annual-1):null};
  }
  function quantile(xs,q) {
    const a=xs.slice().sort((x,y)=>x-y),k=(a.length-1)*q,i=Math.floor(k);
    return a[i]+(a[Math.min(i+1,a.length-1)]-a[i])*(k-i);
  }
  function modelRange(ensemble,rows) {
    if(!ensemble||!ensemble.length)return null;
    const predictions=ensemble.map(m=>predict(m,rows));
    const interval=a=>[quantile(a,.05),quantile(a,.95)];
    return {annual:interval(predictions.map(p=>p.annual)),
      bands:Array.from({length:6},(_,i)=>interval(predictions.map(p=>p.bands[i]))),predictions};
  }
  function pairedChangeRange(ensemble,before,after) {
    const delta=ensemble.map(m=>100*(predict(m,after).annual-predict(m,before).annual));
    return [quantile(delta,.05),quantile(delta,.95)];
  }
  const api={rate,probability,predict,speedRows,compare,quantile,modelRange,pairedChangeRange};
  if(typeof module!=='undefined') module.exports=api;
  root.IntersectionModel=api;
})(typeof window!=='undefined'?window:globalThis);
