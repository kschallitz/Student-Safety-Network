"""Annual calibration diagnostics and a portable narrative from saved results."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from intersection_prediction import OUT,predict_export,probability

def write_report(evaluation=None,summary=None,prep=None):
    annual=pd.read_csv(OUT/'annual_calibration_evaluation.csv')
    cal=pd.read_csv(OUT/'annual_reliability.csv')
    cohorts=pd.read_csv(OUT/'history_calibration_cohorts.csv')
    current=pd.read_csv(OUT/'map_predictions.csv')
    models=json.loads((OUT/'model.json').read_text())
    ev=annual.loc[annual.year.ge(2023)]
    labels=['Previous 3-year NN','Ten-year pooled NN','Ten-year pooled regression','Ten-year pooled baseline']
    colors={'Previous 3-year NN':'#8b6b51','Ten-year pooled NN':'#176e89','Ten-year pooled regression':'#76559a','Ten-year pooled baseline':'#71818b'}
    short={'Previous 3-year NN':'Previous 3-year NN','Ten-year pooled NN':'Ten-year NN','Ten-year pooled regression':'Ten-year regression','Ten-year pooled baseline':'Ten-year rate baseline'}
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white'})
    fig,axes=plt.subplots(1,2,figsize=(12.4,4.8),layout='constrained')
    for label in labels:
        g=ev.loc[ev.model.eq(label)]
        axes[0].plot(g.year,g.log_loss,marker='o',color=colors[label],label=short[label])
        axes[1].plot(g.year,g.brier,marker='o',color=colors[label],label=short[label])
    for ax,title,ylabel in zip(axes,['Annual probability error','Annual Brier score'],['Log loss · lower is better','Brier score · lower is better']):
        ax.set(title=title,ylabel=ylabel,xticks=[2023,2024,2025],xticklabels=['2023','2024*','2025*']);ax.grid(alpha=.2);ax.legend(fontsize=9)
    fig.suptitle('Complete 500-ft area-year outcomes · reused diagnostics · *provisional',fontsize=12)
    fig.savefig(OUT/'held_out_evaluation.png',dpi=150);plt.close(fig)

    fig,axes=plt.subplots(1,3,figsize=(14.5,4.8),layout='constrained',sharex=True,sharey=True)
    for ax,year in zip(axes,[2023,2024,2025]):
        for label in ['Previous 3-year NN','Ten-year pooled NN','Ten-year pooled regression']:
            g=cal.loc[cal.year.eq(year)&cal.model.eq(label)&cal.rows.ge(40)]
            ax.plot(g.mean_probability*100,g.observed_fraction*100,'o-',color=colors[label],label=short[label])
            if label!='Previous 3-year NN':
                ax.vlines(g.mean_probability*100,g.observed_low*100,g.observed_high*100,color=colors[label],alpha=.6)
        ax.plot([0,100],[0,100],'--',color='#56636c',label='Perfect agreement')
        ax.set(title=str(year)+('*' if year>=2024 else ''),xlabel='Mean predicted annual probability (%)',xlim=(0,100),ylim=(0,100));ax.grid(alpha=.2)
    axes[0].set_ylabel('Areas with ≥1 recorded collision (%)');axes[0].legend(fontsize=8)
    fig.suptitle('Annual reliability · fixed probability bins with ≥40 areas\nBars: 95% spatial-block sampling intervals for observed frequencies; not individual-risk intervals',fontsize=12)
    fig.savefig(OUT/'calibration.png',dpi=150);plt.close(fig)

    zero=cohorts.loc[cohorts.group.eq('No mapped collisions in prior window')]
    fig,ax=plt.subplots(figsize=(9,4.8),layout='constrained');pos=np.arange(3);width=.24
    for off,label in [(-width,'Previous 3-year NN'),(0,'Ten-year pooled NN')]:
        g=zero.loc[zero.model.eq(label)].sort_values('year')
        rects=ax.bar(pos+off,g.mean_probability*100,width,color=colors[label],label=short[label]);ax.bar_label(rects,fmt='%.1f%%',padding=3)
    g=zero.loc[zero.model.eq('Ten-year pooled NN')].sort_values('year')
    rects=ax.bar(pos+width,g.observed_fraction*100,width,color='#748278',label='Observed',yerr=np.array([g.observed_fraction-g.observed_low,g.observed_high-g.observed_fraction])*100,capsize=4)
    ax.bar_label(rects,fmt='%.1f%%',padding=3)
    ax.set(xticks=pos,xticklabels=[f'{r.year}{"*" if r.year>=2024 else ""}\n{r.rows:,} areas' for r in g.itertuples()],ylabel='Annual probability / observed frequency (%)',ylim=(0,7),title='Areas with no mapped collisions in their preceding history window')
    ax.legend(fontsize=10);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
    fig.savefig(OUT/'zero_history_calibration.png',dpi=150);plt.close(fig)

    ece=[]
    for (year,label),g in cal.groupby(['year','model']):
        ece.append({'year':year,'model':label,'fixed_bin_absolute_calibration_gap':np.average(abs(g.mean_probability-g.observed_fraction),weights=g.rows)})
    pd.DataFrame(ece).to_csv(OUT/'annual_calibration_bin_error.csv',index=False)
    examples=current.loc[current.junction_id.isin(['J00970','J00699','J02430']),['junction_id','name','previous_probability','annual_probability','mapped_cases_2016_2025','usable_history_cases','known_band_years_min','known_band_years_max']]
    fx=np.load(OUT/'map_features.npz')['x']
    regression=probability(predict_export(models['glm'],fx).reshape(len(current),6).sum(axis=1))
    examples['default_regression_probability']=regression[examples.index]
    ranges=pd.read_csv(OUT/'probability_ranges.csv')
    examples=examples.merge(ranges.loc[ranges.model.eq('nn'),['junction_id','model_range_low','model_range_high']],on='junction_id')
    examples=examples.rename(columns={'previous_probability':'previous_neural_probability',
        'annual_probability':'neural_probability','model_range_low':'neural_range_low',
        'model_range_high':'neural_range_high'})
    examples.to_csv(OUT/'ten_year_examples.csv',index=False)
    zero_now=current.loc[current.recorded_cases_2014_2025.eq(0)&current.coverage_complete]
    nn=ev.loc[ev.model.eq('Ten-year pooled NN')].set_index('year');old=ev.loc[ev.model.eq('Previous 3-year NN')].set_index('year')
    improvements={int(y):100*(1-nn.loc[y,'log_loss']/old.loc[y,'log_loss']) for y in [2023,2024,2025]}
    summary={'annual_nn_log_loss_improvement_percent':improvements,'zero_history_areas':len(zero_now),'zero_history_at_least20pct_old':int(zero_now.previous_probability.ge(.2).sum()),'zero_history_at_least20pct_new':int(zero_now.annual_probability.ge(.2).sum()),'nn_prior_equivalent_years':models['nn']['prior_years'],'nn_calibration':models['nn']['calibration'],'assessment':'Exploratory only: improved prediction error and zero-history calibration, with substantial remaining year/subgroup miscalibration.'}
    summary['default_model']=models['default_model']
    summary['zero_history_at_least20pct_regression']=int((regression[zero_now.index]>=.2).sum())
    (OUT/'ten_year_assessment.json').write_text(json.dumps(summary,indent=2))
    table=ev.loc[ev.model.isin(labels),['year','model','rows','positive_rows','mean_probability','observed_fraction','log_loss','brier']]
    ztable=zero.loc[zero.model.isin(['Previous 3-year NN','Ten-year pooled NN']),['year','model','rows','mean_probability','observed_fraction','observed_low','observed_high']]
    text=['# Ten-year history, regional pooling and calibration','',
      '**Assessment: share with caveats.** The model has actually been retrained and calibrated. Annual neural-network log loss improves against the previous three-year model by '+', '.join(f'{improvements[y]:.1f}% in {y}' for y in [2023,2024,2025])+'. The simpler pooled regression has lower annual error in all three years. Individual intersection percentages remain uncertain, and the v0.26 speed slider uses a separate published-reference scenario.','',
      '**The map defaults to the pooled regression**, selected by its lower 2021 annual log loss (0.24972 versus 0.25169 for the pooled neural network); later diagnostic outcomes did not select this default. The neural model remains available in the model selector. There is an important unresolved tail: the neural model gives more zero-record areas estimates above 20%, concentrated in poorly observed cities. This is another reason not to interpret every model output as an established probability.','',
      '## What changed','',
      'The current 2026 scenario uses **2016–2025**: ten calendar years of local collision history. The entire 2014–2025 source record remains visible on the map. For each earlier target year, history stops at the preceding December and uses at most ten years; early backtests necessarily have less. **Missing or unresolved year/time-band records are not counted as collision-free years.** Only usable band-year counts and their matching observation-years enter the local rate. Road existence over the whole window is not established by the current inventory.','',
      'A regional neural network learns expected counts from road and school attributes and time band, without a local-history input. A city adjustment, shrunk toward the regional fit, represents broad geographic differences. The local estimate is `(usable collision count + k × regional annual count) / (usable years + k)` for each band. The weight comes from model selection, not a hand-picked percentage cap. At zero usable years the regional model supplies the estimate; more observed collision-free years pull it lower without forcing zero risk.','',
      f'The selected neural model uses **k = {models["nn"]["prior_years"]:g} equivalent years** of regional support. With ten usable years, that means equal local/regional weight before calibration. With incomplete history, regional weight is higher. The regression comparison uses k = {models["glm"]["prior_years"]:g}. This is an empirical-Bayes-style count-pooling experiment, not an official exposure-adjusted Highway Safety Manual SPF.','',
      '## Timing and calibration','',
      '- Candidate regional models are fitted on 2017–2020. Architecture, regularization and pooling strength are selected using complete **2021 annual outcomes**.\n- Selected regional models are refitted on 2017–2021. A monotone, two-parameter annual calibrator is fitted only on **2022** outcomes. It rescales the six band hazards together, retaining a coherent annual probability.\n- **2023–2025** are reused temporal diagnostics; no new selection or calibration parameters use those outcomes. They were inspected in earlier project iterations, so this is not an untouched final test. **2024–2025 records are provisional.**\n- The map still runs both full fitted pipelines in the browser. The v0.26 speed control preserves their baseline and applies a separate published-reference rate multiplier. See the speed-response method for its local tests, assumptions and wider sensitivity range.','',
      '## Annual predictive accuracy','',
      'Each row is a 500-foot area with all six usable outcome time bands. Overlapping circles share source cases, so these are not independent crashes. Fractions in the tables are decimals: 0.10 means 10%. Lower log loss/Brier is better, but those scores reflect both calibration and ranking.','',table.to_markdown(index=False,floatfmt='.5f'),'',
      '![Annual error comparison](intersection_prediction_output/held_out_evaluation.png)','',
      'Calibration remains uneven. The new neural model is close to the overall 2023 event rate, underpredicts 2024 and overpredicts 2025. The 2022 calibrator cannot remove later shifts. A history-only pooled baseline is also reported; it beats the network in some years. The network is retained for transparent comparison and road-feature exploration, not declared universally best.','',
      '**Annual evaluation coverage is limited.** Oakland and Berkeley have no complete annual outcomes in these checks under the current city/year/band uncertainty exclusions. Pleasanton, Tracy and Fremont also lack complete 2023–2025 annual outcomes, although they contribute 2022 calibration data. These cities cannot inherit a claim of locally checked annual calibration. Livermore has 2,030 eligible annual outcomes in each year. Eligibility changes the city mix across years; these annual averages are not a like-for-like regional trend. Per-city denominators and observed frequencies are downloadable.','',
      pd.read_csv(OUT/'annual_city_support.csv').pivot(index='city',columns='year',values='complete_area_outcomes').to_markdown(),'',
      '![Annual reliability](intersection_prediction_output/calibration.png)','',
      'Fixed probability bins, denominators and sampling intervals are saved in `annual_reliability.csv`. Bins with fewer than 40 areas are omitted from the chart but retained in the table. Fixed-bin absolute calibration gaps are in `annual_calibration_bin_error.csv`. Error bars are approximate 95% intervals for grouped observed frequencies from resampling 2-km spatial blocks, not confidence intervals for a specific intersection. Cross-block spatial dependence can remain.','',
      '## No prior mapped collisions','',ztable.to_markdown(index=False,floatfmt='.5f'),'',
      '![Zero-history comparison](intersection_prediction_output/zero_history_calibration.png)','',
      'These cohorts are selected using only the preceding history window, including mapped cases with unknown time. They can have missing observation-years. The estimates move closer to observed frequencies in this cohort in all three checks, but 2025 still overpredicts. Zero mapped crashes does not establish complete reporting or absence of all crashes.','',
      f'For current areas with no mapped cases anywhere in the saved 2014–2025 record, {summary["zero_history_at_least20pct_old"]} previously had neural estimates at least 20%; now {summary["zero_history_at_least20pct_new"]} do with the pooled network, and {summary["zero_history_at_least20pct_regression"]} with the default pooled regression. Most high neural estimates are in Oakland/Berkeley, where history is incomplete and annual calibration is untested. Better average error does not resolve this problematic tail. No percentage cap was imposed.','',
      '## Inspectable examples','',
      'Probabilities are fractions (0.10 = 10%). The range columns belong to the updated neural network; the map separately computes ranges for the selected model. The default regression probability is shown in its own column.','',
      examples.to_markdown(index=False,floatfmt='.5f'),'',
      'The mapped count can exceed the usable training-history count when a band/year has unresolved records. The map displays both. The 2015 Garaventa/Vasco case remains visible but falls outside the current ten-year window.','',
      '## Uncertainty and remaining limits','',
      'Map whiskers are the central 90% range from 40 regional-model/city-adjustment/calibrator refits with 2-km spatial block weights. Selected model settings, pooling strength and each location’s observed history are fixed. These ranges measure conditional model stability; they do not have verified 90% coverage of true local risk. Unreported crashes, coordinate errors, historical geometry, missing traffic exposure, model selection and causal speed-effect uncertainty remain outside them.','',
      'The evaluation measures the risk of a **reported pedestrian/bicycle injury or fatal collision in a 500-foot circle over 12 months**, all ages. It does not give per-student, per-crossing, all-collision, school-trip or single-day probabilities. Age 5–18 is a recorded descriptive flag only.','',
      '## Reproduce and inspect','',
      '`School_Intersection_Neural_Network.ipynb` embeds prepared sources, saved models, plots and code. It defaults to saved results. Set `RETRAIN=True` to rerun selection, calibration and 40 bootstrap fits on CPU. Local commands: `python ten_year_model.py`, `python scripts/build_intersection_deliverables.py`, then rebuild/execute the notebook. The prior release is archived in `archives/before_ten_year_v006.zip`.','',
      'Methods: [FHWA explanation of combining modeled and observed crash frequency](https://highways.dot.gov/safety/learn-safety/road-safety-fundamentals-html-version/unit-4-solving-safety-problems); [scikit-learn calibration guidance](https://scikit-learn.org/stable/modules/calibration.html). Data: [TIMS](https://tims.berkeley.edu/tools/query/) and saved city/county road, school and historical-speed sources. Our missing exposure data and overlapping targets differ from an official HSM analysis.','',
      'The earlier historical-speed comparison remains in the pre-update archive. Its accuracy and speed-ablation results describe the old model and must not be attributed to this model. Adopted speed-change records and descriptive before/after counts remain available in the map and downloads.','']
    report='\n'.join(text)
    Path('Ten_Year_Calibration_Results.md').write_text(report)
    Path('Intersection_Prediction_Results.md').write_text(report)
    Path('Annual_Speed_History_Results.md').write_text(report)

if __name__=='__main__':write_report()
