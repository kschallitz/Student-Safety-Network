"""Post-installation SUMO versus frozen Explorer benchmark."""
