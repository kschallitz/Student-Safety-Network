"""Publishable results narrative generated only from completed runs."""
import json
import numpy as np,pandas as pd
from .run import ROOT,OUT

def pct(x,d=3):
 value=100*float(x)
 return '>99.99%' if value>99.99 else f'{value:.{d}f}%'

def main():
 result=json.loads((OUT/'summary.json').read_text());s=pd.read_csv(OUT/'session_summary.csv');m=pd.read_csv(OUT/'explorer_predictions.csv');c=pd.read_csv(OUT/'session_comparison.csv');a=pd.read_csv(OUT/'annual_scenario_comparison.csv');steps=pd.read_csv(OUT/'step_summary.csv');events=pd.read_csv(OUT/'event_audit.csv');verification=json.loads((OUT/'verification.json').read_text())
 primary=c[(c.step_seconds==.5)&(c.feature_year==2026)].copy();table=[]
 for (site,h),g in primary.groupby(['site','start_hour']):
  r=g.iloc[0];nn=g[g.model=='nn'].iloc[0];glm=g[g.model=='glm'].iloc[0]
  table.append({'Intersection':site,'Period':r.window+(' Sat' if h==11 else ''),'SUMO contact runs':f'{r.contact_runs}/{r.complete_runs} complete' + (f' (+{r.incomplete_runs} incomplete)' if r.incomplete_runs else ''),'SUMO contact chance':pct(r.probability_sumo,2),'95% sampling interval':f'{pct(r.mc95_low,2)}–{pct(r.mc95_high,2)}','Explorer NN [90% stability range]':f'{pct(nn.probability_explorer,4)} [{pct(nn.model_stability_low,4)}–{pct(nn.model_stability_high,4)}]','Explorer default [90% stability range]':f'{pct(glm.probability_explorer,4)} [{pct(glm.model_stability_low,4)}–{pct(glm.model_stability_high,4)}]','Gap vs NN (pp)':f'{nn.gap_percentage_points:+.4f}'})
 per_session=pd.DataFrame(table);per_session.to_csv(OUT/'readable_session_comparison.csv',index=False)
 selected=a[(a.step_seconds==.5)&(a.assumed_weekdays==180)&(a.feature_year==2026)];annual=[]
 for site,g in selected.groupby('site'):
  r=g.iloc[0];annual.append({'Intersection':site,'SUMO contacts, covered windows':pct(r.sumo_probability_in_covered_windows,3),'SUMO 95% conditional interval':f'{pct(r.sumo_simultaneous95_low,2)}–{pct(r.sumo_simultaneous95_high,2)}','Explorer NN, same windows':pct(g[g.model=='nn'].explorer_probability_in_same_windows.iloc[0],3),'Explorer default, same windows':pct(g[g.model=='glm'].explorer_probability_in_same_windows.iloc[0],3),'Expected simulated contacts':f'{r.sumo_expected_contacts:.2f}'})
 annual=pd.DataFrame(annual);annual.to_csv(OUT/'readable_annual_comparison.csv',index=False)
 current=m[(m.window=='full_year')&(m.feature_year==2026)].pivot(index='site',columns='display_name',values='probability').map(lambda x:pct(x,2))
 old=m[(m.window=='full_year')&(m.feature_year==2023)].pivot(index='site',columns='display_name',values='probability').map(lambda x:pct(x,2))
 primary_s=s[s.step_seconds==.5];eligible=events[events.reason=='eligible'];eligible_primary=eligible[eligible.step_seconds==.5]
 fine_count=result['fine_contacts'];coarse_paired=int(steps.coarse_contacts.sum());disagreements=int(steps.pairs_with_different_counts.sum())
 nr=primary_s.loc[primary_s.contact_pairs.gt(0)]
 observed=pd.read_csv(ROOT/'data/sumo_v02/junction_demand_15min.csv');post=observed[observed.phase=='post_installation']
 exposure=post.groupby(['site','session_id','mode'])['count'].sum().unstack(fill_value=0).reset_index();exposure.to_csv(OUT/'observed_session_counts.csv',index=False)
 text=f'''# East Avenue: SUMO risk versus Explorer predictions

**The requested numerical comparison is complete: {result['primary_runs']} primary simulations, {result['finer_step_runs']} finer-step checks and {result['integration_control_runs']} additional matched numerical controls, using the post-installation traffic counts at Estates and Hillcrest.** The primary runs produced **{result['primary_contacts']} distinct pedestrian/bicycle contact pairs** in {int(primary_s.contact_runs.sum())} two-hour replays. {result['total_runs']-result['incomplete_runs']} of {result['total_runs']} runs passed all requested traffic; {result['incomplete_runs']} incomplete run remains explicitly flagged. These are estimates of risk **inside this simulator**, not newly measured field collision probabilities.

The main finding is visible below: the nonzero simulated contact probabilities are much larger than the Explorer's allocated injury-crash probabilities. The simulation and Explorer are not numerically close in those periods. Both systems use real source data, but they model different events and neither becomes ground truth for the other.

## 1. Direct two-hour comparison

Each row repeats one measured two-hour traffic pattern **48 times**, with different departures and driver-speed draws. The Explorer columns are the current website's 2026 estimates allocated to the same two hours. Percentages below are not annual probabilities.

{per_session.to_markdown(index=False)}

![Two-hour comparison](two_hour_comparison.png)

**How the Explorer column is calculated:** use the frozen model's six calibrated annual time-band hazards. For a two-hour window, sum `band hazard × hours overlapping that band ÷ band length ÷ 365`; then use `1 − exp(−sum)`. For example, 14–16 receives one hour from the noon–15 band and one from the 15–18 band. This assumes uniform risk within a time band and across days; the model has no school-day exposure variable. No model was retrained to match SUMO.

**What is being compared:** SUMO detects physical pedestrian/bicycle contacts; the Explorer predicts **reported pedestrian/bicycle injury or fatal crashes**. SUMO does not provide a calibrated probability that a simulated contact produces a reportable injury. Thus a numerical gap is a model-comparison finding, not a measured forecast error. The NN and default regression have both been shown rather than substituting one for the other.

**Uncertainty:** completed sessions use exact 95% binomial intervals for random-seed variation under fixed traffic patterns and parameters. Estates morning has one incomplete run: its point estimate uses the 47 completed runs, and its interval also allows the incomplete run to have either outcome. Zero contacts does not establish zero risk; with 48 runs the upper bound is {pct(primary_s[primary_s.contact_runs==0].mc95_high.iloc[0],2) if (primary_s.contact_runs==0).any() else 'reported in the table'}. These intervals do not include uncertainty in traffic counts, geometry, behavior, injury, reporting, or extrapolation. Explorer model-stability ranges are retained in the CSV, with their separate meaning.

## 2. Annual exposure scenario

365 simulations are not 365 days of newly observed data. This experiment has 384 primary runs total: **384 simulated hours per intersection**, generated from **eight observed hours per intersection** on two source dates. The finer-step repetitions are additional checks, not extra independent field exposure.

To answer the annual question explicitly, the scenario repeats each of the three weekday windows on **180 assumed school weekdays**, and the Saturday window on **52 Saturdays**. This represents **1,184 hours**. The remaining **7,576 hours are unmodeled**, not counted as safe. Each system is compared over the same specified windows:

{annual.to_markdown(index=False)}

![Annual scenario](annual_scenario.png)

SUMO uses `1 − product((1 − session contact probability)^number of repetitions)`, assuming independent repetitions of the fixed patterns. The interval propagates four simultaneous binomial / incomplete-run envelopes using a Bonferroni adjustment. A separate Poisson-count projection and 120/180/220-weekday sensitivity are in the CSV. Near-100% values are the mathematical consequence of repeating a simulator with frequent contacts; **they are not a claim that an actual injury collision is virtually certain**.

For reference, the existing website's **full 12-month** predictions are:

{current.to_markdown()}

Those full-year values include all six time bands and should not be directly subtracted from the limited-hours annual scenario above.

## 3. Match the 2023 data year as well

The present website uses 2016–2025 local history to make its 2026 estimate. It would be misleading to call that a prediction made before the May 2023 study. I also evaluated the same frozen model pipeline using **only pre-2023 local history and its 2023 speed features**. Its full-year outputs are:

{old.to_markdown()}

The per-session and annual-scenario CSVs contain both feature years. This is a reused historical diagnostic, not a newly blinded test. The current model pipeline was fitted/selected through 2021 and calibrated in 2022; no simulator result or post-2023 local history enters these 2023 feature rows.

## 4. Check the simulator itself

Among the **96 paired checks**, the 0.5-second version recorded **{coarse_paired} contacts**, and the 0.1-second version recorded **{fine_count} contacts**. **{disagreements} of 96 pairs changed contact counts.** Arrivals, vehicle parameters and the 0.5-second driver action interval are held fixed. However, SUMO automatically enabled ballistic position integration in the finer-step runs, so those original checks change two numerical settings. Their raw totals are retained; incomplete runs are not treated as successful negatives.

{steps[['site','paired_runs','coarse_contacts','fine_contacts','pairs_with_different_counts','probability_difference_fine_minus_coarse']].to_markdown(index=False,floatfmt='.4f')}

![Original numerical sensitivity](step_sensitivity.png)

To resolve that confound, I ran 96 additional 0.5-second simulations with ballistic integration explicitly enabled, using the same first 12 seeds at every session. This gives a matched three-way comparison. It was added because of the logged settings change, not to search for agreement with Explorer:

{pd.read_csv(OUT/'numerical_control_summary.csv').to_markdown(index=False,floatfmt='.4f')}

![Matched numerical controls](numerical_controls.png)

Of the 96 matched ballistic coarse/fine pairs, **{result['ballistic_paired_count_differences']} changed contact counts**. All paired input files match. Numerical method results remain separate; none is selected as the correct answer because it resembles the Explorer.

![Sampling stability](sampling_stability.png)

More random seeds reduce sampling noise. They do not remove sensitivity to the numerical step, fix assumed crossing dimensions, or supply missing behavior measurements. The paired sample is too limited to establish numerical convergence of rare events. No run is discarded because it disagrees with the Explorer.

## 5. The post-change parameters actually represented

- **Observed:** May 18/20, 2023 native 15-minute vehicle movements, heavy-vehicle subsets, bicycles and pedestrian crossings. All eight complete post sessions are included. Counts are inputs, not a validation of predicted demand.
- **Mapped:** road alignments, lane and turning-lane arrangements, crossing positions, stop/traffic-signal controls from the existing OSM-derived network.
- **Fitted and frozen:** February 2023 directional desired-speed distribution; the East Avenue posted limit is 30 mph. The observed pilot was a geometry/visibility project; a 30-to-25 posted-limit change is not invented.
- **Assumed:** untagged lane and sidewalk widths, private school-access representation, pedestrian speeds, yielding/gap behavior, side-street speeds, signal durations, within-quarter departures and the repeated warmup quarter.
- **Not reconstructed exactly:** April 2023 curb-extension and median-refuge dimensions, subsequent June adjustments, and their behavioral effect. The current mapped network is a post-layout approximation, **not an as-built 2023 treatment model**. The report's 22% corridor-average crossing shortening was not imposed at each site.

Contacts are restricted to the Explorer's **500-foot circle**, during the actual two-hour observation window, with at least one study traveler. Repeated warnings about the same pair count once. Warmup, late, outside-area and other excluded events remain in `event_audit.csv`. The simulated population covers measured junction movements, not every possible traveler throughout that circle. Therefore matching the circle does not fully match geographic exposure.

## 6. What this establishes

We now have an explicit, reproducible SUMO contact-risk estimate and a numerical comparison with both Explorer models. **This experiment has not validated the Explorer's collision percentages against real-world truth.** The gap may reflect behavior/geometry assumptions, numerical contacts, the contact-to-injury/reporting difference, missing traffic exposure, or Explorer error. Those explanations cannot be distinguished by making the two models agree through tuning.

The production collision model and speed slider remain unchanged. No intervention ranking or RL policy has been substituted for this comparison.

The requested budget answers whether the simulator routinely generates contacts, but cannot verify extremely small two-hour probabilities from zero events. The download `sampling_requirements.csv` calculates how many zero-contact trials would be needed just to put an exact 95% binomial upper bound below each Explorer estimate. That is a sampling calculation, not a recommendation to spend that compute before resolving endpoint and parameter differences.

## Reproduce and inspect

The Colab-compatible notebook restores the sources, network, frozen outputs and executed results, regenerates the comparison, and runs a fresh simulation. CPU is sufficient. All seeds, run schedules, event details, exclusions, units, comparison formulas and model hashes are included. The full raw run directories remain in the local project.

Verification: {len(pd.read_csv(OUT/'independent_recount.csv'))} raw simulation outputs independently recounted; demand/arrival totals checked; numerical pairs use identical demand; browser and Python model predictions agree to {json.loads((OUT/'browser_inference_check.json').read_text())['maximum_absolute_error']:.2g}; the published prediction model hash is unchanged.

Sources: [Livermore Tactical East Avenue report](https://www.livermoreca.gov/home/showpublisheddocument/12943/638887914440930000), [OpenStreetMap attribution](https://www.openstreetmap.org/copyright), [SUMO safety and collision definitions](https://sumo.dlr.de/docs/Simulation/Safety.html), [SUMO collision output](https://sumo.dlr.de/docs/Simulation/Output/Collisions.html), and the frozen local Explorer model/datasets. The SUMO documentation distinguishes physical-overlap checks from default minimum-gap warnings; this experiment sets the gap factor to zero and enables junction checks.
'''
 (ROOT/'East_Avenue_SUMO_Explorer_Comparison.md').write_text(text);print('Comparison report saved')

if __name__=='__main__':main()
