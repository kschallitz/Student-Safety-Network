"""Independent XML-based recount and probability-boundary checks."""
import json,hashlib,math,xml.etree.ElementTree as E
import numpy as np,pandas as pd,sumolib
from shapely.geometry import LineString
from scipy.stats import binom
from .run import ROOT,OUT,SITES
from .analyze import binomial_interval,any_repeated

def main():
 runs=pd.read_csv(OUT/'all_runs.csv');original=pd.read_csv(OUT/'runs.csv');network=sumolib.net.readNet(str(ROOT/'outputs/sumo_v03/east_joined.net.xml'),withInternal=True,withPedestrianConnections=True);checks=[]
 for r in runs.itertuples():
  center=network.convertLonLat2XY(SITES[r.site]['lon'],SITES[r.site]['lat']);pairs=set();modes=0
  # Independently inspect raw SUMO output, with Shapely interpolation.
  for event in E.parse(ROOT/r.path/'collisions.xml').getroot():
   ids=[event.get('collider'),event.get('victim')];t=float(event.get('time'))
   if not (900<=t<8100 and any(s.startswith('s') for s in ids) and any('_ped_' in s or s.endswith('_bicycle') for s in ids)):continue
   lane=network.getLane(event.get('lane'));point=LineString(lane.getShape()).interpolate(float(event.get('pos')))
   if math.dist((point.x,point.y),center)<=152.4:pairs.add(tuple(sorted(ids)))
  xml=E.parse(ROOT/r.path/'demand.rou.xml').getroot();requested=sum(z.tag in ['vehicle','person'] and z.get('id','').startswith('s') for z in xml)
  trips=E.parse(ROOT/r.path/'trips.xml').getroot();arrived=sum(z.tag in ['tripinfo','personinfo'] and z.get('id','').startswith('s') for z in trips)
  checks.append({'site':r.site,'session_id':r.session_id,'seed':r.seed,'step_seconds':r.step_seconds,'integration_method':r.integration_method,'raw_xml_unique_pairs':len(pairs),'reported_pairs':r.contact_pairs,'recount_passed':len(pairs)==r.contact_pairs,'demand_passed':requested==r.study_requested,'arrival_record_matches':arrived==r.study_arrived,'all_demand_arrived':requested==arrived,'path':r.path})
 pd.DataFrame(checks).to_csv(OUT/'independent_recount.csv',index=False)
 bound=binomial_interval(0,48)[1]
 assert np.isclose(binom.pmf(0,48,bound),.025) and bound>0
 assert np.isclose(any_repeated([.01],[365]),1-.99**365)
 assert any_repeated([0],[365])==0 and any_repeated([1],[1])==1
 schedule=pd.read_csv(OUT/'run_schedule.csv');same_schedule=set(map(tuple,schedule.to_numpy()))==set(map(tuple,original[['session_id','seed','step_seconds']].to_numpy()))
 fine=original[original.step_seconds.eq(.1)].merge(original[original.step_seconds.eq(.5)],on=['site','session_id','seed'],suffixes=('_fine','_coarse'))
 live=hashlib.sha256((ROOT/'intersection_prediction_output/model.json').read_bytes()).hexdigest();frozen=json.loads((OUT/'model_freeze.json').read_text())['sha256']
 result={'all_576_runs_recounted':len(checks)==576,'raw_contact_recounts_match':all(r['recount_passed'] for r in checks),'demand_totals_match':all(r['demand_passed'] for r in checks),'arrival_records_match':all(r['arrival_record_matches'] for r in checks),'incomplete_demand_runs_retained':sum(not r['all_demand_arrived'] for r in checks),'exact_original_schedule_completed':same_schedule,'numerical_pairs_use_identical_demand':bool(fine.demand_sha256_fine.eq(fine.demand_sha256_coarse).all()),'numerical_pairs':len(fine),'zero_event_upper_bound_not_zero':float(bound),'annual_probability_formula_checked':True,'production_model_unchanged':live==frozen,'browser_inference_matches':json.loads((OUT/'browser_inference_check.json').read_text())['passed'],'field_validation_claimed':False}
 (OUT/'verification.json').write_text(json.dumps(result,indent=2));assert all(v for k,v in result.items() if isinstance(v,bool) and k!='field_validation_claimed');print(json.dumps(result,indent=2))

if __name__=='__main__':main()
