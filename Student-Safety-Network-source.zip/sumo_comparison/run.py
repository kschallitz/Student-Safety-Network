"""Bounded replicated post-layout comparison, with physical-contact event audit."""
import argparse,hashlib,json,math,os,time,xml.etree.ElementTree as E
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np,pandas as pd,sumolib
from sumo_v03.replay import context,make_demand

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/sumo_comparison'
SITES={'Estates':{'junction_id':'J01145','lon':-121.75174663230632,'lat':37.67994037412872},'Hillcrest':{'junction_id':'J02019','lon':-121.74842599458633,'lat':37.6799252082945}}
SEEDS=[610001+1009*i for i in range(48)]
STEP=0.5
RADIUS=152.4

def write_xml(root,path):
 E.indent(root);E.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)

def execute(task):
 import libsumo as sim
 sid,seed,step=task
 observed=pd.read_csv(ROOT/'data/sumo_v02/junction_demand_15min.csv')
 rows=observed[observed.session_id.eq(sid)].copy();site=rows.iloc[0].site
 assert rows.phase.eq('post_installation').all() and rows.interval_start.nunique()==8
 net=ROOT/'outputs/sumo_v03/east_joined.net.xml';signal=ROOT/'data/sumo_v03/fixed_signal.add.xml'
 inputs=[net,signal,ROOT/'outputs/sumo_v02/calibration.json',ROOT/'data/sumo_v02/junction_demand_15min.csv',ROOT/'sumo_v03/replay.py',Path(__file__)]
 digest=hashlib.sha256(b''.join(p.read_bytes() for p in inputs)).hexdigest()
 key=hashlib.sha256(json.dumps([digest,sid,seed,step,'contact-comparison-v1']).encode()).hexdigest()[:20]
 p=OUT/'runs'/key;p.mkdir(parents=True,exist_ok=True)
 if (p/'result.json').exists():return json.loads((p/'result.json').read_text())
 n,ports=context();study,total=make_demand(rows,seed,p,n,ports)
 route=E.parse(p/'demand.rou.xml')
 for v in route.getroot().findall('vType'):
  if v.get('vClass')!='pedestrian':v.set('actionStepLength','0.5')
 write_xml(route.getroot(),p/'demand.rou.xml')
 cfg=E.Element('configuration');inp=E.SubElement(cfg,'input')
 for k,v in [('net-file',os.path.relpath(net,p)),('route-files','demand.rou.xml'),('additional-files',os.path.relpath(signal,p))]:E.SubElement(inp,k,value=v)
 tm=E.SubElement(cfg,'time');E.SubElement(tm,'step-length',value=str(step));E.SubElement(tm,'end',value='9900')
 rand=E.SubElement(cfg,'random_number');E.SubElement(rand,'seed',value=str(seed))
 proc=E.SubElement(cfg,'processing')
 for k,v in [('pedestrian.striping.jamtime','-1'),('pedestrian.striping.jamtime.crossing','-1'),('time-to-teleport','-1'),('collision.action','warn'),('intermodal-collision.action','warn'),('collision.check-junctions','true'),('collision.mingap-factor','0')]:E.SubElement(proc,k,value=v)
 output=E.SubElement(cfg,'output')
 for k,v in [('collision-output','collisions.xml'),('tripinfo-output','trips.xml')]:E.SubElement(output,k,value=v)
 write_xml(cfg,p/'run.sumocfg');tick=time.monotonic()
 sim.start([sumolib.checkBinary('sumo'),'-c',str(p/'run.sumocfg'),'--no-step-log','true','--duration-log.disable','true','--no-warnings','true','--error-log',str(p/'warnings.log')])
 try:sim.simulationStep(9900);pending=sim.simulation.getMinExpectedNumber()
 finally:sim.close()
 center=n.convertLonLat2XY(SITES[site]['lon'],SITES[site]['lat']);audit=[];seen=set();eligible=[]
 for z in E.parse(p/'collisions.xml').getroot():
  a=dict(z.attrib);ids=[a.get('collider',''),a.get('victim','')];vru=any('_ped_' in s or s.endswith('_bicycle') for s in ids)
  xy=sumolib.geomhelper.positionAtShapeOffset(n.getLane(a['lane']).getShape(),float(a['pos']))
  distance=math.dist(xy,center);event_time=float(a['time']);pair=tuple(sorted(ids))
  reason='eligible'
  if not vru:reason='no_pedestrian_or_bicycle'
  elif event_time<900:reason='warmup'
  elif event_time>=8100:reason='after_two_hour_window'
  elif not any(s.startswith('s') for s in ids):reason='warmup_participants_only'
  elif distance>RADIUS:reason='outside_500_feet'
  elif pair in seen:reason='repeat_same_pair'
  if reason=='eligible':seen.add(pair)
  a.update(reason=reason,distance_m=distance,x=xy[0],y=xy[1],motor_vru=any(s.endswith(('_passenger','_heavy')) for s in ids) and vru)
  audit.append(a)
  if reason=='eligible':eligible.append(a)
 (p/'event_audit.json').write_text(json.dumps(audit,indent=2))
 trips=E.parse(p/'trips.xml').getroot();arrived={z.get('id') for z in trips if z.tag in ['tripinfo','personinfo']}
 requested=[z for z in route.getroot() if z.tag in ['vehicle','person'] and z.get('id').startswith('s')]
 motors=[z for z in trips if z.tag=='tripinfo' and z.get('id','').startswith('s') and z.get('vType') in ['passenger','heavy']]
 entered=sum(float(z.get('depart'))<8100 for z in trips if z.tag=='tripinfo' and z.get('id','').startswith('s'))+sum(float(z.get('depart'))<8100 for z in requested if z.tag=='person')
 result={'site':site,'junction_id':SITES[site]['junction_id'],'session_id':sid,'date':rows.iloc[0].date,'start_hour':int(rows.interval_start.min()[11:13]),'seed':seed,'step_seconds':step,'action_step_seconds':.5,'simulation_version':sim.getVersion()[1],'observed_hours':2,'study_requested':study,'study_arrived':sum(s.startswith('s') for s in arrived),'study_entered_by_window_end':entered,'pending':pending,'vru_users_requested':int(rows[rows['mode'].isin(['pedestrian','bicycle'])]['count'].sum()),'contact_pairs':len(eligible),'any_contact':int(bool(eligible)),'motor_vru_pairs':sum(a['motor_vru'] for a in eligible),'raw_warning_rows':len(audit),'warmup_or_tail_vru_warnings':sum(a['reason'] in ['warmup','after_two_hour_window'] for a in audit),'mean_motor_duration_s':float(np.mean([float(z.get('duration')) for z in motors])),'wall_seconds':time.monotonic()-tick,'input_digest':digest,'demand_sha256':hashlib.sha256((p/'demand.rou.xml').read_bytes()).hexdigest(),'path':str(p.relative_to(ROOT))}
 (p/'result.json').write_text(json.dumps(result,indent=2));return result

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');ap.add_argument('--workers',type=int,default=2);args=ap.parse_args();OUT.mkdir(exist_ok=True,parents=True)
 observed=pd.read_csv(ROOT/'data/sumo_v02/junction_demand_15min.csv');sessions=sorted(observed[observed.phase.eq('post_installation')].session_id.unique())
 tasks=[(sid,seed,.5) for seed in SEEDS for sid in sessions]+[(sid,seed,.1) for seed in SEEDS[:12] for sid in sessions]
 if args.pilot:tasks=[(sid,SEEDS[0],step) for sid in sessions if '14:00' in sid for step in [.5,.1]]
 pd.DataFrame(tasks,columns=['session_id','seed','step_seconds']).to_csv(OUT/('pilot_schedule.csv' if args.pilot else 'run_schedule.csv'),index=False)
 results=[];failures=[];started=time.monotonic()
 with ProcessPoolExecutor(max_workers=args.workers) as pool:
  jobs={pool.submit(execute,task):task for task in tasks}
  for job in as_completed(jobs):
   try:results.append(job.result())
   except Exception as ex:failures.append({'task':jobs[job],'error':repr(ex)})
   if len(results)%8==0 or len(results)+len(failures)==len(tasks):
    pd.DataFrame(results).to_csv(OUT/('pilot_runs.csv' if args.pilot else 'runs.csv'),index=False)
    print(json.dumps({'done':len(results),'total':len(tasks),'failures':len(failures),'contacts':sum(r['contact_pairs'] for r in results),'elapsed_s':round(time.monotonic()-started)}),flush=True)
 (OUT/('pilot_failures.json' if args.pilot else 'failures.json')).write_text(json.dumps(failures,indent=2))
 if failures:raise RuntimeError(f'{len(failures)} runs failed; results retained')

if __name__=='__main__':main()
