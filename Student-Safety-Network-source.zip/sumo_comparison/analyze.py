"""Denominator-matched numerical comparison; no simulator-as-truth calibration."""
import json,os,math
from pathlib import Path
import numpy as np,pandas as pd
from scipy.stats import beta,chi2
from .run import ROOT,OUT,SEEDS
from .models import hour_weights

def binomial_interval(k,n,alpha=.05):
 return (0. if k==0 else float(beta.ppf(alpha/2,k,n-k+1)),1. if k==n else float(beta.ppf(1-alpha/2,k+1,n-k)))

def poisson_interval(k,exposure,alpha=.05):
 return (0. if k==0 else float(chi2.ppf(alpha/2,2*k)/(2*exposure)),float(chi2.ppf(1-alpha/2,2*(k+1))/(2*exposure)))

def any_repeated(q,reps):
 q=np.asarray(q);reps=np.asarray(reps)
 if np.any((q>=1)&(reps>0)):return 1.
 return float(-np.expm1(np.dot(reps,np.log1p(-q))))

def summarize(runs):
 rows=[]
 for (site,h,step),g in runs.groupby(['site','start_hour','step_seconds']):
  n=len(g);valid=g[g.pending.eq(0)&g.study_arrived.eq(g.study_requested)];nv=len(valid);failed=n-nv;k=int(valid.any_contact.sum());events=int(valid.contact_pairs.sum())
  # Incomplete demand is unknown for the observed-volume experiment, not a safe negative.
  lo=binomial_interval(k,n)[0];hi=binomial_interval(k+failed,n)[1];rl,rh=poisson_interval(events,2*nv)
  rows.append({'site':site,'start_hour':h,'window':f'{h:02}:00–{h+2:02}:00','step_seconds':step,'runs':n,'complete_runs':nv,'incomplete_runs':failed,'simulated_hours':2*n,'completed_run_hours':2*nv,'contact_runs':k,'contact_pairs':events,'observed_contacts_all_runs':int(g.contact_pairs.sum()),'probability':k/nv,'failure_bracket_low':k/n,'failure_bracket_high':(k+failed)/n,'mc95_low':lo,'mc95_high':hi,'contacts_per_hour':events/(2*nv),'poisson95_rate_low':rl,'poisson95_rate_high':rh,'entered_users':int(valid.study_entered_by_window_end.sum()),'contacts_per_10000_users':10000*events/valid.study_entered_by_window_end.sum(),'pending_runs':int(g.pending.gt(0).sum())})
 return pd.DataFrame(rows).sort_values(['step_seconds','site','start_hour'])

def export_comparisons(s,models):
 comparison=s.merge(models[models.window.ne('full_year')].drop(columns='window'),on=['site','start_hour'],how='left',suffixes=('_sumo','_explorer'))
 comparison['gap_percentage_points']=100*(comparison.probability_sumo-comparison.probability_explorer)
 comparison['probability_ratio']=comparison.probability_sumo/comparison.probability_explorer
 comparison['endpoint_note']='SUMO contact versus reported injury/fatal crash; numerical benchmark, not field validation'
 comparison.to_csv(OUT/'session_comparison.csv',index=False)
 annual=[]
 for (site,step),g in s.groupby(['site','step_seconds']):
  g=g.sort_values('start_hour');q=g.probability.to_numpy();bounds=np.array([(binomial_interval(int(r.contact_runs),int(r.runs),alpha=.05/4)[0],binomial_interval(int(r.contact_runs+r.incomplete_runs),int(r.runs),alpha=.05/4)[1]) for r in g.itertuples()])
  for weekdays in [120,180,220]:
   reps=np.array([52 if h==11 else weekdays for h in g.start_hour]);hours=int(2*reps.sum());ps=any_repeated(q,reps);low=any_repeated(bounds[:,0],reps);high=any_repeated(bounds[:,1],reps);mean=float(np.dot(reps,g.contact_pairs/g.complete_runs))
   for year in [2023,2026]:
    for kind in ['nn','glm']:
     m=models[(models.site==site)&(models.feature_year==year)&(models.model==kind)&(models.window!='full_year')].set_index('start_hour').loc[g.start_hour]
     explorer_count=float(np.dot(reps,m.expected_count));pe=float(-np.expm1(-explorer_count))
     full=models[(models.site==site)&(models.feature_year==year)&(models.model==kind)&(models.window=='full_year')].iloc[0]
     annual.append({'site':site,'step_seconds':step,'assumed_weekdays':weekdays,'assumed_saturdays':52,'covered_hours':hours,'unmodeled_hours':8760-hours,'feature_year':year,'model':kind,'sumo_probability_in_covered_windows':ps,'sumo_simultaneous95_low':low,'sumo_simultaneous95_high':high,'sumo_expected_contacts':mean,'sumo_poisson_probability':float(-np.expm1(-mean)),'explorer_probability_in_same_windows':pe,'explorer_expected_reported_injury_crashes_in_windows':explorer_count,'explorer_full_year_probability':full.probability,'gap_percentage_points':100*(ps-pe),'expected_event_ratio':mean/explorer_count,'endpoint_note':'Physical contact versus reported injury/fatal crash; independent identical day-pattern assumptions; outside hours unmodeled'})
 a=pd.DataFrame(annual);a.to_csv(OUT/'annual_scenario_comparison.csv',index=False)
 return comparison,a

def event_tables(runs):
 rows=[]
 for r in runs.itertuples():
  for z in json.loads((ROOT/r.path/'event_audit.json').read_text()):rows.append({'site':r.site,'session_id':r.session_id,'seed':r.seed,'step_seconds':r.step_seconds,'integration_method':getattr(r,'integration_method','Euler' if r.step_seconds==.5 else 'ballistic'),'run_path':r.path,**z})
 events=pd.DataFrame(rows);events.to_csv(OUT/'event_audit.csv',index=False)
 if len(events):
  grouped=events.groupby(['step_seconds','integration_method','site','reason','type','lane']).size().rename('warning_rows').reset_index();grouped.to_csv(OUT/'event_locations.csv',index=False)
 return events

def step_audit(runs):
 a=runs[runs.step_seconds.eq(.5)];b=runs[runs.step_seconds.eq(.1)]
 pair=a.merge(b,on=['session_id','seed','site'],suffixes=('_coarse','_fine'));pair['same_demand']=pair.demand_sha256_coarse.eq(pair.demand_sha256_fine);pair['contact_count_difference']=pair.contact_pairs_fine-pair.contact_pairs_coarse
 pair.to_csv(OUT/'paired_step_checks.csv',index=False)
 rows=[]
 for site,g in pair.groupby('site'):
  valid=g[g.pending_fine.eq(0)&g.pending_coarse.eq(0)&g.study_requested_fine.eq(g.study_arrived_fine)&g.study_requested_coarse.eq(g.study_arrived_coarse)];n=len(valid);delta=valid.any_contact_fine.to_numpy()-valid.any_contact_coarse.to_numpy();rng=np.random.default_rng(7729);boot=np.mean(rng.choice(delta,(10000,n),replace=True),axis=1);lo,hi=np.quantile(boot,[.025,.975])
  rows.append({'site':site,'paired_runs':n,'coarse_contact_runs':int(g.any_contact_coarse.sum()),'fine_contact_runs':int(g.any_contact_fine.sum()),'coarse_contacts':int(g.contact_pairs_coarse.sum()),'fine_contacts':int(g.contact_pairs_fine.sum()),'probability_difference_fine_minus_coarse':float(delta.mean()),'paired_bootstrap95_low':lo,'paired_bootstrap95_high':hi,'pairs_with_different_counts':int(g.contact_count_difference.ne(0).sum()),'identical_demand':bool(g.same_demand.all()),'note':'Within-seed arrivals and vehicle parameters identical; time discretization also changes stochastic evolution. Limited numerical sensitivity sample, not proof of convergence.'})
 pd.DataFrame(rows).to_csv(OUT/'step_summary.csv',index=False)
 return pair

def plots(s,models,annual,runs):
 os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.mplconfig'))
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white'})
 primary=s[s.step_seconds.eq(.5)].sort_values(['site','start_hour']);y=np.arange(len(primary));fig,ax=plt.subplots(figsize=(11,6.5))
 ax.errorbar(primary.probability*100,y,xerr=np.array([primary.probability-primary.mc95_low,primary.mc95_high-primary.probability])*100,fmt='o',color='#176e89',capsize=4,label='SUMO contact · 95% sampling / incomplete-run envelope')
 for kind,mark,color in [('nn','s','#af651d'),('glm','^','#4f6570')]:
  m=models[(models.model==kind)&(models.feature_year==2026)&(models.window!='full_year')].set_index(['site','start_hour']);v=[m.loc[(r.site,r.start_hour),'probability']*100 for r in primary.itertuples()]
  ax.scatter(v,y+(.13 if kind=='nn' else -.13),marker=mark,color=color,label=('Explorer neural' if kind=='nn' else 'Explorer regression')+' · allocated injury-crash probability')
 ax.set(yticks=y,yticklabels=[f'{r.site} · {r.window}'+(' Saturday' if r.start_hour==11 else '') for r in primary.itertuples()],xlabel='Probability of ≥1 event in a two-hour period (%)',title='Same two-hour windows, different event definitions',xlim=(-.5,max(primary.mc95_high)*110));ax.invert_yaxis();ax.grid(axis='x',alpha=.2);ax.legend(loc='lower right',fontsize=9)
 fig.text(.02,.018,'48 scheduled seeds per session; one incomplete run is retained. SUMO contacts versus reported injury/fatal crashes.\nExplorer allocation assumes uniform risk within each time band over 365 days; this is not observed exposure.',fontsize=10);fig.tight_layout(rect=(0,.09,1,1));fig.savefig(OUT/'two_hour_comparison.png',dpi=160);plt.close(fig)
 fig,axes=plt.subplots(1,2,figsize=(12,5),sharey=True)
 for ax,site in zip(axes,['Estates','Hillcrest']):
  for step,color,mark,label in [(.5,'#176e89','o','0.5 s · 48 seeds'),(.1,'#b06b2b','s','0.1 s · 12 seeds')]:
   g=s[(s.site==site)&(s.step_seconds==step)].sort_values('start_hour');x=np.arange(len(g))+(-.06 if step==.5 else .06)
   ax.errorbar(x,g.probability*100,yerr=np.array([g.probability-g.mc95_low,g.mc95_high-g.probability])*100,fmt=mark,color=color,capsize=3,label=label)
  ax.set(xticks=np.arange(4),xticklabels=['07–09','11–13\nSaturday','14–16','16–18'],title=site,xlabel='Observed two-hour period');ax.grid(axis='y',alpha=.2);ax.legend(fontsize=9)
 axes[0].set_ylabel('SUMO probability of ≥1 contact (%)');fig.suptitle('Original numerical checks · fixed driver action interval');fig.text(.5,.015,'Sampling / incomplete-run intervals; original checks also change position integration. Not field-risk intervals.',ha='center',fontsize=10);fig.tight_layout(rect=(0,.055,1,.94));fig.savefig(OUT/'step_sensitivity.png',dpi=160);plt.close(fig)
 fig,axes=plt.subplots(1,2,figsize=(11,5),sharey=True)
 for ax,site in zip(axes,['Estates','Hillcrest']):
  base=annual[(annual.site==site)&(annual.step_seconds==.5)&(annual.assumed_weekdays==180)&(annual.feature_year==2026)]
  t=base.iloc[0];vals=[t.sumo_probability_in_covered_windows,float(base[base.model=='nn'].explorer_probability_in_same_windows.iloc[0]),float(base[base.model=='glm'].explorer_probability_in_same_windows.iloc[0])]
  bars=ax.bar([0,1,2],np.array(vals)*100,color=['#176e89','#b06b2b','#617783']);ax.bar_label(bars,labels=[f'{v*100:.2f}%' for v in vals],padding=4);ax.errorbar([0],[vals[0]*100],yerr=[[100*(vals[0]-t.sumo_simultaneous95_low)],[100*(t.sumo_simultaneous95_high-vals[0])]],fmt='none',ecolor='#173247',capsize=5)
  ax.set(xticks=[0,1,2],xticklabels=['SUMO\ncontacts','Explorer NN\ninjury crashes','Explorer default\ninjury crashes'],title=site,ylim=(0,113));ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
 axes[0].set_ylabel('Chance of ≥1 event across the specified windows (%)');fig.suptitle('Annual scenario · 1,184 covered hours, remaining hours unmodeled');fig.text(.5,.015,'180 assumed weekdays × three two-hour windows + 52 Saturdays × one window.\nSUMO interval conditions on fixed parameters; different endpoints prevent a field-accuracy interpretation.',ha='center',fontsize=10);fig.tight_layout(rect=(0,.09,1,.94));fig.savefig(OUT/'annual_scenario.png',dpi=160);plt.close(fig)
 # Convergence is computational sampling only, with deterministic prefix order.
 fig,axes=plt.subplots(1,2,figsize=(11,4.5),sharey=True)
 for ax,site in zip(axes,['Estates','Hillcrest']):
  for hour,color,label in [(7,'#546773','07–09'),(11,'#946044','Saturday 11–13'),(14,'#176e89','14–16'),(16,'#a98322','16–18')]:
   g=runs[(runs.site==site)&(runs.start_hour==hour)&(runs.step_seconds==.5)].sort_values('seed');valid=g.pending.eq(0)&g.study_requested.eq(g.study_arrived);y=(g.any_contact*valid).to_numpy().cumsum()/valid.to_numpy().cumsum();ax.plot(np.arange(1,len(g)+1),y*100,color=color,label=label)
  ax.set(title=site,xlabel='Independent seeds per traffic pattern',xlim=(1,48));ax.grid(alpha=.2);ax.legend(fontsize=9)
 axes[0].set_ylabel('Cumulative simulations with ≥1 contact (%)');fig.suptitle('Sampling stability as repetitions accumulate');fig.tight_layout(rect=(0,0,1,.94));fig.savefig(OUT/'sampling_stability.png',dpi=160);plt.close(fig)

def main():
 runs=pd.read_csv(OUT/'runs.csv');assert len(runs)==480 and not runs[['session_id','seed','step_seconds']].duplicated().any()
 # Incomplete simulations remain in the audit and uncertainty envelope.
 s=summarize(runs);s.to_csv(OUT/'session_summary.csv',index=False);models=pd.read_csv(OUT/'explorer_predictions.csv');cmp,a=export_comparisons(s,models);events=event_tables(runs);pair=step_audit(runs);plots(s,models,a,runs)
 requirements=models[(models.window!='full_year')&(models.feature_year==2026)][['site','window','model','probability']].copy()
 requirements['zero_event_runs_needed_for_95_upper_below_model']=np.ceil(np.log(.025)/np.log1p(-requirements.probability)).astype(int)
 requirements.to_csv(OUT/'sampling_requirements.csv',index=False)
 summary={'total_runs':len(runs),'primary_runs':int(runs.step_seconds.eq(.5).sum()),'finer_step_runs':int(runs.step_seconds.eq(.1).sum()),'primary_simulated_hours_per_site':384,'observed_source_days':2,'post_sessions':8,'no_pending_runs':bool(runs.pending.eq(0).all()),'incomplete_runs':int((runs.pending.gt(0)|runs.study_arrived.ne(runs.study_requested)).sum()),'same_demand_in_paired_checks':bool(pair.same_demand.all()),'primary_contacts':int(runs.loc[runs.step_seconds.eq(.5),'contact_pairs'].sum()),'fine_contacts':int(runs.loc[runs.step_seconds.eq(.1),'contact_pairs'].sum()),'endpoints_identical':False,'geometry':'Current mapped approximation of post-installation layout; no exact 2023 as-built dimensions','coverage':'Two junctions; measured movements and 8 observed two-hour sessions; not a full-year continuous field dataset','model_retrained':False,'rl_trained':False,'simulation_risk_estimated':True,'comparison_completed':True,'field_risk_calibrated':False}
 (OUT/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
