"""Resolve the Euler/ballistic confound without selecting a favorable result."""
import json,os
import numpy as np,pandas as pd
from .run import ROOT,OUT,SEEDS
from .analyze import summarize,event_tables

def main():
 r=pd.read_csv(OUT/'runs.csv');b=pd.read_csv(OUT/'integration_runs.csv');assert len(b)==96
 e=r[r.step_seconds.eq(.5)&r.seed.isin(SEEDS[:12])].copy();f=r[r.step_seconds.eq(.1)].copy()
 groups=[('0.5 s Euler',e),('0.5 s ballistic',b),('0.1 s ballistic',f)];summaries=[];session=[]
 for label,g in groups:
  for site,v in g.groupby('site'):
   valid=v.pending.eq(0)&v.study_arrived.eq(v.study_requested)
   summaries.append({'method':label,'site':site,'runs':len(v),'complete_runs':int(valid.sum()),'contact_pairs':int(v.contact_pairs.sum()),'contact_runs':int(v.loc[valid,'any_contact'].sum()),'contact_probability_complete_runs':float(v.loc[valid,'any_contact'].mean())})
  s=summarize(g);s['numerical_method']=label;session.append(s)
 summary=pd.DataFrame(summaries);summary.to_csv(OUT/'numerical_control_summary.csv',index=False);sessions=pd.concat(session);sessions.to_csv(OUT/'numerical_session_summary.csv',index=False)
 pair=b.merge(f,on=['site','session_id','seed'],suffixes=('_coarse','_fine'));pair['same_demand']=pair.demand_sha256_coarse.eq(pair.demand_sha256_fine);pair['changed_contact_count']=pair.contact_pairs_coarse.ne(pair.contact_pairs_fine);pair['both_complete']=pair.pending_coarse.eq(0)&pair.pending_fine.eq(0)&pair.study_requested_coarse.eq(pair.study_arrived_coarse)&pair.study_requested_fine.eq(pair.study_arrived_fine);pair.to_csv(OUT/'matched_ballistic_step_checks.csv',index=False)
 r['integration_method']=np.where(r.step_seconds.eq(.5),'Euler','ballistic');all_runs=pd.concat([r,b],ignore_index=True);all_runs.to_csv(OUT/'all_runs.csv',index=False);event_tables(all_runs)
 state=json.loads((OUT/'summary.json').read_text());state.update(total_runs=len(all_runs),integration_control_runs=len(b),integration_control_contacts=int(b.contact_pairs.sum()),incomplete_runs=int((all_runs.pending.gt(0)|all_runs.study_arrived.ne(all_runs.study_requested)).sum()),no_pending_runs=bool(all_runs.pending.eq(0).all()),ballistic_paired_count_differences=int(pair.changed_contact_count.sum()),ballistic_paired_same_demand=bool(pair.same_demand.all()),numerical_control_note='Original coarse Euler versus fine ballistic had two settings changed automatically. Added 96 matched coarse ballistic controls. All methods retained.')
 (OUT/'summary.json').write_text(json.dumps(state,indent=2))
 os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.mplconfig'))
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,axes=plt.subplots(1,2,figsize=(12,5.2),sharey=True)
 for ax,site in zip(axes,['Estates','Hillcrest']):
  for off,label,color,marker in [(-.15,'0.5 s Euler','#586b76','o'),(0,'0.5 s ballistic','#176e89','s'),(.15,'0.1 s ballistic','#b47431','^')]:
   q=sessions[(sessions.site==site)&(sessions.numerical_method==label)].sort_values('start_hour');x=np.arange(len(q))+off
   ax.errorbar(x,q.probability*100,yerr=np.array([q.probability-q.mc95_low,q.mc95_high-q.probability])*100,fmt=marker,capsize=3,color=color,label=label)
  ax.set(title=site,xticks=np.arange(4),xticklabels=['07–09','11–13\nSaturday','14–16','16–18'],xlabel='Observed traffic pattern');ax.grid(axis='y',alpha=.2);ax.legend(fontsize=9)
 axes[0].set_ylabel('Chance of ≥1 contact in two hours (%)');fig.suptitle('Matched numerical controls · 12 identical input seeds per pattern');fig.text(.5,.018,'95% sampling / incomplete-run envelope. Constant 0.5-second vehicle action interval.\nChanging numerical updates can change stochastic evolution; these are not intervals for field risk.',ha='center',fontsize=10);fig.tight_layout(rect=(0,.09,1,.94));fig.savefig(OUT/'numerical_controls.png',dpi=160);plt.close(fig)
 print(summary.to_string(index=False));print(json.dumps(state,indent=2))

if __name__=='__main__':main()
