"""Freeze model outputs at the exact two sites, without fitting to SUMO."""
import json,hashlib
from pathlib import Path
import numpy as np,pandas as pd
from .run import ROOT,OUT,SITES

BAND_EDGES=np.array([0,6,9,12,15,18,24])

def hour_weights(start,end):
 return np.maximum(0,np.minimum(end,BAND_EDGES[1:])-np.maximum(start,BAND_EDGES[:-1]))/np.diff(BAND_EDGES)/365

def main():
 from intersection_prediction import load_prepared,predict_export
 from ten_year_model import feature_year
 OUT.mkdir(parents=True,exist_ok=True);bundle=json.loads((ROOT/'intersection_prediction_output/model.json').read_text());bootstrap=json.loads((ROOT/'intersection_prediction_output/bootstrap_models.json').read_text())
 j,c,u=load_prepared();index={s:int(np.flatnonzero(j.junction_id.eq(v['junction_id']))[0]) for s,v in SITES.items()};ids=list(index.values());sites=list(index)
 current=np.load(ROOT/'intersection_prediction_output/map_features.npz')['x'].reshape(len(j),6,-1)[ids].reshape(12,-1)
 original_year=feature_year(j,c,u,2023,bundle['cities']).reshape(len(j),6,-1)[ids].reshape(12,-1)
 rows=[];inputs=[]
 for year,x in [(2023,original_year),(2026,current)]:
  for site_i,site in enumerate(sites):
   local=x[site_i*6:(site_i+1)*6]
   for kind in ['nn','glm']:
    mu=predict_export(bundle[kind],local);bs=np.array([predict_export(m,local) for m in bootstrap[kind]])
    for start in [None,7,11,14,16]:
     weights=np.ones(6) if start is None else hour_weights(start,start+2)
     rate=float(mu@weights);p=float(-np.expm1(-rate));lo,hi=np.quantile(-np.expm1(-(bs@weights)),[.05,.95])
     rows.append({'site':site,'junction_id':SITES[site]['junction_id'],'feature_year':year,'model':kind,'display_name':'Neural network' if kind=='nn' else 'Default regression','window':'full_year' if start is None else f'{start:02}:00–{start+2:02}:00','start_hour':start,'expected_count':rate,'probability':p,'model_stability_low':lo,'model_stability_high':hi,'band_rates':json.dumps(mu.tolist()),'allocation_assumption':'none' if start is None else 'Uniform within each time band and over 365 calendar days; no weekday or seasonality feature'})
    inputs.append({'site':site,'feature_year':year,'model':kind,'rows':local.tolist(),'expected_rates':mu.tolist(),'expected_annual':float(-np.expm1(-mu.sum()))})
 pd.DataFrame(rows).to_csv(OUT/'explorer_predictions.csv',index=False)
 (OUT/'inference_check_inputs.json').write_text(json.dumps(inputs))
 (OUT/'frozen_models.json').write_text(json.dumps({'bundle':bundle,'bootstrap':bootstrap,'rows':inputs}))
 (OUT/'model_freeze.json').write_text(json.dumps({'sha256':hashlib.sha256((ROOT/'intersection_prediction_output/model.json').read_bytes()).hexdigest(),'no_retraining':True,'current_feature_year':2026,'retrospective_feature_year':2023,'default_model':bundle['default_model'],'endpoint':bundle['protocol']['target']},indent=2))
 print(pd.DataFrame(rows).query("window == 'full_year'")[['site','feature_year','display_name','probability']].to_string(index=False))

if __name__=='__main__':main()
