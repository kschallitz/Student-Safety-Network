"""Additional prespecified 12-seed control for SUMO's automatic ballistic switch."""
import hashlib,json,math,shutil,time,xml.etree.ElementTree as E
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np,pandas as pd,sumolib
from .run import ROOT,OUT,SITES,SEEDS

def execute_control(row):
 import libsumo as sim
 source=ROOT/row['path'];key=hashlib.sha256((row['path']+'ballistic-control-v1').encode()).hexdigest()[:20];p=OUT/'integration_runs'/key;p.mkdir(exist_ok=True,parents=True)
 if (p/'result.json').exists():return json.loads((p/'result.json').read_text())
 shutil.copyfile(source/'demand.rou.xml',p/'demand.rou.xml');shutil.copyfile(source/'route_audit.csv',p/'route_audit.csv')
 cfg=E.parse(source/'run.sumocfg');E.SubElement(cfg.getroot().find('processing'),'step-method.ballistic',value='true');E.indent(cfg);cfg.write(p/'run.sumocfg',encoding='utf-8',xml_declaration=True)
 n=sumolib.net.readNet(str(ROOT/'outputs/sumo_v03/east_joined.net.xml'),withInternal=True,withPedestrianConnections=True);tick=time.monotonic()
 sim.start([sumolib.checkBinary('sumo'),'-c',str(p/'run.sumocfg'),'--no-step-log','true','--duration-log.disable','true','--no-warnings','true','--error-log',str(p/'warnings.log')])
 try:sim.simulationStep(9900);pending=sim.simulation.getMinExpectedNumber()
 finally:sim.close()
 site=row['site'];center=n.convertLonLat2XY(SITES[site]['lon'],SITES[site]['lat']);audit=[];eligible=[];seen=set()
 for z in E.parse(p/'collisions.xml').getroot():
  a=dict(z.attrib);ids=[a.get('collider',''),a.get('victim','')];vru=any('_ped_' in s or s.endswith('_bicycle') for s in ids);xy=sumolib.geomhelper.positionAtShapeOffset(n.getLane(a['lane']).getShape(),float(a['pos']));distance=math.dist(xy,center);t=float(a['time']);pair=tuple(sorted(ids));reason='eligible'
  if not vru:reason='no_pedestrian_or_bicycle'
  elif t<900:reason='warmup'
  elif t>=8100:reason='after_two_hour_window'
  elif not any(s.startswith('s') for s in ids):reason='warmup_participants_only'
  elif distance>152.4:reason='outside_500_feet'
  elif pair in seen:reason='repeat_same_pair'
  if reason=='eligible':seen.add(pair)
  a.update(reason=reason,distance_m=distance,x=xy[0],y=xy[1],motor_vru=any(s.endswith(('_passenger','_heavy')) for s in ids) and vru);audit.append(a)
  if reason=='eligible':eligible.append(a)
 (p/'event_audit.json').write_text(json.dumps(audit,indent=2));trips=E.parse(p/'trips.xml').getroot();arrived={z.get('id') for z in trips if z.tag in ['tripinfo','personinfo']};motors=[z for z in trips if z.tag=='tripinfo' and z.get('id','').startswith('s') and z.get('vType') in ['passenger','heavy']]
 people=E.parse(p/'demand.rou.xml').getroot();entered=sum(float(z.get('depart'))<8100 for z in trips if z.tag=='tripinfo' and z.get('id','').startswith('s'))+sum(float(z.get('depart'))<8100 for z in people if z.tag=='person' and z.get('id','').startswith('s'))
 result={**row,'path':str(p.relative_to(ROOT)),'source_coarse_path':row['path'],'integration_method':'ballistic','study_arrived':sum(s.startswith('s') for s in arrived),'study_entered_by_window_end':entered,'pending':pending,'contact_pairs':len(eligible),'any_contact':int(bool(eligible)),'motor_vru_pairs':sum(a['motor_vru'] for a in eligible),'raw_warning_rows':len(audit),'warmup_or_tail_vru_warnings':sum(a['reason'] in ['warmup','after_two_hour_window'] for a in audit),'mean_motor_duration_s':float(np.mean([float(z.get('duration')) for z in motors])),'wall_seconds':time.monotonic()-tick,'demand_sha256':hashlib.sha256((p/'demand.rou.xml').read_bytes()).hexdigest()}
 (p/'result.json').write_text(json.dumps(result,indent=2));return result

def main():
 r=pd.read_csv(OUT/'runs.csv');assert len(r)==480
 selected=r[r.step_seconds.eq(.5)&r.seed.isin(SEEDS[:12])];assert len(selected)==96
 results=[];fail=[];start=time.monotonic()
 with ProcessPoolExecutor(max_workers=2) as pool:
  futures=[pool.submit(execute_control,row) for row in selected.to_dict('records')]
  for f in as_completed(futures):
   try:results.append(f.result())
   except Exception as e:fail.append(repr(e))
   if len(results)%8==0 or len(results)+len(fail)==96:
    pd.DataFrame(results).to_csv(OUT/'integration_runs.csv',index=False);print(json.dumps({'integration_checks':len(results),'total':96,'contacts':sum(r['contact_pairs'] for r in results),'failures':len(fail),'seconds':round(time.monotonic()-start)}),flush=True)
 (OUT/'integration_failures.json').write_text(json.dumps(fail));assert not fail

if __name__=='__main__':main()
