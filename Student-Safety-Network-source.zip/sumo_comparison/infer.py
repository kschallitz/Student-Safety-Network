"""Portable inference from the frozen Explorer models and exact feature rows."""
import json
import numpy as np,pandas as pd
from .models import hour_weights
from .run import SITES

def rates(model,rows):
 x=np.asarray(rows,dtype=float)
 if model['kind']=='ten_year_pooled':
  regional=rates(model['regional'],np.c_[x[:,:10],x[:,12:18]])
  factors=np.asarray(model['city_factors']);city=x[:,18].astype(int)
  regional*=np.array([factors[i] if 0<=i<len(factors) else 1 for i in city])
  mu=(x[:,10]+model['prior_years']*regional)/(x[:,11]+model['prior_years'])
  raw=mu.reshape(-1,6);total=np.maximum(raw.sum(axis=1),1e-12);a,b=model['calibration']
  return (raw*(np.exp(a)*total**b/total)[:,None]).ravel()
 v=(x-np.array(model['mean']))/np.array(model['scale'])
 if model['kind']=='poisson_glm':return np.exp(v@np.array(model['weights'])+model['intercept'])
 for i,(w,b) in enumerate(zip(model['weights'],model['biases'])):
  v=v@np.asarray(w)+np.asarray(b);v=np.exp(v) if i==len(model['weights'])-1 else np.tanh(v)
 return v.ravel()

def table_from_frozen(frozen):
 out=[]
 for entry in frozen['rows']:
  site,kind,year=entry['site'],entry['model'],entry['feature_year'];mu=rates(frozen['bundle'][kind],entry['rows']);bs=np.array([rates(m,entry['rows']) for m in frozen['bootstrap'][kind]])
  assert np.allclose(mu,entry['expected_rates'],atol=1e-12,rtol=1e-12)
  for start in [None,7,11,14,16]:
   weights=np.ones(6) if start is None else hour_weights(start,start+2);count=float(mu@weights);low,high=np.quantile(-np.expm1(-(bs@weights)),[.05,.95])
   out.append({'site':site,'junction_id':SITES[site]['junction_id'],'feature_year':year,'model':kind,'display_name':'Neural network' if kind=='nn' else 'Default regression','window':'full_year' if start is None else f'{start:02}:00–{start+2:02}:00','start_hour':start,'expected_count':count,'probability':float(-np.expm1(-count)),'model_stability_low':low,'model_stability_high':high,'band_rates':json.dumps(mu.tolist()),'allocation_assumption':'none' if start is None else 'Uniform within each time band and over 365 calendar days; no weekday or seasonality feature'})
 return pd.DataFrame(out)
