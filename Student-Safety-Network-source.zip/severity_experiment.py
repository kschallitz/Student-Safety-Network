"""Reproducible severity experiment; notebook builder embeds these sections."""
# %% severity_imports
import copy
import random
import numpy as np
import pandas as pd
import torch
from torch import nn
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, roc_auc_score, brier_score_loss,
                             log_loss, precision_recall_curve, confusion_matrix)

SEVERITY_SEED = 42
SEVERITY_NUMERIC = ['hour_sin', 'hour_cos', 'weekday_sin', 'weekday_cos',
                    'month_sin', 'month_cos', 'longitude', 'latitude']
SEVERITY_CATEGORICAL = ['weather', 'lighting', 'road_surface']
SEVERITY_FEATURES = SEVERITY_NUMERIC + SEVERITY_CATEGORICAL

# %% severity_prepare
def severity_frame(collection):
    """One row per original case; never use the overlapping school-buffer joins."""
    raw = pd.DataFrame([f['properties'] for f in collection['features']])
    if raw.CASE_ID.isna().any() or raw.CASE_ID.duplicated().any():
        raise ValueError('Severity experiment requires unique nonmissing CASE_ID values.')
    severity = pd.to_numeric(raw.COLLISION_SEVERITY, errors='raise')
    if not severity.isin([1, 2, 3, 4]).all():
        raise ValueError('Only documented severity codes 1–4 are supported; do not impute targets.')
    dates = pd.to_datetime(raw.COLLISION_DATE, unit='ms', errors='raise')
    if dates.isna().any() or not dates.dt.year.eq(raw.ACCIDENT_YEAR).all():
        raise ValueError('Missing or inconsistent collision dates.')
    if not dates.dt.year.between(2020, 2024).all():
        raise ValueError('Review the temporal protocol before extending this frozen experiment.')
    hhmm = pd.to_numeric(raw.COLLISION_TIME, errors='raise')
    valid_time = hhmm.between(0, 2359) & hhmm.mod(1).eq(0) & hhmm.mod(100).lt(60)
    # Invalid/unknown time becomes missing; the imputer learns only from training rows.
    hours = (hhmm // 100 + hhmm.mod(100) / 60).where(valid_time)
    d = pd.DataFrame({'case_id': raw.CASE_ID.astype(str), 'date': dates,
                      'year': dates.dt.year, 'severity_code': severity.astype(int),
                      'severe_or_fatal': severity.isin([1, 2]).astype(int)})
    for name, values, period in [('hour', hours, 24), ('weekday', dates.dt.dayofweek, 7),
                                  ('month', dates.dt.month - 1, 12)]:
        d[name + '_sin'] = np.sin(2 * np.pi * values / period)
        d[name + '_cos'] = np.cos(2 * np.pi * values / period)
    coordinates = np.asarray([f['geometry']['coordinates'] for f in collection['features']], dtype=float)
    if coordinates.shape != (len(d), 2) or not np.isfinite(coordinates).all():
        raise ValueError('Missing or invalid point coordinates.')
    if not ((coordinates[:, 0] > -122.2) & (coordinates[:, 0] < -121.3) &
            (coordinates[:, 1] > 37.2) & (coordinates[:, 1] < 38.1)).all():
        raise ValueError('Unexpected study-area coordinates.')
    d['longitude'], d['latitude'] = coordinates[:, 0], coordinates[:, 1]
    for target, source in [('weather', 'WEATHER_1'), ('lighting', 'LIGHTING'),
                            ('road_surface', 'ROAD_SURFACE')]:
        d[target] = raw[source].fillna('Unknown').astype(str).str.strip().replace({'': 'Unknown', '-': 'Unknown'})
    d['split'] = np.select([d.year.le(2022), d.year.eq(2023)], ['train', 'validation'], default='test')
    return d.sort_values(['date', 'case_id']).reset_index(drop=True)


def severity_preprocessor():
    return ColumnTransformer([
        ('numeric', Pipeline([('impute', SimpleImputer(strategy='median', keep_empty_features=True)),
                              ('scale', StandardScaler())]), SEVERITY_NUMERIC),
        ('categorical', OneHotEncoder(handle_unknown='ignore', sparse_output=False), SEVERITY_CATEGORICAL)
    ], remainder='drop')


def prepare_severity_splits(frame):
    parts = {s: frame.loc[frame.split.eq(s)].copy() for s in ['train', 'validation', 'test']}
    if any(p.empty or p.severe_or_fatal.nunique() != 2 for p in parts.values()):
        raise ValueError('Each temporal partition must have cases of both target classes.')
    assert parts['train'].date.max() < parts['validation'].date.min() < parts['test'].date.min()
    preprocessor = severity_preprocessor()
    # Explicit allowlist plus training-only fit prevents target and holdout leakage.
    x = {'train': preprocessor.fit_transform(parts['train'][SEVERITY_FEATURES]).astype('float32')}
    for split in ['validation', 'test']:
        x[split] = preprocessor.transform(parts[split][SEVERITY_FEATURES]).astype('float32')
    y = {s: p.severe_or_fatal.to_numpy(dtype='int64') for s, p in parts.items()}
    if not all(np.isfinite(a).all() for a in x.values()):
        raise ValueError('Preprocessing produced nonfinite values.')
    return parts, preprocessor, x, y


# %% severity_train
class SeverityMLP(nn.Module):
    def __init__(self, input_size):
        super().__init__()
        self.layers = nn.Sequential(nn.Linear(input_size, 16), nn.ReLU(),
                                    nn.Linear(16, 8), nn.ReLU(), nn.Linear(8, 1))

    def forward(self, x):
        return self.layers(x).squeeze(-1)


def fit_severity_models(x, y, seed=SEVERITY_SEED, max_epochs=400, patience=40):
    """Training API receives train/validation ONLY; no test arrays or labels."""
    if set(x) != {'train', 'validation'} or set(y) != {'train', 'validation'}:
        raise ValueError('Test data must not be supplied to the training function.')
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)  # Must run before layer initialization.
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    model = SeverityMLP(x['train'].shape[1]).cpu()
    prevalence = float(y['train'].mean())
    with torch.no_grad():
        model.layers[-1].bias.fill_(np.log(prevalence / (1 - prevalence)))
    optimizer = torch.optim.Adam(model.parameters(), lr=0.003, weight_decay=0.01)
    criterion = nn.BCEWithLogitsLoss()  # No oversampling or class weighting.
    tx = {s: torch.as_tensor(a, dtype=torch.float32) for s, a in x.items()}
    ty = {s: torch.as_tensor(a, dtype=torch.float32) for s, a in y.items()}
    history, best_loss, best_epoch, stale = [], float('inf'), 0, 0
    best_state = copy.deepcopy(model.state_dict())
    # Epoch zero exposes the untrained starting point and is a valid early-stop candidate.
    for epoch in range(max_epochs + 1):
        if epoch:
            model.train()
            optimizer.zero_grad()
            loss = criterion(model(tx['train']), ty['train'])
            loss.backward()
            optimizer.step()
        model.eval()
        with torch.no_grad():
            train_loss = float(criterion(model(tx['train']), ty['train']))
            val_loss = float(criterion(model(tx['validation']), ty['validation']))
        history.append({'epoch': epoch, 'train_log_loss': train_loss, 'validation_log_loss': val_loss})
        if val_loss < best_loss - 1e-6:
            best_loss, best_epoch, stale = val_loss, epoch, 0
            best_state = copy.deepcopy(model.state_dict())
        else:
            stale += 1
        if stale >= patience:
            break
    model.load_state_dict(best_state)
    model.eval()
    logistic = LogisticRegression(C=1.0, penalty='l2', solver='lbfgs', max_iter=2000)
    logistic.fit(x['train'], y['train'])
    return {'neural_network': model, 'logistic_regression': logistic, 'constant_baseline': prevalence,
            'history': pd.DataFrame(history), 'best_epoch': best_epoch,
            'parameter_count': sum(p.numel() for p in model.parameters()),
            'seed': seed, 'max_epochs': max_epochs, 'patience': patience}


def severity_probabilities(fitted, x):
    with torch.no_grad():
        neural = torch.sigmoid(fitted['neural_network'](torch.as_tensor(x, dtype=torch.float32))).numpy()
    return {'Constant baseline': np.full(len(x), fitted['constant_baseline']),
            'Logistic regression': fitted['logistic_regression'].predict_proba(x)[:, 1],
            'Neural network': neural.astype(float)}


def validation_threshold(y, p):
    """Maximize validation F1; ties choose the highest threshold, never use test outcomes."""
    precision, recall, thresholds = precision_recall_curve(y, p)
    f1 = 2 * precision[:-1] * recall[:-1] / np.maximum(precision[:-1] + recall[:-1], 1e-12)
    return float(thresholds[np.flatnonzero(np.isclose(f1, f1.max(), rtol=0, atol=1e-12))[-1]])


# %% severity_evaluate
def probability_metrics(y, p):
    return {'average_precision': average_precision_score(y, p), 'roc_auc': roc_auc_score(y, p),
            'brier_score': brier_score_loss(y, p), 'log_loss': log_loss(y, p, labels=[0, 1])}


def wilson_interval(successes, total):
    z = 1.959963984540054
    proportion = successes / total
    denominator = 1 + z*z/total
    midpoint = (proportion + z*z/(2*total)) / denominator
    half = z * np.sqrt(proportion*(1-proportion)/total + z*z/(4*total*total)) / denominator
    return float(midpoint-half), float(midpoint+half)


def evaluate_severity(y, predictions, thresholds):
    metrics, decisions = [], []
    for split in ['validation', 'test']:
        for model, p in predictions[split].items():
            metrics.append({'split': split, 'model': model, 'cases': len(p),
                            'severe_cases': int(y[split].sum()), **probability_metrics(y[split], p)})
            for rule, threshold in [('0.5 reference', .5), ('2023 F1 threshold', thresholds[model])]:
                tn, fp, fn, tp = confusion_matrix(y[split], p >= threshold, labels=[0, 1]).ravel()
                lo, hi = wilson_interval(int(tp), int(tp + fn))
                decisions.append({'split': split, 'model': model, 'threshold_rule': rule,
                                  'threshold': threshold, 'true_positive': int(tp), 'false_positive': int(fp),
                                  'false_negative': int(fn), 'true_negative': int(tn),
                                  'recall': float(tp / (tp+fn)), 'precision': float(tp/(tp+fp)) if tp+fp else 0.,
                                  'recall_wilson_low': lo, 'recall_wilson_high': hi})
    return pd.DataFrame(metrics), pd.DataFrame(decisions)


def severity_figures(fitted, y_test, test_predictions):
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    h = fitted['history']
    axes[0].plot(h.epoch, h.train_log_loss, label='Training: 2020–2022', color='#167b82')
    axes[0].plot(h.epoch, h.validation_log_loss, label='Validation: 2023', color='#b04a20')
    axes[0].axvline(fitted['best_epoch'], linestyle=':', color='#5d527b', label=f"Selected epoch: {fitted['best_epoch']}")
    axes[0].set(title='Learning curve · lower loss is better', xlabel='Training epoch', ylabel='Binary log loss')
    axes[0].legend(fontsize=9)
    for name, color in [('Logistic regression', '#167b82'), ('Neural network', '#70528b')]:
        p, r, _ = precision_recall_curve(y_test, test_predictions[name])
        ap = average_precision_score(y_test, test_predictions[name])
        axes[1].step(r, p, where='post', color=color, label=f'{name}: AP {ap:.3f}')
    axes[1].axhline(y_test.mean(), linestyle='--', color='#777777', label=f'Constant baseline: {y_test.mean():.3f}')
    axes[1].set(title=f'2024 test · {int(y_test.sum())} severe cases / {len(y_test)} crashes',
                xlabel='Recall · fraction of severe cases found', ylabel='Precision · fraction flagged that were severe',
                xlim=(0, 1), ylim=(0, 1.03))
    axes[1].legend(fontsize=9)
    for ax in axes:
        ax.grid(alpha=.15)
    fig.suptitle('Exploratory severity classification · recorded crashes only', fontsize=15)
    fig.tight_layout()
    return fig


def export_severity(output_dir, frame, preprocessor, fitted, predictions, thresholds, metrics, decisions,
                    source_sha256):
    import json
    from pathlib import Path
    dest = Path(output_dir) / 'severity_experiment'
    dest.mkdir(exist_ok=True)
    frame.to_csv(dest / 'modeling_rows.csv', index=False)
    metrics.to_csv(dest / 'probability_metrics.csv', index=False)
    decisions.to_csv(dest / 'threshold_metrics.csv', index=False)
    fitted['history'].to_csv(dest / 'learning_history.csv', index=False)
    prediction_rows = []
    for split, models in predictions.items():
        base = frame.loc[frame.split.eq(split), ['case_id', 'date', 'year', 'severe_or_fatal']].copy()
        for name, p in models.items():
            rows = base.assign(split=split, model=name, probability=p, threshold=thresholds[name],
                               flagged=p >= thresholds[name])
            prediction_rows.append(rows)
    pd.concat(prediction_rows).to_csv(dest / 'heldout_predictions.csv', index=False)
    numeric = preprocessor.named_transformers_['numeric']
    feature_names = preprocessor.get_feature_names_out().tolist()
    schema = {'numeric_columns': SEVERITY_NUMERIC, 'categorical_columns': SEVERITY_CATEGORICAL,
              'imputer_medians': numeric['impute'].statistics_.tolist(),
              'scaler_mean': numeric['scale'].mean_.tolist(), 'scaler_scale': numeric['scale'].scale_.tolist(),
              'categories': [a.tolist() for a in preprocessor.named_transformers_['categorical'].categories_],
              'unknown_category_handling': 'all-zero one-hot vector for that field',
              'feature_names': feature_names}
    (dest / 'preprocessing.json').write_text(json.dumps(schema, indent=2))
    baseline = fitted['logistic_regression']
    (dest / 'baseline_parameters.json').write_text(json.dumps({
        'constant_probability': fitted['constant_baseline'],
        'logistic_coefficients': baseline.coef_.tolist(), 'logistic_intercept': baseline.intercept_.tolist()}, indent=2))
    # Only tensors are saved; load this locally produced artifact with weights_only=True.
    torch.save(fitted['neural_network'].state_dict(), dest / 'severity_mlp_weights.pt')
    summary = frame.groupby('split', sort=False).severe_or_fatal.agg(cases='size', severe_cases='sum').reset_index()
    card = {'task': 'Fatal/severe vs visible injury/complaint of pain, conditional on a recorded city-source crash',
            'target_codes': {'positive': [1, 2], 'negative': [3, 4]},
            'source_snapshot_sha256': source_sha256,
            'split': {'train': [2020, 2021, 2022], 'validation': [2023], 'test': [2024]},
            'split_counts': summary.to_dict(orient='records'), 'seed': fitted['seed'],
            'features': SEVERITY_FEATURES, 'encoded_feature_count': len(feature_names),
            'architecture': [len(feature_names), 16, 8, 1], 'activation': 'ReLU; sigmoid at inference',
            'trainable_parameters': fitted['parameter_count'], 'loss': 'unweighted BCEWithLogitsLoss',
            'optimizer': 'Adam', 'learning_rate': .003, 'weight_decay': .01, 'batch': 'full training set',
            'max_epochs': fitted['max_epochs'], 'early_stopping_patience': fitted['patience'],
            'epochs_run': int(fitted['history'].epoch.max()), 'selected_epoch': fitted['best_epoch'],
            'selection': '2023 log loss only; no hyperparameter search or refit on validation',
            'threshold_selection': '2023 F1 maximum; highest threshold on ties; exploratory only',
            'thresholds': thresholds, 'test_metrics': metrics.loc[metrics.split.eq('test')].to_dict(orient='records'),
            'limits': ['Only 10 fatal/severe outcomes in 2024; results have substantial uncertainty.',
                       'No student/trip labels, no-crash examples, exposure counts, property-damage-only crashes, or causal effects.',
                       'Recorded weather/light/road conditions are retrospective report fields; live input quality is untested.',
                       'Same-city temporal test only; no geographic holdout, source reconciliation, or external validation.',
                       'Recall Wilson intervals assume independent crashes and omit model/threshold selection uncertainty.',
                       '2024 has now been inspected; further tuning requires another untouched evaluation period.',
                       'Single seed; repeatability does not establish robustness across random initializations.']}
    (dest / 'model_card.json').write_text(json.dumps(card, indent=2))
    return dest, card
