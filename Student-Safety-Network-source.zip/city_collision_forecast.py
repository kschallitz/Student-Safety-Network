"""A small, reproducible reporting-area count experiment, separate from school risk."""
# %% imports
from pathlib import Path
import json
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import PoissonRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import mean_absolute_error, mean_poisson_deviance

MODEL_NAMES=['Last-year average','Three-year average','Poisson regression','Small neural network']
NUMERIC=['log_recent_rate','log_long_rate','log_same_month','trend','season_sin','season_cos']
PROTOCOL={
    'target':'Number of pedestrian/bicycle crash records in each reporting area during a future 12-month window',
    'training_target_years':[2021,2022,2023], 'validation_target_year':2024,
    'test_target_year':2025, 'selection_metric':'Mean absolute annual count error across 16 reporting areas',
    'feature_cutoff_rule':'All 12 monthly predictions use only records before January 1 of the target year',
    'models':MODEL_NAMES, 'poisson_alpha':0.1,
    'neural_network':{'hidden_layer_sizes':[8],'activation':'tanh','loss':'poisson',
                      'solver':'lbfgs','alpha':10.0,'random_state':42,'max_iter':2000},
    'excluded_reporting_area':'Oakland Intl Airport (one 2020 record; separate source category)',
    'future_start':'2026-10-01','future_end':'2027-09-30','latest_feature_date':'2025-12-31',
    'future_assumption':'Freeze end-2025 city features and reuse seasonal month effects; no 2026 observations available',
    'intervals':'No calibrated probability or prediction interval claimed',
    'backtest_status':'Retrospective by crash date from a September 2026 snapshot, not true historical as-of reporting'}

# %% computation
def prepare_monthly_counts(payload):
    frames=[]
    for year,rows in payload['crashes'].items():
        if len(rows)!=payload['expected_counts'][year]:raise ValueError('Extract count mismatch')
        f=pd.DataFrame(rows)
        f['date']=pd.to_datetime(f['Crash Date Time'],format='mixed',errors='raise')
        if not f.date.dt.year.eq(int(year)).all():raise ValueError('Date/year mismatch')
        for flag in ['IsDeleted','Is Preliminary']:
            if not f[flag].astype(str).str.lower().eq('false').all():raise ValueError('Review deleted/preliminary records')
        frames.append(f)
    crashes=pd.concat(frames,ignore_index=True)
    if crashes['Collision Id'].isna().any() or crashes['Collision Id'].astype(str).duplicated().any():
        raise ValueError('Missing/duplicate crash IDs')
    if crashes['City Name'].isna().any():raise ValueError('Missing reporting area')
    excluded=crashes.loc[crashes['City Name'].eq('Oakland Intl Airport')]
    crashes=crashes.loc[~crashes['City Name'].eq('Oakland Intl Airport')].copy()
    cities=sorted(crashes['City Name'].unique())
    if len(cities)!=16:raise ValueError('Reporting-area inventory changed; review protocol')
    months=pd.date_range('2020-01-01','2025-12-01',freq='MS')
    index=pd.MultiIndex.from_product([cities,months],names=['city','month'])
    crashes['month']=crashes.date.dt.to_period('M').dt.to_timestamp()
    counts=crashes.groupby(['City Name','month']).size()
    counts.index.names=['city','month']
    monthly=counts.reindex(index,fill_value=0).rename('count').reset_index()
    if monthly['count'].sum()!=len(crashes):raise ValueError('Monthly counts fail reconciliation')
    return monthly,{'source_records':len(crashes)+len(excluded),'modeled_records':len(crashes),
                    'excluded_airport_records':len(excluded),'reporting_areas':len(cities),
                    'monthly_observations':len(monthly),
                    'zero_meaning':'No matching record in this frozen extract; not proof of no actual collision'}


def origin_rows(monthly,cutoff,target_start):
    """Features cannot see outcomes at/after cutoff, even in month 12 of the horizon."""
    cutoff=pd.Timestamp(cutoff);target_start=pd.Timestamp(target_start)
    if target_start<cutoff:raise ValueError('Target precedes feature cutoff')
    history=monthly.loc[monthly.month.lt(cutoff)].copy()
    targets=pd.date_range(target_start,periods=12,freq='MS')
    rows=[]
    for city in sorted(monthly.city.unique()):
        h=history.loc[history.city.eq(city)].sort_values('month')
        recent=h.tail(12);long=h.tail(36)
        if len(recent)!=12 or recent.month.max()!=cutoff-pd.offsets.MonthBegin(1):
            raise ValueError('Incomplete history before cutoff')
        recent_rate=recent['count'].mean();long_rate=long['count'].mean()
        for month in targets:
            same=long.loc[long.month.dt.month.eq(month.month),'count'].mean()
            rows.append({'city':city,'month':month,'feature_cutoff':cutoff-pd.Timedelta(days=1),
                'recent_rate':recent_rate,'long_rate':long_rate,
                'log_recent_rate':np.log1p(recent_rate),'log_long_rate':np.log1p(long_rate),
                'log_same_month':np.log1p(same),'trend':(recent_rate+.5)/(long_rate+.5),
                'season_sin':np.sin(2*np.pi*month.month/12),'season_cos':np.cos(2*np.pi*month.month/12)})
    result=pd.DataFrame(rows)
    return result.merge(monthly.rename(columns={'count':'actual'}),on=['city','month'],how='left',validate='one_to_one')


def model_for(name):
    encoder=ColumnTransformer([('city',OneHotEncoder(handle_unknown='error',sparse_output=False),['city']),
                               ('numeric',StandardScaler(),NUMERIC)])
    if name=='Poisson regression':model=PoissonRegressor(alpha=.1,max_iter=2000)
    elif name=='Small neural network':
        model=MLPRegressor(hidden_layer_sizes=(8,),activation='tanh',loss='poisson',solver='lbfgs',
                           alpha=10.,random_state=42,max_iter=2000,max_fun=30000,tol=1e-6)
    else:return None
    return make_pipeline(encoder,model)


def fit_predict(name,train,target):
    if name in MODEL_NAMES[:2]:
        col='recent_rate' if name==MODEL_NAMES[0] else 'long_rate'
        return target[col].to_numpy(),None,[]
    model=model_for(name)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always',ConvergenceWarning)
        model.fit(train[['city']+NUMERIC],train.actual)
    messages=[str(w.message) for w in caught]
    pred=model.predict(target[['city']+NUMERIC])
    if not np.isfinite(pred).all() or (pred<0).any():raise ValueError('Invalid count prediction')
    return pred,model,messages


def score_rows(rows,pred):
    scored=rows[['city','month','actual']].copy();scored['predicted']=pred
    annual=scored.groupby('city')[['actual','predicted']].sum()
    return {'annual_mae':float(mean_absolute_error(annual.actual,annual.predicted)),
            'monthly_mae':float(mean_absolute_error(scored.actual,scored.predicted)),
            'monthly_poisson_deviance':float(mean_poisson_deviance(scored.actual,np.maximum(pred,1e-8))),
            'annual_bias':float((annual.predicted-annual.actual).mean())},annual


def run_city_experiment(monthly):
    rows=pd.concat([origin_rows(monthly,f'{year}-01-01',f'{year}-01-01').assign(target_year=year)
                    for year in range(2021,2026)],ignore_index=True)
    train=rows.loc[rows.target_year.le(2023)]
    valid=rows.loc[rows.target_year.eq(2024)]
    test=rows.loc[rows.target_year.eq(2025)]
    validation=[];test_metrics=[];test_predictions=[];warning_log={}
    for name in MODEL_NAMES:
        pred,_,messages=fit_predict(name,train,valid)
        scores,_=score_rows(valid,pred)
        validation.append({'model':name,**scores,'converged':not messages})
        warning_log[f'validation: {name}']=messages
    validation=pd.DataFrame(validation)
    selected=validation.loc[validation.converged].sort_values(['annual_mae','model']).iloc[0]['model']
    # Selection is frozen above: test outcomes cannot affect model/parameter choice.
    for name in MODEL_NAMES:
        pred,_,messages=fit_predict(name,rows.loc[rows.target_year.le(2024)],test)
        scores,annual=score_rows(test,pred)
        test_metrics.append({'model':name,**scores,'selected_on_2024':name==selected})
        test_predictions.append(annual.reset_index().assign(model=name))
        warning_log[f'test: {name}']=messages
    future=origin_rows(monthly,'2026-01-01',PROTOCOL['future_start'])
    future_pred,model,messages=fit_predict(selected,rows,future)
    if messages:raise RuntimeError(f'Final model did not converge: {messages}')
    future['predicted']=future_pred
    forecast=future.groupby('city').predicted.sum().reset_index(name='expected_count')
    forecast['forecast_start']=PROTOCOL['future_start'];forecast['forecast_end']=PROTOCOL['future_end']
    forecast['latest_feature_date']=PROTOCOL['latest_feature_date'];forecast['model']=selected
    forecast['status']='Experimental; frozen end-2025 features; no calibrated probability'
    return {'validation':validation,'test_metrics':pd.DataFrame(test_metrics),
            'test_predictions':pd.concat(test_predictions,ignore_index=True),'forecast':forecast,
            'future_monthly':future,'selected_model':selected,'final_model':model,
            'warnings':warning_log,'training_rows':len(train),'validation_rows':len(valid),'test_rows':len(test)}

# %% exports
def export_city_experiment(result,monthly,audit,output):
    output=Path(output);output.mkdir(exist_ok=True,parents=True)
    for key in ['validation','test_metrics','test_predictions','forecast','future_monthly']:
        result[key].to_csv(output/f'{key}.csv',index=False)
    monthly.to_csv(output/'monthly_reported_counts.csv',index=False)
    (output/'protocol.json').write_text(json.dumps(PROTOCOL,indent=2))
    summary={**audit,'selected_model':result['selected_model'],
             **{key:result[key] for key in ['training_rows','validation_rows','test_rows','warnings']},
             'school_probability_trained':False,'severity_forecast_trained':False,
             'new_geocodes_used':0,'source_snapshot_date':'2026-09-24',
             'future_feature_gap_months':9,'no_2026_actuals_used':True}
    (output/'summary.json').write_text(json.dumps(summary,indent=2))
    import joblib
    joblib.dump({'model':result['final_model'],'name':result['selected_model'],'protocol':PROTOCOL},output/'selected_count_model.joblib')
    focus=['Livermore','Pleasanton','Dublin','Tracy','Unincorporated']
    held=result['test_predictions'].loc[result['test_predictions'].model.eq(result['selected_model'])]
    held=held.set_index('city').loc[focus]
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(1,2,figsize=(12.5,5.8),layout='constrained')
    y=np.arange(len(focus));labels=['Livermore','Pleasanton','Dublin','Tracy','Unincorporated Alameda\n(includes Castro Valley)']
    axes[0].barh(y-.18,held.predicted,height=.35,color='#25738c',label='Predicted without 2025 outcomes')
    axes[0].barh(y+.18,held.actual,height=.35,color='#a4b9c5',label='Recorded in 2025 extract')
    axes[0].set_yticks(y,labels);axes[0].invert_yaxis();axes[0].set_title('Held-out year: 2025',loc='left',fontweight='bold')
    axes[0].set_xlabel('Reported pedestrian/bicycle crashes')
    axes[0].legend(loc='upper left',bbox_to_anchor=(0,-.14),fontsize=9,frameon=False)
    for i,(_,r) in enumerate(held.iterrows()):
        axes[0].text(r.predicted+1,i-.18,f'{r.predicted:.1f}',va='center',fontsize=9)
        axes[0].text(r.actual+1,i+.18,str(int(r.actual)),va='center',fontsize=9)
    axes[0].set_xlim(0,max(held.predicted.max(),held.actual.max())*1.22)
    f=result['forecast'].set_index('city').loc[focus]
    axes[1].barh(y,f.expected_count,color='#25738c',height=.5)
    axes[1].set_yticks(y,labels);axes[1].invert_yaxis();axes[1].set_xlabel('Expected reported count · not a probability')
    axes[1].set_title('Experimental: Oct 2026–Sep 2027',loc='left',fontweight='bold')
    for i,value in enumerate(f.expected_count):axes[1].text(value+1,i,f'{value:.1f}',va='center')
    axes[1].set_xlim(0,f.expected_count.max()*1.22)
    fig.suptitle(f'City/area count forecast · {result["selected_model"]}\nFuture projection freezes end-2025 features; school-area risk remains unresolved',fontsize=13,fontweight='bold')
    fig.savefig(output/'count_forecast.png',dpi=170,bbox_inches='tight')
    return fig,summary
