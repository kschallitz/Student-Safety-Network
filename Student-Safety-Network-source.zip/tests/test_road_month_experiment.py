import unittest
import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import LineString,Point
from road_month_experiment import make_monthly_panel,feature_rows,assign_crashes,compare_speed_for_segment,NUMERIC,CATEGORICAL

class RoadMonthTests(unittest.TestCase):
    def roads(self):
        return gpd.GeoDataFrame({'segment_id':['one','two'],'Status':['Active']*2,'FullStreetName':['MAIN ST']*2,
            'posted_speed_mph':[35.,35.],'NumberOfLanes':[2,2],'FunctionalClass':['Local']*2,'length_m':[100.,100.]},
            geometry=[LineString([(600000,4170000),(600100,4170000)]),LineString([(600100,4170000),(600200,4170000)])],crs=26910).to_crs(4326)

    def decisions(self):
        return pd.DataFrame({'case_id':['a','b'],'segment_id':['one',None],
            'month':pd.to_datetime(['2020-02-01','2020-03-01']),
            'possible_segment_ids':[['one'],['one','two']],'block_all_segments':[False,False]})

    def test_unknown_is_not_negative_and_cartesian_grid(self):
        panel=make_monthly_panel(self.roads(),self.decisions(),2020,2025)
        self.assertEqual(len(panel),144)
        self.assertEqual(int(panel.collision_occurred.sum()),1)
        self.assertEqual(int(panel.collision_occurred.isna().sum()),2)
        self.assertTrue(panel.loc[panel.month.eq('2020-03-01'),'collision_occurred'].isna().all())

    def test_unmatched_road_blocks_whole_month_and_positive_survives(self):
        decisions=self.decisions();decisions.loc[1,'block_all_segments']=True
        decisions.loc[1,'month']=pd.Timestamp('2020-02-01')
        p=make_monthly_panel(self.roads(),decisions,2020,2025)
        self.assertEqual(p.loc[p.month.eq('2020-02-01')&p.segment_id.eq('one'),'collision_occurred'].iloc[0],1)
        self.assertTrue(pd.isna(p.loc[p.month.eq('2020-02-01')&p.segment_id.eq('two'),'collision_occurred'].iloc[0]))

    def test_target_cannot_enter_own_features(self):
        panel=make_monthly_panel(self.roads(),self.decisions(),2020,2025)
        first=feature_rows(panel,self.roads())
        modified=panel.copy();modified.loc[modified.month.eq('2022-06-01')&modified.segment_id.eq('one'),'collision_occurred']=1
        second=feature_rows(modified,self.roads())
        current=first.month.le('2022-06-01')
        pd.testing.assert_frame_equal(first.loc[current,NUMERIC+CATEGORICAL],second.loc[current,NUMERIC+CATEGORICAL])
        later=first.month.eq('2022-07-01')&first.segment_id.eq('one')
        self.assertEqual(second.loc[later,'prior12_positive_months'].iloc[0]-first.loc[later,'prior12_positive_months'].iloc[0],1)
        self.assertEqual(set(first.loc[first.split.eq('train'),'month'].dt.year),{2021,2022,2023})

    def test_shared_endpoint_is_ambiguous(self):
        p=gpd.GeoSeries([Point(600100,4170000)],crs=26910).to_crs(4326).iloc[0]
        c=pd.DataFrame({'case_id':['a'],'date':['2020-01-01'],'PrimaryRoad':['MAIN STREET'],'SecondaryRoad':['CROSS ST'],'Latitude':[p.y],'Longitude':[p.x]})
        _,d=assign_crashes(self.roads(),c)
        self.assertEqual(d.match_status.iloc[0],'ambiguous_adjacent_segments')
        self.assertTrue(pd.isna(d.segment_id.iloc[0]))
        with self.assertRaisesRegex(ValueError,'collision IDs'):assign_crashes(self.roads(),pd.concat([c,c]))

    def test_scenario_changes_only_speed_and_preserves_input(self):
        class Recorder:
            def __init__(self):self.inputs=[]
            def predict_proba(self,x):
                self.inputs.append(x.copy());p=x.posted_speed_mph.to_numpy()/1000
                return np.column_stack([1-p,p])
        panel=make_monthly_panel(self.roads(),self.decisions(),2020,2025);frame=feature_rows(panel,self.roads());saved=frame.copy(deep=True)
        model=Recorder();r=compare_speed_for_segment({'models':{'spy':model},'selected':'spy'},frame,'one',25)
        self.assertAlmostEqual(r.relative_reduction_percent.iloc[0],100*(1-25/35))
        pd.testing.assert_frame_equal(model.inputs[0].drop(columns='posted_speed_mph'),model.inputs[1].drop(columns='posted_speed_mph'))
        pd.testing.assert_frame_equal(frame,saved)
        frame.loc[frame.segment_id.eq('one'),'posted_speed_mph']=np.nan
        with self.assertRaisesRegex(ValueError,'Verify'):compare_speed_for_segment({'models':{'spy':model}},frame,'one',25)

if __name__=='__main__':unittest.main()
