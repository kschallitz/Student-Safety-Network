"""Ensure the stated road-user objective controls rewards, including zeros."""
import copy,unittest
from metadrive_school.rewards import score_episode

class RoadUserRewardTests(unittest.TestCase):
    def test_mode_matrix_and_duplicate_pairs(self):
        modes={'car':'passenger','truck':'heavy','ped':'pedestrian','ped2':'pedestrian','bike':'bicycle','bike2':'bicycle'}
        raw=dict(score=-999999,contacts=[dict(pair=p) for p in [
            ['car','truck'],['car','ped'],['truck','bike'],['bike','ped'],['bike','bike2'],['ped','ped2'],['ped','car']]],
            near_misses=[dict(pair=p) for p in [['truck','ped2'],['car','ped2'],['ped2','car'],['car','truck'],['bike','ped2'],['car','ped']]])
        original=copy.deepcopy(raw);r=score_episode(raw,modes)
        self.assertEqual(raw,original)
        self.assertEqual(r['collision_pairs'],2)
        self.assertEqual(r['motor_pedestrian_collision_pairs'],1)
        self.assertEqual(r['motor_bicycle_collision_pairs'],1)
        self.assertEqual(r['motor_vehicle_collision_pairs_diagnostic'],1)
        self.assertEqual(r['other_contact_pairs_diagnostic'],3)
        self.assertEqual(r['near_pairs'],2)
        self.assertEqual(r['score'],-2010)
        self.assertIsNone(r['motor_bicycle_near_pairs'])
        self.assertFalse(r['bicycle_near_misses_measured'])
    def test_vehicle_vehicle_only_receives_zero_penalty(self):
        r=score_episode(dict(score=-1000,contacts=[dict(pair=['a','b'])],near_misses=[]),{'a':'passenger','b':'heavy'})
        self.assertEqual(r['score'],0);self.assertEqual(r['all_contact_pairs'],1)
    def test_bicycle_collision_is_penalized(self):
        r=score_episode(dict(score=-1000,contacts=[dict(pair=['a','b'])],near_misses=[]),{'a':'bicycle','b':'heavy'})
        self.assertEqual(r['score'],-1000)
    def test_missing_mode_is_not_silently_excluded(self):
        with self.assertRaises(KeyError):
            score_episode(dict(score=0,contacts=[dict(pair=['a','b'])],near_misses=[]),{'a':'passenger'})
    def test_conflicting_mode_is_rejected(self):
        with self.assertRaises(ValueError):
            score_episode(dict(score=0,contacts=[dict(pair=['a','b'],actors=[dict(id='a',mode='pedestrian')])],near_misses=[]),{'a':'passenger','b':'heavy'})

if __name__=='__main__':unittest.main()
