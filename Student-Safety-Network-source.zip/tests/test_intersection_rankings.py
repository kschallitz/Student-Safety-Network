from pathlib import Path
import tempfile,unittest
import pandas as pd
import geopandas as gpd
from intersection_rankings import rank_intersections

ROOT=Path(__file__).resolve().parents[1]
class IntersectionRankingsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases=gpd.read_file(ROOT/'data/raw/collisions.geojson')
        cls.roads=gpd.read_file(ROOT/'school_forecast_output/livermore_road_speed_inventory.geojson')
        cls.schools=gpd.read_file(ROOT/'school_forecast_output/school_sites.geojson')

    def test_unique_cases_membership_and_ties(self):
        with tempfile.TemporaryDirectory() as tmp:
            city,near,p=rank_intersections(self.cases,self.schools,self.roads,tmp)
        self.assertEqual(int(city.pedbike_collisions.sum()),158)
        ids=[i for text in city.case_ids for i in text.split(';')]
        self.assertEqual(len(ids),len(set(ids)))
        self.assertEqual(len(near),16)
        self.assertTrue(near.miles_from_christensen.lt(2).all())
        self.assertTrue(near.pedbike_collisions.eq(1).all())
        self.assertEqual(int(near.fatal_or_serious.sum()),3)
        self.assertEqual(set(near.loc[near['rank'].eq(1),'intersection']),{
            'Golf Drive & Rhododendron Drive','Leisure Street & Southfront Road','Northfront Road & Vasco Road'})
        self.assertEqual(city.loc[city.intersection.eq('Murrieta Boulevard & Portola Avenue'),'pedbike_collisions'].iloc[0],5)
        self.assertEqual(len(city.loc[city['rank'].eq(4)]),3)
        self.assertEqual(p['boundary_uncertain'],0)

    def test_duplicate_collision_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(AssertionError):
                rank_intersections(pd.concat([self.cases,self.cases.iloc[:1]]),self.schools,self.roads,tmp)

if __name__=='__main__':unittest.main()
