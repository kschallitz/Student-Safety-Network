"""Adapter safeguards; fixture rewards are never included in study results."""
import unittest
import pandas as pd
from metadrive_school.learning import MitigationEnv

class RewardGateTests(unittest.TestCase):
    def environment(self,**changes):
        contexts=pd.DataFrame([dict(context_id='fixture',passenger=10,heavy=0,bicycle=1,pedestrian=2,hour=8,weekend=0)])
        row=dict(context_id='fixture',action='C01',score=-1015,collision_pairs=1,near_pairs=3,complete=True,
                 precontact_boundary_violations=0,precontact_max_route_deviation_m=.2)
        row.update(changes)
        return MitigationEnv(contexts,pd.DataFrame([row]))
    def test_cumulative_reward_and_terminal(self):
        env=self.environment();obs,_=env.reset();self.assertEqual(obs.shape,(6,))
        _,reward,done,truncated,_=env.step(0)
        self.assertEqual(reward,-1015);self.assertTrue(done);self.assertFalse(truncated)
        with self.assertRaises(RuntimeError):env.step(0)
    def test_unserved_demand_cannot_win(self):
        env=self.environment(complete=False,score=0,collision_pairs=0,near_pairs=0);env.reset()
        with self.assertRaises(ValueError):env.step(0)
    def test_geometry_failure_cannot_win(self):
        env=self.environment(precontact_boundary_violations=1);env.reset()
        with self.assertRaises(ValueError):env.step(0)
    def test_inconsistent_reward_rejected(self):
        env=self.environment(score=0);env.reset()
        with self.assertRaises(ValueError):env.step(0)
    def test_extra_delay_does_not_disqualify_a_safe_complete_run(self):
        env=self.environment(mean_delay_s=120,baseline_delay_s=5,score=0,collision_pairs=0,near_pairs=0)
        env.reset()
        _,reward,done,_,_=env.step(0)
        self.assertEqual(reward,0)
        self.assertTrue(done)


class LearnerSeparationTests(unittest.TestCase):
    def test_known_optimum_without_benchmark_or_test_labels(self):
        import tempfile
        from pathlib import Path
        from unittest.mock import patch
        from metadrive_school import learning
        contexts=pd.DataFrame([dict(context_id=f'fixture{i}',passenger=100+10*i,heavy=2,bicycle=3,pedestrian=10+i,hour=8,weekend=0,split=s) for i,s in enumerate(['train','train','validation','test'])])
        records=[]
        for c in contexts.itertuples():
            for index,action in enumerate(learning.ACTION_IDS):
                # The correct answer is deliberately C03, not the benchmark C07.
                score=-1000*abs(index-2) if c.split!='test' else 999999
                records.append(dict(context_id=c.context_id,action=action,realization=0,complete=True,physics_pass=True,demand_sha256=c.context_id,score=score,split=c.split))
        runs=pd.DataFrame(records)
        with tempfile.TemporaryDirectory() as folder:
            destination=Path(folder)
            contexts.to_csv(destination/'fixture_contexts.csv',index=False)
            runs.to_csv(destination/'fixture_runs.csv',index=False)
            quality=dict(snapshot='synthetic_test_only',recommendation_released=False,release_blockers=['Synthetic unit test only'])
            with patch.object(learning,'OUT',destination),patch('metadrive_school.quality.assess',return_value=(quality,runs)):
                result=learning.fit('fixture',updates=1200)
            self.assertTrue(all(a['fixed_action']=='C03' for a in result['agents'].values()))
            self.assertFalse(result['test_outcomes_used'])
            self.assertFalse(result['consultant_identity_used'])
            self.assertNotIn('fixture3',result['train_contexts'])

if __name__=='__main__':unittest.main()
