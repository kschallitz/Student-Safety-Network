"""Boundary and unknown-outcome tests; artificial fixtures are never training data."""
import copy
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from school_forecast_preparation import audit_forecast_sources, RADIUS_METRES, METRIC_CRS
import geopandas as gpd
import pandas as pd
from shapely.geometry import Point


def crash(case_id='one', **overrides):
    row={'Collision Id':case_id,'Crash Date Time':'2024-05-01T08:00:00',
         'Latitude':37.72,'Longitude':-121.73,'NumberInjured':1,'NumberKilled':0,
         'Is Preliminary':False,'IsDeleted':False,'City Name':'Livermore'}
    row.update(overrides)
    return row


def payload(rows=None, injuries=None, points=None):
    rows=rows if rows is not None else [crash()]
    points=points or [Point(-121.73,37.72)]
    features=[{'type':'Feature','geometry':p.__geo_interface__,
        'properties':{'CDSCode':f'00{i}','SchoolName':f'School {i}','City':'Livermore',
                      'CountyNameGeo':'Alameda','OpenDate':0,'Year':'2025-26','Status':'Active'}}
        for i,p in enumerate(points)]
    return {'crashes':{'2024':rows},'expected_counts':{'2024':len(rows)},
            'injuries':{'2024':injuries or []},'schools':{'type':'FeatureCollection','features':features}}


class ForecastPreparationTests(unittest.TestCase):
    def test_unlocated_or_unmatched_cases_never_become_zero_labels(self):
        p=payload([crash(Latitude=None),crash('far',Latitude=37.3)])
        result=audit_forecast_sources(p)
        self.assertEqual(len(result[0]),2)
        self.assertTrue(result[5].empty)
        self.assertEqual(result[6]['missing_coordinates'],1)
        self.assertFalse(result[6]['zero_outcome_labels_created'])

    def test_unknown_severity_remains_nullable(self):
        d=audit_forecast_sources(payload())[0]
        self.assertEqual(d.loc[0,'documented_severity'],'Unknown')
        self.assertTrue(pd.isna(d.loc[0,'fatal_or_severe_outcome']))

    def test_documented_positive_survives_incomplete_injury_inventory(self):
        injury=[{'case_id':'one','ExtentOfInjuryCode':'SuspectSerious','n':1,'distinct_person_ids':1}]
        d=audit_forecast_sources(payload([crash(NumberInjured=2)],injury))[0]
        self.assertTrue(d.loc[0,'fatal_or_severe_outcome'])
        self.assertFalse(d.loc[0,'injury_totals_reconciled'])

    def test_reconciled_minor_and_no_injury_are_negative_severity_only(self):
        injury=[{'case_id':'one','ExtentOfInjuryCode':'SuspectMinor','n':1,'distinct_person_ids':1}]
        d=audit_forecast_sources(payload([crash(),crash('two',NumberInjured=0)],injury))[0]
        self.assertEqual(d.fatal_or_severe_outcome.tolist(),[False,False])
        self.assertEqual(len(d),2)  # Both are still collision occurrences.

    def test_missing_and_duplicate_keys_rejected(self):
        for value in [None,'','   ','nan']:
            with self.subTest(value=value),self.assertRaises(ValueError):
                audit_forecast_sources(payload([crash(value)]))
        with self.assertRaises(ValueError):audit_forecast_sources(payload([crash(),crash()]))
        p=payload();p['schools']['features'][0]['properties']['CDSCode']=None
        with self.assertRaises(ValueError):audit_forecast_sources(p)

    def test_partial_extract_and_injury_join_fail_closed(self):
        p=payload();p['expected_counts']['2024']=2
        with self.assertRaises(ValueError):audit_forecast_sources(p)
        for case_id,n,distinct in [('orphan',1,1),('one',2,1)]:
            p=payload(injuries=[{'case_id':case_id,'ExtentOfInjuryCode':'SuspectMinor','n':n,'distinct_person_ids':distinct}])
            with self.assertRaises(ValueError):audit_forecast_sources(p)

    def test_deleted_wrong_year_and_invalid_coordinates_excluded_from_pairs(self):
        p=payload([crash('deleted',IsDeleted=True),crash('wrong-year',**{'Crash Date Time':'2023-05-01'}),
                   crash('invalid',Latitude=0),crash('valid')])
        r=audit_forecast_sources(p)
        self.assertEqual(set(r[4].case_id),{'valid'})
        self.assertEqual(len(r[0]),4)

    def test_one_mile_boundary_and_overlapping_schools(self):
        origin=gpd.GeoSeries([Point(-121.73,37.72)],crs=4326).to_crs(METRIC_CRS).iloc[0]
        offsets=gpd.GeoSeries([Point(origin.x+d,origin.y) for d in [RADIUS_METRES-1,RADIUS_METRES+1]],crs=METRIC_CRS).to_crs(4326)
        rows=[crash(name,Longitude=p.x,Latitude=p.y) for name,p in zip(['inside','outside'],offsets)]
        r=audit_forecast_sources(payload(rows,points=[Point(-121.73,37.72)]*2))
        self.assertEqual(len(r[4]),2)
        self.assertEqual(set(r[4].case_id),{'inside'})
        self.assertEqual(r[6]['matched_unique_crashes'],1)
        self.assertEqual(r[1].school_id.tolist(),['000','001'])

    def test_unknown_source_flag_not_silently_false(self):
        with self.assertRaises(ValueError):
            audit_forecast_sources(payload([crash(IsDeleted=None)]))


if __name__=='__main__':unittest.main()
