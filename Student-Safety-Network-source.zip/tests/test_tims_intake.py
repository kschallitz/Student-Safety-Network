import pandas as pd
from tims_data_preparation import prepare_victims, summarize_victims


def test_school_age_includes_18_preserves_zero_and_unknown_and_uses_correct_person():
    # A young driver must not classify the adult pedestrian as school-age.
    rows = [
        ("A", "3", "18", "5"), ("B", "1", "12", "3"),
        ("B", "3", "45", "3"), ("C", "4", "998", "2"),
        ("D", "3", "0", "1"), ("E", "4", "999", "1"),
        ("F", "4", "998", "2"), ("F", "3", "5", "3"),
        ("G", "2", "10", "3"), ("H", "4", "19", "4"),
    ]
    v = prepare_victims(pd.DataFrame(rows, columns=["CASE_ID", "VICTIM_ROLE", "VICTIM_AGE", "VICTIM_DEGREE_OF_INJURY"]))
    s = summarize_victims(v).set_index("CASE_ID")
    assert s.loc["A", "recorded_pedbike_age_5_18"]
    assert not s.loc["B", "recorded_pedbike_age_5_18"]
    assert pd.isna(s.loc["C", "recorded_pedbike_age_5_18"])
    assert not s.loc["D", "recorded_pedbike_age_5_18"]
    assert pd.isna(s.loc["E", "recorded_pedbike_age_5_18"])
    assert s.loc["F", "recorded_pedbike_age_5_18"]
    assert pd.isna(s.loc["G", "recorded_pedbike_age_5_18"])
    assert not s.loc["H", "recorded_pedbike_age_5_18"]
    assert s.loc["F", "pedbike_victims_age_unknown"] == 1
    assert v.loc[0, "injury_level_harmonized"] == "serious"
    assert v.loc[4, "age_years"] == 0
