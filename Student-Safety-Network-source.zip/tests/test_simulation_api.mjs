import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {simulationApi} from '../hosted_map/server/simulation-api.js';
const db=new DatabaseSync(':memory:');
for(const file of fs.readdirSync('hosted_map/drizzle').filter(f=>f.endsWith('.sql')))db.exec(fs.readFileSync('hosted_map/drizzle/'+file,'utf8'));
const env={SIM_WORKER_KEY:'test-only',DB:{
 prepare(sql){
  const bound=(params=[])=>({
   async first(){return db.prepare(sql).get(...params)||null;},
   async all(){return {results:db.prepare(sql).all(...params)};},
   async run(){return db.prepare(sql).run(...params);}
  });
  return {...bound(),bind(...params){return bound(params);}};
 }
}};
async function call(path,method='GET',body=null,who='user'){
 const headers={'content-type':'application/json',origin:'https://example.test'};
 if(who==='user')headers['oai-authenticated-user-id']='owner';
 if(who==='worker')headers['x-simulation-worker-key']='test-only';
 const r=await simulationApi(new Request('https://example.test/api/simulation'+path,{method,headers,...(body?{body:JSON.stringify(body)}:{})}),env);
 return [r.status,await r.json()];
}
assert.equal((await call('/status','GET',null,'none'))[0],401);
assert.equal((await call('/jobs','POST',{junctionId:'J999',realizations:1}))[0],400);
const [status,data]=await call('/jobs','POST',{junctionId:'J02019',realizations:1});assert.equal(status,201);assert.equal(data.job.total,72);
assert.equal((await call('/jobs','POST',{junctionId:'J02019',realizations:1}))[1].job.id,data.job.id);
assert.equal((await call('/worker/claim','POST',{},'user'))[0],403);
const claim=(await call('/worker/claim','POST',{},'worker'))[1].job;
assert.equal(claim.id,data.job.id);assert.equal(claim.status,'running');
assert.equal((await call('/status'))[1].online,true);
assert.equal((await call('/worker/progress','POST',{id:claim.id,lease:'wrong',completed:1},'worker'))[0],409);
assert.equal((await call('/worker/progress','POST',{id:claim.id,lease:claim.lease,completed:72,status:'completed',result:{releaseChecked:true}},'worker'))[0],400);
assert.equal((await call('/worker/progress','POST',{id:claim.id,lease:claim.lease,completed:72,status:'failed',message:'Source quality check failed'},'worker'))[0],200);
assert.equal((await call('/jobs?junction=J02019'))[1].jobs[0].status,'failed');
assert.equal((await call('/jobs','POST',{junctionId:'J02019',realizations:2,trafficMode:'saved'}))[0],400);
await call('/jobs','POST',{junctionId:'J02019',realizations:1,trafficMode:'saved'});
const second=(await call('/worker/claim','POST',{},'worker'))[1].job;
assert.equal(second.realizationStart,0);
const actions=['C01','C02','C03','C04','C05','C08'];
const result={junctionId:'J02019',releaseChecked:true,bicycleNearMeasured:true,scoringVersion:'motor-vru-v2',snapshot:'checked-test',selected:'C02',candidates:actions.map(id=>({id})),protocol:{realizations:1,start_realization:0},
 episodes:Array.from({length:12},(_,i)=>actions.map(action=>({context:'period'+i,action,realization:0,contacts:0,near:3,pedestrianNear:2,bicycleNear:1,reward:-15,travelers:25}))).flat()};
assert.equal((await call('/worker/progress','POST',{id:second.id,lease:second.lease,completed:72,status:'completed',result},'worker'))[0],200);
assert.equal((await call('/jobs?junction=J02019'))[1].jobs[0].result.episodes[0].bicycleNear,1);
console.log('Passed job API: authentication, site validation, duplicate suppression, claim lease, heartbeat, result validation and failed-run reporting.');
