const assert=require('assert'),fs=require('fs');
const m=require('../intersection_model.js'),s=require('../speed_response.js');
const e=JSON.parse(fs.readFileSync('outputs/speed_response/speed_response_evidence.json'));
const payload=JSON.parse(fs.readFileSync('intersection_prediction_output/map_payload.json'));
const p=s.fromRates([.01,.02,.03,.04,.05,.06]),road={speeds:[30,30]};
const close=(a,b)=>assert(Math.abs(a-b)<1e-11,`${a} != ${b}`);
// Published intervention reproduced on the affected rate, not by multiplying probability.
close(s.roadFactor(e,[e.before_mph],e.after_mph),.447);
const all=s.apply(p,.447,1,[1,1,1,1,1,1]);
close(all.annual,1-Math.exp(-.21*.447));
assert(Math.abs(all.annual-p.annual*.447)>.001);
const noChange=s.compare(e,p,[p],road,30);
close(noChange.scenario.annual,p.annual);close(noChange.changeRange[0],0);close(noChange.changeRange[1],0);
assert(!s.assess(e,{speeds:[null]},25).ok);
assert(!s.assess(e,{speeds:[30]},55).ok);
assert(s.assess(e,{speeds:[30]},55,null,true).ok);
assert(!s.assess(e,{speeds:[30]},NaN).ok);
const untouched=JSON.stringify(p),partial=s.apply(p,.7,.25,[0,.4,1,1,.5,0]);
close(partial.rates[0],p.rates[0]);close(partial.rates[5],p.rates[5]);
close(partial.rates[2],p.rates[2]*(.75+.25*.7));assert.equal(JSON.stringify(p),untouched);
close(s.apply(p,.1,0,[1,1,1,1,1,1]).annual,p.annual);
close(s.roadFactor(e,[30,30],25),s.roadFactor(e,[30],25));
let checks=0,complete=0,modelChecks=0;
for(const j of payload.junctions){
 if(!j.coverageComplete)continue;complete++;
 j.x=Array.from({length:6},(_,b)=>[...j.base,j.historyBand[b],j.knownBand[b],...Array.from({length:6},(_,i)=>+(i===b)),j.region]);
 for(const kind of ['glm','nn']){
   const baseline=m.predict(payload.models[kind],j.x);modelChecks++;
   for(const a of j.approaches){
     let prev=-1;
     for(const proposed of [15,20,25,30,35,40,45,50,55,60,65]){
       const check=s.assess(e,a,proposed,30,true);assert(check.ok);
       const factor=s.roadFactor(e,check.speeds,proposed),result=s.apply(baseline,factor,a.speeds.length/j.approaches.reduce((n,r)=>n+r.speeds.length,0),[0,.4,.6,.5,.4,0]);
       assert(result.annual>=prev-1e-13);assert(result.annual>=0&&result.annual<=1);
       close(result.annual,1-result.bands.reduce((n,p)=>n*(1-p),1));prev=result.annual;checks++;
     }
   }
 }
}
// Full uncertainty path checked for one representative junction of each model.
const example=payload.junctions.find(j=>j.id==='J00699');
const results=[];
for(const kind of ['glm','nn']){
 const b=m.predict(payload.models[kind],example.x),br=m.modelRange(payload.bootstrap[kind],example.x);
 const a=example.approaches.find(a=>a.name.includes('GARAVENTA'));
 const c=s.compare(e,b,br.predictions,a,25,{roadShare:.5,timeShares:e.school_time_by_city.LIVERMORE.fraction});
 assert(c.ok&&c.scenario.annual<b.annual);assert(c.range.annual[0]<=c.scenario.annual&&c.range.annual[1]>=c.scenario.annual);
 assert(c.range.annual[0]<=br.annual[0]&&c.range.annual[1]>=br.annual[1]);assert(c.changeRange[0]<=0&&c.changeRange[1]===0);
 results.push({kind,baseline:b.annual,scenario:c.scenario.annual,range:c.range.annual,change_range:c.changeRange});
}
const report={complete_junctions:complete,baseline_model_checks:modelChecks,ordered_speed_checks:checks,monotonicity_failures:0,baseline_model_sha256:require('crypto').createHash('sha256').update(fs.readFileSync('intersection_prediction_output/model.json')).digest('hex'),example_garaventa_vasco:results};
assert.equal(report.baseline_model_sha256,e.baseline_model_sha256);
fs.writeFileSync('outputs/speed_response/scenario_validation.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
