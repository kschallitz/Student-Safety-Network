"""Protect uncertain annual histories, corridor bounds and transition exclusions."""
import unittest,json
import numpy as np,pandas as pd,geopandas as gpd
from shapely.geometry import LineString
from historical_speed_features import CorridorMatcher,records,panel,year_features,eligible
from intersection_prediction import load_prepared,feature_year,OUT

class HistoricalSpeeds(unittest.TestCase):
    def test_named_bounds_do_not_select_rest_of_road(self):
        # X extends far past both named endpoints; only its middle section applies.
        lines=[LineString([(0,0),(0,100)]),LineString([(0,100),(0,200)]),LineString([(0,200),(0,300)]),
               LineString([(-40,100),(40,100)]),LineString([(-40,200),(40,200)])]
        g=gpd.GeoDataFrame({'sid':['a','b','c','d','e'],'city':['TEST']*5,
                           'name':['X RD']*3+['START ST','FINISH ST']},geometry=lines,crs=26910)
        ids,info=CorridorMatcher(g).match('TEST','X Road','Start Street to Finish Street')
        self.assertEqual(ids,['b']);self.assertEqual(info['status'],'matched')
        self.assertEqual(CorridorMatcher(g).match('TEST','X Road','100 feet north of Start Street to Finish Street')[0],[])

    def test_adoption_year_is_missing_and_preperiod_is_bounded(self):
        r=next(r for r in records() if r['record_id']=='CHG-002')
        self.assertEqual(r['values'][2017],25);self.assertEqual(r['values'][2019],25)
        self.assertNotIn(2016,r['values']);self.assertNotIn(2020,r['values'])
        self.assertEqual(r['values'][2021],30)
        r=next(r for r in records() if r['record_id']=='CHG-037')
        self.assertTrue(all(y>2021 for y in r['values']))

    def test_transition_mask_preserves_raw_cases_and_lagged_history(self):
        j,c,u=load_prepared();original=c.copy();p=panel()
        index=int(j.index[j.junction_id.eq('J00699')][0])
        self.assertTrue(p['transition'][index,2020-2014])
        self.assertFalse(eligible(j,u,2020).reshape(-1,6)[index].any())
        self.assertEqual(c[index,2022-2014,:].sum(),1)
        x=feature_year(j,c,u,2023)
        self.assertGreater(x[index*6+1,11],0)
        np.testing.assert_array_equal(c,original)
        # Actual speed assignments at the example change: both legs of that road.
        speeds=pd.read_csv(OUT/'historical_segment_year_speeds.csv.gz')
        sids=next(a['segments'] for a in j.approaches.iloc[index] if a['name']=='GARAVENTA RANCH RD')
        vals=speeds.loc[speeds.sid.isin(sids)]
        self.assertEqual(set(vals.loc[vals.year.eq(2019),'mph']),{25})
        self.assertEqual(set(vals.loc[vals.year.eq(2021),'mph']),{30})

    def test_current_map_values_are_not_historical_backfill(self):
        j,c,u=load_prepared();p=panel()
        np.testing.assert_allclose(year_features(j,2026),j[['speed_mean','speed_max','speed_unknown_share']].to_numpy(float))
        no_history=(p['features'][:,:-1,2]==1).all(axis=1)
        self.assertTrue((no_history & j.speed_unknown_share.lt(1)).any())
        self.assertTrue(np.isfinite(p['features']).all())
        self.assertTrue(((p['features'][:,:,2]>=0)&(p['features'][:,:,2]<=1)).all())
        self.assertFalse(pd.read_csv(OUT/'historical_segment_year_speeds.csv.gz').duplicated(['sid','year']).any())

if __name__=='__main__':unittest.main()
