import unittest
from types import SimpleNamespace
import numpy as np
from metadrive_intersections.geometry import Route
from metadrive_intersections.bicycle_conflicts import BicycleConflicts,rectangle_ttc
from metadrive_intersections.conflicts import projected_pose
from metadrive_intersections.rewards import score_episode

def actor(name,mode,points,position,speed,heading=0):
    return dict(record=dict(id=name,mode=mode,study=True),route=Route(points,name),
                pos=np.array(position,float),v=speed,neighbors=[],obj=SimpleNamespace(
                heading_theta=heading,LENGTH=4.5 if mode=='passenger' else 1.75,WIDTH=1.85 if mode=='passenger' else .4))

class BicycleDetectorTests(unittest.TestCase):
    def test_crossing_and_parallel(self):
        times=np.arange(0,1.501,.025)
        a=actor('car','passenger',[[-20,0],[20,0]],[-10,0],10)
        b=actor('bike','bicycle',[[0,-20],[0,20]],[0,-5],5,np.pi/2)
        pose=lambda x:projected_pose(x['route'],x['pos'],x['obj'].heading_theta,x['v'],times)
        k=rectangle_ttc(pose(a),pose(b),(4.5,1.85),(1.75,.4),times)
        self.assertIsNotNone(k);self.assertGreater(times[k],0);self.assertLess(times[k],1.5)
        b=actor('bike','bicycle',[[-20,5],[20,5]],[-5,5],5)
        self.assertIsNone(rectangle_ttc(pose(a),pose(b),(4.5,1.85),(1.75,.4),times))

    def test_close_passage_required_and_contacts_excluded(self):
        # A crossing conflict is projected at t=0. Car slows; bike clears first.
        d=BicycleConflicts();a=actor('c','passenger',[[-20,0],[20,0]],[-10,0],10)
        b=actor('b','bicycle',[[0,-20],[0,20]],[0,-5],5,np.pi/2)
        a['neighbors']=[b];b['neighbors']=[a]
        d.observe([a,b],0);self.assertTrue(d.events);self.assertFalse(d.classify({}))
        for t in np.arange(.05,4,.05):
            a['pos']=np.array([-10+5*t,0]);a['v']=5
            b['pos']=np.array([0,-5+5*t]);d.observe([a,b],float(t))
        self.assertEqual(len(d.classify({})),1)
        self.assertFalse(d.classify({('b','c'):True}))

    def test_reward_scope_and_deduplication(self):
        raw=dict(score=-999,contacts=[dict(pair=['c','p'])],near_misses=[dict(pair=['c','b']),dict(pair=['b','c']),dict(pair=['c','p'])],safety_metric_version='route-ttc-pet-motor-bicycle-v2')
        scored=score_episode(raw,dict(c='passenger',p='pedestrian',b='bicycle'))
        self.assertEqual(scored['score'],-1005);self.assertEqual(scored['motor_bicycle_near_pairs'],1)
        self.assertEqual(scored['motor_pedestrian_near_pairs'],0)
        self.assertTrue(scored['bicycle_near_misses_measured'])
        raw['safety_metric_version']='old'
        with self.assertRaises(ValueError):score_episode(raw,dict(c='passenger',p='pedestrian',b='bicycle'))

    def test_following_diverging_and_stationary(self):
        times=np.arange(0,1.501,.025)
        pose=lambda x:projected_pose(x['route'],x['pos'],x['obj'].heading_theta,x['v'],times)
        a=actor('car','passenger',[[-30,0],[30,0]],[-10,0],10)
        b=actor('bike','bicycle',[[-30,0],[30,0]],[-2,0],3)
        self.assertIsNotNone(rectangle_ttc(pose(a),pose(b),(4.5,1.85),(1.75,.4),times))
        a['v']=2;b['v']=5
        self.assertIsNone(rectangle_ttc(pose(a),pose(b),(4.5,1.85),(1.75,.4),times))
        a['v']=0;b['v']=0
        self.assertIsNone(rectangle_ttc(pose(a),pose(b),(4.5,1.85),(1.75,.4),times))

    def test_unvisited_projection_expires_without_reward(self):
        d=BicycleConflicts();a=actor('c','passenger',[[-20,0],[20,0]],[-10,0],10)
        b=actor('b','bicycle',[[0,-20],[0,20]],[0,-5],5,np.pi/2)
        b['neighbors']=[a];d.observe([a,b],0)
        self.assertTrue(d.events)
        a['v']=0;b['v']=0
        for t in range(1,15):d.observe([a,b],t)
        self.assertFalse(d.active);self.assertFalse(d.classify({}))

if __name__=='__main__':unittest.main()
