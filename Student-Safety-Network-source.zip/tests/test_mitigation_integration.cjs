const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const Planner = require('../mitigation_planner.js');
const evidence = JSON.parse(fs.readFileSync('hosted_map/out/mitigation-evidence.json'));
const payload = JSON.parse(fs.readFileSync('intersection_prediction_output/map_payload.json'));
const estates = payload.junctions.find(j=>j.id==='J01145');
const study = Planner.site(evidence,estates);
assert(study.candidates.some(c=>c.id===study.selected));
assert.equal(payload.junctions.filter(j=>Planner.site(evidence,j)).length,Object.keys(evidence.sites).length);
assert.equal(Planner.site(evidence,{...estates,ll:[37.7,-121.7]}),null);
const blocked=structuredClone(evidence);blocked.sites.J01145.releaseChecked=false;
assert.equal(Planner.site(blocked,estates),null);
const may=Planner.totals(study,'test');
for(const s of Object.values(evidence.sites)){
 const choice=s.selected;
 for(const r of Planner.totals(s)){
  assert.equal(r.reward,-1000*r.contacts-5*r.near);
  assert.equal(r.near,r.pedestrianNear+(r.bicycleNear??0));
  assert.equal(r.bicycleNear===null,!s.bicycleNearMeasured);
 }
 Planner.totals(s,'train');assert.equal(s.selected,choice);
 if(s.bicycleNearMeasured){assert.equal(s.scoringVersion,'motor-vru-v2');assert.equal(s.episodes.length,12*s.candidates.length*s.protocol.realizations);}
}
// Keep the unknown/zero distinction independent of measured real outcomes.
const mocked={candidates:[{id:'X'}],episodes:[{action:'X',split:'test',contacts:0,near:3,pedestrianNear:2,bicycleNear:1,reward:-15,travelers:10,vehicleContacts:0,delaySeconds:2}],bicycleNearMeasured:true};
assert.equal(Planner.totals(mocked)[0].bicycleNear,1);
assert.equal(Planner.totals({...mocked,bicycleNearMeasured:false})[0].bicycleNear,null);
const unknown=payload.junctions.find(j=>j.id==='J24283');
const hillcrest=payload.junctions.find(j=>j.id==='J02019');
const inputs=Planner.inputs(evidence,hillcrest);
assert.equal(inputs.intervals,56);
assert.equal(inputs.simulationReady,true);
assert.equal(inputs.recommendationPending,!Planner.site(evidence,hillcrest));
assert(inputs.movementChecks>=126);
assert.equal(inputs.candidates.length,6);
assert.equal(Planner.inputs(evidence,estates),null);
assert.equal(Planner.inputs(evidence,{...hillcrest,ll:estates.ll}),null);
assert.equal(Planner.preparation(hillcrest,null,inputs).find(r=>r.id==='demand').status,'Available — direct observations');
const TrafficCSV=require('../traffic_csv.js');
const countsBuffer=fs.readFileSync('hosted_map/out/'+inputs.csvPath);
assert.equal(require('node:crypto').createHash('sha256').update(countsBuffer).digest('hex'),inputs.csvSha256);
const counts=TrafficCSV.validate(countsBuffer.toString(),'J02019');
assert.equal(counts.ok,true,JSON.stringify(counts.errors));
assert.equal(counts.intervals,56);
assert.equal(counts.records.length,2688);
assert.deepEqual(counts.totalsByStatus.observed,inputs.totals);
assert.equal(TrafficCSV.validate(countsBuffer.toString(),'J01145').ok,false);
assert.equal(Planner.site(evidence,unknown),null);
assert.equal(Planner.preparation(unknown,null).find(r=>r.id==='features').status,'Not downloaded here');
assert.equal(Planner.preparation(unknown,null).find(r=>r.id==='evaluation').status,'Not run for this site');
assert(Planner.proposals(unknown,null).find(r=>r.id==='speed').reason.includes('Verify current limits'));
for(const file of ['hosted_map/out/index.html','hosted_map/out/metadrive-lab.html']){
 const html=fs.readFileSync(file,'utf8');
 for(const match of html.matchAll(/<script(?:\s[^>]*)?>(.*?)<\/script>/gs))if(match[1].trim())new vm.Script(match[1]);
 assert(!html.includes('/*MITIGATION_INTEGRATION*/'));
}
console.log('Passed: exact site binding, source CSV reconciliation, reward scope, fixed policy, measured vs unknown bicycle metrics, and published script syntax.');
