"""Checks that protect label timing, uncertain cases, and speed-scenario arithmetic."""
import json
import unittest
import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point
from intersection_prediction import (BASE_FEATURES,FEATURES,hour_band,road_key,
    feature_year,match_cases,scenario_rows,probability,predict_export,OUT,load_prepared)


class IntersectionChecks(unittest.TestCase):
    def test_hour_boundaries(self):
        self.assertEqual([hour_band(h) for h in [0,5,6,8,9,11,12,14,15,17,18,23,np.nan]],
                         [0,0,1,1,2,2,3,3,4,4,5,5,-1])

    def test_history_never_uses_target_or_future(self):
        j=pd.DataFrame(np.ones((1,10)),columns=BASE_FEATURES[:10])
        c=np.zeros((1,12,6));u=np.zeros_like(c,dtype=bool)
        c[0,0,1]=3;c[0,1,1]=3;c[0,2,2]=3
        x=feature_year(j,c,u,2017)
        c[:,3:,:]=999
        np.testing.assert_array_equal(x,feature_year(j,c,u,2017))
        self.assertEqual(x[1,11],2);self.assertEqual(x[2,11],1)
        self.assertEqual(x.shape,(6,len(FEATURES)))

    def test_unknown_time_and_unresolved_location_exclude_zero_labels(self):
        j=gpd.GeoDataFrame({'names':[['PRESTON AV','S VASCO RD']],'city':['LIVERMORE']},
                           geometry=[Point(-121.722721,37.706218)],crs=4326).to_crs(26910)
        c=pd.DataFrame([{'CASE_ID':1,'coordinate_screen_pass':True,'longitude':-121.7227,
            'latitude':37.70619,'PRIMARY_RD':'PRESTON AVENUE','SECONDARY_RD':'S VASCO ROAD',
            'hour':np.nan,'INTERSECTION':'Y','year':2017,'CITY':'LIVERMORE','DISTANCE':0},
            {'CASE_ID':2,'coordinate_screen_pass':False,'longitude':np.nan,'latitude':np.nan,
            'PRIMARY_RD':'LOST ROAD','SECONDARY_RD':'UNKNOWN STREET','hour':15,
            'INTERSECTION':'Y','year':2018,'CITY':'LIVERMORE','DISTANCE':0}])
        audit,count,unknown,members=match_cases(j,c)
        self.assertEqual(audit.junction_index.notna().sum(),1)
        self.assertEqual(count.sum(),0)
        self.assertTrue(unknown[0,3,:].all())
        self.assertTrue(unknown[0,4,4]);self.assertFalse(unknown[0,4,0])

    def test_speed_change_only_changes_selected_road_summaries(self):
        x=np.arange(6*19,dtype=float).reshape(6,19);original=x.copy()
        roads=[{'speeds':[45,45]},{'speeds':[25,None]}]
        edited=scenario_rows(x,roads,0,20)
        np.testing.assert_allclose(edited[:,0],65/3)
        np.testing.assert_allclose(edited[:,1],25)
        np.testing.assert_array_equal(edited[:,2:],x[:,2:])
        np.testing.assert_array_equal(x,original)
        self.assertEqual(roads[0]['speeds'],[45,45])

    def test_annual_probability_is_union_not_sum(self):
        mu=np.array([.01,.02,.03,.04,.05,.06])
        self.assertAlmostEqual(float(probability(mu.sum())),1-np.prod(1-probability(mu)))
        self.assertLess(probability(mu.sum()),probability(mu).sum())

    def test_saved_inventory_and_preston_case(self):
        j,counts,unknown=load_prepared()
        a=pd.read_csv(OUT/'case_assignment_audit.csv')
        self.assertTrue(j.junction_id.is_unique);self.assertTrue(a.case_id.is_unique)
        self.assertEqual(counts.shape,(len(j),12,6))
        r=a.loc[a.case_id.eq(8524954)].iloc[0]
        self.assertEqual(r.match_method,'within_500ft_area')
        self.assertEqual(j.iloc[int(r.junction_index)]['name'],'PRESTON AV / S VASCO RD')
        self.assertGreater(int((counts.sum(axis=(1,2))==0).sum()),0)
        self.assertEqual(road_key('Preston Avenue'),'PRESTON AV')

    def test_radius_includes_midblock_and_overlapping_areas_once_each(self):
        j=gpd.GeoDataFrame({'city':['LIVERMORE']*3,'coverage_complete':[True,True,False]},
            geometry=[Point(600000,4170000),Point(600100,4170000),Point(600150,4170000)],crs=26910)
        points=gpd.GeoSeries([Point(600000,4170000),Point(599847.59,4170000)],crs=26910).to_crs(4326)
        c=pd.DataFrame([{'CASE_ID':i+1,'coordinate_screen_pass':True,'longitude':p.x,
            'latitude':p.y,'hour':8,'INTERSECTION':'N','year':2022,'CITY':'LIVERMORE',
            'PRIMARY_RD':'Unmatched road','SECONDARY_RD':'Other reference'} for i,p in enumerate(points)])
        audit,count,unknown,members=match_cases(j,c)
        self.assertEqual(audit.area_memberships.tolist(),[3,0])
        self.assertEqual(len(members),3)
        self.assertFalse(members.duplicated(['case_id','junction_index']).any())
        np.testing.assert_array_equal(count[:,8,1],[1,1,1])
        self.assertTrue(unknown[2].all());self.assertFalse(unknown[:2].any())

    def test_screenshot_case_and_area_history_match_source(self):
        j,counts,unknown=load_prepared()
        a=pd.read_csv(OUT/'case_assignment_audit.csv')
        members=pd.read_csv(OUT/'case_area_membership.csv')
        row=a.loc[a.case_id.eq(81874171)].iloc[0]
        self.assertEqual(row.match_method,'within_500ft_area')
        self.assertLess(row.distance_m,8)
        area=members.loc[members.junction_index.eq(j.index[j.junction_id.eq('J00699')][0])]
        self.assertEqual(set(area.year),{2015,2022});self.assertEqual(len(area),2)
        self.assertIn(81874171,area.case_id.values)
        self.assertFalse(members.duplicated(['case_id','junction_index']).any())


if __name__=='__main__':unittest.main()
