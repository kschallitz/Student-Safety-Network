import unittest
import numpy as np
from ten_year_model import history_window, pooled_raw, calibrated_rates, calibration_fit, make_baseline
from intersection_prediction import probability

class TenYearChecks(unittest.TestCase):
    def test_full_window_excludes_target_future_and_oldest_years(self):
        c=np.arange(12).reshape(1,12,1)*np.ones((1,12,6));u=np.zeros(c.shape,bool)
        count,years,window=history_window(c,u,2026)
        np.testing.assert_array_equal(count,np.full((1,6),sum(range(2,12))))
        np.testing.assert_array_equal(years,np.full((1,6),10));self.assertEqual(window,(2016,2025))
        before=history_window(c,u,2021);c[:,7:]=999
        after=history_window(c,u,2021)
        np.testing.assert_array_equal(before[0],after[0]);self.assertEqual(after[2],(2014,2020))
        np.testing.assert_array_equal(after[1],np.full((1,6),7))

    def test_unknown_year_is_neither_a_zero_nor_exposure(self):
        c=np.zeros((1,12,6));u=np.zeros(c.shape,bool);c[0,5,1]=7;u[0,5,1]=True
        count,years,_=history_window(c,u,2026)
        self.assertEqual(count[0,1],0);self.assertEqual(years[0,1],9);self.assertEqual(years[0,0],10)
        u[:]=True
        count,years,_=history_window(c,u,2026)
        self.assertEqual(count.sum(),0);self.assertEqual(years.sum(),0)

    def rows(self,years,count=0):
        return np.c_[np.zeros((6,10)),np.full(6,count),np.full(6,years),np.eye(6),np.zeros(6)]

    def test_more_known_zero_years_reduce_risk_but_never_force_zero(self):
        m=make_baseline(np.repeat(.05,6),['TEST'],3)
        short=pooled_raw(m,self.rows(3));long=pooled_raw(m,self.rows(10))
        self.assertTrue((long<short).all());self.assertTrue((long>0).all())
        np.testing.assert_allclose(pooled_raw(m,self.rows(0)),.05)
        np.testing.assert_allclose(long,(0+3*.05)/(10+3))
        self.assertTrue((pooled_raw(m,self.rows(10,1))>long).all())

    def test_annual_calibration_preserves_union_and_positive_order(self):
        m=make_baseline(np.repeat(.05,6),['TEST'],3);m['calibration']=[-.2,1.2]
        x=self.rows(10);rates=calibrated_rates(m,x);raw=pooled_raw(m,x)
        self.assertAlmostEqual(rates.sum(),np.exp(-.2)*raw.sum()**1.2)
        self.assertAlmostEqual(probability(rates.sum()),1-np.prod(1-probability(rates)))
        self.assertGreater(calibrated_rates(m,self.rows(10,1)).sum(),rates.sum())
        with self.assertRaises(ValueError):calibrated_rates(m,x[:5])

    def test_calibration_fitted_on_separate_data_corrects_overprediction(self):
        raw=np.repeat(.4,1000);y=np.r_[np.ones(100),np.zeros(900)]
        a,b=calibration_fit(raw,y)
        self.assertAlmostEqual(float(probability(np.exp(a)*.4**b)),.1,places=5)

if __name__=='__main__':unittest.main()
