const assert=require('node:assert/strict'),CSV=require('../traffic_csv.js'),P=require('../mitigation_planner.js');
const header=CSV.HEADERS.join(',');
const row=['J00699','Test intersection','2026-10-09','07:30','15','GARAVENTA RANCH RD','N VASCO RD','passenger','12','observed','Synthetic QA fixture','Not field counts'];
const csv=r=>header+'\r\n'+r.map(c=>c.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(',')).join('\r\n');
const check=r=>CSV.validate(csv(r),'J00699');
let accepted=check([row]);assert(accepted.ok);assert.equal(accepted.records[0].count,12);assert.equal(accepted.simulationReady,false);assert(accepted.warnings.some(w=>w.includes('Missing modes')));
assert(!CSV.validate(csv([row]),'J01145').ok);
for(const [field,value] of [['count',''],['count','-1'],['count','1.5'],['count','NaN'],['count_date','2026-02-30'],['count_date','invalid'],['start_local','24:00'],['start_local','07:31'],['duration_minutes','60'],['mode','any'],['measurement_status',''],['source',''],['approach_road','']]){
 const invalid=[...row];invalid[CSV.HEADERS.indexOf(field)]=value;assert(!check([invalid]).ok,field+' '+value);
}
assert(!check([row,row]).ok);
const zero=[...row];zero[8]='0';assert.equal(check([zero]).records[0].count,0);
const quoted=[...row];quoted[10]='Test, "quoted"\nsource';assert.equal(check([quoted]).records[0].source,quoted[10]);
assert(!CSV.validate(header+'\n"unclosed','J00699').ok);
assert(!CSV.validate(header+'\n','J00699').ok);
assert(CSV.validate('\uFEFF'+csv([row]),'J00699').ok);
const estimated=[...row];estimated[7]='bicycle';estimated[8]='3';estimated[9]='estimated';
accepted=check([row,estimated]);assert.equal(accepted.totalsByStatus.observed.bicycle,null);assert.equal(accepted.totalsByStatus.estimated.passenger,null);assert.equal(accepted.totalsByStatus.estimated.bicycle,3);
const proposals=P.proposals({approaches:[{speeds:[45]}]},null);
for(const id of ['speed_humps','crossing_guard']){const p=proposals.find(p=>p.id===id);assert.equal(p.simulationStatus,'not_implemented');assert(p.requiredInputs.length>4);}
console.log('Passed CSV intake: quoted/BOM fields, matching site, valid dates/times, count and source checks, duplicates, explicit zeros, missing modes/status separation, and pending treatment status.');
