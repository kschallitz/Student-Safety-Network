import unittest
import pandas as pd
from city_collision_forecast import origin_rows,NUMERIC

class ChronologicalForecastTests(unittest.TestCase):
    def setUp(self):
        self.monthly=pd.DataFrame({'city':'Test area','month':pd.date_range('2020-01-01','2025-12-01',freq='MS'),'count':2})

    def test_target_year_outcomes_cannot_change_any_forecast_feature(self):
        before=origin_rows(self.monthly,'2025-01-01','2025-01-01')
        poisoned=self.monthly.copy();poisoned.loc[poisoned.month.dt.year.eq(2025),'count']=999999
        after=origin_rows(poisoned,'2025-01-01','2025-01-01')
        pd.testing.assert_frame_equal(before[['city','month','feature_cutoff','recent_rate','long_rate']+NUMERIC],
                                      after[['city','month','feature_cutoff','recent_rate','long_rate']+NUMERIC])
        self.assertTrue(after.actual.eq(999999).all())
        self.assertTrue(after.feature_cutoff.lt(after.month).all())

    def test_future_gap_freezes_history_and_does_not_make_up_outcomes(self):
        rows=origin_rows(self.monthly,'2026-01-01','2026-10-01')
        self.assertEqual(len(rows),12)
        self.assertEqual(rows.month.max(),pd.Timestamp('2027-09-01'))
        self.assertTrue(rows.actual.isna().all())
        self.assertTrue(rows.feature_cutoff.eq(pd.Timestamp('2025-12-31')).all())
        self.assertTrue(rows.recent_rate.eq(2).all())

    def test_no_history_is_not_treated_as_zero_exposure(self):
        with self.assertRaisesRegex(ValueError,'Incomplete history'):
            origin_rows(self.monthly,'2020-06-01','2020-06-01')

    def test_target_before_feature_cutoff_rejected(self):
        with self.assertRaisesRegex(ValueError,'Target precedes'):
            origin_rows(self.monthly,'2025-01-01','2024-01-01')

if __name__=='__main__':unittest.main()
