"""Leakage and provenance checks; synthetic perturbations stay inside tests."""
import copy
import json
from pathlib import Path
import unittest
import numpy as np
import pandas as pd
import torch
from severity_experiment import (severity_frame, prepare_severity_splits, fit_severity_models,
                                 SEVERITY_FEATURES, validation_threshold)

ROOT = Path(__file__).resolve().parents[1]

class SeverityIntegrityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = json.loads((ROOT/'data/raw/collisions.geojson').read_text())
        cls.frame = severity_frame(cls.source)

    def test_real_case_counts_and_disjoint_temporal_split(self):
        parts, _, _, y = prepare_severity_splits(self.frame)
        self.assertEqual([(len(parts[s]), int(y[s].sum())) for s in parts], [(463,31),(175,16),(195,10)])
        self.assertEqual(sum(len(p) for p in parts.values()), self.frame.case_id.nunique())
        self.assertLess(parts['train'].date.max(), parts['validation'].date.min())
        self.assertLess(parts['validation'].date.max(), parts['test'].date.min())

    def test_missing_outcome_and_duplicate_case_rejected(self):
        bad = copy.deepcopy(self.source)
        bad['features'][0]['properties']['COLLISION_SEVERITY'] = None
        with self.assertRaises(ValueError):
            severity_frame(bad)
        bad = copy.deepcopy(self.source)
        bad['features'].append(bad['features'][0])
        with self.assertRaises(ValueError):
            severity_frame(bad)

    def test_report_outcomes_cannot_enter_predictors(self):
        bad = copy.deepcopy(self.source)
        for f in bad['features']:
            f['properties']['NUMBER_KILLED'] = 999
            f['properties']['NUMBER_INJURED'] = 999
            f['properties']['COUNT_SEVERE_INJ'] = 999
            f['properties']['COLLISION_SEVERITY'] = 1
        changed = severity_frame(bad)
        pd.testing.assert_frame_equal(self.frame[SEVERITY_FEATURES], changed[SEVERITY_FEATURES])
        self.assertNotIn('year', SEVERITY_FEATURES)
        self.assertNotIn('case_id', SEVERITY_FEATURES)

    def test_holdout_values_cannot_change_fitted_preprocessor(self):
        _, original, x1, _ = prepare_severity_splits(self.frame)
        changed = self.frame.copy()
        holdout = changed.split.ne('train')
        changed.loc[holdout,'longitude'] = 100000
        changed.loc[holdout,'weather'] = 'NEVER_SEEN'
        _, altered, x2, _ = prepare_severity_splits(changed)
        np.testing.assert_array_equal(x1['train'], x2['train'])
        np.testing.assert_array_equal(original.named_transformers_['numeric']['scale'].mean_,
                                      altered.named_transformers_['numeric']['scale'].mean_)
        self.assertNotIn('NEVER_SEEN', altered.named_transformers_['categorical'].categories_[0])

    def test_missing_hhmm_not_interpreted_as_midnight(self):
        bad = copy.deepcopy(self.source)
        bad['features'][0]['properties']['COLLISION_TIME'] = 9999
        changed = severity_frame(bad).set_index('case_id')
        case = str(bad['features'][0]['properties']['CASE_ID'])
        self.assertTrue(np.isnan(changed.loc[case,'hour_sin']))

    def test_training_function_rejects_test_arrays(self):
        _, _, x, y = prepare_severity_splits(self.frame)
        with self.assertRaisesRegex(ValueError,'Test data'):
            fit_severity_models(x,y,max_epochs=1)

    def test_seeding_before_initialization_reproduces_weights(self):
        rng = np.random.default_rng(7)
        x = {'train':rng.normal(size=(20,3)).astype('float32'), 'validation':rng.normal(size=(10,3)).astype('float32')}
        y = {'train':np.array([0,1]*10), 'validation':np.array([0,1]*5)}
        a = fit_severity_models(x,y,max_epochs=5)
        b = fit_severity_models(x,y,max_epochs=5)
        for key,value in a['neural_network'].state_dict().items():
            self.assertTrue(torch.equal(value,b['neural_network'].state_dict()[key]))

    def test_threshold_uses_validation_outcomes(self):
        threshold = validation_threshold(np.array([0,0,1,1]),np.array([.1,.2,.3,.4]))
        self.assertAlmostEqual(threshold,.3)

if __name__ == '__main__':
    unittest.main()
