import copy
import json
from pathlib import Path
import unittest
import geopandas as gpd
from shapely.geometry import LineString, Point
from road_speed_features import prepare_road_speeds, school_speed_context, scenario_road_inputs

ROOT = Path(__file__).resolve().parents[1]


class RoadSpeedsTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        raw = ROOT / 'data/road_speeds/raw'
        cls.source = json.loads((raw / 'street_centerlines.geojson').read_text())
        cls.manifest = json.loads((raw / 'manifest.json').read_text())

    def test_source_and_semantics(self):
        roads, audit = prepare_road_speeds(self.source, self.manifest)
        self.assertEqual(audit['segments'], 4045)
        self.assertEqual(audit['posted_speed_populated'], 921)
        self.assertEqual(audit['posted_speed_unknown'], 3124)
        self.assertEqual(audit['posted_dispatch_disagreements'], 34)
        self.assertTrue(roads.loc[roads.PostedSpeedLimit.isna(), 'posted_speed_mph'].isna().all())
        self.assertTrue(roads.speed_effective_from.isna().all())
        self.assertFalse(roads.historical_speed_verified.any())
        self.assertFalse(audit['causal_effect_estimated'])

    def test_duplicate_ids_rejected(self):
        source = copy.deepcopy(self.source)
        source['features'][1]['properties']['OBJECTID'] = source['features'][0]['properties']['OBJECTID']
        with self.assertRaisesRegex(ValueError, 'unique'):
            prepare_road_speeds(source, self.manifest)

    def test_scenario_preserves_observations_and_rejects_unknown(self):
        roads, _ = prepare_road_speeds(self.source, self.manifest)
        row = roads.loc[roads.posted_speed_mph.gt(25)].iloc[0]
        result = scenario_road_inputs(roads, [row.segment_id], 25)
        self.assertEqual(int(result.scenario_changed.sum()), 1)
        self.assertTrue(result.posted_speed_mph.equals(roads.posted_speed_mph))
        self.assertTrue(result.dispatch_speed_mph.equals(roads.dispatch_speed_mph))
        unknown = roads.loc[~roads.posted_speed_known].iloc[0]
        with self.assertRaisesRegex(ValueError, 'Verify'):
            scenario_road_inputs(roads, [unknown.segment_id], 25)
        with self.assertRaises(ValueError):
            scenario_road_inputs(roads, ['unknown'], 25)

    def test_clipped_length_weighting_and_unknowns(self):
        # Synthetic geometry is only a unit-test fixture, never a real-data output.
        x, y = 620000, 4180000
        roads = gpd.GeoDataFrame({'Status': ['Active'] * 2, 'posted_speed_known': [True, False],
                                 'posted_speed_mph': [40., float('nan')]},
            geometry=[LineString([(x-200, y), (x+200, y)]),
                      LineString([(x, y), (x, y+50)])], crs='EPSG:26910')
        schools = gpd.GeoDataFrame({'school_id': ['test'], 'school_name': ['test']},
                                  geometry=[Point(x, y)], crs=roads.crs)
        result = school_speed_context(roads, schools, radius_metres=100).iloc[0]
        self.assertAlmostEqual(result.inventory_road_km, .25)
        self.assertAlmostEqual(result.known_posted_length_share, .8)
        self.assertAlmostEqual(result.length_weighted_posted_mph, 40.)
        self.assertAlmostEqual(result.unknown_posted_road_km, .05)


if __name__ == '__main__':
    unittest.main()
