"""Synthetic fixtures used only to test missingness, overlap, and interval semantics."""
import unittest
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from livermore_prototype import *
from shapely.geometry import Point

class IntegrityTests(unittest.TestCase):
    def daily(self):
        return pd.DataFrame([dict(school_id='001',date='2024-10-01',time_window='07:30-08:30',direction='arrival',
            walk=10,bike=2,private_car=5,carpool=1,school_bus=0,transit=0,other=0,total_observed=18,
            coverage_status='observed_complete',source_url='https://example.test/observation')])

    def test_missing_counts_are_not_zero_labels(self):
        d=self.daily();d.loc[0,'walk']=np.nan
        out=validate_daily_tallies(d,{'001'})
        self.assertTrue(pd.isna(out.loc[0,'walk']))
        self.assertFalse(out.loc[0,'usable_count_label'])

    def test_invalid_denominator_rejected(self):
        d=self.daily();d.loc[0,'total_observed']=20
        with self.assertRaises(ValueError):validate_daily_tallies(d,{'001'})

    def test_duplicate_observation_rejected(self):
        with self.assertRaises(ValueError):validate_daily_tallies(pd.concat([self.daily()]*2),{'001'})

    def test_missing_date_rejected(self):
        d=self.daily();d.loc[0,'date']=None
        with self.assertRaises(ValueError):validate_daily_tallies(d,{'001'})

    def test_leading_zero_school_ids_preserved(self):
        out=validate_daily_tallies(self.daily(),{'001'})
        self.assertEqual(out.loc[0,'school_id'],'001')
        self.assertTrue(out.loc[0,'usable_count_label'])

    def closure(self):
        return pd.DataFrame([dict(event_id='test-1',site_id='site',actual_start='2024-10-01',
            actual_end='2024-10-02',date_kind='verified_actual',lane_closure='unknown',
            sidewalk_closure='unknown',crosswalk_closure='unknown',source_url='https://example.test/closure')])

    def test_planned_dates_cannot_be_actual(self):
        d=self.closure();d.loc[0,'date_kind']='planned_completion'
        with self.assertRaises(ValueError):validate_closures(d,{'site'})

    def test_unknown_end_date_cannot_be_actual(self):
        d=self.closure();d.loc[0,'actual_end']=None
        with self.assertRaises(ValueError):validate_closures(d,{'site'})

    def test_overlapping_school_buffers_keep_one_city_case(self):
        schools=gpd.GeoDataFrame({'school_id':['001','002'],'school_name':['A','B'],
            'open_date':pd.to_datetime(['2000-01-01']*2)},geometry=[Point(-121.77,37.68),Point(-121.7701,37.68)],crs=4326)
        collisions=gpd.GeoDataFrame({'case_id':['c'],'date':pd.to_datetime(['2024-01-01']),
            'mode':['Pedestrian'],'severity':['Visible injury']},geometry=[Point(-121.77,37.68)],crs=4326)
        pairs,summary=school_proximity(schools,collisions,800)
        self.assertEqual(len(pairs),2);self.assertEqual(pairs.case_id.nunique(),1)
        self.assertEqual(summary.recorded_collisions_within_radius.tolist(),[1,1])

    def test_interval_edges_inclusive_and_gap_excluded(self):
        c=gpd.GeoDataFrame({'case_id':['before','start','end','gap'],
            'date':pd.to_datetime(['2024-09-30','2024-10-01','2024-10-02','2024-10-03'])},
            geometry=[Point(-121.77,37.68)]*4,crs=4326)
        p=gpd.GeoDataFrame({'site_id':['site']},geometry=[Point(-121.77,37.68)],crs=4326)
        d=validate_closures(self.closure(),{'site'})
        matched=closure_collision_matches(c,p,d)
        self.assertEqual(set(matched.case_id),{'start','end'})

    def test_snapshot_counts_and_unknown_students(self):
        import json
        p=json.loads((Path(__file__).resolve().parents[1]/'data/processed/embedded_snapshot.json').read_text())
        schools,raw,c,projects,b=prepare_sources(p)
        self.assertEqual((len(schools),len(raw),len(c)),(18,833,179))
        self.assertEqual((int(c.pedestrian.sum()),int(c.bicycle.sum())),(70,110))
        self.assertTrue(c.student_status.isna().all())
        self.assertTrue(projects.actual_start.isna().all())
        self.assertEqual(len(p['planned_schedules']),8)
        self.assertEqual([r for r in p['travel_evidence'] if r['school_name']=='Granada High'][0]['observation_years'],[])

if __name__=='__main__':unittest.main()
