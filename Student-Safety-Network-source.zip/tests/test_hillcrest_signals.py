import unittest
from types import SimpleNamespace
from metadrive_intersections.hillcrest_signals import SignalPlan

class SignalClearanceTests(unittest.TestCase):
    def test_occupied_junction_holds_conflicting_green(self):
        s=SignalPlan()
        car={'record':{'mode':'passenger'},'started':False,'signal_entered':True,
             's':110.,'route':SimpleNamespace(s=[0.,100.,140.,240.]),
             'obj':SimpleNamespace(LENGTH=4.5)}
        s.observe(13.,[car])
        self.assertEqual(s.phase(13.)[0],'all_red')
        self.assertFalse(s.vehicle_green({'from_arm':'W','to_arm':'E'},13.))
        self.assertFalse(s.pedestrian_walk('S',13.))
        car['s']=144.
        s.observe(20.,[car])
        self.assertTrue(s.vehicle_green({'from_arm':'W','to_arm':'E'},20.))
        self.assertEqual(s.clearance_holds,[{'start':13.,'end':20.,'seconds':7.}])

    def test_started_walker_clears_but_waiting_red_walker_does_not_hold(self):
        s=SignalPlan();p={'record':{'mode':'pedestrian'},'started':True}
        s.observe(13.,[p]);self.assertEqual(s.phase(13.)[0],'all_red')
        p['started']=False
        s.observe(15.,[p]);self.assertEqual(s.phase(15.)[0],'EW_through')

if __name__=='__main__':unittest.main()
