"""Synthetic verification fixtures, never source evidence or model training data."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pandas as pd
from school_forecast_enrichment import enrich_public_crashes,load_traffic_citations,CITATION_COLUMNS


def inputs():
    crashes=pd.DataFrame([{'case_id':'one','Report Number':'agency-123','missing_coordinates':True,'valid_coordinates':False}])
    evidence={'roads':[{'Collision Id':'one','Report Number':'agency-123','NCIC Code':'0100',
        'PrimaryRoad':'FIRST ST','SecondaryRoad':'SECOND ST','SecondaryDistance':None,
        'SecondaryDirection':None,'SecondaryUnitOfMeasure':None,'PrimaryCollisionFactorIsCited':None}],
        'ages':[{'case_id':'one','pedbike_parties':1,'distinct_party_ids':1,'age_1_4':0,'age_5_17':0,
                 'age_18_19':0,'age_20_plus':0,'age_unknown':1}],
        'modes':[{'case_id':'one','mode_parties':1,'mode_distinct_party_ids':1,'pedestrian_parties':1,'bicycle_parties':0}]}
    return crashes,evidence


class EnrichmentTests(unittest.TestCase):
    def test_pedestrian_bicycle_and_both_flags_preserve_unique_cases(self):
        for ped,bike,label in [(1,0,'Pedestrian'),(0,1,'Bicycle'),(1,1,'Pedestrian + bicycle')]:
            c,e=inputs();e['modes'][0].update(pedestrian_parties=ped,bicycle_parties=bike)
            d,_,summary=enrich_public_crashes(c,e)
            self.assertEqual(len(d),1)
            self.assertEqual(d.loc[0,'collision_modes'],label)
            self.assertEqual(summary['pedestrian_involved_crashes']+summary['bicycle_involved_crashes']-summary['both_modes_crashes'],1)

    def test_missing_mode_inventory_is_not_guessed(self):
        c,e=inputs();e['modes'][0]['case_id']='different'
        with self.assertRaisesRegex(ValueError,'missing frozen-snapshot'):enrich_public_crashes(c,e)

    def test_absent_offset_is_not_an_intersection(self):
        c,e=inputs();d,queue,summary=enrich_public_crashes(c,e)
        self.assertEqual(d.loc[0,'location_recovery_status'],'Road pair; offset unresolved')
        self.assertEqual(summary['locations_recovered'],0)
        self.assertEqual(len(queue),1)

    def test_unknown_age_is_not_a_negative_and_young_age_is_not_student(self):
        c,e=inputs();d,_,_=enrich_public_crashes(c,e)
        self.assertTrue(pd.isna(d.loc[0,'reported_pedbike_age_5_17']))
        e['ages'][0]['age_unknown']=0;e['ages'][0]['age_5_17']=1
        d,_,_=enrich_public_crashes(c,e)
        self.assertTrue(d.loc[0,'reported_pedbike_age_5_17'])
        self.assertTrue(pd.isna(d.loc[0,'student_status']))

    def test_cause_code_does_not_create_citation(self):
        c,e=inputs();e['roads'][0]['Primary Collision Factor Violation']='VC 22350'
        d,_,s=enrich_public_crashes(c,e)
        self.assertTrue(pd.isna(d.loc[0,'crash_factor_marked_cited']))
        self.assertEqual(s['crash_factor_marked_cited'],0)
        self.assertFalse(s['all_enforcement_citations_available'])

    def test_report_id_mismatch_and_age_count_mismatch_rejected(self):
        for change in ['report','counts']:
            c,e=inputs()
            if change=='report':e['roads'][0]['Report Number']='different'
            else:e['ages'][0]['age_5_17']=1
            with self.assertRaises(ValueError):enrich_public_crashes(c,e)

    def test_placeholder_cross_street_not_counted_as_recovery_pair(self):
        c,e=inputs();e['roads'][0]['SecondaryRoad']='NOT STATED'
        _,_,s=enrich_public_crashes(c,e)
        self.assertEqual(s['missing_gps_with_usable_road_pair'],0)

    def test_matching_internal_id_preserves_missing_local_report_number(self):
        c,e=inputs();c.loc[0,'Report Number']=None;e['roads'][0]['Report Number']=None
        d,_,s=enrich_public_crashes(c,e)
        self.assertTrue(pd.isna(d.loc[0,'Report Number']))
        self.assertEqual(s['local_report_number_unknown'],1)

    def test_citation_import_requires_known_location_and_unique_event(self):
        row={'citation_id':'0001','agency':'Test Agency','issued_date':'2024-05-03',
            'violation_code':'test','violation_description':'Test fixture','latitude':37.72,'longitude':-121.73,
            'location_precision':'block','location_role':'stop','source_url':'https://example.test/data'}
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'fixture.csv';pd.DataFrame([row]).to_csv(p,index=False)
            d=load_traffic_citations(p)
            self.assertEqual(d.loc[0,'citation_id'],'0001')
            self.assertEqual(d.loc[0,'location_role'],'stop')
            pd.DataFrame([row,row]).to_csv(p,index=False)
            with self.assertRaises(ValueError):load_traffic_citations(p)
            row['latitude']=None;pd.DataFrame([row]).to_csv(p,index=False)
            with self.assertRaises(ValueError):load_traffic_citations(p)


if __name__=='__main__':unittest.main()
