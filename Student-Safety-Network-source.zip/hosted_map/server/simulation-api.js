const SITES={J01145:{site:'Estates',actions:8},J02019:{site:'Hillcrest',actions:6}};
const json=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{'content-type':'application/json','cache-control':'no-store'}});
const publicJob=r=>r?{id:r.id,junctionId:r.junction_id,site:r.site,status:r.status,createdAt:r.created_at,updatedAt:r.updated_at,realizations:r.realizations,trafficMode:r.realization_start===0?'saved':'fresh',completed:r.completed,total:r.total,message:r.message,result:r.result_json?JSON.parse(r.result_json):null}:null;
function validResult(r,job){
  return r&&r.junctionId===job.junction_id&&r.releaseChecked&&r.bicycleNearMeasured&&r.scoringVersion==='motor-vru-v2'&&
    typeof r.snapshot==='string'&&r.episodes?.length===job.total&&r.candidates?.some(c=>c.id===r.selected)&&
    r.protocol?.realizations===job.realizations&&r.protocol?.start_realization===job.realization_start&&
    new Set(r.episodes.map(e=>`${e.context}|${e.action}|${e.realization}`)).size===job.total&&
    r.episodes.every(e=>[e.contacts,e.near,e.bicycleNear,e.pedestrianNear,e.travelers].every(v=>Number.isInteger(v)&&v>=0)&&
      e.near===e.bicycleNear+e.pedestrianNear&&e.reward===-1000*e.contacts-5*e.near);
}
async function isWorker(request,env){
  const key=request.headers.get('x-simulation-worker-key');
  if(!key||!env.SIM_WORKER_KEY)return false;
  const enc=new TextEncoder();
  const [a,b]=await Promise.all([key,env.SIM_WORKER_KEY].map(k=>crypto.subtle.digest('SHA-256',enc.encode(k))));
  const x=new Uint8Array(a),y=new Uint8Array(b);let diff=0;for(let i=0;i<x.length;i++)diff|=x[i]^y[i];return diff===0;
}
export async function simulationApi(request,env){
  const url=new URL(request.url),path=url.pathname.replace('/api/simulation',''),now=Date.now();
  const worker=await isWorker(request,env),user=request.headers.get('oai-authenticated-user-id');
  // The host enforces owner-private access. Worker credentials grant no browser session.
  if(!worker&&!user)return json({error:'Sign in to this private site.'},401);
  if(request.method!=='GET'&&!worker){
    if(request.headers.get('origin')!==url.origin)return json({error:'Request must come from this site.'},403);
  }
  const body=async()=>{const text=await request.text();if(text.length>2500000)throw new Error('Request too large');return JSON.parse(text);};
  try{
    if(path==='/status'&&request.method==='GET'){
      const w=await env.DB.prepare('SELECT last_seen,job_id FROM sim_worker WHERE id = 1').first();
      return json({online:!!w&&now-w.last_seen<90000,lastSeen:w?.last_seen||null,jobId:w?.job_id||null,compute:'Mac worker',sites:Object.keys(SITES)});
    }
    if(path==='/jobs'&&request.method==='GET'){
      const id=url.searchParams.get('junction');if(!SITES[id])return json({error:'Unsupported intersection'},400);
      const {results}=await env.DB.prepare('SELECT * FROM sim_jobs WHERE junction_id = ? ORDER BY created_at DESC LIMIT 10').bind(id).all();
      let included=false;return json({jobs:results.map(r=>{const job=publicJob(r);if(job.status==='completed'&&!included)included=true;else job.result=null;return job;})});
    }
    if(path==='/jobs'&&request.method==='POST'){
      const b=await body(),site=SITES[b.junctionId];
      if(!site||!Number.isInteger(b.realizations)||b.realizations<1||b.realizations>30||!['saved','fresh',undefined].includes(b.trafficMode)||(b.trafficMode==='saved'&&b.realizations!==1))return json({error:'Choose a supported site and 1–30 matched realizations; reproducing saved arrivals uses one.'},400);
      // At most one waiting/running job per site, including double taps and retries.
      const existing=await env.DB.prepare("SELECT * FROM sim_jobs WHERE junction_id=? AND status IN ('queued','running') LIMIT 1").bind(b.junctionId).first();
      if(existing)return json({job:publicJob(existing),reused:true});
      const id=crypto.randomUUID(),start=b.trafficMode==='saved'?0:1+crypto.getRandomValues(new Uint32Array(1))[0];
      await env.DB.prepare("INSERT INTO sim_jobs(id,junction_id,site,status,created_at,updated_at,realizations,realization_start,completed,total,message) VALUES(?,?,?,'queued',?,?,?,?,0,?,'Waiting for simulation worker')").bind(id,b.junctionId,site.site,now,now,b.realizations,start,b.realizations*12*site.actions).run();
      return json({job:publicJob(await env.DB.prepare('SELECT * FROM sim_jobs WHERE id=?').bind(id).first())},201);
    }
    if(path==='/worker/claim'&&request.method==='POST'&&worker){
      const lease=crypto.randomUUID();
      // A lost worker lease is explicit and retryable; do not silently lose a job.
      await env.DB.prepare("UPDATE sim_jobs SET status='interrupted',message='Worker disconnected; start a new comparison to retry',updated_at=? WHERE status='running' AND updated_at < ?").bind(now,now-180000).run();
      const job=await env.DB.prepare("UPDATE sim_jobs SET status='running',lease=?,updated_at=?,message='Preparing matched simulations' WHERE id=(SELECT id FROM sim_jobs WHERE status='queued' ORDER BY created_at LIMIT 1) AND status='queued' RETURNING *").bind(lease,now).first();
      await env.DB.prepare('INSERT INTO sim_worker(id,last_seen,job_id) VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET last_seen=excluded.last_seen,job_id=excluded.job_id').bind(now,job?.id||null).run();
      return json({job:job?{...publicJob(job),lease,realizationStart:job.realization_start}:null});
    }
    if(path==='/worker/progress'&&request.method==='POST'&&worker){
      const b=await body(),job=await env.DB.prepare("SELECT * FROM sim_jobs WHERE id=? AND lease=? AND status='running'").bind(b.id,b.lease).first();
      if(!job)return json({error:'This worker no longer owns the job.'},409);
      if(!Number.isInteger(b.completed)||b.completed<0||b.completed>job.total)return json({error:'Invalid progress'},400);
      const status=['running','completed','failed'].includes(b.status)?b.status:'running';
      if(status==='completed'&&(!validResult(b.result,job)||b.completed!==job.total))return json({error:'A completed job needs checked site results and full accounting.'},400);
      await env.DB.prepare('UPDATE sim_jobs SET completed=?,status=?,message=?,result_json=?,updated_at=? WHERE id=? AND lease=?').bind(b.completed,status,String(b.message||'').slice(0,800),b.result?JSON.stringify(b.result):null,now,b.id,b.lease).run();
      await env.DB.prepare('UPDATE sim_worker SET last_seen=?,job_id=? WHERE id=1').bind(now,status==='running'?b.id:null).run();
      return json({ok:true});
    }
    return json({error:worker?'Route not found':'Worker authorization required'},worker?404:403);
  }catch(e){return json({error:String(e.message||e)},400);}
}
