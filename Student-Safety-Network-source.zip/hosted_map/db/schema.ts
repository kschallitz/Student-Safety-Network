import {sqliteTable,text,integer,uniqueIndex} from 'drizzle-orm/sqlite-core';
import {sql} from 'drizzle-orm';
export const jobs=sqliteTable('sim_jobs',{
 id:text('id').primaryKey(),junctionId:text('junction_id').notNull(),site:text('site').notNull(),status:text('status').notNull(),
 createdAt:integer('created_at').notNull(),updatedAt:integer('updated_at').notNull(),realizations:integer('realizations').notNull(),
 realizationStart:integer('realization_start').notNull(),completed:integer('completed').notNull(),total:integer('total').notNull(),
 message:text('message'),lease:text('lease'),resultJson:text('result_json')
},t=>[uniqueIndex('sim_one_active_site').on(t.junctionId).where(sql`${t.status} in ('queued','running')`)]);
export const worker=sqliteTable('sim_worker',{id:integer('id').primaryKey(),lastSeen:integer('last_seen').notNull(),jobId:text('job_id')});
