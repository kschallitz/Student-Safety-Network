CREATE TABLE `sim_jobs` (
	`id` text PRIMARY KEY NOT NULL,
	`junction_id` text NOT NULL,
	`site` text NOT NULL,
	`status` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	`realizations` integer NOT NULL,
	`realization_start` integer NOT NULL,
	`completed` integer NOT NULL,
	`total` integer NOT NULL,
	`message` text,
	`lease` text,
	`result_json` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `sim_one_active_site` ON `sim_jobs` (`junction_id`) WHERE "sim_jobs"."status" in ('queued','running');--> statement-breakpoint
CREATE TABLE `sim_worker` (
	`id` integer PRIMARY KEY NOT NULL,
	`last_seen` integer NOT NULL,
	`job_id` text
);
