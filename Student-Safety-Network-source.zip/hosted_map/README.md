# Simulation job API source

`server/simulation-api.js` and the D1 schema/migration implement the authenticated queue used by the live website. The browser controls live in the root `mitigation_jobs.js` and `mitigation_panel.js`; the Mac consumer is `metadrive_intersections/worker.py`.

The public source archive omits the managed hosting scaffold, deployment identifiers, credentials and rendered pages containing study records. This folder alone is not a deployable website. Integration requires a D1 `DB` binding, an independently configured `SIM_WORKER_KEY` secret, trusted server-injected user identity, and owner authentication. Never trust a client-supplied identity header on an unprotected deployment.

The queue test uses only synthetic fixtures and an in-memory SQLite database:

```sh
node tests/test_simulation_api.mjs
```

Run that command from the extracted archive root using Node 22.13 or newer.
