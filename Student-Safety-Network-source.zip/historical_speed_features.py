"""Auditable annual speed histories on a fixed contemporary road inventory.

This is an explicitly assumed annual continuity experiment, not sign-installation
history. Adoption years are withheld. Unmatched bounds and conflicting values
remain unknown. Crash labels/history are never edited by the speed pipeline.
"""
from pathlib import Path
import json, re
from functools import lru_cache
import numpy as np
import pandas as pd
import geopandas as gpd
import networkx as nx
from shapely.geometry import Point
from shapely.ops import unary_union
from scipy.spatial import cKDTree

OUT = Path('intersection_prediction_output')
HISTORY = Path('outputs/speed_history')
YEARS = np.arange(2014, 2027)
RULE = ('Annual continuity assumption: documented pre-change limits extend at most three full years backward; '
        'adopted limits continue through 2025 unless contradicted by another collected record. '
        'Unchanged Livermore 2020 survey corridors use 2017–2025; Pleasanton code snapshots carry '
        'forward from the next full year. Adoption years are excluded. Unknown installation dates '
        'and uncollected changes remain a limitation. Current 2026 GIS speeds are used only for map scenarios.')


def key(s):
    from intersection_prediction import road_key
    s = str(s).replace('Bvld', 'Blvd').replace('Collier Canyons', 'Collier Canyon')
    s = re.sub(r'SR\s*-?\s*84\s*\(([^)]+)\)', r'\1', s, flags=re.I)
    return road_key(s)


class CorridorMatcher:
    """Select a shortest connected same-road path between two named cross roads.

    Endpoint snapping is 4 m; cross-road tolerance is 30 m. Disconnected parallel
    carriageways are included only when a complete path independently connects
    both bounds and lies within 65 m of the primary path. No fuzzy name matching.
    """
    def __init__(self, roads):
        self.roads = roads.to_crs(26910).reset_index(drop=True)
        self.cache = {}

    def named(self, city, name):
        r = self.roads.loc[self.roads.city.eq(city.upper())]
        k = key(name)
        exact = r.loc[r.name.eq(k)]
        if re.match(r'^[NSEW] ',k): return exact
        # N/S qualifiers omitted in the source are allowed, but street suffixes
        # are never guessed. Spatial endpoints still determine the corridor.
        return r.loc[r.name.map(lambda n: re.sub(r'^[NSEW] ', '', n)).eq(k)]

    def match(self, city, road, limits):
        token = (city, road, limits)
        if token in self.cache: return self.cache[token]
        def done(ids, reason, **extra):
            ans = (ids, {'status':reason, **extra}); self.cache[token]=ans; return ans
        # Numeric offsets, city lines, waterways, railway and road-end limits need
        # separate verified geometries; never replace them with a nearby street.
        limits=re.sub(r'SR\s*-?\s*84\s*\(([^)]+)\)', r'\1', limits, flags=re.I)
        if re.search(r"\d|city limit|\bend\b|under\s*pass|canal|arroyo laguna|parking|north\)|south\)", limits, re.I):
            return done([], 'deferred: non-street or offset endpoint')
        bounds = re.split(r'\s+to\s+|\s+-\s+', limits.strip(), flags=re.I)
        if len(bounds)!=2 or '/' in limits or '(' in road:
            return done([], 'deferred: ambiguous endpoint or branch')
        target=self.named(city,road)
        if target.empty:return done([], 'unmatched road name')
        refs=[self.named(city,b) for b in bounds]
        if any(r.empty for r in refs):return done([], 'unmatched endpoint name')
        lines=list(target.geometry)
        if any(g.geom_type!='LineString' for g in lines):return done([], 'deferred: multipart road')
        ends=np.array([p for g in lines for p in [g.coords[0][:2],g.coords[-1][:2]]])
        from intersection_prediction import Union
        uf=Union(len(ends))
        for a,b in cKDTree(ends).query_pairs(4):uf.join(a,b)
        centers={i:ends[[k for k in range(len(ends)) if uf.find(k)==i]].mean(axis=0)
                 for i in set(uf.find(k) for k in range(len(ends)))}
        graph=nx.Graph()
        for i,g in enumerate(lines):
            a,b=uf.find(2*i),uf.find(2*i+1)
            if a!=b:graph.add_edge(a,b,weight=g.length,rows=[i])
        refgeom=[unary_union(list(r.geometry)) for r in refs]
        found=[]
        for comp in nx.connected_components(graph):
            nodes=list(comp); sub=graph.subgraph(comp)
            dist=np.array([[Point(centers[n]).distance(g) for n in nodes] for g in refgeom])
            if np.any(dist.min(axis=1)>30):continue
            candidates=[[nodes[i] for i,d in enumerate(ds) if d<=min(30,ds.min()+2)] for ds in dist]
            paths=[]
            for a in candidates[0]:
                for b in candidates[1]:
                    if a==b:continue
                    path=nx.shortest_path(sub,a,b,weight='weight')
                    length=nx.path_weight(sub,path,'weight')
                    if length<30:continue
                    rows=[v for u,w in zip(path,path[1:]) for v in sub[u][w]['rows']]
                    paths.append((length,rows))
            if paths:
                length,rows=min(paths,key=lambda x:x[0]); geom=unary_union([lines[i] for i in rows])
                found.append((length,rows,geom,float(dist[0].min()),float(dist[1].min())))
        if not found:return done([], 'unmatched: no complete bounded path')
        found.sort(key=lambda t:t[0]);primary=found[0]
        accepted=[f for f in found if .6*primary[0]<=f[0]<=1.6*primary[0] and f[2].hausdorff_distance(primary[2])<=65]
        rows=sorted(set(i for f in accepted for i in f[1]))
        return done(target.iloc[rows].sid.tolist(), 'matched', length_m=float(sum(lines[i].length for i in rows)),
                    endpoint_a= bounds[0],endpoint_b=bounds[1],endpoint_a_gap_m=primary[3],endpoint_b_gap_m=primary[4])


def records():
    """Only sourced limits; the carry-forward/backward periods are assumptions."""
    result=[]
    for r in pd.read_csv(HISTORY/'documented_speed_changes.csv').fillna('').to_dict('records'):
        cy=int(r['adoption_date'][:4]);r.update(kind='change',change_year=cy,priority=2)
        r['values']={y:(float(r['old_mph']) if y<cy and r['old_mph']!='' else float(r['new_mph']))
                     for y in range(max(2014,cy-3),2026) if y!=cy and (y>cy or r['old_mph']!='')}
        r['skip']=r['boundary_changed'] is True or str(r['boundary_changed']).lower()=='true'
        result.append(r)
    for r in pd.read_csv(HISTORY/'livermore_2019_2020_survey.csv').fillna('').to_dict('records'):
        if r['old_mph']!=r['new_mph']:continue # Already represented by the change ledger.
        r.update(kind='unchanged survey',priority=1,change_year=None,skip=False,
                 values={y:float(r['new_mph']) for y in range(2017,2026)})
        result.append(r)
    for r in pd.read_csv(HISTORY/'pleasanton_code_snapshots.csv').fillna('').to_dict('records'):
        sy=int(r['snapshot_month'][:4]);r.update(kind='code snapshot',priority=1,change_year=None,
            skip=bool(r['source_conflict']),values={y:float(r['posted_limit_mph']) for y in range(sy+1,2020 if sy==2016 else 2026)})
        # Independence boundaries changed again in 2016 and 2019; its textual
        # offset endpoints cannot be represented by this first matcher.
        if 'Independence' in r['road']:r['skip']=True
        result.append(r)
    return result


def build():
    from intersection_prediction import load_prepared
    roads=gpd.read_file(OUT/'road_inventory.geojson');matcher=CorridorMatcher(roads)
    j,counts,unknown=load_prepared();jp=j.to_crs(26910)
    rs=records();audit=[];sid_values={};sid_transition={};corridors=[]
    for r in rs:
        ids,detail=([],{'status':'deferred: source conflict or revised boundary'}) if r['skip'] else matcher.match(r['city'],r['road'],r['segment_limits'])
        r['segments']=ids
        audit.append({k:v for k,v in r.items() if k not in ['values','segments']}|detail|{'matched_segments':len(ids),'segment_ids':'|'.join(ids)})
        for sid in ids:
            for year,speed in r['values'].items():
                sid_values.setdefault((sid,year),[]).append((r['priority'],speed,r['record_id']))
            if r['change_year'] is not None:sid_transition.setdefault(sid,set()).add(r['change_year'])
        if ids:
            geom=unary_union(list(matcher.roads.loc[matcher.roads.sid.isin(ids)].geometry))
            corridors.append({'record_id':r['record_id'],'city':r['city'],'road':r['road'],'limits':r['segment_limits'],
                              'kind':r['kind'],'change_year':r['change_year'],'geometry':geom})
    pd.DataFrame(audit).to_csv(OUT/'historical_speed_match_audit.csv',index=False)
    corridor_frame=gpd.GeoDataFrame(corridors,crs=26910)
    corridor_frame.to_crs(4326).to_file(OUT/'historical_speed_corridors.geojson',driver='GeoJSON')
    resolved={};conflicts=[];annual=[]
    for (sid,year),vals in sid_values.items():
        p=max(v[0] for v in vals);used=[v for v in vals if v[0]==p];speeds=set(v[1] for v in used)
        speed=next(iter(speeds)) if len(speeds)==1 else np.nan
        # Transition exclusion always wins over another snapshot for that segment.
        if year in sid_transition.get(sid,set()):speed=np.nan
        if len(speeds)>1:conflicts.append({'sid':sid,'year':year,'values':str(sorted(speeds))})
        resolved[sid,year]=speed
        annual.append({'sid':sid,'year':year,'mph':speed,'basis':'assumed annual continuity from sourced records',
                       'records':'|'.join(sorted(set(v[2] for v in used)))})
    pd.DataFrame(annual).to_csv(OUT/'historical_segment_year_speeds.csv.gz',index=False)
    pd.DataFrame(conflicts,columns=['sid','year','values']).to_csv(OUT/'historical_speed_conflicts.csv',index=False)
    features=np.empty((len(j),len(YEARS),3));features[:]=[30,30,1]
    transition=np.zeros((len(j),len(YEARS)),dtype=bool)
    for c in corridors:
        cy=c['change_year']
        if cy in YEARS:
            close=jp.sindex.query(c['geometry'].buffer(152.4),predicate='intersects')
            transition[close,int(cy)-2014]=True
    support=[]
    for i,row in j.iterrows():
        sids=[s for a in row.approaches for s in a['segments']]
        for k,year in enumerate(YEARS[:-1]):
            vals=np.array([resolved.get((s,int(year)),np.nan) for s in sids]);known=vals[np.isfinite(vals)]
            if len(known):features[i,k]=[known.mean(),known.max(),1-len(known)/len(vals)]
        features[i,-1]=row[['speed_mean','speed_max','speed_unknown_share']].to_numpy(float)
        nearby=[]
        for k in corridor_frame.sindex.query(jp.geometry.iloc[i].buffer(152.4),predicate='intersects'):
            nearby.append(corridors[k]['record_id'])
        support.append({'junction_id':row.junction_id,'years_with_speed':int((features[i,:-1,2]<1).sum()),
                        'transition_years':[int(y) for y in YEARS[transition[i]]], 'records':nearby})
    np.savez_compressed(OUT/'historical_speed_panel.npz',features=features,transition=transition,
                        years=YEARS,junction_ids=j.junction_id.to_numpy(str))
    (OUT/'historical_speed_junction_support.json').write_text(json.dumps(support))
    byyear=[]
    for k,year in enumerate(YEARS[:-1]):
        byyear.append({'year':int(year),'junctions_with_historical_speed':int((features[:,k,2]<1).sum()),
                       'transition_areas_excluded':int(transition[:,k].sum()),
                       'otherwise_eligible_rows_excluded':int(((~unknown[:,k,:])&transition[:,k,None]).sum())})
    pd.DataFrame(byyear).to_csv(OUT/'historical_speed_coverage.csv',index=False)
    matched=[r for r in rs if r['segments']]
    summary={'version':'annual-speed-history-2026-09-26','rule':RULE,'input_records':len(rs),'matched_records':len(matched),
             'matched_changes':sum(r['kind']=='change' for r in matched),
             'matched_changes_with_old_and_new':sum(r['kind']=='change' and r['old_mph']!='' for r in matched),
             'changed_roads_by_city':pd.Series([r['city'] for r in matched if r['kind']=='change']).value_counts().to_dict(),
             'matched_segments':len(set(s for r in matched for s in r['segments'])),
             'junctions_with_any_historical_speed':int((features[:,:-1,2]<1).any(axis=1).sum()),
             'conflicting_segment_years':len(conflicts),'coverage':byyear,
             'not_reconstructed':'Historical road geometry, travel exposure, sign installation dates and uncollected amendments.',
             'deferred_rule':'Offsets, city limits, street ends, revised boundaries and ambiguous names are not guessed.'}
    (OUT/'historical_speed_summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k!='coverage'},indent=2))
    return summary


@lru_cache(maxsize=1)
def panel():
    with np.load(OUT/'historical_speed_panel.npz') as f:return {k:f[k] for k in f.files}


def year_features(j,year):
    p=panel(); assert np.array_equal(j.junction_id.to_numpy(str),p['junction_ids']), 'Speed panel / junction order mismatch'
    return p['features'][:,list(p['years']).index(year)]


def eligible(j,unknown,year):
    p=panel();assert np.array_equal(j.junction_id.to_numpy(str),p['junction_ids'])
    return ((~unknown[:,year-2014,:])&(~p['transition'][:,year-2014,None])).reshape(-1)


if __name__=='__main__':build()
