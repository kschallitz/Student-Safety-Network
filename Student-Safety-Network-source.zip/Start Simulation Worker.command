#!/bin/zsh
cd -- "${0:A:h}"
exec .venv-metadrive/bin/python -m metadrive_intersections.worker
