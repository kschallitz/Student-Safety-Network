"""Load the saved primary agent and execute its selected intervention in live SUMO."""
import json
import numpy as np
import torch
from environment import InterventionEnv
from train_agent import QNet
from experiment import OUT,ACTIONS

def main(seed=7102):
    ckpt=torch.load(OUT/'agent_collision_event.pt',map_location='cpu',weights_only=True)
    model=QNet();model.load_state_dict(ckpt['state_dict']);model.eval()
    env=InterventionEnv();state,info=env.reset(seed=seed)
    x=(state-np.array(ckpt['mean'],dtype=np.float32))/np.array(ckpt['std'],dtype=np.float32)
    with torch.no_grad():action=int(model(torch.tensor(x)[None]).argmax())
    _,reward,terminated,_,result=env.step(action)
    record={'chosen_context':info,'action':ACTIONS[action],'reward':reward,'complete':terminated,'sumo_result':result,'interpretation':'experimental simulator policy; not a field recommendation'}
    (OUT/'live_agent_demo.json').write_text(json.dumps(record,indent=2))
    print(json.dumps(record,indent=2))
    return result
if __name__=='__main__':main()
