"""Sensitivity of a small set of busy contexts; no refitting to post outcomes."""
from experiment import *

def main():
    rows=pd.read_csv(DATA/'east_avenue_observations_15min.csv');bins=pd.read_csv(DATA/'pre_speed_distributions.csv');ctx=pd.read_csv(DATA/'contexts.csv')
    ctx=ctx[ctx.complete & ctx.date.eq('2023-05-18') & ctx.clock.isin(['07:30','14:30'])]
    out=[]
    variants=[{'margin':.9,'radius':5.5},{'margin':2.7,'radius':5.5},{'margin':1.8,'radius':4},{'margin':1.8,'radius':7},{'step_length':.1},{'cycle':75},{'cycle':105}]
    for _,c in ctx.iterrows():
        for variant in variants:
            if 'cycle' in variant and c.site!='Hillcrest':continue
            for action in ['no_change','curb_extensions_proxy']:
                for seed in [901,902]:
                    out.append(run_episode(c.to_dict(),action,seed,rows,bins,variant=variant))
        print(c.interval_id,len(out),flush=True)
    pd.DataFrame(out).to_csv(OUT/'sensitivity_episodes.csv',index=False)
if __name__=='__main__':main()
