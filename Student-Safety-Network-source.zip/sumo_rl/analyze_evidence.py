"""Observed before/after evidence, simulation fidelity and transfer readiness."""
from experiment import *

def main():
    d=pd.read_csv(OBS/'speed_daily_summaries.csv');d['collection']=d.observation_date.str[:7]
    rng=np.random.default_rng(938);periods=[]
    for (coll,dr),g in d.groupby(['collection','travel_direction']):
        mean=np.average(g.mean_mph,weights=g.sample_count);arr=g[['mean_mph','sample_count']].to_numpy()
        draws=arr[rng.integers(0,len(g),size=(3000,len(g)))];bs=(draws[:,:,0]*draws[:,:,1]).sum(axis=1)/draws[:,:,1].sum(axis=1)
        periods.append({'collection':coll,'direction':dr,'days':len(g),'vehicles':int(g.sample_count.sum()),'mean_mph':mean,'day_bootstrap_low':np.quantile(bs,.025),'day_bootstrap_high':np.quantile(bs,.975),'measurement_status':'observed','processing_status':'count_weighted_rounded_daily_means'})
    p=pd.DataFrame(periods);p.to_csv(OUT/'observed_speed_comparison.csv',index=False)
    base=p[p.collection.eq('2023-02')].set_index('direction').mean_mph
    p['change_from_feb_mph']=p.mean_mph-p.direction.map(base);p.to_csv(OUT/'observed_speed_comparison.csv',index=False)
    # Training-input persistence forecast for exposure, compared with independent post counts.
    ctx=pd.read_csv(DATA/'contexts.csv');ctx=ctx[ctx.complete];ctx['weekend']=pd.to_datetime(ctx.date).dt.dayofweek.ge(5)
    pre=ctx[ctx.phase.eq('pre_installation')];post=ctx[ctx.phase.eq('post_installation')]
    pairs=post.merge(pre,on=['site','clock','weekend'],suffixes=('_actual','_forecast'),validate='one_to_one')
    for mode in ['motor','pedestrian','bicycle']:pairs[mode+'_error']=pairs[mode+'_count_forecast']-pairs[mode+'_count_actual']
    pairs.to_csv(OUT/'exposure_persistence_validation.csv',index=False)
    # Post hourly means not reported: midpoint estimates and bin-implied bounds remain estimated.
    bins=pd.read_csv(OBS/'speed_distributions.csv');bins['collection']=bins.observation_date.str[:7];bins['hour']=bins.interval_start.str[11:13].astype(int)
    vals=[]
    for (coll,dr,h),g in bins[bins.collection.isin(['2023-05','2023-06'])].groupby(['collection','travel_direction','hour']):
        # Source open-top bins produce no finite upper mean bound if populated.
        lo=g.speed_bin_lower_mph.to_numpy();hi=g.speed_bin_upper_mph.to_numpy();n=g['count'].to_numpy();positive=n>0
        mid=(lo+hi)/2
        vals.append({'collection':coll,'direction':dr,'hour':h,'actual_bin_midpoint_mean_mph':np.average(mid[positive],weights=n[positive]),'bin_implied_low_mph':np.average(lo[positive],weights=n[positive]),'bin_implied_high_mph':np.average(hi[positive],weights=n[positive]),'vehicles':int(n.sum()),'measurement_status':'estimated','processing_status':'speed_bin_midpoint_not_reported_hourly_mean'})
    actual=pd.DataFrame(vals);actual.to_csv(OUT/'post_speed_bin_estimates.csv',index=False)
    sim=pd.read_csv(OUT/'benchmark_episodes.csv');results=[]
    for action in ACTIONS:
        s=sim[sim.site.eq('Estates')&sim.split.eq('post_test')&sim.action.eq(action)&sim.date.eq('2023-05-18')].copy();s['hour']=s.clock.str[:2].astype(int)
        for hour,g in s.groupby('hour'):
            for dr in ['eastbound','westbound']:
                modeled=np.average(g[dr+'_mean_mph'],weights=g[dr+'_n'])
                for coll in ['2023-05','2023-06']:
                    a=actual[(actual.collection==coll)&(actual.direction==dr)&(actual.hour==hour)].iloc[0]
                    results.append({'action':action,'hour':hour,'direction':dr,'observed_speed_collection':coll,'simulated_mean_mph':modeled,'observed_bin_midpoint_mph':a.actual_bin_midpoint_mean_mph,'error_mph':modeled-a.actual_bin_midpoint_mean_mph,'bin_implied_low_mph':a.bin_implied_low_mph,'bin_implied_high_mph':a.bin_implied_high_mph,'within_bin_mean_bounds':bool(a.bin_implied_low_mph<=modeled<=a.bin_implied_high_mph),'comparison_limitation':'sim demand May18 vs speed May24-25/June2-7; virtual detector location approximate; pre speed parameters frozen'})
    comp=pd.DataFrame(results);comp.to_csv(OUT/'simulation_speed_validation.csv',index=False)
    transfer=[{'school':'East Avenue Middle','observed_inputs':'native 15-min motor/bike turns and pedestrian leg counts; four speed collections','what_is_trainable':'demand replay, pre-speed distribution, experimental simulator policy','intervention_effect_trainable':'not identified: one bundled intervention, unmatched days, no untreated control','geometry_status':'schematic; 2023 as-built dimensions and signal program missing','transfer_status':'simulation pilot; fails gate if speeds/operations mismatch','missing':'as-built survey, timing, observed yielding/trajectories, repeat counts, exposure-matched crash outcomes'}, {'school':'Christensen Middle','observed_inputs':'2019 Bluebell speed n108 mean28.6 p8532; TWO-lane collector vs East Avenue FOUR; corridor ADTs; 2023/24 statistic unspecified','what_is_trainable':'a coarse historical corridor speed prior after quality review','intervention_effect_trainable':'no; no dated comparable turning/crossing counts','geometry_status':'not configured from a site survey','transfer_status':'do not deploy East Avenue learned policy or risk percentage','missing':'arrival/dismissal movements, crossing legs, actual speed distributions, yielding and geometry'}, {'school':'Altamont Creek Elementary','observed_inputs':'2019 Garaventa speed n72 mean31.8 p8535; TWO-lane collector vs East Avenue FOUR; old/coarse ADTs; 2024 volumes N/A','what_is_trainable':'a coarse historical corridor speed prior after quality review','intervention_effect_trainable':'no; no contemporary intersection-period exposure','geometry_status':'not configured from a site survey','transfer_status':'do not deploy East Avenue learned policy or risk percentage','missing':'same contemporary exposure/geometry/behavior measurements as Christensen'}]
    pd.DataFrame(transfer).to_csv(DATA/'school_transfer_readiness.csv',index=False)
    metrics={'speed_validation_by_action':comp.groupby('action').error_mph.apply(lambda x:float(np.abs(x).mean())).to_dict(),'exposure_forecast_mae':{m:float(pairs[m+'_error'].abs().mean()) for m in ['motor','pedestrian','bicycle']},'exposure_forecast_matched_intervals':len(pairs),'post_speed_match_is_concurrent':False,'exact_as_built_intervention_available':False,'observed_before_after_collision_probability_available':False,'real_world_collision_probability_calibrated':False,'sites_approved_for_transfer':[]}
    (OUT/'evidence_results.json').write_text(json.dumps(metrics,indent=2));print(json.dumps(metrics,indent=2))
if __name__=='__main__':main()
