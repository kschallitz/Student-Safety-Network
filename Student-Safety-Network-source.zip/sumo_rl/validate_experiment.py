"""Independent artifact invariants and release gate. No claim of field validation."""
from pathlib import Path
import hashlib,json,os,re,xml.etree.ElementTree as ET
import numpy as np,pandas as pd
from experiment import ROOT,OBS,DATA,OUT,ACTIONS

def main():
    checks=[]
    def check(name,condition,detail=''):
        checks.append({'check':name,'passed':bool(condition),'detail':detail})
    rows=pd.read_csv(DATA/'east_avenue_observations_15min.csv');ctx=pd.read_csv(DATA/'contexts.csv');b=pd.read_csv(OUT/'benchmark_episodes.csv')
    raw=pd.concat([pd.read_csv(OBS/'turning_movements.csv'),pd.read_csv(OBS/'nonmotorized_crossings.csv')],ignore_index=True).set_index('observation_id')
    orig=rows.source_observation.map(raw['count'])
    check('every modeled-input count matches its cited native source cell',np.array_equal(orig,rows['count']))
    check('source observation identifiers unique',rows.source_observation.is_unique)
    check('heavy subset not double counted',not rows.source_observation.map(raw.mode_or_class).eq('heavy_vehicles_subset').any())
    check('counts nonnegative integers',rows['count'].ge(0).all()&(rows['count']%1==0).all())
    check('no incomplete source sessions used',b.complete.all())
    check('training and test seed sets disjoint',len(set(b[b.split=='train'].seed)&set(b[b.split=='post_test'].seed))==0)
    check('no post dates in policy training',set(b[b.split=='train'].date)=={'2023-03-02'})
    orig_speed=pd.read_csv(OBS/'speed_distributions.csv');orig_speed=orig_speed[orig_speed.observation_date.str.startswith('2023-02')].copy();orig_speed['hour']=orig_speed.interval_start.str[11:13].astype(int)
    expected_speed=orig_speed.groupby(['travel_direction','hour','speed_bin_lower_mph','speed_bin_upper_mph'],dropna=False)['count'].sum().reset_index()
    check('speed fit equals February pre-only source bins',expected_speed.equals(pd.read_csv(DATA/'pre_speed_distributions.csv')))
    counts=b.groupby(['interval_id','seed']).action.nunique()
    check('all four paired actions evaluated',counts.eq(4).all())
    expected=ctx[ctx.complete];n_expected=sum(12 if d=='2023-02-11' else 16 for d in expected.date)
    check('full declared experiment completed',len(b)==n_expected,f'{len(b)} / {n_expected} episodes')
    check('no teleport removal',b.teleports.eq(0).all())
    demand_hashes={}
    for _,r in b.iterrows():
        folder=ROOT/r.episode_path
        demand_hashes.setdefault((r.interval_id,r.seed),set()).add(hashlib.sha256((folder/'demand.rou.xml').read_bytes()).hexdigest())
        # Portable replay configuration derives from SUMO's own recorded run header.
        raw_config=re.search(r'<libsumoConfiguration.*?</libsumoConfiguration>',(folder/'collisions.xml').read_text(),re.S).group()
        el=ET.fromstring(raw_config);el.tag='configuration';el.attrib.clear()
        for name in ['net-file','route-files']:
            item=el.find('input/'+name);p=Path(item.get('value'))
            if p.is_absolute():item.set('value',os.path.relpath(p,folder))
        for item in el.findall('output/*'):
            item.set('value','replay_'+Path(item.get('value')).name)
        item=el.find('report/error-log')
        if item is not None:item.set('value','replay_warnings.log')
        ET.SubElement(el.find('time'),'end',value='1500')
        ET.ElementTree(el).write(folder/'replay.sumocfg',encoding='utf-8',xml_declaration=True)
        if not (folder/'result.json').exists():
            (folder/'result.json').write_text(json.dumps(r.to_dict(),indent=2,default=str))
    check('identical scheduled people, routes, departure times and speeds across paired actions',all(len(v)==1 for v in demand_hashes.values()))
    for school,exp in [('Christensen Middle',108),('Altamont Creek Elementary',72)]:
        speeds=pd.read_csv(DATA/'other_school_speed_bins_2019.csv');check(school+' speed-bin total',speeds.loc[speeds.school.eq(school),'count'].sum()==exp)
    for site in ['Estates','Hillcrest']:
        nets=[]
        for action in ['no_change','curb_extensions_proxy']:
            f=OUT/'networks_v2'/f'{site}_{action}_m1.8_r5.5_c90/network.net.xml';tr=ET.parse(f)
            lengths=[float(e[0].get('length')) for e in tr.findall('edge') if e.get('function')=='crossing' and 'E_in' in e.get('crossingEdges','')];nets.append(lengths[0])
        check(site+' curb proxy shortens modeled East crossing without deleting demand',nets[1]<nets[0],str(nets)+' metres; assumed dimensions')
    prod=ROOT/'intersection_prediction_output/model.json'
    if prod.exists():check('production collision model unchanged',hashlib.sha256(prod.read_bytes()).hexdigest()=='12d19ef2f8bd7ab047e50f3fa435c29c8a8bada6ff5d26fdd85c8ebf1f4c3818')
    evidence=json.loads((OUT/'evidence_results.json').read_text())
    release={'field_policy_release':'NOT_VALIDATED','exact_2023_reproduction':False,'real_collision_probability_calibration':False,'transfer_to_other_schools':False,'source_and_code_checks_passed':all(c['passed'] for c in checks),'unfinished_sumo_episodes':int(b.pending.gt(0).sum()),'reasons':['No exact 2023 as-built geometry / current signal plan','Collision-producing behavior and encounter surrogate not field-calibrated','Short nonconcurrent before/after exposure snapshots; no matched crash-probability outcome','Some proxy scenarios deadlock or generate collision artifacts; numerical sensitivity must be inspected','Two-lane Christensen/Altamont contexts lack site-period movement counts']}
    pd.DataFrame(checks).to_csv(OUT/'validation_checks.csv',index=False);(OUT/'release_gate.json').write_text(json.dumps(release,indent=2))
    print(json.dumps(release,indent=2));assert all(c['passed'] for c in checks),[c for c in checks if not c['passed']]
if __name__=='__main__':main()
