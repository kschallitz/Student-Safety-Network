from pathlib import Path
import json,xml.etree.ElementTree as ET
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np,pandas as pd
from experiment import OUT,ACTIONS
plt.rcParams.update({'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'font.size':11,'axes.titlesize':12})
C=['#196e86','#bd702a','#626970','#944e69']

def main():
    (OUT/'figures').mkdir(exist_ok=True)
    data=pd.read_csv(OUT/'observed_speed_comparison.csv')
    fig,ax=plt.subplots(figsize=(9,4.7))
    for i,(dr,g) in enumerate(data.groupby('direction')):
        x=np.arange(len(g))+(i-.5)*.08
        ax.errorbar(x,g.mean_mph,yerr=[g.mean_mph-g.day_bootstrap_low,g.day_bootstrap_high-g.mean_mph],fmt='o',capsize=5,color=C[i],label=dr.title())
    ax.set_xticks(range(4),['June 2022\nbefore','February 2023\nbefore','May 2023\nafter','June 2023\nafter*']);ax.set_ylabel('Observed mean speed (mph)');ax.set_ylim(30,38);ax.grid(axis='y',alpha=.2);ax.legend(frameon=False,ncols=2)
    ax.set_title('East Avenue measured speeds · Jensen–Estates corridor')
    fig.text(.02,.01,'Bars: 95% resampling range over measured days; only 2 May days. *June adjustment day unknown.\nNot a causal effect estimate; means weight rounded daily statistics by counts.',fontsize=9)
    fig.tight_layout(rect=(0,.10,1,1));fig.savefig(OUT/'figures/observed_speeds.png',dpi=160);plt.close(fig)
    s=pd.read_csv(OUT/'simulation_speed_validation.csv');s=s[s.observed_speed_collection.eq('2023-05')]
    fig,axs=plt.subplots(1,2,figsize=(11,4.7),sharey=True)
    for ax,dr in zip(axs,['eastbound','westbound']):
        base=s[(s.direction==dr)&(s.action=='no_change')].sort_values('hour')
        x=base.hour.to_numpy();ax.fill_between(x,base.bin_implied_low_mph,base.bin_implied_high_mph,color='#ddd',label='Observed-bin mean bounds')
        ax.plot(x,base.observed_bin_midpoint_mph,'ko--',label='Observed-bin midpoint estimate')
        for a,col,label in [('no_change',C[0],'SUMO unchanged'),('curb_extensions_proxy',C[1],'SUMO curb approximation')]:
            d=s[(s.direction==dr)&(s.action==a)].sort_values('hour');ax.plot(d.hour,d.simulated_mean_mph,'o-',color=col,label=label)
        ax.set_xticks([7,8,14,15,16,17],['7 AM','8 AM','2 PM','3 PM','4 PM','5 PM']);ax.set_title(dr.title());ax.grid(axis='y',alpha=.2);ax.set_ylim(22,40)
    axs[0].set_ylabel('Mean speed (mph)');handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,frameon=False,fontsize=9,loc='upper center',bbox_to_anchor=(.5,.9),ncols=2)
    fig.suptitle('Retrospective speed check · simulator parameters fitted from before data only')
    fig.text(.02,.015,'May 18 traffic demand versus May 24–25 corridor speeds: dates are not concurrent. Grey bounds reflect source binning, not confidence intervals.',fontsize=9)
    fig.tight_layout(rect=(0,.04,1,.78));fig.savefig(OUT/'figures/speed_validation.png',dpi=160);plt.close(fig)
    b=pd.read_csv(OUT/'benchmark_episodes.csv');a=pd.read_csv(OUT/'policy_choices_collision_event.csv');b=b[b.split=='post_test'];a=a[a.split=='post_test']
    groups=[b[b.action=='no_change'],a,b[b.action=='posted_25']];names=['No change','Collision-reward agent','Always 25 mph\n(post hoc comparator)']
    fig,ax=plt.subplots(figsize=(9,4.7));z=1.96
    for i,g in enumerate(groups):
        n=len(g);k=int(g.collision_event.sum());p=k/n;den=1+z*z/n;mid=(p+z*z/(2*n))/den;half=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
        ax.errorbar(p*100,i,xerr=[[100*(p-mid+half)],[100*(mid+half-p)]],fmt='o',capsize=5,color=C[i]);ax.annotate(f'{k}/{n}',(p*100,i),xytext=(5,9),textcoords='offset points')
    ax.set_yticks(range(3),names);ax.set_ylim(2.35,-.35);ax.set_xlim(0,4);ax.set_xlabel('SUMO VRU collision-event frequency per arrival batch (%)');ax.grid(axis='x',alpha=.2);ax.set_title('Held-out May contexts · rare simulator events')
    fig.text(.02,.015,'Bars: descriptive 95% Wilson intervals conditional on these simulations; shared contexts limit independence.\nNot field probabilities. The paired agent difference is also compatible with no improvement.',fontsize=9)
    fig.tight_layout(rect=(0,.11,1,1));fig.savefig(OUT/'figures/agent_comparison.png',dpi=160);plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(10,5))
    for ax,action in zip(axs,['no_change','curb_extensions_proxy']):
        t=ET.parse(OUT/'networks_v2'/f'Estates_{action}_m1.8_r5.5_c90/network.net.xml');j=t.find("junction[@id='J']");cx,cy=float(j.get('x')),float(j.get('y'))
        for edge in t.findall('edge'):
            for la in edge.findall('lane'):
                pts=np.array([[float(z) for z in q.split(',')] for q in la.get('shape').split()]);col='#9dabb2';w=1
                if edge.get('function')=='crossing':col=C[1];w=4
                elif la.get('allow')=='pedestrian':col='#c8c4b6'
                elif la.get('allow')=='authority':col='#d8dce0'
                else:col=C[0]
                ax.plot(pts[:,0]-cx,pts[:,1]-cy,color=col,linewidth=w)
        ax.set_xlim(-55,55);ax.set_ylim(-20,55);ax.set_aspect('equal');ax.set_title('Unchanged' if action=='no_change' else 'Curb approximation');ax.set_xlabel('Schematic metres');ax.grid(alpha=.1)
    axs[0].set_ylabel('Schematic metres');fig.suptitle('Estates SUMO network · assumed dimensions, not an as-built map')
    fig.text(.04,.02,'Blue: vehicle paths. Orange: crossings. Grey: sidewalk / unused roadside margin. East crossing: 16.4 → 12.8 m by assumption.',fontsize=9)
    fig.tight_layout(rect=(0,.05,1,.95));fig.savefig(OUT/'figures/network_schematic.png',dpi=160);plt.close(fig)
    print('Saved four notebook figures')
if __name__=='__main__':main()
