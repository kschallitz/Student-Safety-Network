from pathlib import Path
import re,hashlib,subprocess
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
raw=ROOT/'data/speed_history/raw/livermore_speed_survey_2019_2020.pdf'
out=ROOT/'data/sumo_rl';out.mkdir(parents=True,exist_ok=True)
text=subprocess.check_output(['pdftotext','-layout',str(raw),'-'],text=True).split('\f')
source='https://library.livermoreca.gov/home/showpublisheddocument/6689/637583207174130000'
records=[];summaries=[]
for page,school,road,date,start,end,n,mean,p85,lanes,limit,flag in [(26,'Christensen Middle','Bluebell Drive','2019-10-24','11:05','11:20',108,28.6,32,2,25,''),(82,'Altamont Creek Elementary','Garaventa Ranch Road','2019-08-27','14:20','15:20',72,31.8,35,2,25,'source says Wednesday; calendar date was Tuesday; no date correction made')]:
 p=text[page-1];data=p.split('SPEED PARAMETERS')[0]
 bins=[]
 for m in re.finditer(r'^[ \t]*(<=10|>=70|\d{1,2})[ \t]+(\d+)[ \t]*',data,re.M):
  s,c=m.groups()
  if m.start(1)-data.rfind('\n',0,m.start(1))>10:continue
  bins.append((s,int(c)))
 assert sum(c for s,c in bins)==n,(page,sum(c for s,c in bins))
 for speed,count in bins:records.append({'school':school,'road':road,'date':date,'start':start,'end':end,'speed_mph_label':speed,'count':count,'measurement_status':'observed','processing_status':'transcribed','source_page':page,'source_url':source,'quality_flag':flag})
 summaries.append({'school':school,'road':road,'date':date,'start':start,'end':end,'sample_count':n,'mean_mph':mean,'p85_mph':p85,'total_road_lanes':lanes,'posted_mph_on_sheet':limit,'measurement_status':'observed','source_page':page,'source_url':source,'source_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'use':'historical speed prior only; not current intersection demand or before/after effect','quality_flag':flag})
pd.DataFrame(records).to_csv(out/'other_school_speed_bins_2019.csv',index=False)
pd.DataFrame(summaries).to_csv(out/'other_school_speed_priors_2019.csv',index=False)
print('Verified',len(records),'speed-bin cells; 108 + 72 observed vehicles')
