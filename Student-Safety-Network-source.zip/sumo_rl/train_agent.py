"""One fixed intervention per episode: neural contextual bandit, gamma=0.
Two separate agents: literal SUMO VRU collision-event reward and an explicitly
uncalibrated close-encounter surrogate. Post-installation outcomes never fit weights.
"""
import json, hashlib
import numpy as np
import pandas as pd
import torch
from torch import nn
from experiment import DATA, OUT, ACTIONS
FEATURES=['log_motor_count','log_pedestrian_count','log_bicycle_count','hour_sin','hour_cos','signalized','weekend']

def features(df):
    h=df.clock.str[:2].astype(float)+df.clock.str[3:].astype(float)/60
    return np.column_stack([np.log1p(df.motor_count),np.log1p(df.pedestrian_count),np.log1p(df.bicycle_count),np.sin(h/24*2*np.pi),np.cos(h/24*2*np.pi),df.site.eq('Hillcrest').astype(float),pd.to_datetime(df.date).dt.dayofweek.ge(5).astype(float)]).astype('float32')

class QNet(nn.Module):
    def __init__(self):
        super().__init__();self.layers=nn.Sequential(nn.Linear(7,32),nn.Tanh(),nn.Linear(32,32),nn.Tanh(),nn.Linear(32,4))
    def forward(self,x):return self.layers(x)

def train(df,target,seed=502,steps=8000):
    torch.set_num_threads(1);torch.manual_seed(seed);rng=np.random.default_rng(seed)
    train=df[df.split.eq('train')].copy()
    contexts=train.drop_duplicates(['interval_id','seed']).reset_index(drop=True)
    X=features(contexts);mu=X.mean(axis=0);sd=X.std(axis=0);sd[sd<1e-6]=1;X=(X-mu)/sd
    reward=-train.pivot(index=['interval_id','seed'],columns='action',values=target).reindex(pd.MultiIndex.from_frame(contexts[['interval_id','seed']]))[ACTIONS].to_numpy(dtype='float32')
    # Penalize any failure to clear demand; never reward hiding travelers in a queue.
    bad=train.pivot(index=['interval_id','seed'],columns='action',values='pending').reindex(pd.MultiIndex.from_frame(contexts[['interval_id','seed']]))[ACTIONS].to_numpy()>0
    reward-=bad*(2.0 if target=='collision_event' else 1000.0)
    scale=max(float(np.std(reward)),.01); R=reward/scale
    model=QNet();opt=torch.optim.Adam(model.parameters(),lr=.001);xt=torch.from_numpy(X);rt=torch.from_numpy(R)
    logs=[]
    for step in range(steps):
        ids=rng.integers(0,len(X),size=32);x=xt[ids];rr=rt[ids]
        q=model(x);epsilon=max(.1,1-step/5000)
        selected=q.detach().argmax(dim=1).numpy();mask=rng.random(32)<epsilon;selected[mask]=rng.integers(0,4,mask.sum())
        a=torch.tensor(selected);pred=q[torch.arange(32),a];observed=rr[torch.arange(32),a]
        loss=((pred-observed)**2).mean();opt.zero_grad();loss.backward();opt.step()
        if step%200==0:logs.append({'update':step,'epsilon':epsilon,'loss':float(loss.detach()),'mean_sampled_reward':float(observed.mean())*scale})
    payload={'state_dict':model.state_dict(),'mean':mu.tolist(),'std':sd.tolist(),'reward_scale':scale,'features':FEATURES,'actions':ACTIONS,'reward':'negative '+target,'incomplete_demand_penalty':2 if target=='collision_event' else 1000,'gamma':0,'algorithm':'epsilon-greedy neural contextual Q bandit; one action then terminal','train_dates':sorted(train.date.unique()),'seed':seed,'steps':steps}
    torch.save(payload,OUT/f'agent_{target}.pt');pd.DataFrame(logs).to_csv(OUT/f'training_{target}.csv',index=False)
    unique=df.drop_duplicates(['interval_id','seed']).copy()
    with torch.no_grad():q=model(torch.from_numpy((features(unique)-mu)/sd)).numpy()*scale
    unique['selected_action']=[ACTIONS[i] for i in q.argmax(axis=1)]
    unique['predicted_reward']=q.max(axis=1)
    selected=unique[['interval_id','seed','selected_action','predicted_reward']].merge(df,left_on=['interval_id','seed','selected_action'],right_on=['interval_id','seed','action'],validate='one_to_one')
    selected.to_csv(OUT/f'policy_choices_{target}.csv',index=False)
    summaries=[]
    train['penalized_cost']=train[target]+train.pending.gt(0)*(2 if target=='collision_event' else 1000)
    fixed=train.groupby('action').penalized_cost.mean().idxmin()
    for split in ['train','pre_holdout','post_test']:
        for policy,sub in [('neural_agent',selected[selected.split.eq(split)]),('no_change',df[df.split.eq(split)&df.action.eq('no_change')]),('best_fixed_training_action',df[df.split.eq(split)&df.action.eq(fixed)])]:
            summaries.append({'reward_target':target,'split':split,'policy':policy,'fixed_action':fixed if policy=='best_fixed_training_action' else None,'episodes':len(sub),'collision_event_fraction':sub.collision_event.mean(),'mean_encounter_pairs_per_100_vru':sub.encounter_pairs_per_100_vru.mean(),'mean_close_pairs':sub.projected_close_encounter_pairs.mean(),'completion_min':sub.completion_fraction.min(),'incomplete_episodes':int(sub.pending.gt(0).sum())})
    # Paired interval-level bootstrap; these are conditional simulator ranges, not real-world CIs.
    selected_test=selected[selected.split.eq('post_test')];base=df[df.split.eq('post_test')&df.action.eq('no_change')]
    p=selected_test.merge(base,on=['interval_id','seed'],suffixes=('_agent','_baseline'),validate='one_to_one')
    p['delta']=p[target+'_agent']-p[target+'_baseline'];delta=p.groupby('interval_id').delta.mean().to_numpy()
    boots=np.array([rng.choice(delta,len(delta),replace=True).mean() for _ in range(3000)])
    stats={'target':target,'test_mean_paired_change':float(delta.mean()),'simulator_context_bootstrap_95':np.quantile(boots,[.025,.975]).tolist(),'selected_actions':selected_test.selected_action.value_counts().to_dict(),'best_fixed_action_selected_on_training_only':fixed,'training_collision_events':int(train.collision_event.sum()),'training_target_nonzero':int((train[target]!=0).sum()),'interval_meanings':'conditional modeled-context bootstrap; no field or parameter uncertainty; not annual collision probability'}
    return summaries,stats

def main():
    df=pd.read_csv(OUT/'benchmark_episodes.csv');summ=[];stats=[]
    for target in ['collision_event','encounter_pairs_per_100_vru']:
        a,b=train(df,target);summ+=a;stats.append(b)
    pd.DataFrame(summ).to_csv(OUT/'agent_evaluation.csv',index=False)
    (OUT/'agent_results.json').write_text(json.dumps(stats,indent=2))
    print(json.dumps(stats,indent=2))
if __name__=='__main__':main()
