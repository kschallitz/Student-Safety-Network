"""Generate reproducible paired SUMO trials; policy fitting is in train_agent.py."""
import json, time
import pandas as pd
from experiment import *

def main():
    rows=prepare();bins=fit_speed_inputs();ctx=pd.read_csv(DATA/'contexts.csv');ctx=ctx[ctx.complete]
    records=[];start=time.monotonic()
    for _,c in ctx.iterrows():
        context=c.to_dict()
        split='train' if c.date=='2023-03-02' else 'pre_holdout' if c.date=='2023-02-11' else 'post_test'
        seeds={'train':range(11,15),'pre_holdout':range(101,104),'post_test':range(201,205)}[split]
        for seed in seeds:
            for action in ACTIONS:
                r=run_episode(context,action,seed,rows,bins);r['split']=split;records.append(r)
        pd.DataFrame(records).to_csv(OUT/'benchmark_episodes.csv',index=False)
        print(f'{len(records)} episodes; {split} {c.interval_id}; elapsed {time.monotonic()-start:.1f}s',flush=True)
    pd.DataFrame(records).to_csv(OUT/'benchmark_episodes.csv',index=False)
    print('BENCHMARK COMPLETE',len(records),time.monotonic()-start,flush=True)
if __name__=='__main__':main()
