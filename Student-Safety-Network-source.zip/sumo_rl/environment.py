"""Live SUMO one-decision RL environment; no cached prediction formula in step()."""
import numpy as np
import pandas as pd
import gymnasium as gym
from gymnasium import spaces
from experiment import DATA,ACTIONS,run_episode
from train_agent import features

class InterventionEnv(gym.Env):
    metadata={'render_modes':[]}
    def __init__(self,context_ids=None):
        self.contexts=pd.read_csv(DATA/'contexts.csv')
        self.contexts=self.contexts[self.contexts.complete]
        if context_ids is None:self.contexts=self.contexts[self.contexts.date.eq('2023-03-02')]
        else:self.contexts=self.contexts[self.contexts.interval_id.isin(context_ids)]
        if self.contexts.empty:raise ValueError('No complete observed contexts selected')
        self.rows=pd.read_csv(DATA/'east_avenue_observations_15min.csv')
        self.bins=pd.read_csv(DATA/'pre_speed_distributions.csv')
        self.action_space=spaces.Discrete(4)
        self.observation_space=spaces.Box(-np.inf,np.inf,shape=(7,),dtype=np.float32)
        self.done=True
    def reset(self,*,seed=None,options=None):
        super().reset(seed=seed);options=options or {}
        candidates=self.contexts
        if 'interval_id' in options:candidates=candidates[candidates.interval_id.eq(options['interval_id'])]
        self.context=candidates.iloc[self.np_random.integers(len(candidates))].to_dict()
        self.sim_seed=int(options.get('sim_seed',self.np_random.integers(10000,1000000)))
        self.state=features(pd.DataFrame([self.context]))[0];self.done=False
        return self.state.copy(),{'interval_id':self.context['interval_id'],'sumo_seed':self.sim_seed}
    def step(self,action):
        if self.done:raise RuntimeError('This episode is terminal. Call reset() before choosing another intervention.')
        if not self.action_space.contains(action):raise ValueError('Action must be integer 0..3')
        result=run_episode(self.context,ACTIONS[int(action)],self.sim_seed,self.rows,self.bins)
        reward=-float(result['collision_event'])-2*int(result['pending']>0)
        self.done=True
        return self.state.copy(),reward,True,False,result
