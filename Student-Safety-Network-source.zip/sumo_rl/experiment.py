"""East Avenue evidence-bounded SUMO / neural contextual-bandit experiment.
No conversion of surrogate encounters to real-world crash probabilities.
"""
from pathlib import Path
import argparse, hashlib, json, math, time, subprocess, sys, os
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
import sumolib

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data/sumo_rl'; OUT=ROOT/'outputs/sumo_rl'
OBS=ROOT/'data/traffic_exposure/normalized'
MPH=0.44704
ACTIONS=['no_change','posted_25','curb_extensions_proxy','curbs_and_25']
DIR={'eastbound':'W','westbound':'E','northbound':'S','southbound':'N'}
END={'W':{'TH':'E','LT':'N','RT':'S','UT':'W'},'E':{'TH':'W','LT':'S','RT':'N','UT':'E'},'N':{'TH':'S','LT':'E','RT':'W','UT':'N'},'S':{'TH':'N','LT':'W','RT':'E','UT':'S'}}
SITES={'Estates':{'source':'East Ave / Estates St','control':'priority_stop','arms':'WEN'},'Hillcrest':{'source':'East Ave / Hillcrest Ave','control':'traffic_light','arms':'WENS'}}

def save_xml(el,path):
    ET.indent(el); ET.ElementTree(el).write(path,encoding='utf-8',xml_declaration=True)

def prepare():
    DATA.mkdir(parents=True,exist_ok=True);OUT.mkdir(parents=True,exist_ok=True)
    t=pd.read_csv(OBS/'turning_movements.csv'); p=pd.read_csv(OBS/'nonmotorized_crossings.csv')
    rows=[]; exclusions=[]
    for site,info in SITES.items():
        for _,r in t[t.site_name.eq(info['source'])].iterrows():
            if r.mode_or_class=='heavy_vehicles_subset':continue
            mode='motor' if r.mode_or_class=='all_motor_vehicles' else 'bicycle'
            start=DIR[r.approach_direction]; mov=r.movement.replace('_including_UT','')
            end=END[start][mov]
            if not bool(r.approach_present) or str(r.approach_road)=='Dead Leg':
                assert r['count']==0; continue
            if not r.eligible_for_automatic_aggregation or pd.isna(r['count']):
                exclusions.append({'source_observation':r.observation_id,'reason':'source_page_quality_flag','site':site,'session_id':r.session_id});continue
            if start not in info['arms'] or end not in info['arms']:
                assert r['count']==0;continue
            rows.append({'site':site,'date':r.observation_date,'session_id':r.session_id,'interval_start':r.interval_start,'mode':mode,'from_arm':start,'to_arm':end,'crossing_leg':'','count':int(r['count']),'source_page':int(r.source_page),'source_observation':r.observation_id,'phase':r.intervention_phase,'measurement_status':'observed','processing_status':'transcribed_native_15_min'})
        for _,r in p[p.site_name.eq(info['source'])].iterrows():
            leg=r.crossing_leg[0].upper()
            # Estates south leg is a pedestrian-only dead-leg tally; retain it.
            if not r.eligible_for_automatic_aggregation:
                exclusions.append({'source_observation':r.observation_id,'reason':'source_page_quality_flag','site':site,'session_id':r.session_id});continue
            rows.append({'site':site,'date':r.observation_date,'session_id':r.session_id,'interval_start':r.interval_start,'mode':'pedestrian','from_arm':'','to_arm':'','crossing_leg':leg,'count':int(r['count']),'source_page':int(r.source_page),'source_observation':r.observation_id,'phase':r.intervention_phase,'measurement_status':'observed','processing_status':'transcribed_native_15_min'})
    df=pd.DataFrame(rows);df['interval_id']=df.site+'_'+df.interval_start.str.replace(':','',regex=False)
    # A page-level exclusion makes the affected interval incomplete, never a zero.
    ex_sessions={r['session_id'] for r in exclusions}
    df['session_complete']=~df.session_id.isin(ex_sessions)
    df.to_csv(DATA/'east_avenue_observations_15min.csv',index=False)
    pd.DataFrame(exclusions).to_csv(DATA/'input_exclusions.csv',index=False)
    contexts=[]
    for k,g in df.groupby('interval_id',sort=True):
        r=g.iloc[0]; sums=g.groupby('mode')['count'].sum()
        contexts.append({'interval_id':k,'site':r.site,'date':r.date,'session_id':r.session_id,'clock':r.interval_start[11:16],'phase':r.phase,'complete':bool(r.session_complete),'motor_count':int(sums.get('motor',0)),'bicycle_count':int(sums.get('bicycle',0)),'pedestrian_count':int(sums.get('pedestrian',0))})
    pd.DataFrame(contexts).to_csv(DATA/'contexts.csv',index=False)
    params=[('East Avenue','through_lanes_per_direction',2,'documented','Phase I PDF p21'),('Hillcrest','traffic_control','signal','documented','Phase I PDF p52; timing assumed'),('Estates','traffic_control','side_street_stop','documented','Phase I PDF p52'),('both','vehicle_lane_width_m',3.2,'assumed','no surveyed 2023 geometry'),('both','baseline_unused_road_margin_m',1.8,'assumed','per side; not a surveyed parking lane'),('both','baseline_corner_radius_m',9,'assumed','sensitivity input'),('both','pilot_corner_radius_m',5.5,'assumed','not 2025 proposed 20 ft radius'),('both','pilot_unused_margin_m',0,'assumed','proxy reclaims margin in last 50 m'),('both','pedestrian_direction_split',0.5,'assumed','only crossing-leg totals observed'),('both','posted_limit_mph',30,'documented','Phase I p22; conditional school 25 not timed in count sheets'),('both','driver_speed_distribution','February 2023 only','observed','speed instrument between Jensen and Estates; applied to both sites'),('both','pilot_crossing_reduction_percent',22,'documented_corridor_average_only','Final report p7 after June adjustments; NOT a site-specific May geometry'),('Hillcrest','signal_cycle_seconds',90,'assumed','SUMO generated program; no current timing sheet'),('both','posted_speed_response','speedFactor held fixed','assumed','drivers respond proportionally; compliance not measured'),('both','crash_probability_calibration','unavailable','missing','no matched conflict/crash labels')]
    pd.DataFrame(params,columns=['site','parameter','value','evidence_status','source_or_note']).to_csv(DATA/'simulation_assumptions.csv',index=False)
    return df

def network(site,action,margin=1.8,radius=5.5,cycle=90):
    """Schematic two-direction roads; geometry is parameterized, not an as-built map."""
    folder=OUT/'networks_v2'/f'{site}_{action}_m{margin}_r{radius}_c{cycle}';folder.mkdir(parents=True,exist_ok=True)
    net=folder/'network.net.xml'
    if net.exists(): return net
    curb='curb' in action; info=SITES[site]
    coords={'W':(-250,0),'E':(250,0),'N':(0,250),'S':(0,-250)}
    n=ET.Element('nodes');ET.SubElement(n,'node',id='J',x='0',y='0',type=info['control'],radius=str(radius if curb else 9))
    e=ET.Element('edges')
    for arm in info['arms']:
        x,y=coords[arm]
        ET.SubElement(n,'node',id=arm,x=str(x),y=str(y),type='priority')
        ET.SubElement(n,'node',id=arm+'near',x=str(x/5),y=str(y/5),type='priority',radius='0')
        for seg,a,b in [('in',arm+'near','J'),('out','J',arm+'near'),('far_in',arm,arm+'near'),('far_out',arm+'near',arm)]:
            main=arm in 'WE'; near=seg in ['in','out']; shoulder=margin if main and not(curb and near) else 0
            speed=25 if '25' in action and main else (30 if main else 25)
            edge=ET.SubElement(e,'edge',id=arm+'_'+seg,attrib={'from':a,'to':b},numLanes=str((2 if main else 1)+(1 if shoulder else 0)),speed=str(speed*MPH),priority=str(3 if main else 1),width='3.2',sidewalkWidth='2',disallow='pedestrian')
            if shoulder:
                ET.SubElement(edge,'lane',index='0',width=str(shoulder),allow='authority')
            # Unused margin is a reserved lane with no scheduled traffic. Cars retain two lanes.
            # The curb proxy removes only that margin within 50 m, not a through lane.
    c=ET.Element('connections')
    for arm in info['arms']:
        ET.SubElement(c,'crossing',node='J',edges=f'{arm}_in {arm}_out',priority='true',width='3')
    save_xml(n,folder/'nodes.nod.xml');save_xml(e,folder/'edges.edg.xml');save_xml(c,folder/'connections.con.xml')
    cmd=[sumolib.checkBinary('netconvert'),'-n',str(folder/'nodes.nod.xml'),'-e',str(folder/'edges.edg.xml'),'-x',str(folder/'connections.con.xml'),'-o',str(net),'--walkingareas','true','--junctions.corner-detail','5','--tls.cycle.time',str(cycle),'--no-turnarounds','false']
    r=subprocess.run(cmd,capture_output=True,text=True);(folder/'netconvert.log').write_text(r.stdout+r.stderr)
    if r.returncode:raise RuntimeError(r.stderr)
    return net

def fit_speed_inputs():
    b=pd.read_csv(OBS/'speed_distributions.csv');b=b[b.observation_date.str.startswith('2023-02')].copy()
    b['hour']=b.interval_start.str[11:13].astype(int)
    # Entire pre-installation February week only. No post-installation fitting.
    b.groupby(['travel_direction','hour','speed_bin_lower_mph','speed_bin_upper_mph'],dropna=False)['count'].sum().reset_index().to_csv(DATA/'pre_speed_distributions.csv',index=False)
    return pd.read_csv(DATA/'pre_speed_distributions.csv')

def speed_sample(bins,direction,hour,rng):
    g=bins[(bins.travel_direction==direction)&(bins.hour==hour)]
    r=g.iloc[rng.choice(len(g),p=g['count'].to_numpy()/g['count'].sum())]
    return rng.uniform(float(r.speed_bin_lower_mph),float(r.speed_bin_upper_mph))/30

def demand(context,rows,bins,seed,folder):
    rng=np.random.default_rng(seed);root=ET.Element('routes')
    ET.SubElement(root,'vType',id='car',vClass='passenger',accel='2.6',decel='4.5',sigma='0.5',length='5',tau='1.2',minGap='2.5',maxSpeed='60')
    ET.SubElement(root,'vType',id='bike',vClass='bicycle',accel='1.2',decel='3',maxSpeed='5.56',length='1.6',speedFactor='1',speedDev='0')
    ET.SubElement(root,'vType',id='walker',vClass='pedestrian',maxSpeed='1.4',speedFactor='1',speedDev='0.1')
    # All-motor class includes heavy vehicles. Heavy split not imputed; limitation documented.
    entities=[]; vid=0; pid=0; hour=int(context['clock'][:2])
    for _,r in rows[rows.interval_id.eq(context['interval_id'])].iterrows():
        for _ in range(int(r['count'])):
            dep=float(rng.uniform(0,900))
            if r['mode']=='pedestrian':
                arm=r.crossing_leg; forward=rng.random()<.5
                # Reverse-direction walkers use the same crossing, not the opposite road leg.
                a=f'{arm}_in' if forward else f'{arm}_out';b=f'{arm}_out' if forward else f'{arm}_in'
                if context['site']=='Estates' and arm=='S':
                    a,b=('W_in','E_out') if forward else ('E_out','W_in')
                el=ET.Element('person',id=f'p{pid}',type='walker',depart=f'{dep:.2f}',departPos='-10' if forward else '10');pid+=1
                ET.SubElement(el,'walk',edges=f'{a} {b}',arrivalPos='10' if forward else '-10')
            else:
                a,b=r.from_arm,r.to_arm;is_bike=r['mode']=='bicycle'
                direction='eastbound' if a=='W' else 'westbound' if a=='E' else None
                factor=speed_sample(bins,direction,hour,rng) if direction else float(np.clip(rng.normal(1,.1),.7,1.3))
                el=ET.Element('vehicle',id=('b' if is_bike else 'v')+str(vid),type='bike' if is_bike else 'car',depart=f'{dep:.2f}',departLane='best',departSpeed='max',speedFactor='1' if is_bike else f'{factor:.5f}');vid+=1
                ET.SubElement(el,'route',edges=f'{a}_far_in {a}_in {b}_out {b}_far_out')
            entities.append((dep,el))
    for _,el in sorted(entities,key=lambda z:z[0]):root.append(el)
    path=folder/'demand.rou.xml';save_xml(root,path);return path

def run_episode(context,action,seed,rows,bins,keep=False,variant=None):
    import libsumo as sim
    variant=variant or {};network_args=dict(variant);step_length=network_args.pop('step_length',.5);net=network(context['site'],action,**network_args)
    ident=f"{context['interval_id']}_{action}_{seed}"+('_'+str(variant) if variant else '')
    folder=OUT/'episodes'/hashlib.sha256(ident.encode()).hexdigest()[:16];folder.mkdir(parents=True,exist_ok=True)
    routes=demand(context,rows,bins,seed,folder)
    cfg=ET.Element('configuration');i=ET.SubElement(cfg,'input');ET.SubElement(i,'net-file',value=os.path.relpath(net,folder));ET.SubElement(i,'route-files',value=routes.name)
    tm=ET.SubElement(cfg,'time');ET.SubElement(tm,'step-length',value=str(step_length));save_xml(cfg,folder/'run.sumocfg')
    collisions=folder/'collisions.xml'
    args=[sumolib.checkBinary('sumo'),'-c',str(folder/'run.sumocfg'),'--seed',str(seed),'--no-step-log','true','--duration-log.disable','true','--no-warnings','true','--error-log',str(folder/'warnings.log'),'--collision-output',str(collisions),'--collision.check-junctions','true','--collision.mingap-factor','0','--collision.action','warn','--intermodal-collision.action','warn','--time-to-teleport','-1','--pedestrian.striping.jamtime','-1','--pedestrian.striping.jamtime.crossing','-1']
    if keep:args+=['--fcd-output',str(folder/'trajectories.xml'),'--device.fcd.period','1']
    start=time.monotonic();sim.start(args)
    center=sim.junction.getPosition('J');seen=set();ped_crossed=set();sampled={};encounters=set();minsep=1e9;teleports=0;arrived=0;parrived=0;delays=[];speeds={'eastbound':[],'westbound':[]};running=0
    try:
        for step in range(round(1500/step_length)):
            sim.simulationStep();running=step+1
            teleports+=sim.simulation.getStartingTeleportNumber();arrived+=sim.simulation.getArrivedNumber();parrived+=sim.simulation.getArrivedPersonNumber()
            if step%round(1/step_length):continue
            vehicles=sim.vehicle.getIDList();people=sim.person.getIDList();cars=[];vru=[]
            for v in vehicles:
                pos=np.array(sim.vehicle.getPosition(v));road=sim.vehicle.getRoadID(v);sp=sim.vehicle.getSpeed(v)
                # West-arm virtual detector: corridor speed, not turning speed.
                if v[0]=='v' and v not in sampled and road in ['W_far_in','W_far_out'] and abs(pos[0]-(center[0]-125))<12:
                    dr='eastbound' if road=='W_far_in' else 'westbound';speeds[dr].append(sp/MPH);sampled[v]=dr
                if np.linalg.norm(pos-np.array(center))>40:continue
                angle=math.radians(sim.vehicle.getAngle(v));vel=np.array([math.sin(angle)*sp,math.cos(angle)*sp]);length=sim.vehicle.getLength(v)
                item=(v,pos-vel/max(sp,1e-6)*length/2,vel)
                (vru if v[0]=='b' else cars).append(item)
            for p in people:
                road=sim.person.getRoadID(p)
                if road.startswith(':J_c'):ped_crossed.add(p)
                pos=np.array(sim.person.getPosition(p))
                if not road.startswith(':J_c'):continue
                sp=sim.person.getSpeed(p);angle=math.radians(sim.person.getAngle(p));vru.append((p,pos,np.array([math.sin(angle)*sp,math.cos(angle)*sp])))
            # Uncalibrated constant-velocity close-approach screen, not a crash model.
            # Only car-versus-pedestrian-on-crossing or bicycle near the junction.
            for v,pv,vv in cars:
                for u,pu,vu in vru:
                    d=pu-pv;dv=vu-vv;vv2=float(dv@dv)
                    t=-float(d@dv)/vv2 if vv2>1e-8 else -1
                    if 0<t<=3 and np.linalg.norm(d+t*dv)<2:
                        encounters.add(tuple(sorted((v,u))))
            if sim.simulation.getMinExpectedNumber()==0:break
        pending=sim.simulation.getMinExpectedNumber()
    finally:sim.close()
    allcoll=ET.parse(collisions).getroot().findall('collision')
    target=[r for r in allcoll if r.get('victim','').startswith(('p','b')) or r.get('collider','').startswith(('p','b'))]
    pairs={tuple(sorted((r.get('victim'),r.get('collider')))) for r in target}
    expected=int(context['motor_count']+context['bicycle_count']+context['pedestrian_count'])
    result={**context,'action':action,'seed':seed,'variant':json.dumps(variant,sort_keys=True),'motor_arrived':arrived,'pedestrians_arrived':parrived,'pedestrians_crossed':len(ped_crossed),'requested_total':expected,'completion_fraction':(arrived+parrived)/max(expected,1),'pending':pending,'teleports':teleports,'sumo_vru_collision_pairs':len(pairs),'sumo_any_collision_pairs':len({tuple(sorted((r.get('victim'),r.get('collider')))) for r in allcoll}),'collision_event':int(len(pairs)>0),'projected_close_encounter_pairs':len(encounters),'encounter_pairs_per_100_vru':100*len(encounters)/max(context['pedestrian_count']+context['bicycle_count'],1),'simulated_seconds':running*step_length,'wall_seconds':round(time.monotonic()-start,3),'episode_path':str(folder.relative_to(ROOT))}
    for dr,ss in speeds.items():
        result[dr+'_mean_mph']=float(np.mean(ss)) if ss else None;result[dr+'_n']=len(ss);result[dr+'_p85_mph']=float(np.quantile(ss,.85)) if ss else None
    (folder/'result.json').write_text(json.dumps(result,indent=2,default=str))
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');args=ap.parse_args()
    rows=prepare();bins=fit_speed_inputs();ctx=pd.read_csv(DATA/'contexts.csv');c=ctx[(ctx.site=='Estates')&(ctx.clock=='14:00')&(ctx.phase=='pre_installation')].iloc[0].to_dict()
    print(json.dumps(run_episode(c,'no_change',41,rows,bins,keep=True),indent=2,default=str))
