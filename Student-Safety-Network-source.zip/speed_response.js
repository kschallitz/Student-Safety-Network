/* Published-reference speed scenarios. Historical baseline inference stays frozen.
 * An exponential interpolation of a two-speed intervention is an assumption,
 * not a newly estimated per-mph effect. Ranges below are sensitivity envelopes.
 */
(function(root){
  function probability(rate){return -Math.expm1(-Math.max(0,rate));}
  function fromRates(rates){return {rates,bands:rates.map(probability),annual:probability(rates.reduce((a,b)=>a+b,0))};}
  function assess(evidence,road,proposed,assumed=null,allowExtrapolation=false){
    if(!Number.isFinite(proposed)||proposed<15||proposed>65)return {ok:false,reason:'Enter a proposed limit from 15 to 65 mph.'};
    const missing=road.speeds.some(s=>s===null);
    if(missing&&(!Number.isFinite(assumed)||assumed<15||assumed>65))return {ok:false,reason:'Enter the missing current-speed assumption first. The historical estimate stays unchanged.'};
    const speeds=road.speeds.map(s=>s===null?assumed:s);
    if(!speeds.length||speeds.some(s=>!Number.isFinite(s)||s<=0))return {ok:false,reason:'No usable current-speed value is available.'};
    // 20/25/30 mph are the UI's rounded values within the study's 18.6–31.1 mph range.
    const extrapolated=speeds.some(s=>s<evidence.support_mph[0]||s>evidence.support_mph[1])||proposed<evidence.support_mph[0]||proposed>evidence.support_mph[1];
    if(extrapolated&&!allowExtrapolation)return {ok:false,reason:'This speed is outside the reference study’s 18.6–31.1 mph range. Enable extrapolation below to explore it as an additional assumption.',extrapolated};
    return {ok:true,speeds,extrapolated,assumed:missing};
  }
  function roadFactor(evidence,speeds,proposed,rateRatio=evidence.rate_ratio){
    const beta=Math.log(rateRatio)/(evidence.after_mph-evidence.before_mph);
    // Multiple directions are averaged once; the factor is never compounded per arm.
    return speeds.reduce((s,v)=>s+Math.exp(beta*(proposed-v)),0)/speeds.length;
  }
  function apply(baseline,factor,roadShare,timeShares){
    if(roadShare<0||roadShare>1||timeShares.length!==6||timeShares.some(x=>x<0||x>1))throw Error('Invalid affected-risk shares');
    return fromRates(baseline.rates.map((r,i)=>r*(1+roadShare*timeShares[i]*(factor-1))));
  }
  function compare(evidence,baseline,ensemblePredictions,road,proposed,options={}){
    const check=assess(evidence,road,proposed,options.assumed??null,!!options.allowExtrapolation);
    if(!check.ok)return check;
    const roadShare=options.roadShare??.5,timeShares=options.timeShares??[1,1,1,1,1,1];
    const factor=roadFactor(evidence,check.speeds,proposed),scenario=apply(baseline,factor,roadShare,timeShares);
    const factors=[1,factor,...evidence.rate_ratio_interval.map(rr=>roadFactor(evidence,check.speeds,proposed,rr))];
    // Include no response and full selected-road attribution. Quantile endpoints
    // of the frozen baseline ensemble are combined with these response extremes.
    // This is not a joint 90% confidence interval; transfer error is unmeasured.
    const predictions=ensemblePredictions?.length?ensemblePredictions:[baseline];
    const quantile=(xs,q)=>{const a=xs.slice().sort((a,b)=>a-b),k=(a.length-1)*q,i=Math.floor(k);return a[i]+(a[Math.min(i+1,a.length-1)]-a[i])*(k-i);};
    const candidates=[];const delta=[];
    for(const f of factors)for(const share of [0,roadShare,1]){
      const ps=predictions.map(p=>apply(p,f,share,timeShares));
      candidates.push({annual:[quantile(ps.map(p=>p.annual),.05),quantile(ps.map(p=>p.annual),.95)],bands:Array.from({length:6},(_,i)=>[quantile(ps.map(p=>p.bands[i]),.05),quantile(ps.map(p=>p.bands[i]),.95)])});
      delta.push(...ps.map((p,i)=>100*(p.annual-predictions[i].annual)));
      delta.push(100*(apply(baseline,f,share,timeShares).annual-baseline.annual));
    }
    const range={annual:[Math.min(scenario.annual,...candidates.map(p=>p.annual[0])),Math.max(scenario.annual,...candidates.map(p=>p.annual[1]))],bands:Array.from({length:6},(_,i)=>[Math.min(scenario.bands[i],...candidates.map(p=>p.bands[i][0])),Math.max(scenario.bands[i],...candidates.map(p=>p.bands[i][1]))])};
    return {...check,scenario,factor,roadShare,timeShares,range,changeRange:[Math.min(0,...delta),Math.max(0,...delta)],percentagePoints:100*(scenario.annual-baseline.annual),relativePercent:baseline.annual?100*(scenario.annual/baseline.annual-1):0};
  }
  const api={probability,fromRates,assess,roadFactor,apply,compare};
  if(typeof module!=='undefined')module.exports=api;
  root.SpeedResponse=api;
})(typeof window!=='undefined'?window:globalThis);
