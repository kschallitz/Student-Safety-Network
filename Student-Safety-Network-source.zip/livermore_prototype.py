"""Source-grounded preparation and mapping for the Livermore Colab prototype."""
# %% imports
from pathlib import Path
import json
import html
import re
import math
import hashlib
from datetime import datetime, timezone
import numpy as np
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import folium
from branca.element import Element, MacroElement, Template

METRIC_CRS = 'EPSG:26910'  # NAD83 / UTM zone 10N; distances in metres.
ROAD_CATEGORIES = ['Street Maintenance', 'Traffic Control',
                   'Trail, Bike, and Miscellaneous', 'Transportation Infrastructure']
MODE_COLORS = {'Pedestrian':'#b04a20', 'Bicycle':'#167b82', 'Pedestrian + bicycle':'#70528b'}
SEVERITIES = {1:'Fatal', 2:'Severe injury', 3:'Visible injury', 4:'Complaint of pain'}
DAILY_COLUMNS = ['school_id','date','time_window','direction','walk','bike','private_car',
                 'carpool','school_bus','transit','other','total_observed','coverage_status','source_url']
COUNT_COLUMNS = ['walk','bike','private_car','carpool','school_bus','transit','other']
CLOSURE_COLUMNS = ['event_id','site_id','actual_start','actual_end','date_kind',
                   'lane_closure','sidewalk_closure','crosswalk_closure','source_url']

def feature_frame(collection):
    return gpd.GeoDataFrame.from_features(collection['features'], crs='EPSG:4326')

def require_unique(frame, column):
    if frame[column].isna().any() or frame[column].duplicated().any():
        raise ValueError(f'{column}: missing or duplicate identifiers require source reconciliation.')

def check_geometry(frame, name):
    missing = frame.geometry.isna() | frame.geometry.is_empty
    if missing.any():
        raise ValueError(f'{name}: {missing.sum()} missing geometries; reconcile before mapping.')
    if not frame.geometry.is_valid.all():
        raise ValueError(f'{name}: invalid geometries; review before spatial joins.')
    # A broad Livermore-area reasonableness check; not a municipal inclusion filter.
    b = frame.total_bounds
    if not (-122.2 < b[0] <= b[2] < -121.3 and 37.2 < b[1] <= b[3] < 38.1):
        raise ValueError(f'{name}: unexpected coordinate bounds {b}.')

# %% prepare
def prepare_sources(payload, start_year=2020, end_year=2024):
    if not (2020 <= start_year <= end_year <= 2024):
        raise ValueError('The embedded collision snapshot covers 2020–2024 only.')
    schools = feature_frame(payload['schools']).rename(columns={
        'CDSCode':'school_id','SchoolName':'school_name','Year':'enrollment_year',
        'EnrollTotal':'enrollment','OpenDate':'open_date'})
    require_unique(schools, 'school_id')
    schools['school_id'] = schools.school_id.astype(str)
    schools['open_date'] = pd.to_datetime(schools.open_date, unit='ms', errors='coerce')
    check_geometry(schools, 'Schools')
    raw = feature_frame(payload['collisions'])
    require_unique(raw, 'CASE_ID')
    check_geometry(raw, 'Collisions')
    # Date-only field: retain the encoded calendar date; do not shift midnight to Pacific.
    raw['date'] = pd.to_datetime(raw.COLLISION_DATE, unit='ms', errors='coerce').dt.normalize()
    if raw.date.isna().any():
        raise ValueError('Collision date is missing or invalid.')
    if not raw.date.dt.year.eq(raw.ACCIDENT_YEAR).all():
        raise ValueError('Collision date/year disagreement.')
    raw = raw.loc[raw.date.dt.year.between(start_year, end_year)].copy()
    raw['pedestrian'] = raw.PEDESTRIAN_ACCIDENT.fillna('').str.upper().eq('Y')
    raw['bicycle'] = raw.BICYCLE_ACCIDENT.fillna('').str.upper().eq('Y')
    collisions = raw.loc[raw.pedestrian | raw.bicycle].copy()
    collisions['case_id'] = collisions.CASE_ID.astype('int64').astype(str)
    collisions['mode'] = np.select([collisions.pedestrian & collisions.bicycle,
                                  collisions.pedestrian],
                                 ['Pedestrian + bicycle','Pedestrian'], default='Bicycle')
    collisions['severity'] = collisions.COLLISION_SEVERITY.map(SEVERITIES).fillna('Unknown')
    # No student, school-trip, or motor-vehicle involvement label is inferred from proximity/age.
    collisions['student_status'] = pd.Series(pd.NA, index=collisions.index, dtype='string')
    collisions['school_trip_status'] = pd.Series(pd.NA, index=collisions.index, dtype='string')
    collisions['location'] = collisions.PRIMARY_RD.fillna('Unknown road') + ' / ' + collisions.SECONDARY_RD.fillna('Unknown cross street')
    times = pd.to_numeric(collisions.COLLISION_TIME, errors='coerce')
    valid_time = times.between(0,2359) & times.mod(100).lt(60) & times.eq(times.round())
    collisions['hour'] = (times.where(valid_time) // 100).astype('Int64')
    projects = feature_frame(payload['cip_boundaries']).rename(columns={'GlobalID':'site_id'})
    projects = projects.loc[projects.project_category.isin(ROAD_CATEGORIES) & projects.display.eq(1)].copy()
    require_unique(projects, 'site_id')
    check_geometry(projects, 'Road project footprints')
    # GIS edit timestamps are never interpreted as construction dates.
    projects['snapshot_date'] = payload['snapshot_date']
    projects['actual_start'] = pd.NaT
    projects['actual_end'] = pd.NaT
    projects['closure_dates_verified'] = False
    boundary = feature_frame(payload['city_boundary'])
    check_geometry(boundary, 'City boundary')
    return schools, raw, collisions, projects, boundary

# %% spatial
def school_proximity(schools, collisions, radius_m=800):
    if not 0 < radius_m <= 16093.44:
        raise ValueError('Choose a proximity distance greater than 0 and at most 10 miles.')
    s = schools[['school_id','school_name','open_date','geometry']].to_crs(METRIC_CRS)
    c = collisions[['case_id','date','mode','severity','geometry']].to_crs(METRIC_CRS)
    # dwithin includes the boundary. Multiple schools may match a single collision.
    pairs = gpd.sjoin(c, s, predicate='dwithin', distance=radius_m, how='inner')
    pairs['distance_m'] = [geom.distance(s.loc[i].geometry) for geom,i in zip(pairs.geometry,pairs.index_right)]
    pairs['school_open_by_event'] = pairs.open_date.notna() & pairs.open_date.le(pairs.date)
    counts = pairs.groupby('school_id').case_id.nunique()
    summary = schools[['school_id','school_name']].copy()
    # Zero here means zero matches in THIS extract, never a negative collision training label.
    summary['recorded_collisions_within_radius'] = summary.school_id.map(counts).fillna(0).astype(int)
    return pairs.drop(columns='index_right'), summary.sort_values('school_name')

def project_school_proximity(schools, projects, radius_m):
    s = schools[['school_id','school_name','geometry']].to_crs(METRIC_CRS)
    p = projects[['site_id','project_number','project_status','geometry']].to_crs(METRIC_CRS)
    return gpd.sjoin(s, p, predicate='dwithin', distance=radius_m, how='inner').drop(columns='index_right')

# %% inputs
def validate_daily_tallies(frame, school_ids):
    missing = set(DAILY_COLUMNS) - set(frame.columns)
    if missing:
        raise ValueError(f'Daily tally columns missing: {sorted(missing)}')
    d = frame[DAILY_COLUMNS].copy()
    if d.empty:
        d['date'] = pd.to_datetime(d.date)
        return d
    for col in ['school_id','time_window','direction','coverage_status','source_url']:
        if d[col].isna().any() or d[col].astype(str).str.strip().eq('').any():
            raise ValueError(f'Daily tallies require {col}.')
    if not d.school_id.isin(school_ids).all():
        raise ValueError('Unknown school_id; use CDE CDS codes as strings, including leading zeros.')
    d['date'] = pd.to_datetime(d.date, format='%Y-%m-%d', errors='raise')
    if d.date.isna().any():
        raise ValueError('Daily tallies need actual observation dates.')
    if not d.direction.isin(['arrival','departure']).all():
        raise ValueError('direction must be arrival or departure; do not pool them.')
    if d.duplicated(['school_id','date','time_window','direction']).any():
        raise ValueError('Duplicate school/date/window/direction: consolidate classroom records first.')
    for col in COUNT_COLUMNS + ['total_observed']:
        d[col] = pd.to_numeric(d[col], errors='raise')
        observed = d[col].dropna()
        if (observed.lt(0) | observed.mod(1).ne(0)).any():
            raise ValueError(f'{col} must contain nonnegative whole counts or blanks.')
    complete = d[COUNT_COLUMNS + ['total_observed']].notna().all(axis=1)
    if not d.loc[complete,COUNT_COLUMNS].sum(axis=1).eq(d.loc[complete,'total_observed']).all():
        raise ValueError('Mode counts do not sum to the observed denominator.')
    d['usable_count_label'] = complete & d.total_observed.gt(0) & d.coverage_status.eq('observed_complete')
    return d

def validate_closures(frame, site_ids):
    missing = set(CLOSURE_COLUMNS) - set(frame.columns)
    if missing:
        raise ValueError(f'Closure columns missing: {sorted(missing)}')
    d = frame[CLOSURE_COLUMNS].copy()
    if d.empty:
        d['actual_start'] = pd.to_datetime(d.actual_start)
        d['actual_end'] = pd.to_datetime(d.actual_end)
        return d
    require_unique(d, 'event_id')
    if not d.site_id.isin(site_ids).all():
        raise ValueError('Unknown site_id: use a mapped project footprint or add verified geometry first.')
    if not d.date_kind.eq('verified_actual').all():
        raise ValueError('Only verified_actual intervals belong in actual closure records.')
    for col in ['actual_start','actual_end']:
        d[col] = pd.to_datetime(d[col], format='%Y-%m-%d', errors='raise')
        if d[col].isna().any():
            raise ValueError('Both verified actual dates are required; incomplete intervals stay unknown.')
    if d.actual_end.lt(d.actual_start).any():
        raise ValueError('Closure ends before it begins.')
    if d.source_url.isna().any() or d.source_url.str.strip().eq('').any():
        raise ValueError('Actual closures need a supporting source.')
    return d

def closure_collision_matches(collisions, projects, closures, distance_m=100):
    columns = ['case_id','site_id','event_id','date','actual_start','actual_end']
    if closures.empty or collisions.empty:
        return pd.DataFrame(columns=columns)
    sites = projects[['site_id','geometry']].to_crs(METRIC_CRS)
    joined = gpd.sjoin(collisions[['case_id','date','geometry']].to_crs(METRIC_CRS),
                       sites, predicate='dwithin', distance=distance_m, how='inner')
    joined = joined.merge(closures, on='site_id', how='inner', validate='many_to_many')
    matched = joined.loc[joined.date.ge(joined.actual_start) & joined.date.le(joined.actual_end)]
    # A spatial/temporal association is not a causal effect or proof of a detour.
    return pd.DataFrame(matched[columns]).drop_duplicates()

# %% plotting
def plot_observed_collisions(collisions, start_year, end_year, output_dir):
    modes = list(MODE_COLORS)
    counts = pd.crosstab(collisions.date.dt.year, collisions['mode']).reindex(
        index=range(start_year,end_year+1), columns=modes, fill_value=0).fillna(0).astype(int)
    fig, ax = plt.subplots(figsize=(10,4.2))
    counts.plot.bar(ax=ax, stacked=True, color=[MODE_COLORS[m] for m in modes], width=.65)
    ax.set(title='Recorded pedestrian / bicycle collisions in the city extract',
           xlabel='Collision year', ylabel='Unique collision records')
    ax.tick_params(axis='x', rotation=0)
    ax.set_ylim(0, max(1,counts.sum(axis=1).max()*1.25))
    for i,n in enumerate(counts.sum(axis=1)):
        ax.text(i,n+.5,str(n),ha='center',fontsize=11)
    ax.legend(frameon=False, loc='upper left', bbox_to_anchor=(1.01,1))
    ax.grid(axis='y',alpha=.18); ax.set_axisbelow(True)
    fig.text(.08,.015,'Source: City of Livermore Vision Zero layer. Counts are not exposure-adjusted risk; student status is unknown.',fontsize=9)
    fig.tight_layout(rect=(0,.04,1,1))
    fig.savefig(output_dir/'collision_years.png',dpi=170,bbox_inches='tight')
    return fig, counts

def plot_static_map(schools, collisions, projects, boundary, output_dir):
    fig,ax = plt.subplots(figsize=(10,7))
    boundary.to_crs(METRIC_CRS).boundary.plot(ax=ax,color='#999999',linewidth=.7)
    if len(projects):
        projects.to_crs(METRIC_CRS).plot(ax=ax,facecolor='#ddb87b',edgecolor='#af8138',alpha=.3,linewidth=.7)
    for mode,color in MODE_COLORS.items():
        d=collisions.loc[collisions['mode'].eq(mode)]
        if len(d): d.to_crs(METRIC_CRS).plot(ax=ax,color=color,markersize=14,alpha=.8)
    schools.to_crs(METRIC_CRS).plot(ax=ax,marker='^',color='#234c7e',markersize=38,edgecolor='white',linewidth=.5)
    ax.set_title('Livermore: schools, recorded collisions, and road-project footprints',loc='left',fontsize=13,pad=13)
    ax.set(xlabel='Easting (metres; NAD83 / UTM 10N)',ylabel='Northing (metres)')
    ax.ticklabel_format(style='plain',useOffset=False); ax.tick_params(labelsize=8)
    handles=[Line2D([],[],marker='^',ls='',color='#234c7e',label='Schools: 2025–26')]
    handles += [Line2D([],[],marker='o',ls='',color=v,label=k) for k,v in MODE_COLORS.items()]
    handles += [Line2D([],[],color='#af8138',lw=5,alpha=.5,label='Project footprint: current snapshot')]
    ax.legend(handles=handles,frameon=True,loc='upper left',fontsize=8)
    fig.text(.07,.015,'Mixed time periods shown for context. Project footprints do not establish historical closures. No basemap required.',fontsize=9)
    fig.tight_layout(rect=(0,.04,1,1));fig.savefig(output_dir/'livermore_overview.png',dpi=170,bbox_inches='tight')
    return fig

# %% map
def escape(value):
    return html.escape('Unknown' if pd.isna(value) else str(value))

def make_map(schools, collisions, projects, boundary, travel_evidence, selected_school,
             radius_m=800, context_miles=10, start_year=2020, end_year=2024):
    focus=schools.loc[schools.school_name.eq(selected_school)]
    if focus.empty:
        raise ValueError(f'Unknown selected school: {selected_school}')
    origin=focus.iloc[0].geometry
    m=folium.Map([origin.y,origin.x],zoom_start=12,tiles='OpenStreetMap',control_scale=True)
    bounds=boundary.total_bounds
    m.fit_bounds([[bounds[1],bounds[0]],[bounds[3],bounds[2]]],padding=(25,25))
    title=f'''<div style="position:absolute;top:12px;left:55px;z-index:999;background:white;padding:12px 16px;border:1px solid #ddd;max-width:490px;font:14px/1.45 Arial">
    <b>Livermore school travel &amp; collision evidence</b><br>
    {len(schools)} schools · {len(collisions)} collision records ({start_year}–{end_year})<br>
    <span style="font-size:12px">Schools: 2025–26 · Projects: snapshot {escape(projects.snapshot_date.iloc[0]) if len(projects) else 'unavailable'}<br>
    Student status unknown. Project footprints are not verified closure periods.</span></div>'''
    m.get_root().html.add_child(Element(title))
    folium.GeoJson(json.loads(boundary.to_json()),name='City boundary / collision source coverage',
                   style_function=lambda f:{'color':'#666','weight':2,'dashArray':'5 4','fillOpacity':0}).add_to(m)
    fg=folium.FeatureGroup(name='Public schools · 2025–26').add_to(m)
    for _,s in schools.iterrows():
        evidence=travel_evidence.loc[travel_evidence.school_id.eq(s.school_id)]
        travel_note=(evidence.iloc[0].availability if len(evidence) else 'Snapshot not reviewed in this prototype')
        school_tip=f'{escape(s.school_name)} | 2025–26 enrollment: {escape(s.enrollment)}'
        text=f'<b>{escape(s.school_name)}</b><br>CDS: {escape(s.school_id)}<br>Enrollment: {escape(s.enrollment)} ({escape(s.enrollment_year)})<br>Travel evidence: {escape(travel_note)}<br>Enrollment is not a daily travel count.'
        marker=folium.Marker([s.geometry.y,s.geometry.x],tooltip=school_tip,popup=folium.Popup(text,max_width=340),
                            icon=folium.Icon(color='blue',icon='graduation-cap',prefix='fa'),keyboard=True)
        marker.add_to(fg)
    for mode,color in MODE_COLORS.items():
        fg=folium.FeatureGroup(name=f'{mode} collisions · {start_year}–{end_year}').add_to(m)
        for _,c in collisions.loc[collisions['mode'].eq(mode)].iterrows():
            text=f'<b>{escape(mode)}</b><br>{c.date:%Y-%m-%d} · {escape(c.severity)}<br>{escape(c.location)}<br>Case: {escape(c.case_id)}<br>Student / school trip: unknown'
            folium.CircleMarker([c.geometry.y,c.geometry.x],radius=4,color=color,weight=1,
                fill=True,fill_opacity=.8,tooltip=f'{escape(mode)} | {c.date:%Y-%m-%d} | {escape(c.location)}',
                popup=folium.Popup(text,max_width=320)).add_to(fg)
    status_colors={'Recently Completed Projects':'#6d756d','Projects in Construction':'#ac6726',
                   'Projects in Design':'#9f862b','Future Projects':'#888888'}
    for status,color in status_colors.items():
        p=projects.loc[projects.project_status.eq(status)].copy()
        if p.empty: continue
        p['source_link']=p.project_url.map(lambda u:f'<a href="{html.escape(str(u),quote=True)}" target="_blank" rel="noopener">City project page</a>')
        p['date_note']='Actual closure start/end unknown; GIS edit date is not construction date'
        fields=['project_name','project_subname','project_number','project_status','snapshot_date','date_note','source_link']
        # Avoid interpreting any source-supplied HTML as executable page content.
        for col in fields[:-1]: p[col]=p[col].map(escape)
        folium.GeoJson(json.loads(p[fields+['geometry']].to_json()),
            name=f'Road projects: {status} (snapshot)',show=status!='Future Projects',
            style_function=lambda f,col=color:{'color':col,'weight':2,'fillColor':col,'fillOpacity':.17},
            tooltip=folium.GeoJsonTooltip(fields=['project_name','project_subname','project_status','snapshot_date'],
                      aliases=['Project','Site','Snapshot status','Snapshot date'],sticky=False),
            popup=folium.GeoJsonPopup(fields=fields,aliases=['Project','Site','Number','Status','Snapshot date','Dates','Source'])).add_to(m)
    fg=folium.FeatureGroup(name=f'{selected_school}: {radius_m:g} m proximity area',show=False).add_to(m)
    folium.Circle([origin.y,origin.x],radius=radius_m,color='#234c7e',fill=False,
                  tooltip='Straight-line proximity; not a school route or attendance boundary').add_to(fg)
    fg=folium.FeatureGroup(name=f'{selected_school}: {context_miles:g}-mile context',show=False).add_to(m)
    folium.Circle([origin.y,origin.x],radius=context_miles*1609.344,color='#666666',fill=False,
        tooltip='Requested context radius. Crash coverage outside the city is not provided by this extract.').add_to(fg)
    folium.LayerControl(collapsed=False,position='topright').add_to(m)
    # Make vector layers keyboard reachable and display the same tooltip on focus.
    accessibility=MacroElement()
    accessibility._template=Template('''{% macro script(this, kwargs) %}
    function attachFocus(layer) {
      if (layer.feature && layer.feature.properties && layer.feature.properties.project_name && layer.bindTooltip) {
        const p=layer.feature.properties;
        if (!layer.getTooltip || !layer.getTooltip())
          layer.bindTooltip(p.project_name+' | '+p.project_subname+' | '+p.project_status+' | '+p.snapshot_date);
      }
      if (layer.eachLayer) layer.eachLayer(attachFocus);
      if (!layer.getTooltip || !layer.getTooltip()) return;
      const el = layer.getElement ? layer.getElement() : null;
      if (!el) return;
      el.setAttribute('tabindex','0'); el.setAttribute('role','button');
      el.setAttribute('aria-label', String(layer.getTooltip().getContent()).replace(/<[^>]*>/g,''));
      if (el.dataset.focusReady) return; el.dataset.focusReady='1';
      el.addEventListener('focus',()=>layer.openTooltip());
      el.addEventListener('blur',()=>layer.closeTooltip());
      el.addEventListener('keydown',e=>{if(e.key==='Enter' && layer.openPopup)layer.openPopup();});
    }
    {{this._parent.get_name()}}.whenReady(()=>{{this._parent.get_name()}}.eachLayer(attachFocus));
    {{this._parent.get_name()}}.on('layeradd',e=>attachFocus(e.layer));
    {% endmacro %}''')
    m.add_child(accessibility)
    return m

# %% readiness
def training_readiness(collisions, daily, closures, travel_evidence):
    usable=int(daily.get('usable_count_label',pd.Series(dtype=bool)).sum())
    return pd.DataFrame([
      {'Target':'Daily walk / bike / car counts','Available':f'{usable} complete observed school-period labels',
       'Decision':'Blocked: acquire repeated dated counts' if not usable else 'Needs temporal coverage and baseline review',
       'Reason':'Published mode charts and enrollment do not supply daily denominators or separate walking/biking counts.'},
      {'Target':'Student–vehicle collision probability','Available':f'{len(collisions)} pedestrian/bicycle records; 0 verified student labels',
       'Decision':'Blocked: target population is not identified',
       'Reason':'Need verified student / school-trip / vehicle involvement plus a defined segment-time observation panel and exposure.'},
      {'Target':'Construction-associated conditions','Available':f'{len(closures)} verified actual intervals',
       'Decision':'Blocked: actual closure history incomplete',
       'Reason':'Current project status and planned schedules cannot label prior lane or sidewalk closures.'},
      {'Target':'Descriptive geographic screening','Available':'Schools, collision locations, road-project footprints, report inventory',
       'Decision':'Available with source and period caveats',
       'Reason':'Proximity is descriptive; it does not establish school-trip involvement, individual risk, or causation.'}
    ])
