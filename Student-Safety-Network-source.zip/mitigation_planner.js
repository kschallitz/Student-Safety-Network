/* Pure functions shared by the map UI and integration checks. */
(function(root){
  const Planner={
    site(evidence,junction){
      const s=evidence.sites[junction.id];
      return s&&s.releaseChecked&&s.ll.every((v,i)=>Math.abs(v-junction.ll[i])<.00001)?s:null;
    },
    inputs(evidence,junction){
      const s=evidence.availableInputs?.[junction.id];
      return s&&s.ll.every((v,i)=>Math.abs(v-junction.ll[i])<.00001)?s:null;
    },
    totals(site,split='test'){
      return site.candidates.map(c=>{
        const rows=site.episodes.filter(r=>r.action===c.id&&(split==='all'||r.split===split));
        const sum=k=>rows.reduce((s,r)=>s+r[k],0);
        return {...c,periods:rows.length,contacts:sum('contacts'),near:sum('near'),
          pedestrianNear:rows.reduce((s,r)=>s+(r.pedestrianNear??r.near),0),bicycleNear:site.bicycleNearMeasured?sum('bicycleNear'):null,
          reward:sum('reward'),travelers:sum('travelers'),vehicleContacts:sum('vehicleContacts'),
          delaySeconds:sum('travelers')?rows.reduce((s,r)=>s+r.delaySeconds*r.travelers,0)/sum('travelers'):null};
      });
    },
    preparation(junction,mapped,inputs=null){
      const known=junction.approaches.flatMap(a=>a.speeds).filter(v=>v!==null);
      return [
        {id:'baseline',title:'Historical probability and crash records',status:junction.coverageComplete?'Available':'Incomplete coverage',detail:'500-foot area; 2014–2025 records. These do not supply turning counts.'},
        {id:'posted',title:'Posted speed limits',status:known.length===junction.approaches.reduce((n,a)=>n+a.speeds.length,0)?'Available':'Partial / unknown',detail:junction.approaches.map(a=>a.name+': '+[...new Set(a.speeds)].map(s=>s===null?'unknown':s+' mph').join(' / ')).join('; ')},
        {id:'features',title:'Mapped crossings and controls',status:mapped?'Partial map evidence':'Not downloaded here',detail:mapped?`${mapped.mapped_crossing_nodes} crossing tags; ${mapped.mapped_signal_nodes} signal tags; ${mapped.mapped_stop_nodes} stop-control tags within 60 m. Tags require field verification.`:'Missing tags do not mean crossings or signals are absent.'},
        {id:'geometry',title:'Simulation geometry and movements',status:inputs?.simulationReady?'Checked simulator setup':inputs?'Source tracing available; setup pending':'Needed',detail:inputs?inputs.geometryStatus+' '+inputs.controlStatus:'Survey lane paths, crossing lengths, curb outlines, priorities and any signal timing; adapt the Estates-specific simulator.'},
        {id:'demand',title:'Arrival and dismissal traffic counts',status:inputs?'Available — direct observations':'Needed',detail:inputs?`${inputs.intervals} fifteen-minute periods across ${inputs.dates.length} dates in 2023, before and after installation. Includes cars, heavy vehicles, bicycles and pedestrians at this intersection. No replacement CSV is required.`:'Dated 15-minute vehicle and bicycle turning movements, pedestrians by crossing leg; keep missing counts blank.'},
        {id:'behavior',title:'Approach speeds and yielding',status:inputs?'Corridor speeds available; site behavior incomplete':'Needed',detail:inputs?inputs.speedStatus:'Measured operating-speed distributions and observed yielding / conflicts for checking the site setup.'},
        {id:'evaluation',title:'Checked simulation and RL comparison',status:inputs?.simulationReady?'Initial comparison pending':'Not run for this site',detail:inputs?.simulationReady?'Bicycle and pedestrian scoring implemented. Complete the full matched comparison before releasing a recommendation.':'Use matched traffic arrivals across designs, complete every trip, fit on training periods and compare on reserved periods. Add bicycle near-miss coverage.'}
      ];
    },
    proposals(junction,mapped){
      const known=junction.approaches.flatMap(a=>a.speeds).filter(v=>v!==null);
      return [
        {id:'unchanged',label:'Keep current layout',reason:'Baseline for every paired comparison.'},
        {id:'speed',label:'Lower approach operating speeds',reason:known.length?`Recorded limits span ${Math.min(...known)}–${Math.max(...known)} mph. Specify each road separately and measure driver response.`:'Verify current limits and operating speeds before setting the target.'},
        {id:'crossings',label:'Shorten crossing distance',reason:mapped&&mapped.mapped_crossing_nodes?`${mapped.mapped_crossing_nodes} nearby crossing tags provide a starting point; confirm the actual crossing legs and widths.`:'Locate crossing legs and measure widths before choosing curb extensions.'},
        {id:'curbs',label:'Protect corners / tighten turning paths',reason:'Check truck and bus swept paths, accessibility, bike space and drainage against measured geometry.'},
        {id:'medians',label:'Median or channelization',reason:'Confirm road width and turn access. The Estates candidate used channelization, not a modeled pedestrian refuge.'},
        {id:'speed_humps',label:'Speed humps',reason:'Choose the road and placement, hump dimensions and spacing, and approach/pass-over speed behavior. Check road-class, bus and emergency-route suitability. Simulator support and scored trials are pending.',simulationStatus:'not_implemented',requiredInputs:['road_and_lane_ids','placement_m','length_m','height_m','spacing_m','pass_over_speed_distribution','braking_and_compliance','site_suitability_review']},
        {id:'crossing_guard',label:'Crossing guard',reason:'Choose crossing legs and staffed periods; model stopping traffic, confirming all conflicting lanes have stopped, then releasing a crossing group. Include reaction, compliance and clearance time. Simulator support and scored trials are pending.',simulationStatus:'not_implemented',requiredInputs:['crossing_legs','staffed_periods','guard_count','reaction_time_s','driver_compliance','group_release_policy','crossing_clearance_s','signal_coordination']},
        {id:'package',label:'Combine feasible changes',reason:'Test the physical package with and without lower operating speeds; compare against each single change.'}
      ];
    }
  };
  if(typeof module!=='undefined'&&module.exports)module.exports=Planner;
  else root.MitigationPlanner=Planner;
})(typeof globalThis!=='undefined'?globalThis:this);
