"""Prepare the school-area forecast without inventing location-based negatives."""
# %% imports
from pathlib import Path
import json
import numpy as np
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt

RADIUS_METRES = 1609.344
METRIC_CRS = 'EPSG:26910'

# %% preparation
def checked_ids(values, label):
    ids=values.astype('string').str.strip()
    if (ids.isna() | ids.str.lower().isin(['', 'none', 'null', 'nan', '<na>'])).any():
        raise ValueError(f'Missing {label} IDs require source reconciliation.')
    return ids


def audit_forecast_sources(payload):
    frames=[]
    for year,rows in payload['crashes'].items():
        d=pd.DataFrame(rows).copy()
        expected=payload['expected_counts'][year]
        if len(d)!=expected:
            raise ValueError(f'{year}: extracted {len(d)}, expected {expected}')
        d['source_year']=int(year)
        frames.append(d)
    crashes=pd.concat(frames,ignore_index=True)
    crashes['case_id']=checked_ids(crashes['Collision Id'],'crash')
    if crashes.case_id.duplicated().any():
        raise ValueError('Missing/duplicate crash IDs require source reconciliation.')
    crashes['date']=pd.to_datetime(crashes['Crash Date Time'],format='mixed',errors='raise')
    if crashes.date.isna().any():
        raise ValueError('Missing collision dates.')
    crashes['date_matches_source_year']=crashes.date.dt.year.eq(crashes.source_year)
    for col in ['Latitude','Longitude','NumberInjured','NumberKilled']:
        crashes[col]=pd.to_numeric(crashes[col],errors='coerce')
    crashes['missing_coordinates']=crashes[['Latitude','Longitude']].isna().any(axis=1)
    crashes['valid_coordinates']=(crashes.Latitude.between(37.0,38.3) & crashes.Longitude.between(-123,-120.8))
    for source,dest in [('Is Preliminary','is_preliminary'),('IsDeleted','is_deleted')]:
        flags=crashes[source].astype('string').str.lower()
        if flags.isna().any() or not flags.isin(['true','false']).all():
            raise ValueError(f'Unknown {source} flags require review.')
        crashes[dest]=flags.eq('true')
    for column in ['NumberInjured','NumberKilled']:
        values=crashes[column].dropna()
        if (values.lt(0) | values.mod(1).ne(0)).any():
            raise ValueError(f'Invalid {column} counts')
    # Source codes describe the worst documented injury; unknown stays unknown.
    ranks={'Fatal':5,'SuspectSerious':4,'SevereInactive':4,'SuspectMinor':3,
           'OtherVisibleInactive':3,'PossibleInjury':2,'ComplaintOfPainInactive':2}
    injury=[]
    for year,rows in payload['injuries'].items():
        for row in rows:
            injury.append({'case_id':row['case_id'],'code':row['ExtentOfInjuryCode'],
                           'n':row['n'],'unique_people':row['distinct_person_ids'],'source_year':int(year)})
    injuries=pd.DataFrame(injury,columns=['case_id','code','n','unique_people','source_year'])
    injuries['case_id']=checked_ids(injuries.case_id,'injury crash')
    if injuries.duplicated(['case_id','code']).any():
        raise ValueError('Duplicate injury-summary groups require reconciliation.')
    for column in ['n','unique_people']:
        injuries[column]=pd.to_numeric(injuries[column],errors='raise')
        if (injuries[column].isna() | injuries[column].lt(1) | injuries[column].mod(1).ne(0)).any():
            raise ValueError('Invalid injury summary counts')
    if not injuries.n.eq(injuries.unique_people).all():
        raise ValueError('Duplicate or missing injury person IDs require reconciliation.')
    crash_year=crashes.set_index('case_id').source_year
    if not injuries.case_id.map(crash_year).eq(injuries.source_year).all():
        raise ValueError('Injury summaries do not match the crash ID/year inventory.')
    unexpected=set(injuries.code.dropna())-set(ranks)
    if unexpected:raise ValueError(f'Unreviewed injury codes: {unexpected}')
    injuries['rank']=injuries.code.map(ranks)
    known=injuries.loc[injuries['rank'].notna()].groupby('case_id').agg(
        known_injury_records=('n','sum'),worst_documented_rank=('rank','max'))
    crashes=crashes.join(known,on='case_id')
    crashes['known_injury_records']=crashes.known_injury_records.fillna(0)
    # Unknown overall severity is never replaced with the least-severe category.
    crashes['documented_severity']=pd.Series('Unknown',index=crashes.index)
    total=crashes.NumberInjured+crashes.NumberKilled
    complete=crashes.known_injury_records.eq(total) & total.notna()
    crashes['injury_totals_reconciled']=complete
    labels={2:'Possible injury / complaint of pain',3:'Minor / visible injury',4:'Serious / severe injury',5:'Fatal'}
    for rank,label in labels.items():
        crashes.loc[complete & crashes.worst_documented_rank.eq(rank),'documented_severity']=label
    crashes.loc[complete & total.eq(0),'documented_severity']='No reported injury'
    crashes.loc[crashes.worst_documented_rank.eq(4),'documented_severity']='Serious / severe injury'
    crashes.loc[crashes.NumberKilled.gt(0)|crashes.worst_documented_rank.eq(5),'documented_severity']='Fatal'
    # Nullable outcome: a false value requires a reconciled nonsevere outcome.
    crashes['fatal_or_severe_outcome']=pd.Series(pd.NA,index=crashes.index,dtype='boolean')
    crashes.loc[crashes.documented_severity.ne('Unknown'),'fatal_or_severe_outcome']=False
    crashes.loc[crashes.documented_severity.isin(['Fatal','Serious / severe injury']),'fatal_or_severe_outcome']=True
    annual=crashes.groupby('source_year').agg(records=('case_id','size'),
        missing_coordinates=('missing_coordinates','sum'),usable_coordinates=('valid_coordinates','sum'),
        preliminary=('is_preliminary','sum'),deleted=('is_deleted','sum'),
        date_year_mismatches=('date_matches_source_year',lambda s:int((~s).sum())))
    annual['missing_coordinate_share']=annual.missing_coordinates/annual.records
    by_city=crashes.groupby(['source_year','City Name']).agg(records=('case_id','size'),
        missing_coordinates=('missing_coordinates','sum'),usable_coordinates=('valid_coordinates','sum'))
    by_city['missing_coordinate_share']=by_city.missing_coordinates/by_city.records
    schools=gpd.GeoDataFrame.from_features(payload['schools']['features'],crs='EPSG:4326').rename(
        columns={'CDSCode':'school_id','SchoolName':'school_name','City':'city','CountyNameGeo':'county'})
    schools['school_id']=checked_ids(schools.school_id,'school')
    if schools.school_id.duplicated().any():raise ValueError('Duplicate school IDs')
    if schools.geometry.isna().any() or schools.geometry.is_empty.any():raise ValueError('School geometry missing')
    if not schools.geom_type.eq('Point').all():raise ValueError('School site geometry must be a point')
    if not (schools.geometry.y.between(37,38.3) & schools.geometry.x.between(-123,-120.8)).all():
        raise ValueError('School coordinates outside expected study region')
    # Current public school sites, not a reconstructed historical campus inventory.
    schools['open_date']=pd.to_datetime(schools.OpenDate,unit='ms',errors='coerce')
    usable=crashes.loc[crashes.valid_coordinates & ~crashes.is_deleted & crashes.date_matches_source_year].copy()
    points=gpd.GeoDataFrame(usable,geometry=gpd.points_from_xy(usable.Longitude,usable.Latitude),crs='EPSG:4326')
    pairs=gpd.sjoin(schools[['school_id','school_name','city','geometry']].to_crs(METRIC_CRS),
        points[['case_id','date','source_year','documented_severity','is_preliminary','geometry']].to_crs(METRIC_CRS),
        how='inner',predicate='dwithin',distance=RADIUS_METRES).drop(columns='index_right')
    # This is a presence-only descriptive table; never label an unmatched school-year as zero.
    counts=pairs.groupby(['school_id','school_name','source_year']).case_id.nunique().rename('matched_records').reset_index()
    counts['interpretation']='Observed matches only; missing locations and border coverage unresolved'
    readiness={
        'prediction_task':'At least one reported pedestrian/bicycle collision within a one-mile school-site radius during the next 12 months',
        'severity_task':'Probability of at least one fatal or serious-injury collision in the same area/window; optional worst-severity distribution',
        'radius_metres':RADIUS_METRES,'school_sites':len(schools),'source_crash_records':len(crashes),
        'missing_coordinates':int(crashes.missing_coordinates.sum()),
        'invalid_nonmissing_coordinates':int((~crashes.valid_coordinates & ~crashes.missing_coordinates).sum()),
        'matched_unique_crashes':int(pairs.case_id.nunique()),'school_crash_pairs':len(pairs),
        'unknown_severity_records':int(crashes.fatal_or_severe_outcome.isna().sum()),
        'unreconciled_injury_totals':int((~crashes.injury_totals_reconciled).sum()),
        'forecast_training_run':False,'school_probabilities_published':False,'zero_outcome_labels_created':False,
        'status':'Additional source reconciliation required before fitting or publishing school-area probabilities',
        'blocking_gaps':['Crash coordinates missing unevenly by municipality and year; unlocated cases cannot be assigned to buffers.',
                         'County/city filters omit potential crashes across one-mile buffer boundaries.',
                         '2025–26 school coordinates do not establish historical campus locations.',
                         'Current next-12-month forecasts require recent predictor history and a documented reporting-lag cutoff.'],
        'source_limits':['Public reporting is not a census of all actual collisions or near misses.',
                         'A pedestrian/bicycle crash near a school does not establish student or school-trip involvement.',
                         'Several school buffers overlap; matching rows are not independent crash events.',
                         'Fatal/serious severity means any documented person in the crash, not necessarily the pedestrian/bicyclist.',
                         'Aggregated injury counts cannot establish person-ID uniqueness across injury-code groups; full severity reconciliation is pending.',
                         'CCRS and the earlier city extract have different identifiers and coverage; they were not concatenated.']}
    return crashes,schools,annual,by_city,pairs,counts,readiness

# %% exports
def export_forecast_preparation(result, output_dir):
    output=Path(output_dir);output.mkdir(parents=True,exist_ok=True)
    crashes,schools,annual,by_city,pairs,counts,readiness=result
    crashes.to_csv(output/'regional_pedbike_crash_audit.csv',index=False)
    annual.to_csv(output/'coordinate_coverage_by_year.csv')
    by_city.to_csv(output/'coordinate_coverage_by_city_year.csv')
    schools[['school_id','school_name','city','county','Year','Status','geometry']].to_file(output/'school_sites.geojson',driver='GeoJSON')
    pairs.drop(columns='geometry').to_csv(output/'one_mile_observed_school_crash_pairs.csv',index=False)
    counts.to_csv(output/'one_mile_observed_counts_NOT_TRAINING_LABELS.csv',index=False)
    (output/'forecast_readiness.json').write_text(json.dumps(readiness,indent=2))
    fig,ax=plt.subplots(figsize=(9,4.5))
    years=annual.index.astype(str)
    ax.bar(years,annual.usable_coordinates,label='Usable coordinates',color='#167b82')
    ax.bar(years,annual.records-annual.usable_coordinates,bottom=annual.usable_coordinates,
           label='Missing or invalid coordinates',color='#b04a20')
    ax.set(title='A one-mile forecast needs located crash records',ylabel='Reported pedestrian/bicycle crashes',xlabel='Source year')
    ax.legend(frameon=False,loc='upper left',bbox_to_anchor=(0,-.17),ncol=2)
    for i,(_,row) in enumerate(annual.iterrows()):
        ax.text(i,row.records+15,f'{row.missing_coordinate_share:.0%} missing',ha='center',fontsize=10)
    ax.set_ylim(0,annual.records.max()*1.17);ax.spines[['top','right']].set_visible(False)
    fig.tight_layout();fig.savefig(output/'coordinate_coverage.png',dpi=170,bbox_inches='tight')
    latest=int(by_city.index.get_level_values(0).max())
    city_data=by_city.loc[latest].sort_values('missing_coordinate_share')
    city_fig,city_ax=plt.subplots(figsize=(9,6))
    city_ax.barh(city_data.index,100*city_data.missing_coordinate_share,color='#b04a20')
    for i,(_,row) in enumerate(city_data.iterrows()):
        city_ax.text(100*row.missing_coordinate_share+1,i,
                     f'{int(row.missing_coordinates)}/{int(row.records)}',va='center',fontsize=9)
    city_ax.set(xlim=(0,122),xlabel='Records missing coordinates (%)',
                title=f'Location coverage varies across jurisdictions · {latest}')
    city_ax.set_xticks([0,25,50,75,100])
    city_ax.spines[['top','right']].set_visible(False)
    city_fig.text(.98,.005,'Bar labels: missing records / all extracted ped/bike records',ha='right',fontsize=9)
    city_fig.tight_layout(rect=[0,.035,1,1])
    city_fig.savefig(output/'coordinate_coverage_by_city.png',dpi=170,bbox_inches='tight')
    return fig,city_fig
