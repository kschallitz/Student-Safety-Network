"""Package the checked two-site study; private worker settings are never included."""
from pathlib import Path
import hashlib,json,shutil,zipfile
import nbformat as nbf
from website_release import version

ROOT=Path(__file__).resolve().parent

def build():
    out=ROOT/'outputs/metadrive_intersections/release';out.mkdir(parents=True,exist_ok=True)
    files=[];summaries=[];available=[]
    files += list((ROOT/'metadrive_intersections').glob('*.py'))
    files += list((ROOT/'data/metadrive_intersections').rglob('*'))
    files += [ROOT/'INTERSECTION_SIMULATION.md',ROOT/'tests/test_bicycle_conflicts.py',ROOT/'tests/test_hillcrest_signals.py',ROOT/'outputs/metadrive_intersections/runtime_environment.json']
    for site in ('Estates','Hillcrest'):
        folder=ROOT/'outputs/metadrive_intersections'/site
        if not (folder/'pilot_site_evidence.json').exists():
            summaries.append(f'{site}: simulator setup checked; full comparison and recommendation pending. Its inputs and simulator code are included for new runs.')
            files.append(folder/'motion_validation.json')
            continue
        available.append(site)
        evidence=json.loads((folder/'pilot_site_evidence.json').read_text())
        assert evidence['releaseChecked'] and evidence['bicycleNearMeasured']
        chosen=[e for e in evidence['episodes'] if e['split']=='test' and e['action']==evidence['selected']]
        summaries.append(f"{site}: {evidence['selected']} selected by {evidence['champion']}; May evaluation has {sum(e['contacts'] for e in chosen)} scored contacts, {sum(e['pedestrianNear'] for e in chosen)} pedestrian and {sum(e['bicycleNear'] for e in chosen)} bicycle near misses.")
        for f in ['pilot_runs.csv','pilot_contexts.csv','pilot_protocol.json','pilot_policy_freeze.json','pilot_quality.json','pilot_evaluation.json','pilot_site_evidence.json','motion_validation.json']:
            files.append(folder/f)
        files+=list((folder/'runs'/evidence['snapshot']).glob('*.json'))
    payload=json.loads((ROOT/'intersection_prediction_output/map_payload.json').read_text())
    archive=out/'MetaDrive_Intersection_RL.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in files:
            if p.is_file():z.write(p,p.relative_to(ROOT))
        z.writestr('intersection_prediction_output/map_payload.json',json.dumps({'junctions':[j for j in payload['junctions'] if j['id'] in ('J01145','J02019')]}))
    cells=[nbf.v4.new_markdown_cell(f'''# Two-site MetaDrive mitigation study · v{version()}

## Saved results

{' '.join(summaries)}

## Goal and setup

Saved results currently available: {', '.join(available)}. The default path checks the saved traffic episodes and retrains the tabular, linear and neural agents on CPU. The scoring includes motor–bicycle near misses, motor–pedestrian near misses and contacts with either vulnerable road user. Vehicle–vehicle contacts remain unscored diagnostics.

Download **MetaDrive_Intersection_RL.zip** beside this notebook and upload it below. New simulation runs are optional and slower. The Mac-generated motion checks, raw episodes, input tables and source fingerprints are included. This notebook is designed for Colab; execution on Colab itself has not been verified.
'''),nbf.v4.new_code_cell('''import importlib.util, subprocess, sys
needed=[p for p in ['pandas','numpy','torch','gymnasium','shapely','scipy','matplotlib'] if importlib.util.find_spec(p) is None]
if needed: subprocess.check_call([sys.executable,'-m','pip','install','-q',*needed])
'''),nbf.v4.new_code_cell('''import os, json, zipfile
from pathlib import Path
try:
    from google.colab import files
except ImportError:
    archive=Path('MetaDrive_Intersection_RL.zip')
else:
    uploaded=files.upload()
    archive=next(Path(name) for name in uploaded if name.endswith('.zip'))
root=Path('intersection_rl_reproduction').resolve()
root.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as z:
    assert all((root/name).resolve().is_relative_to(root) for name in z.namelist())
    z.extractall(root)
os.chdir(root)
sys.path.insert(0,str(root))
SITE='__DEFAULT_SITE__'  # Choose a site with saved results above; restart runtime to switch.
os.environ['SCHOOL_SIM_SITE']=SITE
'''),nbf.v4.new_code_cell('''import pandas as pd
from metadrive_intersections.config import DATA,OUT
from metadrive_intersections.quality import assess
quality,runs=assess()
assert quality['recommendation_released'],quality['release_blockers']
display(pd.Series({k:quality[k] for k in ['site','completed_runs','planned_runs','physics_pass_runs','software_checks_passed','bicycle_near_misses_measured']},name='Result').to_frame())
display(runs.groupby(['split','action'])[['collision_pairs','motor_pedestrian_near_pairs','motor_bicycle_near_pairs','score']].sum())
'''),nbf.v4.new_markdown_cell('''## Retrain and evaluate

### Sources and assumptions

The City’s [East Avenue Tactical Bikeway final report](https://www.livermoreca.gov/home/showpublisheddocument/12943/638887914440930000) supplies the original counts. Site manifests retain source pages and missing-cell exclusions. Counts describe 2023 conditions; geometry is traced from the 2025 drawing. Hillcrest phase structure is documented, while base timing and crossing clearance are assumptions. All-red extends until committed traffic clears; each episode records its extensions. Operating speeds use corridor observations; individual arrivals and driver responses are sampled assumptions.

The three learners reuse March training rewards. March validation selects the agent; the four May periods evaluate its fixed choice. The consultant label is withheld until fitting finishes. These learning updates do not count as fresh simulation episodes.
'''),nbf.v4.new_code_cell('''from metadrive_intersections.learning import fit,evaluate
policy=fit(updates=10000)
evaluation=evaluate()
display(pd.DataFrame(evaluation['comparison'])[['policy','action','contacts','pedestrian_near_pairs','bicycle_near_pairs','score']].rename(columns={'pedestrian_near_pairs':'Pedestrian near misses','bicycle_near_pairs':'Bicycle near misses'}))
print(evaluation['evaluation_status'])
'''),nbf.v4.new_code_cell('''from metadrive_intersections.export import build
evidence=build()
print('Chosen:',evidence['selected'],'by',evidence['champion'])
print('Best May score ties:',evidence['tiedBestEvaluationActions'])
print('Bicycle near misses included:',evidence['bicycleNearMeasured'])
'''),nbf.v4.new_code_cell('''import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
may=runs[runs['split'].eq('test')].groupby('action').agg(
    contacts=('collision_pairs','sum'), pedestrian=('motor_pedestrian_near_pairs','sum'),
    bicycle=('motor_bicycle_near_pairs','sum'), travelers=('arrived','sum'))
assert may.travelers.nunique()==1
fig,axes=plt.subplots(1,2,figsize=(11,5),layout='constrained',sharey=True)
labels=[a+(' · agent' if a==evidence['selected'] else '')+
        (' · consultant' if a==evidence['consultant'] else '') for a in may.index]
bars=axes[0].barh(labels,may.contacts,color='#465a69')
axes[0].bar_label(bars,padding=5)
axes[0].set_title('Motor–pedestrian/bicycle contacts')
axes[1].barh(labels,may.pedestrian,color='#18758b',label='Pedestrian')
bars=axes[1].barh(labels,may.bicycle,left=may.pedestrian,color='#bf741a',hatch='//',label='Bicycle')
axes[1].bar_label(bars,labels=(may.pedestrian+may.bicycle).astype(str),padding=5)
axes[1].set_title('Measured near misses');axes[1].legend(loc='lower right')
for ax,maximum in zip(axes,[may.contacts.max(),(may.pedestrian+may.bicycle).max()]):
    ax.set_xlim(0,max(1,maximum*1.25));ax.xaxis.set_major_locator(MaxNLocator(integer=True))
    ax.set_xlabel('Distinct pairs across four May periods')
    ax.spines[['top','right']].set_visible(False)
axes[0].invert_yaxis()
fig.suptitle(f'{SITE}: {int(may.travelers.iloc[0]):,} matched travelers per design')
plt.show()
print('Raw totals from one matched arrival realization per period; no uncertainty interval is estimated here.')
'''),nbf.v4.new_markdown_cell('''## Optional: generate fresh MetaDrive episodes

The default is off. This installs the pinned official MetaDrive source and reruns movement checks before making a new 72-episode Hillcrest or 96-episode Estates matrix. Keep the runtime connected; CPU execution can take hours. Signal phase durations, arrival seconds and driver responses are assumptions recorded in the protocol. All candidates receive matched arrivals and must finish their traffic cohorts.
'''),nbf.v4.new_code_cell('''RUN_NEW=False
RUN_SITE=SITE  # Both 'Hillcrest' and 'Estates' inputs and simulator setups are included.
if RUN_NEW:
    vendor=root/'vendor/metadrive'
    if not vendor.exists():
        subprocess.check_call(['git','clone','https://github.com/metadriverse/metadrive.git',str(vendor)])
        subprocess.check_call(['git','-C',str(vendor),'checkout','85e5dadc6c7436d324348f6e3d8f8e680c06b4db'])
    subprocess.check_call([sys.executable,'-m','pip','install','-e',str(vendor)])
    env={**os.environ,'PYTHONPATH':str(vendor),'SCHOOL_SIM_SITE':RUN_SITE}
    commands=[['validate'],['run','--suite','colab_new','--start-realization','100','--workers','2'],
              ['learning','--suite','colab_new'],['export','--suite','colab_new']]
    for args in commands:
        subprocess.check_call([sys.executable,'-m','metadrive_intersections.'+args[0],*args[1:]],env=env)
''')]
    for cell in cells:cell.source=cell.source.replace('__DEFAULT_SITE__',available[-1])
    nb=nbf.v4.new_notebook(cells=cells,metadata={'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'}})
    nbf.write(nb,out/'MetaDrive_Intersection_RL.ipynb')
    (out/'bundle_sha256.txt').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
    for target in ('hosted_map/out','hosted_map/public'):
        for f in [archive,out/'MetaDrive_Intersection_RL.ipynb']:
            shutil.copy2(f,ROOT/target/f.name)
    print(archive)

if __name__=='__main__':build()
