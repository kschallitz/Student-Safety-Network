"""Independent NumPy calculation of the published-reference example and envelope."""
import numpy as np


def exported_rates(model, rows):
    x=np.asarray(rows,float)
    regional=np.concatenate([x[:,:10],x[:,12:18]],axis=1)
    r=model['regional']
    # The saved default is a Poisson GLM. Neural baseline verification is covered
    # by the existing native estimator/JavaScript export check.
    assert r['kind']=='poisson_glm'
    mu=np.exp(r['intercept']+((regional-np.array(r['mean']))/r['scale'])@r['weights'])
    mu*=np.array(model['city_factors'])[x[:,18].astype(int)]
    pooled=(x[:,10]+model['prior_years']*mu)/(x[:,11]+model['prior_years'])
    a,b=model['calibration']
    return pooled*np.exp(a)*pooled.sum()**(b-1)


def reference_example(inputs):
    e=inputs['evidence'];before=exported_rates(inputs['model'],inputs['x'])
    draws=np.array([exported_rates(m,inputs['x']) for m in inputs['bootstrap']])
    times=np.array(e['school_time_by_city']['LIVERMORE']['fraction'])
    beta=np.log(e['rate_ratio'])/(e['after_mph']-e['before_mph'])
    factor=np.exp(beta*(25-30));after=before*(1+.5*times*(factor-1))
    factors=[1,factor]+[np.exp(np.log(r)/(e['after_mph']-e['before_mph'])*(25-30)) for r in e['rate_ratio_interval']]
    lower=[];upper=[]
    for f in factors:
        for share in [0,.5,1]:
            annual=-np.expm1(-(draws*(1+share*times*(f-1))).sum(axis=1))
            q=np.quantile(annual,[.05,.95]);lower.append(q[0]);upper.append(q[1])
    p=-np.expm1(-after.sum())
    return {'baseline':float(-np.expm1(-before.sum())),'scenario':float(p),
            'range':[float(min(p,*lower)),float(max(p,*upper))]}
