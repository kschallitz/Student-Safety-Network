"""Three one-step Q-learning families; no benchmark/test file is read here."""
import hashlib,json,math
import numpy as np,pandas as pd,torch
from torch import nn
from .prepare import ROOT,DATA,OUT,ACTIONS,sha
from .events import reward
FEATURES=['log_motor','log_pedestrian','log_bicycle','hour_sin','hour_cos','weekend','heavy_share']
def features(c):
 motor=c.passenger.to_numpy()+c.heavy.to_numpy();h=c.hour.to_numpy()
 return np.column_stack([np.log1p(motor),np.log1p(c.pedestrian),np.log1p(c.bicycle),np.sin(h/24*2*np.pi),np.cos(h/24*2*np.pi),c.weekend,c.heavy/np.maximum(motor,1)]).astype(float)
def key(c):
 return f'{int(c["hour"]//3)}_{int(np.digitize(c["pedestrian"],[1,5,15,40]))}_{int(np.digitize(c["passenger"]+c["heavy"],[150,250,400]))}'
def scored(split):
 d=pd.read_csv(OUT/f'{split}_runs.csv');base=d[d.action.eq('A0')][['context_id','seed','collision','near','mean_motor_delay']].rename(columns={'collision':'base_collision','near':'base_near','mean_motor_delay':'base_delay'})
 d=d.merge(base,on=['context_id','seed'],validate='many_to_one')
 d['reward']=[reward(r.collision,r.near,r.base_collision,r.base_near) if r.complete else np.nan for r in d.itertuples()]
 return d
def values(model,c):
 x=(features(c)-np.array(model['mean']))/np.array(model['std'])
 if model['family']=='tabular':return np.array([model['table'].get(key(row),model['fallback']) for row in c.to_dict('records')])
 if model['family']=='linear':return np.column_stack([x,np.ones(len(x))])@np.array(model['weights'])
 for layer in model['layers']:
  x=x@np.array(layer['weight']).T+np.array(layer['bias'])
  if layer['activation']=='tanh':x=np.tanh(x)
 return x
def evaluate(model,contexts,d):
 c=contexts.copy();c['chosen']=[ACTIONS[i] for i in values(model,c).argmax(1)]
 picks=c[['context_id','chosen']].merge(d,left_on=['context_id','chosen'],right_on=['context_id','action'],validate='one_to_many')
 eligible=bool(picks.complete.all() and (picks.mean_motor_delay-picks.base_delay).mean()<=30)
 return {'mean_reward':float(picks.reward.mean()),'eligible':eligible,'delay_increase':float((picks.mean_motor_delay-picks.base_delay).mean()),'choices':c[['context_id','chosen']].to_dict('records')}
def train(family,seed,c,d):
 rng=np.random.default_rng(seed);torch.set_num_threads(1);torch.manual_seed(seed)
 mu=features(c).mean(0);sd=features(c).std(0);sd[sd<1e-6]=1;x=(features(c)-mu)/sd
 model={'family':family,'seed':seed,'features':FEATURES,'mean':mu.tolist(),'std':sd.tolist(),'actions':ACTIONS,'gamma':0,'steps':6000}
 # A sampled transition reveals ONLY its selected action's reward to the update.
 blocks=d.pivot(index=['context_id','seed'],columns='action',values='reward')[ACTIONS].dropna()
 rewards=blocks.to_numpy();indices=c.reset_index().set_index('context_id')['index'];ix=np.array([indices[k[0]] for k in blocks.index]);keys=[key(z) for z in c.to_dict('records')]
 table={k:np.zeros(4) for k in keys};fallback=np.zeros(4);counts=np.zeros(4);w=np.zeros((x.shape[1]+1,4));net=nn.Sequential(nn.Linear(7,32),nn.Tanh(),nn.Linear(32,32),nn.Tanh(),nn.Linear(32,4));opt=torch.optim.Adam(net.parameters(),lr=.001)
 logs=[];window=[]
 for step in range(6000):
  j=int(rng.integers(len(rewards)));i=ix[j];xx=x[i];epsilon=max(.08,1-step/4500)
  if family=='tabular':q=table[keys[i]]
  elif family=='linear':q=np.r_[xx,1.]@w
  else:
   with torch.no_grad():q=net(torch.tensor(xx,dtype=torch.float32)).numpy()
  a=int(rng.integers(4)) if rng.random()<epsilon else int(np.argmax(q));r=float(rewards[j,a]);window.append(r)
  counts[a]+=1;fallback[a]+=(r-fallback[a])/counts[a]
  if family=='tabular':table[keys[i]][a]+=.08*(r-q[a])
  elif family=='linear':w[:,a]+=.01*(r-q[a])*np.r_[xx,1.]/max(1,float(np.dot(xx,xx)))
  else:
   pred=net(torch.tensor(xx,dtype=torch.float32))[a];loss=(pred-r)**2;opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),10);opt.step()
  if (step+1)%200==0:logs.append({'agent':f'{family}_{seed}','episode':step+1,'mean_training_reward':float(np.mean(window)),'epsilon':epsilon});window=[]
 if family=='tabular':model.update(table={k:v.tolist() for k,v in table.items()},fallback=fallback.tolist())
 elif family=='linear':model['weights']=w.tolist()
 else:model['layers']=[{'weight':layer.weight.detach().numpy().tolist(),'bias':layer.bias.detach().numpy().tolist(),'activation':'linear' if n==4 else 'tanh'} for n,layer in enumerate(net) if isinstance(layer,nn.Linear)]
 return model,logs
def main():
 c=pd.read_csv(DATA/'contexts.csv');tr=scored('train');va=scored('validation');logs=[];records=[];models={}
 # Full action blocks: no selective omission of a failed action's outcome.
 valid=tr.groupby(['context_id','seed']).complete.all();bad=valid[~valid].reset_index()[['context_id','seed']]
 tr=tr.merge(valid.rename('block_complete'),on=['context_id','seed']);tr=tr[tr.block_complete].copy();bad.to_csv(OUT/'excluded_training_blocks.csv',index=False)
 assert tr.action.nunique()==4 and not tr.empty
 assert tr.groupby(['context_id','seed']).demand_sha256.nunique().eq(1).all()
 train_c=c[c.split.eq('train')].reset_index(drop=True);val_c=c[c.split.eq('validation')].reset_index(drop=True)
 for family in ['tabular','linear','neural']:
  for seed in [41,73,109]:
   model,history=train(family,seed,train_c,tr);name=f'{family}_{seed}';models[name]=model;logs+=history
   val=evaluate(model,val_c,va);records.append({'agent':name,'family':family,'seed':seed,**{k:v for k,v in val.items() if k!='choices'}})
 ranking=sorted(records,key=lambda x:(not x['eligible'],-x['mean_reward'],x['agent']))
 chosen={f:next(r['agent'] for r in ranking if r['family']==f) for f in ['tabular','linear','neural']}
 bestfixed=tr.groupby('action').reward.mean().sort_index().idxmax();champion=ranking[0]['agent']
 (OUT/'models.json').write_text(json.dumps(models,indent=2));pd.DataFrame(logs).to_csv(OUT/'training_history.csv',index=False);pd.DataFrame(records).to_csv(OUT/'validation_agents.csv',index=False)
 frozen={'algorithm':'one-step Q learning / contextual bandits','representatives':chosen,'champion':champion,'best_fixed_training_action':bestfixed,'selection':'validation mean reward; eligible first; ties lexicographic agent ID','training_only_actions':ACTIONS,'hidden_benchmark_accessed':False,'post_test_accessed':False,'excluded_train_blocks':len(bad),'models_sha256':sha(OUT/'models.json'),'train_sha256':sha(OUT/'train_runs.csv'),'validation_sha256':sha(OUT/'validation_runs.csv'),'protocol_sha256':sha(ROOT/'mitigation_rl/protocol.md'),'trainer_sha256':sha(__file__)}
 (OUT/'policy_freeze.json').write_text(json.dumps(frozen,indent=2));print(json.dumps(frozen,indent=2))
if __name__=='__main__':main()
