"""Constant-velocity oriented-footprint contact surrogate; analytic interval SAT."""
import math,numpy as np
def body(x,y,angle,speed,length,width,front=True):
 t=math.radians(angle);u=np.array([math.sin(t),math.cos(t)]);v=np.array([u[1],-u[0]])
 center=np.array([x,y])-u*length/2 if front else np.array([x,y])
 return (center,u*speed,u,v,length/2,width/2)
def ttc(a,b,horizon=2.):
 """First projected footprint overlap; None if no contact within horizon."""
 dp=b[0]-a[0];dv=b[1]-a[1];entry,leave=0.,horizon
 for axis in [a[2],a[3],b[2],b[3]]:
  radius=abs(axis@a[2])*a[4]+abs(axis@a[3])*a[5]+abs(axis@b[2])*b[4]+abs(axis@b[3])*b[5]
  p=float(dp@axis);vel=float(dv@axis)
  if abs(vel)<1e-9:
   if abs(p)>radius:return None
   continue
  lo,hi=sorted([(-radius-p)/vel,(radius-p)/vel]);entry=max(entry,lo);leave=min(leave,hi)
  if entry>leave:return None
 return max(0.,entry) if leave>=0 and entry<=horizon else None
def reward(collision,near,base_collision,base_near):
 return -10 if collision else -5 if near else 1 if base_collision or base_near else 0
def test():
 # Head-on: centers 10m apart, two 2m bodies, closing speed 4m/s -> 2s.
 a=body(0,0,90,2,2,1,False);b=body(10,0,270,2,2,1,False)
 assert abs(ttc(a,b,3)-2)<1e-8
 assert ttc(a,body(0,4,90,2,2,1,False),3) is None
 assert ttc(a,body(10,0,90,4,2,1,False),3) is None
 assert ttc(a,body(0,0,0,0,1,1,False))==0
 assert [reward(*x) for x in [(1,1,0,0),(0,1,1,1),(0,0,0,1),(0,0,0,0)]]==[-10,-5,1,0]
 return {'analytic_ttc_cases':4,'reward_precedence_cases':4,'passed':True}
if __name__=='__main__':print(test())
