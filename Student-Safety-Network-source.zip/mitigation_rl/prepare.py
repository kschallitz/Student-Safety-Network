"""Prepare anonymous generic actions without using installed-pilot geometry."""
import copy,hashlib,json,shutil,xml.etree.ElementTree as E
from pathlib import Path
import numpy as np,pandas as pd
from shapely.geometry import Polygon,Point
ROOT=Path(__file__).resolve().parents[1];DATA=ROOT/'data/mitigation_rl';OUT=ROOT/'outputs/mitigation_rl'
ACTIONS=['A0','A1','A2','A3']
LABELS={'A0':'No intervention','A1':'25 mph operating-response scenario','A2':'Generic curb extensions (0.75 m)','A3':'Generic curbs + 25 mph response','H':'Held-out implemented pilot'}
SEEDS={'train':[81011,81023,81041],'validation':[82009,82021],'test':[83003,83017,83029]}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def speed_network(src,dest):
 shutil.copytree(src,dest,dirs_exist_ok=True);r=E.parse(dest/'network.net.xml')
 for e in r.findall('edge'):
  if e.get('id','').startswith(('E_','W_',':')):
   for l in e.findall('lane'):
    if l.get('allow')!='pedestrian':l.set('speed',str(min(float(l.get('speed','99')),25*.44704)))
 for c in r.findall('connection'):
  if 'speed' in c.attrib:c.set('speed',str(min(float(c.get('speed')),25*.44704)))
 E.indent(r);r.write(dest/'network.net.xml',encoding='utf-8',xml_declaration=True)
def main():
 DATA.mkdir(parents=True,exist_ok=True);OUT.mkdir(parents=True,exist_ok=True)
 d=pd.read_csv(ROOT/'data/sumo_v02/junction_demand_15min.csv');d=d[d.site.eq('Estates')].copy()
 d['context_id']=d.interval_start.str.replace(':','',regex=False).str.replace('-','',regex=False)
 dates=d.interval_start.str[:10];d['split']=np.where(dates.eq('2023-03-02'),'train',np.where(dates.eq('2023-02-11'),'validation','test'))
 d.to_csv(DATA/'observations.csv',index=False)
 contexts=d.groupby(['context_id','interval_start','split','phase'])['count'].sum().reset_index(name='total')
 for mode in ['passenger','heavy','bicycle','pedestrian']:
  contexts[mode]=contexts.context_id.map(d[d['mode'].eq(mode)].groupby('context_id')['count'].sum()).fillna(0).astype(int)
 contexts['hour']=pd.to_datetime(contexts.interval_start).dt.hour+pd.to_datetime(contexts.interval_start).dt.minute/60
 contexts['weekend']=(pd.to_datetime(contexts.interval_start).dt.dayofweek>=5).astype(int)
 contexts.to_csv(DATA/'contexts.csv',index=False)
 nets=DATA/'networks';base=ROOT/'outputs/sumo_v06/networks/Estates/before';shutil.copytree(base,nets/'A0',dirs_exist_ok=True)
 # Keep only pre-layout coordinates. No installed-pilot array or median is used.
 import sumo_v06.network as builder
 source=builder.TRACE;spec=copy.deepcopy(source['Estates']);clean={}
 for k,v in spec.items():
  if k in ['corners','crossings']:clean[k]={n:{kk:vv for kk,vv in a.items() if kk!='pilot'} for n,a in v.items()}
  elif k!='medians':clean[k]=v
 clean['medians']=[]
 sanitized={'metres_per_pixel':source['metres_per_pixel'],'Estates':clean}
 (DATA/'retained_geometry.json').write_text(json.dumps(sanitized,indent=2))
 generic=copy.deepcopy(sanitized);scale=source['metres_per_pixel'];origin=np.array(clean['origin'])
 def pixels(points):
  a=(np.array(points)-250)/scale;a[:,1]*=-1;return (a+origin).tolist()
 central=Point(250,250).buffer(20)
 for name,corner in generic['Estates']['corners'].items():
  p=Polygon(builder.xy('Estates',clean['corners'][name]['before']))
  expanded=p.union(p.buffer(.75,join_style=2).intersection(central));corner['before']=pixels(list(expanded.exterior.coords)[:-1])
 for name,cross in generic['Estates']['crossings'].items():
  a,b=builder.xy('Estates',clean['crossings'][name]['before']);u=(b-a)/np.linalg.norm(b-a)
  # Endpoints inside central area move with generic curb extension.
  aa=a+.75*u if central.contains(Point(a)) else a;bb=b-.75*u if central.contains(Point(b)) else b
  cross['before']=pixels([aa,bb])
 (DATA/'generic_geometry.json').write_text(json.dumps(generic,indent=2))
 builder.TRACE=generic;builder.OUT=OUT/'generic_build';p=builder.build('Estates','before');shutil.copytree(p,nets/'A2',dirs_exist_ok=True)
 speed_network(nets/'A0',nets/'A1');speed_network(nets/'A2',nets/'A3')
 catalog=[{'id':a,'label':LABELS[a],'available_during_training':True,'net_sha256':sha(nets/a/'network.net.xml')} for a in ACTIONS]
 (DATA/'actions.json').write_text(json.dumps(catalog,indent=2))
 manifest={'protocol_sha256':sha(ROOT/'mitigation_rl/protocol.md'),'train_contexts':int(contexts.split.eq('train').sum()),'validation_contexts':int(contexts.split.eq('validation').sum()),'test_contexts':int(contexts.split.eq('test').sum()),'actions':catalog,'hidden_pilot_in_training':False,'post_outcomes_in_training':False,'scope':'retrospective policy holdout; developer knew study','pre_observations_sha256':hashlib.sha256(d[d.split.eq('train')].to_csv(index=False).encode()).hexdigest()}
 (OUT/'preparation.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest))
if __name__=='__main__':main()
