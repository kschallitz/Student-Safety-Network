"""Publish inspectable results and a portable, executable coursework companion."""
import base64,hashlib,html,io,json,re,shutil,zipfile
from pathlib import Path
import numpy as np,pandas as pd,nbformat
from .prepare import ROOT,DATA,OUT,ACTIONS,LABELS,sha
from .learn import values

def figures(results,freeze):
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
 names=list(freeze['representatives'].values())+['A0','best_fixed','random','H']
 d=pd.DataFrame(results['policies']).set_index('policy').loc[names]
 labels=[n.split('_')[0].title()+' Q' if n in freeze['representatives'].values() else {'A0':'Unchanged','best_fixed':'Best fixed from training','random':'Uniform random','H':'Held-out pilot'}[n] for n in names]
 fig,ax=plt.subplots(figsize=(9,4.5),layout='constrained');y=np.arange(len(d));ax.errorbar(d.mean_reward,y,xerr=[d.mean_reward-d.reward_low,d.reward_high-d.mean_reward],fmt='o',color='#147787',capsize=4)
 ax.axvline(0,color='#9eb0b6',lw=.7);ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlabel('Mean held-out episode reward (higher is better)');ax.set_title('Estates · 96 paired episodes per policy · 95% context-bootstrap intervals',loc='left',fontsize=11);ax.grid(axis='x',alpha=.15)
 fig.savefig(OUT/'policy_results.png',dpi=160);plt.close(fig)
 s=pd.read_csv(OUT/'threshold_sensitivity.csv');fig,ax=plt.subplots(figsize=(9,4),layout='constrained')
 for name,color in [(freeze['champion'],'#147787'),('A0','#697c89'),('H','#bb6c25')]:
  z=s[s.policy.eq(name)];ax.plot(z.ttc_seconds,100*z.episode_fraction,'o-',label=name if name!='H' else 'Held-out pilot',color=color)
 ax.set_xticks([1,1.5,2]);ax.set_xlabel('Projected time-to-contact threshold (seconds)');ax.set_ylabel('Episodes with a near-miss surrogate (%)');ax.set_ylim(0,100);ax.legend();ax.grid(alpha=.15);fig.savefig(OUT/'thresholds.png',dpi=160);plt.close(fig)
 h=pd.read_csv(OUT/'training_history.csv');fig,ax=plt.subplots(figsize=(9,4),layout='constrained')
 for family,g in h.groupby(h.agent.str.split('_').str[0]):
  z=g.groupby('episode').mean_training_reward.mean();ax.plot(z.index,z,label=family)
 ax.set_xlabel('Selected-action updates per agent');ax.set_ylabel('Training reward (200-update blocks)');ax.set_title('Exploration decreases during training; this curve is not a holdout test',loc='left',fontsize=11);ax.legend();ax.grid(alpha=.15);fig.savefig(OUT/'learning.png',dpi=160);plt.close(fig)

def documentation(results,verification,finding):
 f=results['frozen_selection'];pol=pd.DataFrame(results['policies']).set_index('policy');champ=pol.loc[f['champion']];base=pol.loc['A0'];h=pol.loc['H'];out=OUT/'paper_materials';out.mkdir(exist_ok=True)
 text=f'''# COSC 645 final project: evidence and writing pack

Prepared October 3, 2026. This is documentation material, not a completed 8–10-page paper.

## Assignment requirements captured from the user
The paper requires 8–10 pages, APA guidelines, Times New Roman 12-point font, and code in an appendix. Application description and development plan are each worth 75 points; anticipated roadblocks and writing quality are each worth 25. The user clarified the working project must be complete by Wednesday, October 7, ahead of the Sunday write-up deadline. The rubric specifies Sunday before 11:59 PM and a presentation the following week.

## 1. Application description (75 points)
Proposed application: a school-area traffic mitigation decision-support tool in the public transportation and education sectors. A school administrator or transportation planner can inspect collision history, observed school-period traffic, and simulated interventions. The working experiment focuses on East Avenue and Estates Avenue near East Avenue Middle School in Livermore.

The original intersection explorer estimates recorded pedestrian/bicycle injury-collision probabilities from historical records and road features. Its percentage estimates are a separate statistical model. This experiment does not use those probabilities as SUMO targets or as reward. It uses observed traffic demand, reconstructed road geometry and pre-period speed behavior to compare interventions under matched conditions.

Existing traffic microsimulators, including SUMO and the consultants' SimTraffic workflow, already model individual road users. The proposed contribution is the integration of a school-focused explorer with transparent reinforcement-learning intervention selection, a held-out implemented treatment, and downloadable provenance. Do not claim that agent-based traffic simulation or RL traffic control is novel.

Initial use: exploratory planning and a classroom demonstration. The app is not yet evidence for installing a particular treatment or claiming a real-world collision reduction. Transfer to Christensen and Altamont Creek requires site-specific demand and geometry and a new validation study.

## 2. Development plan and implemented system (75 points)
Implemented stack: Python, Eclipse SUMO/libsumo 1.27.1, Gymnasium, NumPy, pandas, PyTorch, Shapely for generic geometry construction, Matplotlib, Jupyter/Colab, and a static JavaScript web interface. Training and simulation execute on CPU. No OpenAI API, paid model service, GPU or TPU is required by this workflow.

Data model: one observed 15-minute context contains turning movements and pedestrian crossings, with passenger vehicles, heavy vehicles, bicycles and pedestrians preserved separately. Four source dates supply 64 contexts: March 2 (24 training), February 11 (8 validation), and May 18/20 (32 testing). Simulation seeds produce conditional repeats, not new observed dates. Published speed observations and pre-installation geometry support behavior and network construction. The current map's OSM features and crash probabilities were not substituted for source-specific East Avenue geometry or observed counts.

Seven policy features: log motor volume, log pedestrian crossings, log bicycle volume, sine and cosine of time of day, weekend indicator and heavy-vehicle share. Means and standard deviations come from training contexts only. Tabular Q discretizes demand and time; linear Q and neural Q use standardized features. The neural policy has two 32-unit tanh layers and four action values.

The environment is a one-step decision: choose an intervention, execute a traffic episode, collect a reward, and terminate. This is contextual-bandit reinforcement learning with gamma=0, not a multistep autonomous-driving controller. Each vehicle follows SUMO behavior; the RL agent chooses the site intervention.

Generic training actions: A0 unchanged; A1 an assumed 25 mph operating response; A2 generic 0.75 m curb extensions derived solely from retained geometry; A3 both. A changed sign does not guarantee the assumed speed response. The actual pilot H is evaluated after policy freezing and is never a training action. The developer already knew the published study; this is a retrospective policy holdout, not a fully blind prospective discovery.

Reward: -10 when any motor/VRU collision occurs, otherwise -5 when any qualifying near miss occurs, otherwise +1 if the matched baseline had either event, otherwise 0. Unique motor/VRU pairs are counted. A collision is a SUMO physical overlap; a near miss is projected oriented-footprint contact in >0 to 1.5 seconds at current velocity and heading. Pedestrians must be on a crossing and the motor vehicle must be moving at least 1 m/s. This is an explicit surrogate, not an observed field label.

Training: three families × three learner seeds × 6,000 selected-action updates = 54,000 updates, reusing 288 training SUMO runs. Validation uses 64 SUMO runs; final testing uses 480 (32 contexts × 3 simulation seeds × 5 layouts). Total primary simulations: 832. Every action in a matched block uses the same travelers and desired speeds. Incomplete runs are invalid, not safe outcomes. Delay increases above 30 seconds per motor vehicle make a policy ineligible.

Before opening test results, validation selected {f['champion']}; the linear champion tied the best tabular validation scores and was selected by the frozen deterministic tie rule. The best fixed training action was {f['best_fixed_training_action']}. Test data were not used to select or refit either.

## Results that may be reported
{finding}

The frozen champion's mean reward was {champ.mean_reward:.3f} (95% context-bootstrap interval {champ.reward_low:.3f} to {champ.reward_high:.3f}); unchanged was {base.mean_reward:.3f}. The paired reward improvement was {champ.reward_gain_vs_baseline:.3f} (interval {champ.gain_low:.3f} to {champ.gain_high:.3f}). The champion's simulated near-miss episode frequency was {champ.near_miss_fraction:.1%}; unchanged was {base.near_miss_fraction:.1%}. The pilot benchmark's mean reward was {h.mean_reward:.3f}, with a near-miss frequency of {h.near_miss_fraction:.1%}.

The champion selected a generic curb-extension component in {champ.curb_component_agreement:.1%} of test contexts. This compares intervention family, not exact geometry. {results['completed_test_simulations']}/{results['test_simulations']} test simulations completed. All {verification['fine_runs_completed']}/{verification['fine_step_runs']} numerical-check runs completed; {verification['changed_event_classifications']}/{verification['checked_context_action_pairs']} classifications changed with the finer integration step. A separate post-hoc audit repeated the three test episodes with contacts at 0.05 seconds: all three contacts persisted. One involved a stopped vehicle and a moving pedestrian. These overlaps are simulator diagnostics, not calibrated injury events; the audit did not alter rewards or train new agents.

Intervals resample the 32 observed context clusters and condition on this simulator and two test dates. They omit field-label, parameter, geometric and seasonal uncertainty. A zero observed collision count does not establish zero risk. The experiment does not demonstrate that any policy reduces annual real-world collision probability.

## 3. Anticipated roadblocks (25 points)
Development: imperfect source geometry and uncertain as-built dates; lack of numerical field conflict and turning-speed targets; sparse observed dates; imbalance between weekday training and Saturday validation; unstable policy selection from small samples; simplified driver compliance and pedestrian behavior; numerical contact artifacts; package/runtime reproducibility. Addressed now: source labels, paired demand hashes, explicit reward, held-out policy selection, completion checks, numerical sensitivity, portable model exports and a runnable environment. Still needed: a field-validated conflict measure, broader counts, geometry verification and repeated intervention studies.

Implementation after launch: local traffic changes and model drift, incomplete counts at additional schools, accessibility, transparent uncertainty, practical feasibility and costs of interventions, and avoidance of overclaiming a causal safety benefit. Filming road users introduces privacy and retention considerations; aggregate counts can often serve the modeling need. Proposed recommendations still require transportation engineering review and local field validation.

The website performs real trained-policy inference in JavaScript but displays cached SUMO outcomes. It does not run SUMO on a hosting server. The notebook's environment runs new simulations locally or on a Colab CPU. This distinction should appear in the paper and demonstration.

## Suggested paper structure
Application, intended users and related systems: 2–3 pages. Development architecture, data and RL method: 3–4 pages. Demonstration and evaluation: 1–2 pages. Development and implementation roadblocks: 1–2 pages. Adjust the final body to the instructor's 8–10-page requirement; place code in an appendix. Confirm whether title/reference pages count before final pagination.

## Evidence to cite and inspect
- City of Livermore. (n.d.). *East Avenue tactical bikeway final report*. https://www.livermoreca.gov/home/showpublisheddocument/12943/638887914440930000 — published counts and speed observations; confirm the report's title-page date before final APA formatting.
- HMH. (2025, April 3). *East Avenue permanent treatments memorandum* [Technical memorandum; verify exact title on source]. https://library.livermoreca.gov/home/showpublisheddocument/12945/638887914731000000 — geometric evidence, with acquisition-date uncertainty.
- Eclipse SUMO. (n.d.). *Safety*. https://sumo.dlr.de/docs/Simulation/Safety.html — physical overlap and simulation safety behavior.
- Eclipse SUMO. (n.d.). *SSM device*. https://sumo.dlr.de/docs/Simulation/Output/SSM_Device.html — existing surrogate outputs; this project's pedestrian-inclusive detector is separate custom code.
- Farama Foundation. (n.d.). *Env*. https://gymnasium.farama.org/api/env/ — reset/step environment interface.

These are working reference notes, not a fully checked APA reference page. The source audit remains available in the field-validation lab. The source report has no quantitative near-miss or collision-reduction target against which these rewards can be calibrated.

## Appendix and reproduction pointers
`mitigation_rl/events.py`: event geometry and reward. `environment.py`: live Gymnasium reset/step. `learn.py`: policies and selected-action updates. `simulator.py`: actual SUMO execution. `protocol.md`: frozen design. `policy_freeze.json`: model/selection hashes. CSVs contain every primary episode and policy aggregate. The notebook embeds its reproduction bundle and can rerun the full workflow.
'''
 (out/'Evidence_Pack.md').write_text(text)
 # Readable HTML without depending on a Markdown renderer.
 body=[]
 for paragraph in text.split('\n\n'):
  if paragraph.startswith('# '):body.append('<h1>'+html.escape(paragraph[2:])+'</h1>')
  elif paragraph.startswith('## '):body.append('<h2>'+html.escape(paragraph[3:])+'</h2>')
  else:body.append('<p>'+html.escape(paragraph).replace('\n','<br>')+'</p>')
 (out/'Evidence_Pack.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>COSC 645 evidence pack</title><style>body{max-width:900px;margin:32px auto;padding:0 20px;font:17px/1.6 Georgia,serif;color:#193b4d}h1,h2{font-family:system-ui}h2{margin-top:40px}</style><a href="/mitigation-lab">Return to mitigation lab</a>'+''.join(body)+'</html>')
 (out/'Appendix_Sample.py').write_text('''# Illustrative live use; full runnable context is in the notebook.
import json
import pandas as pd
from mitigation_rl.environment import MitigationEnv
from mitigation_rl.learn import values
from mitigation_rl.prepare import OUT

freeze = json.loads((OUT / 'policy_freeze.json').read_text())
models = json.loads((OUT / 'models.json').read_text())
env = MitigationEnv('test')
observation, info = env.reset(seed=413)
q = values(models[freeze['champion']], pd.DataFrame([env.context]))[0]
action = int(q.argmax())
observation, reward, terminated, truncated, info = env.step(action)
print(action, reward, info['result']['near_pairs'])
''')

def bundle():
 paths=list((ROOT/'mitigation_rl').glob('*.py'))+[ROOT/'mitigation_rl/protocol.md']
 paths += [ROOT/'sumo_v06'/f for f in ['demand.py','network.py']]
 paths += list(DATA.glob('*.csv'))+list(DATA.glob('*.json'))+list((DATA/'networks').rglob('*.xml'))+list((DATA/'networks').rglob('*.json'))
 paths += [ROOT/'data/sumo_v06/traces.json',ROOT/'data/sumo_v02/junction_demand_15min.csv',ROOT/'outputs/sumo_v02/calibration.json',ROOT/'outputs/sumo_v07/calibration.json',ROOT/'outputs/sumo_v03/east_joined.net.xml']
 paths += list((ROOT/'outputs/sumo_v06/networks/Estates').rglob('*.xml'))+list((ROOT/'outputs/sumo_v06/networks/Estates').rglob('*.json'))
 paths += list(OUT.glob('*.csv'))+list(OUT.glob('*.json'))+list(OUT.glob('*.png'))+list((OUT/'paper_materials').glob('*'))
 # Compact, auditable records. Full per-step/trip XML stays in local episode directories.
 for name in ['train','validation','test','numerical']:
  for row in pd.read_csv(OUT/f'{name}_runs.csv').itertuples():
   paths.extend(ROOT/row.path/f for f in ['result.json','event_pairs.json','contacts.xml'])
 buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(set(paths)):z.write(p,p.relative_to(ROOT))
 data=buf.getvalue();(ROOT/'Estates_Mitigation_RL.zip').write_bytes(data);return data

def notebook(payload):
 nb=nbformat.v4.new_notebook();cells=[];md=lambda s:cells.append(nbformat.v4.new_markdown_cell(s));code=lambda s:cells.append(nbformat.v4.new_code_cell(s))
 md('''# Estates mitigation reinforcement learning · v0.15

## tl;dr
A working CPU experiment: nine trained policies, four generic actions, a held-out implemented pilot, and 832 primary SUMO runs. This notebook retrains policies from saved **selected-action simulation feedback**, recomputes the holdout comparison, and executes a fresh environment step. Simulation near-miss frequency is not real-world annual crash probability.

## Context & Methods
The decision is one intervention per 15-minute traffic context: a contextual bandit (one-step RL, gamma=0). Three families—tabular, linear and neural Q—receive the same reward. A0 is unchanged, A1 is an assumed 25 mph operating response, A2 is generic curb extensions, A3 is both. H, the documented pilot, is test-only. Policy selection uses pre-installation validation only.

### Key Assumptions
Observed movement counts determine demand, not traveler choices. Speeds use frozen pre-period behavior. Generic geometry and response to 25 mph are modeling assumptions. Constant-velocity time-to-contact is a defined surrogate; it is not a field-validated near-miss label. Every scheduled traveler must finish; incomplete runs never count as safe zeros. The developer knew the report, so this is a retrospective policy holdout.
''')
 code('''import sys,os,subprocess,importlib.util,importlib.metadata,pathlib,zipfile,base64,io,json,contextlib,hashlib
packages={'numpy':'numpy','pandas':'pandas','torch':'torch','gymnasium':'gymnasium','shapely':'shapely','matplotlib':'matplotlib','sumolib':'sumolib==1.27.1','libsumo':'libsumo==1.27.1','sumo':'eclipse-sumo==1.27.1'}
missing=[p for m,p in packages.items() if importlib.util.find_spec(m) is None]
for p in ['sumolib','libsumo','eclipse-sumo']:
    try:
        if importlib.metadata.version(p)!='1.27.1':missing.append(p+'==1.27.1')
    except importlib.metadata.PackageNotFoundError:pass
if missing:subprocess.check_call([sys.executable,'-m','pip','install','-q',*sorted(set(missing))])
workspace=pathlib.Path.cwd()/'estates_mitigation_run';workspace.mkdir(exist_ok=True)
payload="'''+base64.b64encode(payload).decode()+'''"
with zipfile.ZipFile(io.BytesIO(base64.b64decode(payload))) as z:z.extractall(workspace)
os.chdir(workspace);sys.path.insert(0,str(workspace));os.environ['MPLCONFIGDIR']=str(workspace/'.mplconfig')
import numpy as np,pandas as pd
from IPython.display import display,Markdown,Image
OUT=workspace/'outputs/mitigation_rl';DATA=workspace/'data/mitigation_rl'
''')
 md('''## Data
Native quarter-hour observations remain separate from generated warmup and simulated outputs. March 2 trains, February 11 selects, May 18/20 tests. Three seeds are not three new field days. Inspect the exact reward and holdout protocol below.''')
 code('''contexts=pd.read_csv(DATA/'contexts.csv')
display(contexts.groupby('split').agg(windows=('context_id','size'),motor=('passenger','sum'),heavy=('heavy','sum'),bicycle=('bicycle','sum'),pedestrian_crossings=('pedestrian','sum')))
original_freeze=json.loads((OUT/'policy_freeze.json').read_text())
assert hashlib.sha256((OUT/'models.json').read_bytes()).hexdigest()==original_freeze['models_sha256']
assert hashlib.sha256((workspace/'mitigation_rl/protocol.md').read_bytes()).hexdigest()==original_freeze['protocol_sha256']
display(Markdown((workspace/'mitigation_rl/protocol.md').read_text()))
''')
 md('''## Train the agents
These are actual selected-action Q updates, not a fabricated ranking. Each of nine agents performs 6,000 updates by sampling cached SUMO transitions. This saves CPU time. The learner reads only train and validation files. Its checkpoint is frozen before test evaluation.''')
 code('''from mitigation_rl.learn import main as train_agents
with contextlib.redirect_stdout(io.StringIO()):train_agents()
freeze=json.loads((OUT/'policy_freeze.json').read_text())
assert not freeze['hidden_benchmark_accessed'] and not freeze['post_test_accessed']
display(pd.read_csv(OUT/'validation_agents.csv'))
print('Validation-selected champion:',freeze['champion'],'; ties use the documented deterministic rule.')
''')
 md('''## Held-out results
Evaluate the frozen models on post-installation traffic, including the pilot benchmark. The 95% intervals bootstrap entire context clusters; they exclude parameter and field-measurement uncertainty. The denominator is 96 simulated episodes per policy, not a year.''')
 code('''from mitigation_rl.evaluate import main as evaluate_agents
with contextlib.redirect_stdout(io.StringIO()):evaluate_agents()
results=json.loads((OUT/'results.json').read_text())
display(pd.read_csv(OUT/'test_policy_results.csv')[['policy','mean_reward','reward_low','reward_high','near_miss_fraction','collision_fraction','eligible']].round(3))
display(Image(filename=str(OUT/'policy_results.png')))
display(Image(filename=str(OUT/'thresholds.png')))
print('Saved charts describe the original released models. This table is recomputed from the retrained models.')
''')
 md('''## Fresh live SUMO execution
This call selects an action with the trained agent and runs matched unchanged/intervention traffic with a new seed. It returns the actual simulated reward. Browser recommendations use the same exported policy but display saved batches instead of running SUMO on a web server.''')
 code('''from mitigation_rl.environment import MitigationEnv
from mitigation_rl.learn import values
models=json.loads((OUT/'models.json').read_text())
env=MitigationEnv('test');obs,info=env.reset(seed=413,options={'simulation_seed':995317})
q=values(models[freeze['champion']],pd.DataFrame([env.context]))[0];action=int(q.argmax())
obs,reward,terminated,truncated,detail=env.step(action)
assert terminated and not truncated
assert detail['result']['complete'] and detail['baseline']['complete']
assert detail['result']['demand_sha256']==detail['baseline']['demand_sha256']
display(pd.DataFrame([{'role':'baseline',**detail['baseline']},{'role':'chosen',**detail['result']}])[['role','action','requested','arrived','near_pairs','collision_pairs','mean_motor_delay']])
print('Fresh episode reward:',reward,'; action:',action)
''')
 md('''## Implementation checks and takeaways
The finite sample supports comparison inside this simulation, not an engineering certification. The actual pilot is a package; generic curb agreement does not imply the exact consultant design was discovered. See the evidence pack for the assignment outline, factual claims, sources, code appendix pointers and unresolved roadblocks.
''')
 code('''from mitigation_rl.events import test
assert test()['passed'];verification=json.loads((OUT/'verification.json').read_text());display(verification)
display(Image(filename=str(OUT/'learning.png')))
display(Markdown((OUT/'paper_materials/Evidence_Pack.md').read_text()))
''')
 md('''## Optional full simulation rerun
The default has retrained all agents, recomputed the held-out scores and run a fresh SUMO episode. Set the flag below to run the 832 primary simulations and numerical checks again. This can take minutes to hours on CPU. There is no paid model API. Saved inputs stay native and the learner still excludes the held-out pilot.''')
 code('''RERUN_ALL=False
if RERUN_ALL:
    import shutil,time
    # Preserve the packaged cache so this branch really executes fresh simulations.
    if (OUT/'episodes').exists():shutil.move(str(OUT/'episodes'),str(OUT/f'cached_episodes_{time.time_ns()}'))
    for module,args in [('mitigation_rl.simulator',['train']),('mitigation_rl.simulator',['validation']),('mitigation_rl.learn',[]),('mitigation_rl.simulator',['test']),('mitigation_rl.checks',[]),('mitigation_rl.evaluate',[])]:
        subprocess.check_call([sys.executable,'-m',module,*args])
else:print('Complete simulation rerun disabled; the fresh environment episode above has executed.')
''')
 nb.cells=cells;nb.metadata={'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python'}};nbformat.validate(nb);nbformat.write(nb,ROOT/'Estates_Mitigation_RL.ipynb')

def main():
 results=json.loads((OUT/'results.json').read_text());verification=json.loads((OUT/'verification.json').read_text());freeze=results['frozen_selection'];p=pd.DataFrame(results['policies']).set_index('policy');champ=p.loc[freeze['champion']];base=p.loc['A0'];fixed=p.loc['best_fixed']
 finding=f"The validation-selected {freeze['champion']} scored {champ.mean_reward:.2f} on the held-out traffic, versus {base.mean_reward:.2f} for unchanged and {fixed.mean_reward:.2f} for the best fixed training action. "
 finding+=('Its paired reward improvement over unchanged excludes zero in the conditional 95% interval.' if champ.gain_low>0 else 'The conditional 95% interval does not establish an improvement over unchanged.')
 figures(results,freeze);documentation(results,verification,finding)
 models=json.loads((OUT/'models.json').read_text());c=pd.read_csv(DATA/'contexts.csv');c=c[c.split.eq('test')];runs=pd.read_csv(OUT/'scored_test_runs.csv')
 labels={**LABELS,**{n:n.split('_')[0].title()+' Q ('+n.split('_')[1]+')' for n in models},'random':'Uniform random','best_fixed':'Best fixed from training ('+freeze['best_fixed_training_action']+')'}
 payload={'results':results,'verification':verification,'finding':finding,'models':models,'contexts':c.to_dict('records'),'runs':runs[['context_id','action','seed','reward','collision','near','complete']].to_dict('records'),'labels':labels}
 (OUT/'web_data.json').write_text(json.dumps(payload,allow_nan=False));expected={name:[{'context_id':r.context_id,'q':values(m,pd.DataFrame([r._asdict()]))[0].tolist()} for r in c.itertuples(index=False)] for name,m in models.items()};(OUT/'expected_inference.json').write_text(json.dumps(expected))
 data=bundle();notebook(data)
 print(finding);print('Bundle bytes:',len(data))
if __name__=='__main__':main()
