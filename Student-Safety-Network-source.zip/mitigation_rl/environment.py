"""A runnable Gymnasium environment: step executes SUMO, not a learned risk formula."""
import json,numpy as np,pandas as pd,gymnasium as gym
from gymnasium import spaces
from .prepare import DATA,OUT,ACTIONS
from .learn import features,values
from .simulator import run
from .events import reward
class MitigationEnv(gym.Env):
 def __init__(self,split='train'):
  if split=='test' and not (OUT/'policy_freeze.json').exists():raise ValueError('Freeze policies before test access')
  c=pd.read_csv(DATA/'contexts.csv');self.contexts=c[c.split.eq(split)].reset_index(drop=True)
  self.action_space=spaces.Discrete(4);self.observation_space=spaces.Box(-np.inf,np.inf,(7,),dtype=np.float32);self.done=True
 def reset(self,*,seed=None,options=None):
  super().reset(seed=seed);options=options or {};c=self.contexts
  if 'context_id' in options:c=c[c.context_id.eq(options['context_id'])]
  if c.empty:raise ValueError('Unknown context')
  self.context=c.iloc[int(self.np_random.integers(len(c)))].to_dict();self.seed_value=int(options.get('simulation_seed',self.np_random.integers(900000,999999)));self.done=False
  return features(pd.DataFrame([self.context]))[0].astype(np.float32),{'context_id':self.context['context_id'],'simulation_seed':self.seed_value}
 def step(self,action):
  if self.done:raise RuntimeError('Reset after a terminal episode')
  if not self.action_space.contains(action):raise ValueError('Action must be 0..3')
  task=(self.context['context_id'],ACTIONS[int(action)],self.seed_value,.1);baseline=run((task[0],'A0',task[2],task[3]));result=run(task);self.done=True
  if not result['complete'] or not baseline['complete']:raise RuntimeError('Incomplete SUMO episode; invalid, not a safe zero reward')
  score=reward(result['collision'],result['near'],baseline['collision'],baseline['near'])
  return features(pd.DataFrame([self.context]))[0].astype(np.float32),float(score),True,False,{'baseline':baseline,'result':result,'context':self.context}
def live_demo():
 models=json.loads((OUT/'models.json').read_text());f=json.loads((OUT/'policy_freeze.json').read_text());name=f['champion'];model=models[name]
 env=MitigationEnv('test');obs,info=env.reset(seed=413,options={'simulation_seed':994271});q=values(model,pd.DataFrame([env.context]))[0];action=int(q.argmax());_,score,terminated,truncated,detail=env.step(action)
 answer={'agent':name,'action':ACTIONS[action],'reward':score,'terminated':terminated,'truncated':truncated,'fresh_simulation_seed':994271,**detail};(OUT/'live_demo.json').write_text(json.dumps(answer,indent=2));print(json.dumps({k:answer[k] for k in ['agent','action','reward','terminated','fresh_simulation_seed']}));return answer
if __name__=='__main__':live_demo()
