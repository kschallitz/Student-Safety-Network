"""Reveal post traffic and implemented pilot only after the policy is frozen."""
import json
import numpy as np,pandas as pd
from .prepare import DATA,OUT,ACTIONS,LABELS,sha
from .learn import scored,values
def interval(values,seed=7221):
 x=np.asarray(values,float);rng=np.random.default_rng(seed)
 b=rng.choice(x,(2000,len(x)),replace=True).mean(1)
 return np.quantile(b,[.025,.975]).tolist()
def main():
 freeze=json.loads((OUT/'policy_freeze.json').read_text());assert sha(OUT/'models.json')==freeze['models_sha256']
 models=json.loads((OUT/'models.json').read_text());d=scored('test');c=pd.read_csv(DATA/'contexts.csv');c=c[c.split.eq('test')].copy()
 # Invalid episodes stay invalid in event frequencies as well as in rewards.
 d.loc[~d.complete,['collision','near','near_pairs','reward']]=np.nan
 assert set(d.action)==set(ACTIONS+['H']);assert d.groupby(['context_id','seed']).demand_sha256.nunique().eq(1).all()
 policies={name:dict(zip(c.context_id,[ACTIONS[i] for i in values(model,c).argmax(1)])) for name,model in models.items()}
 policies.update({a:dict.fromkeys(c.context_id,a) for a in ACTIONS+['H']});policies['best_fixed']=dict.fromkeys(c.context_id,freeze['best_fixed_training_action'])
 summaries=[];allpicks=[];base=d[d.action.eq('A0')][['context_id','seed','reward']].rename(columns={'reward':'baseline_reward'})
 for name,mapping in policies.items():
  selected=d[d.action.eq(d.context_id.map(mapping))].copy();selected=selected.merge(base,on=['context_id','seed']);selected['policy']=name;allpicks.append(selected)
  delta=(selected.reward-selected.baseline_reward).groupby(selected.context_id).mean();lo,hi=interval(delta)
  bycontext=selected.groupby('context_id').agg(reward=('reward','mean'),collision=('collision','mean'),near=('near','mean'))
  rlo,rhi=interval(bycontext.reward);clo,chi=interval(bycontext.collision);nlo,nhi=interval(bycontext.near)
  eligible=bool(selected.complete.all() and (selected.mean_motor_delay-selected.base_delay).mean()<=30)
  summaries.append({'policy':name,'label':LABELS.get(name,name),'episodes':len(selected),'mean_reward':float(selected.reward.mean()),'reward_low':rlo,'reward_high':rhi,'reward_gain_vs_baseline':float(delta.mean()),'gain_low':lo,'gain_high':hi,'collision_fraction':float(selected.collision.mean()),'collision_low':clo,'collision_high':chi,'near_miss_fraction':float(selected.near.mean()),'near_low':nlo,'near_high':nhi,'mean_near_pairs':float(selected.near_pairs.mean()),'delay_increase_s':float((selected.mean_motor_delay-selected.base_delay).mean()),'incomplete':int((~selected.complete).sum()),'eligible':eligible,'curb_component_agreement':float(np.mean([v in ['A2','A3'] for v in mapping.values()])) if name in models else None})
 # Uniform random's exact expectation over the four actions, not a lucky draw.
 random_rows=d[d.action.isin(ACTIONS)].copy();random_rows['delay_increase']=random_rows.mean_motor_delay-random_rows.base_delay
 rand=random_rows.groupby(['context_id','seed']).agg(reward=('reward','mean'),collision=('collision','mean'),near=('near','mean'),complete=('complete','all'),delay_increase=('delay_increase','mean')).reset_index();by=rand.groupby('context_id').reward.mean();lo,hi=interval(by)
 summaries.append({'policy':'random','label':'Uniform random (exact expectation)','episodes':len(rand),'mean_reward':float(rand.reward.mean()),'reward_low':lo,'reward_high':hi,'collision_fraction':float(rand.collision.mean()),'near_miss_fraction':float(rand.near.mean()),'delay_increase_s':float(rand.delay_increase.mean()),'incomplete':int((~rand.complete).sum()),'eligible':bool(rand.complete.all() and rand.delay_increase.mean()<=30)})
 pd.DataFrame(summaries).to_csv(OUT/'test_policy_results.csv',index=False);pd.concat(allpicks).to_csv(OUT/'policy_test_episodes.csv',index=False);d.to_csv(OUT/'scored_test_runs.csv',index=False)
 candidate=pd.DataFrame(summaries);fixed=candidate[candidate.policy.isin(ACTIONS)&candidate.eligible].sort_values(['mean_reward','policy'],ascending=[False,True]);winner=fixed.iloc[0].policy if len(fixed) else None
 summary={'frozen_selection':freeze,'test_contexts':len(c),'repetitions_per_context':3,'test_simulations':len(d),'completed_test_simulations':int(d.complete.sum()),'all_demands_matched':True,'policies':summaries,'descriptive_best_fixed_test_action':winner,'test_was_not_used_for_training_or_selection':True,'exact_consultant_design_recovered':False,'comparison_scope':'Agreement in curb-extension component only; implemented pilot is a held-out package, not a training action.','uncertainty':'95% bootstrap intervals over observed 15-minute context clusters, conditional on simulator assumptions and two source dates. Not field crash probability.','study_scope':'Estates only; simulated motor/pedestrian-bicycle interactions.'}
 (OUT/'results.json').write_text(json.dumps(summary,indent=2));print(candidate[['policy','mean_reward','collision_fraction','near_miss_fraction','incomplete','eligible']].to_string(index=False))
 # Diagnostic thresholds never feed back into training or model selection.
 sensitivity=[]
 for name,mapping in policies.items():
  z=d[d.action.eq(d.context_id.map(mapping))]
  for threshold,column in [(1.,'near_pairs_1s'),(1.5,'near_pairs'),(2.,'near_pairs_2s')]:
   valid=z[z.complete];sensitivity.append({'policy':name,'ttc_seconds':threshold,'episode_fraction':float(valid[column].gt(0).mean()),'mean_pairs':float(valid[column].mean())})
 pd.DataFrame(sensitivity).to_csv(OUT/'threshold_sensitivity.csv',index=False)
if __name__=='__main__':main()
