"""Predeclared numerical and implementation checks, not outcome tuning."""
import json
from concurrent.futures import ProcessPoolExecutor
import pandas as pd
from .prepare import ROOT,DATA,OUT,ACTIONS,sha
from .simulator import run
from .events import test
def main():
 frozen=json.loads((OUT/'policy_freeze.json').read_text());assert sha(OUT/'models.json')==frozen['models_sha256']
 assert sha(ROOT/'mitigation_rl/protocol.md')==frozen['protocol_sha256']
 c=pd.read_csv(DATA/'contexts.csv');c=c[c.interval_start.str.startswith('2023-05-18')];c=c[c.hour.isin([7,14])]
 tasks=[(r.context_id,a,84013,step) for r in c.itertuples() for a in ACTIONS+['H'] for step in [.1,.05]]
 with ProcessPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,tasks))
 d=pd.DataFrame(results);d.to_csv(OUT/'numerical_runs.csv',index=False)
 p=d[d.step.eq(.1)].merge(d[d.step.eq(.05)],on=['context_id','action','seed'],suffixes=('_coarse','_fine'))
 p['event_changed']=(p.collision_coarse!=p.collision_fine)|(p.near_coarse!=p.near_fine)
 p.to_csv(OUT/'numerical_check.csv',index=False)
 receipt={**test(),'fine_step_runs':len(d),'fine_runs_completed':int(d.complete.sum()),'changed_event_classifications':int(p.event_changed.sum()),'checked_context_action_pairs':len(p),'protocol_unchanged':True,'models_unchanged':True,'training_actions':frozen['training_only_actions'],'consultant_geometry_used_to_fit_policy':False,'post_outcomes_used_to_fit_policy':False}
 (OUT/'verification.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
if __name__=='__main__':main()
