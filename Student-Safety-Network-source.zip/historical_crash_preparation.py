"""Reconcile the historical public extract without rewriting the recent snapshot."""
from pathlib import Path
import json,hashlib
import pandas as pd

def prepare_historical(root):
    root=Path(root);raw=root/'data/historical_crashes/raw'
    manifest=json.loads((raw/'download_manifest.json').read_text())
    for item in manifest:
        assert hashlib.sha256((raw/item['file']).read_bytes()).hexdigest()==item['sha256']
    rows=[]
    for year in range(2016,2020):
        if year==2019:
            receipt=json.loads((raw/'download_csv_2019_receipt.json').read_text())
            file=raw/'pedbike_crashes_2019_from_download.csv'
            assert hashlib.sha256(file.read_bytes()).hexdigest()==receipt['extract_sha256']
            d=pd.read_csv(file,dtype=str)
            assert len(d)==receipt['extracted_rows']
            d['source_method']='Official CSV; SQL index incomplete at retrieval'
        else:
            d=pd.DataFrame(json.loads((raw/f'pedbike_crashes_{year}.json').read_text())['result']['records'])
            assert len(d)==int(json.loads((raw/f'pedbike_count_{year}.json').read_text())['result']['records'][0]['n'])
            d['source_method']='CCRS SQL with count reconciliation'
        d['source_year']=year;rows.append(d)
    older=pd.concat(rows,ignore_index=True)
    older['case_id']=older['Collision Id'].astype(str).str.strip()
    older['date']=pd.to_datetime(older['Crash Date Time'],format='mixed',errors='raise')
    assert older.date.dt.year.eq(older.source_year).all()
    assert not older.case_id.duplicated().any()
    assert older.IsDeleted.str.lower().eq('false').all()
    for c in ['Latitude','Longitude','NumberInjured','NumberKilled']:
        older[c]=pd.to_numeric(older[c],errors='coerce')
    older['valid_coordinates']=older.Latitude.between(37,38.3)&older.Longitude.between(-123,-120.8)
    recent=pd.read_csv(root/'school_forecast_output/enriched_public_crashes.csv',dtype={'case_id':str},low_memory=False)
    recent['date']=pd.to_datetime(recent.date)
    recent['source_method']='Frozen prior 2020-2025 CCRS extract and road-reference enrichment'
    combined=pd.concat([older,recent],ignore_index=True)
    assert not combined.case_id.duplicated().any()
    combined['source_year']=combined.date.dt.year
    # Counts refer to matching public records, not independently verified reporting completeness.
    audit=combined.groupby(['source_year','City Name']).agg(records=('case_id','size'),usable_coordinates=('valid_coordinates','sum'))
    out=root/'historical_crash_output';out.mkdir(exist_ok=True)
    older.to_csv(out/'regional_pedbike_2016_2019.csv',index=False)
    combined.to_csv(out/'regional_pedbike_2016_2025.csv.gz',index=False,compression='gzip')
    audit.to_csv(out/'city_year_coverage.csv')
    summary={'older_cases':len(older),'combined_cases':len(combined),'older_livermore_cases':int(older['City Name'].eq('Livermore').sum()),
        'earliest_compatible_public_year':2016,'latest_full_target_year':2025,
        '2019_sql_quarantined':True,'2019_csv_unique_cases':int(receipt['unique_cases']),
        'coverage_verified':False,'older_than_2016':'Official older aggregate reports and 2015 East Avenue corridor study located; no compatible citywide case extract verified without account.'}
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    return combined,audit,summary
